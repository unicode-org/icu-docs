package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_UTF32BE extends UConverterSharedData {

	public UConverterSharedData_UTF32BE(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_UTF32BE()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		T_UConverter_toUnicode_UTF32_BE(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		T_UConverter_fromUnicode_UTF32_BE(args, pErrorCode);
	}
	
	final static int UCNV_NEED_TO_WRITE_BOM = 1;
	
	/* UTF-32BE ----------------------------------------------------------------- */
	
	//static void T_UConverter_toUnicode_UTF32_BE(UConverterToUnicodeArgs * args, UErrorCode * err)
	public final void T_UConverter_toUnicode_UTF32_BE(UConverterToUnicodeArgs args, int[] err)
	{
	    byte[] mySourceArray = args.sourceArray;
	    int mySourceArrayIndex = args.sourceBegin;
	    char[] myTargetArray = args.targetArray;
	    int myTargetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    byte[] toUBytesArray = args.converter.toUBytesArray;
	    int ch, i;
	
	donefornow:
			{
	    /* UTF-8 returns here for only non-offset, this needs to change.*/
	    if (args.converter.toUnicodeStatus != 0 && myTargetArrayIndex < targetLimit) {
	        i = args.converter.toULength;       /* restore # of bytes consumed */
	
	        ch = (int)(args.converter.toUnicodeStatus - 1);/*Stores the previously calculated ch from a previous call*/
	        args.converter.toUnicodeStatus = 0;
					//agljport:comment copied morebytes block here from inside loop below
	//morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch = (ch << 8) | ((byte)(mySourceArray[mySourceArrayIndex]) & UConverterUtility.UNSIGNED_BYTE_MASK);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break donefornow;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break donefornow;
	        }
	    }
	
	    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit) {
	        i = 0;
	        ch = 0;
	//agljport:delete morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch = (ch << 8) | ((byte)(mySourceArray[mySourceArrayIndex]) & UConverterUtility.UNSIGNED_BYTE_MASK);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break;
	        }
	    }
					}
	
	//agljport:delete donefornow:
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0])) {
	        /* End of target buffer */
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
	    args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
	    args.sourceBegin = mySourceArrayIndex;
	}
	
	//static void T_UConverter_fromUnicode_UTF32_BE(UConverterFromUnicodeArgs * args, UErrorCode * err)
	public final void T_UConverter_fromUnicode_UTF32_BE(UConverterFromUnicodeArgs args, int[] err)
	{
	    char[] mySourceArray = args.sourceArray;
		int mySourceArrayIndex = args.sourceBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    long ch, ch2;
	    int indexToWrite;
	    byte temp[/*sizeof(uint32_t)*/] = new byte[4];
	
	    if(mySourceArrayIndex >= sourceLimit) {
	        /* no input, nothing to do */
	        return;
	    }

	    /* write the BOM if necessary */
	    if(args.converter.fromUnicodeStatus==UCNV_NEED_TO_WRITE_BOM) {
	        byte[] bom={ 0, 0, (byte)0xfe, (byte)0xff };
	        int[] targetBegin = {args.targetBegin};
			int[] offsetsBegin = {args.offsetsBegin};
			UConverterUtility.ucnv_fromUWriteBytes(args.converter,
	                             bom, 0, 4,
	                             args.targetArray, targetBegin, args.targetLimit,
	                             args.offsetsArray, offsetsBegin, -1,
	                             err);
	        args.targetBegin = targetBegin[0];
	        args.offsetsBegin = offsetsBegin[0];	        
	        args.converter.fromUnicodeStatus=0;
	    }
	    
	    byte[] myTargetArray = args.targetArray;
		int myTargetArrayIndex = args.targetBegin;
	    temp[0] = 0;
	
		boolean doloop = true;
	    if (args.converter.fromUChar32 != 0) {
	        ch = args.converter.fromUChar32;
	        args.converter.fromUChar32 = 0;
	        //lowsurogate:
            if (mySourceArrayIndex < sourceLimit) {
                ch2 = mySourceArray[mySourceArrayIndex];
                if (UConverterUTF.U_IS_TRAIL((int)ch2)) {
                    ch = ((ch - SURROGATE_HIGH_START) << HALF_SHIFT) + ch2 + SURROGATE_LOW_BASE;
                    mySourceArrayIndex++;
                }
                else {
                    /* this is an unmatched trail code unit (2nd surrogate) */
                    /* callback(illegal) */
                    args.converter.fromUChar32 = (int)ch;
                    err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
											doloop = false;
                }
            }
            else {
                /* ran out of source */
                args.converter.fromUChar32 = (int)ch;
                if (args.flush) {
                    /* this is an unmatched trail code unit (2nd surrogate) */
                    /* callback(illegal) */
                    err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
                }
									doloop = false;
            }
			/*agljport:delete
	            }
	            else {
	                args->converter->fromUChar32 = ch;
	                *err = U_ILLEGAL_CHAR_FOUND;
	                break;
	            }
	        }
					*/
	
	        /* We cannot get any larger than 10FFFF because we are coming from UTF-16 */
	        temp[1] = (byte) (ch >>> 16 & 0x1F);
	        temp[2] = (byte) (ch >>> 8);  /* unsigned cast implicitly does (ch & FF) */
	        temp[3] = (byte) (ch);       /* unsigned cast implicitly does (ch & FF) */
	
	        for (indexToWrite = 0; indexToWrite <= 3; indexToWrite++) {
	            if (myTargetArrayIndex < targetLimit) {
	                myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
	            }
	            else {
	                args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = temp[indexToWrite];
	                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            }
	        }
	    }
	
		if(doloop) {
		    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit) {
		        ch = mySourceArray[mySourceArrayIndex++];
		
		        if (UConverterUTF.U_IS_SURROGATE((int)ch)) {
		            if (UConverterUTF.U_IS_LEAD((int)ch)) {
	            		//lowsurogate:
		                if (mySourceArrayIndex < sourceLimit) {
		                    ch2 = mySourceArray[mySourceArrayIndex];
		                    if (UConverterUTF.U_IS_TRAIL((int)ch2)) {
		                        ch = ((ch - SURROGATE_HIGH_START) << HALF_SHIFT) + ch2 + SURROGATE_LOW_BASE;
		                        mySourceArrayIndex++;
		                    }
		                    else {
		                        /* this is an unmatched trail code unit (2nd surrogate) */
		                        /* callback(illegal) */
		                        args.converter.fromUChar32 = (int)ch;
		                        err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                        break;
		                    }
		                }
		                else {
		                    /* ran out of source */
		                    args.converter.fromUChar32 = (int)ch;
		                    if (args.flush) {
		                        /* this is an unmatched trail code unit (2nd surrogate) */
		                        /* callback(illegal) */
		                        err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                    }
		                    break;
		                }
		            }
		            else {
		                args.converter.fromUChar32 = (int)ch;
		                err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                break;
		            }
		        }
		
		        /* We cannot get any larger than 10FFFF because we are coming from UTF-16 */
		        temp[1] = (byte) (ch >>> 16 & 0x1F);
		        temp[2] = (byte) (ch >>> 8);  /* unsigned cast implicitly does (ch & FF) */
		        temp[3] = (byte) (ch);       /* unsigned cast implicitly does (ch & FF) */
		
		        for (indexToWrite = 0; indexToWrite <= 3; indexToWrite++) {
		            if (myTargetArrayIndex < targetLimit) {
		                myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
		            }
		            else {
		                args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = temp[indexToWrite];
		                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
		            }
		        }
		    }
		}
	
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0])) {
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
		args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
		args.sourceBegin = mySourceArrayIndex;
	}
	
	/*
	static const UConverterImpl _UTF32BEImpl = {
	    UCNV_UTF32_BigEndian,
	
	    NULL,
	    NULL,
	
	    NULL,
	    NULL,
	    NULL,
	
	    T_UConverter_toUnicode_UTF32_BE,
	    T_UConverter_toUnicode_UTF32_BE_OFFSET_LOGIC,
	    T_UConverter_fromUnicode_UTF32_BE,
	    T_UConverter_fromUnicode_UTF32_BE_OFFSET_LOGIC,
	    T_UConverter_getNextUChar_UTF32_BE,
	
	    NULL,
	    NULL,
	    NULL,
	    NULL,
	    ucnv_getNonSurrogateUnicodeSet
	};
	
	static const UConverterStaticData _UTF32BEStaticData = {
	    sizeof(UConverterStaticData),
	    "UTF-32BE",
	    1232,
	    UCNV_IBM, UCNV_UTF32_BigEndian, 4, 4,
	    { 0, 0, 0xff, 0xfd }, 4, FALSE, FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	
	const UConverterSharedData _UTF32BEData = {
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_UTF32BEStaticData, FALSE, &_UTF32BEImpl, 
	    0
	};
	*/
	
	public static UConverterStaticData _UTF32BEStaticData;
	public static UConverterSharedData_UTF32BE _UTF32BEData;
	static 
	{
	
		/* The 1232 CCSID refers to any version of Unicode with any endianess of UTF-32 */
		_UTF32BEStaticData = new UConverterStaticData(
		    UConverterStaticData.sizeofUConverterStaticData,
		    "UTF-32BE",
		    1232,
		    (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_UTF32_BigEndian, (byte)4, (byte)4,
		    new byte[]{ 0, 0, (byte)0xff, (byte)0xfd }, (byte)4, (byte)0, (byte)0,
		    (short)0,
		    (byte)0,
		    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
		);
		
		_UTF32BEData = new UConverterSharedData_UTF32BE(
		    sizeofUConverterSharedData, ~0,
		    /*NULL, NULL,*/ _UTF32BEStaticData, false, /*&_UTF32BEImpl,*/
		    0
		);
	}

}
