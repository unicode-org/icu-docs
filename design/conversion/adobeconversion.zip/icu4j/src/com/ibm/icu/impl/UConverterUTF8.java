package com.ibm.icu.impl;

public final class UConverterUTF8 {

/* single-code point definitions -------------------------------------------- */

/**
 * Does this code unit (byte) encode a code point by itself (US-ASCII 0..0x7f)?
 * @param c 8-bit code unit (byte)
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U8_IS_SINGLE(byte c) {return (((c)&0x80)==0);}

/**
 * Is this code unit (byte) a UTF-8 lead byte?
 * @param c 8-bit code unit (byte)
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U8_IS_LEAD(byte c) {return ((((c)-0xc0) & UConverterUtility.UNSIGNED_BYTE_MASK)<0x3e);}

/**
 * Is this code unit (byte) a UTF-8 trail byte?
 * @param c 8-bit code unit (byte)
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U8_IS_TRAIL(byte c) {return (((c)&0xc0)==0x80);}

/**
 * How many code units (bytes) are used for the UTF-8 encoding
 * of this Unicode code point?
 * @param c 32-bit code point
 * @return 1..4, or 0 if c is a surrogate or not a Unicode code point
 * @stable ICU 2.4
 */
/*agljport:change
#define U8_LENGTH(c) \
    ((uint32_t)(c)<=0x7f ? 1 : \
        ((uint32_t)(c)<=0x7ff ? 2 : \
            ((uint32_t)(c)<=0xd7ff ? 3 : \
                ((uint32_t)(c)<=0xdfff || (uint32_t)(c)>0x10ffff ? 0 : \
                    ((uint32_t)(c)<=0xffff ? 3 : 4)\
                ) \
            ) \
        ) \
    )
*/

public static final int U8_LENGTH(int c)
{
	long uc = c & UConverterUtility.UNSIGNED_INT_MASK;
	return
    (uc<=0x7f ? 1 : 
        (uc<=0x7ff ? 2 : 
            (uc<=0xd7ff ? 3 : 
                (uc<=0xdfff || uc>0x10ffff ? 0 : 
                    (uc<=0xffff ? 3 : 4)
                ) 
            ) 
        ) 
    );
}

/**
 * The maximum number of UTF-8 code units (bytes) per Unicode code point (U+0000..U+10ffff).
 * @return 4
 * @stable ICU 2.4
 */
public static final int U8_MAX_LENGTH  = 4;

}

