package com.ibm.icu.dev.test.converters.tool;

/**
 * To provide the test data class for conversion testing from code page to Unicode,
 * and from Unicode back to code page which is not necessary a round trip.
 * @see 		TestDataFromUToU
 * @see 		TestCase
 * @see 		TestClass
 * @author Niti Hantaweepant 
 */
public class TestDataToUFromU {

	private byte[] cpIn = null;
	private String u = null;
	private byte[] cpOut = null;
	private String exception = null;
	
	/**
	* Constructor to initialize test data
	* @param 	cpIn Code page as input
	* @param 	u Unicode
	* @param 	cpOut Code page as output
	* @param 	exception Expected exception 
    */	
	public TestDataToUFromU(byte[] cpIn, String u, byte[] cpOut, String exception){
		this.cpIn = cpIn;
		this.u = u;
		this.cpOut = cpOut;
		this.exception = exception;		
	}
	
	/**
	* Get a value of code page as input
	* @return byte array of code page
    */
	public byte[] getCPIn(){
		return cpIn;
	}
	
	/**
	* Get a value of Unicode
	* @return Unicode String
    */	
	public String getU(){
		return u;
	}
	
	/**
	* Get a value of code page as output
	* @return byte array of code page
    */	
	public byte[] getCPOut(){
		return cpOut;
	}
	
	/**
	* Get the expected exception name that should occur with this test data, otherwise null is returned
	* @return Exception name
    */	
	public String getException(){
		return exception;
	}
}
