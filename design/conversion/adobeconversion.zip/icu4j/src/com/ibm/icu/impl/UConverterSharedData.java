package com.ibm.icu.impl;

import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.InputStream;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;
import com.ibm.icu.text.UnicodeSet;

/*
 * Defines the UConverterSharedData struct,
 * the immutable, shared part of UConverter.
 */
public abstract class UConverterSharedData {
    //uint32_t structSize;            /* Size of this structure */
	public int structSize;            /* Size of this structure */
    //uint32_t referenceCounter;      /* used to count number of clients, 0xffffffff for static SharedData */
	public int referenceCounter;      /* used to count number of clients, 0xffffffff for static SharedData */

	//agljport:todo const void *dataMemory;         /* from udata_openChoice() - for cleanup */
	//agljport:todo void *table;                    /* Unused. This used to be a UConverterTable - Pointer to conversion data - see mbcs below */

    //const UConverterStaticData *staticData; /* pointer to the static (non changing) data. */
	public UConverterStaticData staticData; /* pointer to the static (non changing) data. */

    //UBool                sharedDataCached;   /* TRUE:  shared data is in cache, don't destroy on ucnv_close() if 0 ref.  FALSE: shared data isn't in the cache, do attempt to clean it up if the ref is 0 */
	public boolean                sharedDataCached;   /* TRUE:  shared data is in cache, don't destroy on ucnv_close() if 0 ref.  FALSE: shared data isn't in the cache, do attempt to clean it up if the ref is 0 */
	/*UBool               staticDataOwned;   TRUE if static data owned by shared data & should be freed with it, NEVER true for udata() loaded statics. This ignored variable was removed to make space for sharedDataCached.   */

    //const UConverterImpl *impl;     /* vtable-style struct of mostly function pointers */
	//public UConverterImpl impl;     /* vtable-style struct of mostly function pointers */

	/*initial values of some members of the mutable part of object */
    //uint32_t toUnicodeStatus;
	public long toUnicodeStatus;

	/*
	 * Shared data structures currently come in two flavors:
	 * - readonly for built-in algorithmic converters
	 * - allocated for MBCS, with a pointer to an allocated UConverterTable
	 *   which always has a UConverterMBCSTable
	 *
	 * To eliminate one allocation, I am making the UConverterMBCSTable
	 * a member of the shared data. It is the last member so that static
	 * definitions of UConverterSharedData work as before.
	 * The table field above also remains to avoid updating all static
	 * definitions, but is now unused.
	 *
	 * markus 2003-nov-07
	 */
	public UConverterMBCSTable mbcs;

	public UConverterSharedData()
	{
		mbcs = new UConverterMBCSTable();
	}
	
	public UConverterSharedData(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		this();
		structSize = structSize_;
		referenceCounter = referenceCounter_;
		staticData = staticData_;
		sharedDataCached = sharedDataCached_;
		//impl = impl_;
		toUnicodeStatus = toUnicodeStatus_;
	}

	/**
	 * UConverterImpl contains all the data and functions for a converter type.
	 * Its function pointers work much like a C++ vtable.
	 * Many converter types need to define only a subset of the functions;
	 * when a function pointer is NULL, then a default action will be performed.
	 *
	 * Every converter type must implement toUnicode, fromUnicode, and getNextUChar,
	 * otherwise the converter may crash.
	 * Every converter type that has variable-length codepage sequences should
	 * also implement toUnicodeWithOffsets and fromUnicodeWithOffsets for
	 * correct offset handling.
	 * All other functions may or may not be implemented - it depends only on
	 * whether the converter type needs them.
	 *
	 * When open() fails, then close() will be called, if present.
	 */
	//public class UConverterImpl {
	    //UConverterType type;
	    //UConverterToUnicode toUnicode;
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
	}
	
	public final void toUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		doToUnicode(args, pErrorCode);
	}
	
	//UConverterFromUnicode fromUnicode;
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
	}
	
	public final void fromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		doFromUnicode(args, pErrorCode);
	}
	
	protected int doGetNextUChar(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		return 0;
	}
	
	//UConverterGetNextUChar getNextUChar;
	public final int getNextUChar(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		return doGetNextUChar(args, pErrorCode);
	}
	
	//public interface UConverterImplLoadable extends UConverterImpl
	protected void doLoad(UConverterLoadArgs pArgs, /*short[] raw,*/ int[] pErrorCode)
	{
	}
	
	//UConverterLoad load;
	public final void load(UConverterLoadArgs pArgs, /*short[] raw,*/ int[] pErrorCode)
	{
		doLoad(pArgs, /*raw,*/ pErrorCode);
	}
	
	protected void doUnload()
	{
	}

	//UConverterUnload unload;
	public final void unload()
	{
		doUnload();
	}

	//public interface UConverterImplOpenable extends UConverterImpl
	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
	}
    
	//UConverterOpen open;
	public final void open(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		doOpen(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doClose(UConverter cnv)
	{
	}
	
    //UConverterClose close;
	public final void close(UConverter cnv)
	{
		doClose(cnv);
	}
	
	protected void doReset(UConverter cnv, int choice)
	{
	}
	
	//typedef void (*UConverterReset) (UConverter *cnv, UConverterResetChoice choice);
	//UConverterReset reset;
	public final void reset(UConverter cnv, int choice)
	{
		doReset(cnv, choice);
	}

	//public interface UConverterImplVariableLength extends UConverterImpl
	protected void doToUnicodeWithOffsets(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
	}
	
    //UConverterToUnicode toUnicodeWithOffsets;
	public final void toUnicodeWithOffsets(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		doToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicodeWithOffsets(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
	}
	
    //UConverterFromUnicode fromUnicodeWithOffsets;
	public final void fromUnicodeWithOffsets(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		doFromUnicodeWithOffsets(args, pErrorCode);
	}

	//public interface UConverterImplMisc extends UConverterImpl
	protected void doGetStarters(UConverter converter, boolean starters[], int[] pErrorCode)
	{
	}
	
    //UConverterGetStarters getStarters;
	public final void getStarters(UConverter converter, boolean starters[], int[] pErrorCode)
	{
		doGetStarters(converter, starters, pErrorCode);
	}
	
	protected String doGetName(UConverter cnv)
	{
		return "";
	}
	
    //UConverterGetName getName;
	public final String getName(UConverter cnv)
	{
		return doGetName(cnv);
	}
	
	protected void doWriteSub(UConverterFromUnicodeArgs pArgs, long offsetIndex, int[] pErrorCode)
	{
	}
	
	//UConverterWriteSub writeSub;
	public final void writeSub(UConverterFromUnicodeArgs pArgs, long offsetIndex, int[] pErrorCode)
	{
		doWriteSub(pArgs, offsetIndex, pErrorCode);
	}
	
	protected UConverter doSafeClone(UConverter cnv, byte[] stackBuffer, int[] pBufferSize, int[] status)
	{
		return new UConverter();
	}

    //UConverterSafeClone safeClone;
	public final UConverter  safeClone(UConverter cnv, byte[] stackBuffer, int[] pBufferSize, int[] status)
	{
		return doSafeClone(cnv, stackBuffer, pBufferSize, status);
	}
	
	protected void doGetUnicodeSet(UConverter cnv, UnicodeSet /*USetAdder*/ sa, int /*UConverterUnicodeSet*/ which, int[] pErrorCode)
	{
	}
	
    //UConverterGetUnicodeSet getUnicodeSet;
	public final void getUnicodeSet(UConverter cnv, UnicodeSet /*USetAdder*/ sa, int /*UConverterUnicodeSet*/ which, int[] pErrorCode)
	{
		doGetUnicodeSet(cnv, sa, which, pErrorCode);
	}

	//}

	static final String DATA_TYPE = "cnv";
	private static final int CNV_DATA_BUFFER_SIZE = 25000;
	public static final int sizeofUConverterSharedData = 100;
	
	//static UDataMemoryIsAcceptable isCnvAcceptable;

	/**
	 * Load a non-algorithmic converter.
	 * If pkg==NULL, then this function must be called inside umtx_lock(&cnvCacheMutex).
	 */
	// UConverterSharedData * ucnv_load(UConverterLoadArgs *pArgs, UErrorCode *err)
	public static final UConverterSharedData ucnv_load(UConverterLoadArgs pArgs, int[] err)
	{
	    UConverterSharedData mySharedConverterData = null;
	
	    if(err == null || ErrorCode.isFailure(err[0])) {
	        return null;
	    }
	
	    if(pArgs.pkg != null && pArgs.pkg.length() != 0) {
	        /* application-provided converters are not currently cached */
	        return UConverterSharedData.createConverterFromFile(pArgs, err);
	    }
	
	    //agljport:fix mySharedConverterData = ucnv_getSharedConverterData(pArgs.name);
	    if (mySharedConverterData == null)
	    {
	        /*Not cached, we need to stream it in from file */
	        mySharedConverterData = UConverterSharedData.createConverterFromFile(pArgs, err);
	        if (ErrorCode.isFailure(err[0]) || (mySharedConverterData == null))
	        {
	            return null;
	        }
	        else
	        {
	            /* share it with other library clients */
	            //agljport:fix ucnv_shareConverterData(mySharedConverterData);
	        }
	    }
	    else
	    {
	        /* The data for this converter was already in the cache.            */
	        /* Update the reference counter on the shared data: one more client */
	        mySharedConverterData.referenceCounter++;
	    }
	
	    return mySharedConverterData;
	}
	
	/*Takes an alias name gets an actual converter file name
	 *goes to disk and opens it.
	 *allocates the memory and returns a new UConverter object
	 */
	//static UConverterSharedData *createConverterFromFile(UConverterLoadArgs *pArgs, UErrorCode * err)
	public static final UConverterSharedData createConverterFromFile(UConverterLoadArgs pArgs, int[] err)
	{
	    UDataMemory data = null;
	    UConverterSharedData sharedData = null;
	
	    //agljport:todo UTRACE_ENTRY_OC(UTRACE_UCNV_LOAD);
	
	    if (err == null || ErrorCode.isFailure(err[0])) {
	        //agljport:todo UTRACE_EXIT_STATUS(*err);
	        return null;
	    }
	
	    //agljport:todo UTRACE_DATA2(UTRACE_OPEN_CLOSE, "load converter %s from package %s", pArgs->name, pArgs->pkg);
	
	    //agljport:fix data = udata_openChoice(pArgs.pkgArray, DATA_TYPE.getBytes(), pArgs.name, isCnvAcceptable, null, err);
	    if(ErrorCode.isFailure(err[0]))
	    {
	        //agljport:todo UTRACE_EXIT_STATUS(*err);
	        return null;
	    }
	
	    sharedData = ucnv_data_unFlattenClone(pArgs, data, err);
	    if(ErrorCode.isFailure(err[0]))
	    {
	        //agljport:fix udata_close(data);
	        //agljport:todo UTRACE_EXIT_STATUS(*err);
	        return null;
	    }
	
	    /*
	     * TODO Store pkg in a field in the shared data so that delta-only converters
	     * can load base converters from the same package.
	     * If the pkg name is longer than the field, then either do not load the converter
	     * in the first place, or just set the pkg field to "".
	     */
	
	    return sharedData;
	}

	UConverterDataReader dataReader;
	
	/**
	 * Un flatten shared data from a UDATA..
	 */
	//static UConverterSharedData* ucnv_data_unFlattenClone(UConverterLoadArgs *pArgs, UDataMemory *pData, UErrorCode *status)
	static final UConverterSharedData ucnv_data_unFlattenClone(UConverterLoadArgs pArgs, UDataMemory pData, int[] status)
	{
	    /* UDataInfo info; -- necessary only if some converters have different formatVersion */
	    //agljport:fix const uint8_t *raw = (const uint8_t *)udata_getMemory(pData);
			//agljport:fix const UConverterStaticData *source = (const UConverterStaticData *) raw;
		UConverterStaticData source = new UConverterStaticData();
		UConverterDataReader dr = null;
		try {
			InputStream i = ICUData.getRequiredStream(ICUResourceBundle.ICU_BUNDLE + "/" + pArgs.name + "." + DATA_TYPE);
			BufferedInputStream b = new BufferedInputStream(i, CNV_DATA_BUFFER_SIZE);
			UConverterDataReader reader = new UConverterDataReader(b);
			reader.readStaticData(source);
			dr = reader;
		}
		catch(IOException e) {
			System.err.println("Caught IOException: " + e.getMessage());
			status[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
		}
		catch(Exception e) {
			status[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
			return null;
		}
	
	    UConverterSharedData data = null;
	    int type = source.conversionType;
	
	    if(ErrorCode.isFailure(status[0]))
	        return null;
	
	    if( type >= UConverterType.UCNV_NUMBER_OF_SUPPORTED_CONVERTER_TYPES || /*converterData[type] == null || converterData[type].referenceCounter != 1 ||*/ source.structSize != sizeofUConverterSharedData) 
	    {
	        status[0] = ErrorCode.U_INVALID_TABLE_FORMAT;
	        return null;
	    }
	
		/*agljport:change
	    if(data == null) {
	        status[0] = UErrorCode.U_MEMORY_ALLOCATION_ERROR;
	        return null;
	    }
		*/
	
	    /* copy initial values from the static structure for this type */
	    //UConverterUtility.uprv_memcpy(data, converterData[type], sizeof(UConverterSharedData));

		switch(type) {
		case UConverterType.UCNV_MBCS:
			data = new UConverterSharedData_MBCS(dr);
			break;
		}

		//#if 0 /* made UConverterMBCSTable part of UConverterSharedData -- markus 20031107 */
		    /*
		     * It would be much more efficient if the table were a direct member, not a pointer.
		     * However, that would add to the size of all UConverterSharedData objects
		     * even if they do not use this table (especially algorithmic ones).
		     * If this changes, then the static templates from converterData[type]
		     * need more entries.
		     *
		     * In principle, it would be cleaner if the load() function below
		     * allocated the table.
		     */
		/*
		    data->table = (UConverterTable *)uprv_malloc(sizeof(UConverterTable));
		    if(data->table == NULL) {
		        uprv_free(data);
		        *status = U_MEMORY_ALLOCATION_ERROR;
		        return NULL;
		    }
		    uprv_memset(data->table, 0, sizeof(UConverterTable));
				*/
		//#endif
	
	    data.staticData = source;
	
	    data.sharedDataCached = false;
	
	    /* fill in fields from the loaded data */
	    //agljport:fix data.dataMemory = (void*)pData; /* for future use */
	
	    //agljport:fix if(data.impl.load != null) 
		{
	        data.load(pArgs, /*raw + source.structSize,*/ status);
	        if(ErrorCode.isFailure(status[0])) {
	            //uprv_free(data.table);
	            //uprv_free(data);
	            return null;
	        }
	    }
	    return data;
	}

	/*returns a converter type from a string
	 */
	// static const UConverterSharedData * getAlgorithmicTypeFromName(const char *realName)
	public static final UConverterSharedData getAlgorithmicTypeFromName(String realName)
	{
	    long mid, start, limit;
	    long lastMid;
	    int result;
	    StringBuffer strippedName = new StringBuffer(UConverterConstants.UCNV_MAX_CONVERTER_NAME_LENGTH);
	
	    /* Lower case and remove ignoreable characters. */
	    UConverterAlias.ucnv_io_stripForCompare(strippedName, realName);
	
	    /* do a binary search for the alias */
	    start = 0;
	    limit = cnvNameType.length;
	    mid = limit;
	    lastMid = UMachine.UINT32_MAX;
	
	    for (;;) {
	        mid = (long)((start + limit) / 2);
	        if (lastMid == mid) {   /* Have we moved? */
	            break;  /* We haven't moved, and it wasn't found. */
	        }
	        lastMid = mid;
	        result = strippedName.substring(0).compareTo(cnvNameType[(int)mid].name);
	
	        if (result < 0) {
	            limit = mid;
	        } else if (result > 0) {
	            start = mid;
	        } else {
	            return converterData[cnvNameType[(int)mid].type];
	        }
	    }
	
	    return null;
	}

	/**
	 * Fallbacks to Unicode are stored outside the normal state table and code point structures
	 * in a vector of items of this type. They are sorted by offset.
	 */
	public final class _MBCSToUFallback {
	    int offset;
	    int codePoint;
	}
	
	/**
	 * This is the MBCS part of the UConverterTable union (a runtime data structure).
	 * It keeps all the per-converter data and points into the loaded mapping tables.
	 */
	public final class UConverterMBCSTable {
	    /* toUnicode */
	    short countStates;
			byte dbcsOnlyState;
			boolean stateTableOwned;
	    int countToUFallbacks;
	
	    int stateTable[/*countStates*/][/*256*/];
	    int swapLFNLStateTable[/*countStates*/][/*256*/]; /* for swaplfnl */
	    char unicodeCodeUnits[/*countUnicodeResults*/];
	    _MBCSToUFallback toUFallbacks[/*countToUFallbacks*/];
	
	    /* fromUnicode */
	    char fromUnicodeTable[];
	    byte fromUnicodeBytes[];
	    byte swapLFNLFromUnicodeBytes[]; /* for swaplfnl */
	    int fromUBytesLength;
	    short outputType, unicodeMask;
	
	    /* converter name for swaplfnl */
	    String swapLFNLName;
	
	    /* extension data */
	    UConverterSharedData baseSharedData;
	    //int extIndexes[];
		ByteBuffer extIndexes; // create int[] view etc. as needed

		UConverterMBCSTable()
		{
		}

		UConverterMBCSTable(UConverterMBCSTable t)
		{
			countStates = t.countStates;
			dbcsOnlyState = t.dbcsOnlyState;
			stateTableOwned = t.stateTableOwned;
			countToUFallbacks = t.countToUFallbacks;
			stateTable = t.stateTable;
			swapLFNLStateTable = t.swapLFNLStateTable;
			unicodeCodeUnits = t.unicodeCodeUnits;
			toUFallbacks = t.toUFallbacks;
			fromUnicodeTable = t.fromUnicodeTable;
			fromUnicodeBytes = t.fromUnicodeBytes;
			swapLFNLFromUnicodeBytes = t.swapLFNLFromUnicodeBytes;
			fromUBytesLength = t.fromUBytesLength;
			outputType = t.outputType;
			unicodeMask = t.unicodeMask;
			swapLFNLName = t.swapLFNLName;
			baseSharedData = t.baseSharedData;
			extIndexes = t.extIndexes;
		}			
	}

	/**
	 * MBCS data header. See data format description above.
	 */
	public final class _MBCSHeader {
	    byte version[/*U_MAX_VERSION_LENGTH*/];
	    int countStates, countToUFallbacks, offsetToUCodeUnits, offsetFromUTable, offsetFromUBytes;
		int flags;
		int fromUBytesLength;

		public _MBCSHeader()
		{
			version = new byte[UVersion.U_MAX_VERSION_LENGTH];
		}
	}

	/**
	 * Enum for specifying basic types of converters
	 * @see ucnv_getType
	 * @stable ICU 2.0
	 */
	public static final class UConverterType {
	    public static final int UCNV_UNSUPPORTED_CONVERTER = -1;
	    public static final int UCNV_SBCS = 0;
	    public static final int UCNV_DBCS = 1;
	    public static final int UCNV_MBCS = 2;
	    public static final int UCNV_LATIN_1 = 3;
	    public static final int UCNV_UTF8 = 4;
	    public static final int UCNV_UTF16_BigEndian = 5;
	    public static final int UCNV_UTF16_LittleEndian = 6;
	    public static final int UCNV_UTF32_BigEndian = 7;
	    public static final int UCNV_UTF32_LittleEndian = 8;
	    public static final int UCNV_EBCDIC_STATEFUL = 9;
	    public static final int UCNV_ISO_2022 = 10;
	
	    public static final int UCNV_LMBCS_1 = 11;
	    public static final int UCNV_LMBCS_2 = UCNV_LMBCS_1 + 1; //12
	    public static final int UCNV_LMBCS_3 = UCNV_LMBCS_2 + 1; //13
	    public static final int UCNV_LMBCS_4 = UCNV_LMBCS_3 + 1; //14
	    public static final int UCNV_LMBCS_5 = UCNV_LMBCS_4 + 1; //15
	    public static final int UCNV_LMBCS_6 = UCNV_LMBCS_5 + 1; //16
	    public static final int UCNV_LMBCS_8 = UCNV_LMBCS_6 + 1; //17
	    public static final int UCNV_LMBCS_11 = UCNV_LMBCS_8 + 1; //18
	    public static final int UCNV_LMBCS_16 = UCNV_LMBCS_11 + 1; //19
	    public static final int UCNV_LMBCS_17 = UCNV_LMBCS_16 + 1; //20
	    public static final int UCNV_LMBCS_18 = UCNV_LMBCS_17 + 1; //21
	    public static final int UCNV_LMBCS_19 = UCNV_LMBCS_18 + 1; //22
	    public static final int UCNV_LMBCS_LAST = UCNV_LMBCS_19; //22
	    public static final int UCNV_HZ =UCNV_LMBCS_LAST + 1; //23
	    public static final int UCNV_SCSU = UCNV_HZ + 1; //24
	    public static final int UCNV_ISCII = UCNV_SCSU + 1; //25
	    public static final int UCNV_US_ASCII = UCNV_ISCII + 1; //26
	    public static final int UCNV_UTF7 = UCNV_US_ASCII + 1; //27
	    public static final int UCNV_BOCU1 = UCNV_UTF7 + 1; //28
	    public static final int UCNV_UTF16 = UCNV_BOCU1 + 1; //29
	    public static final int UCNV_UTF32 = UCNV_UTF16 + 1; //30
	    public static final int UCNV_CESU8 = UCNV_UTF32 + 1; //31
	    public static final int UCNV_IMAP_MAILBOX = UCNV_CESU8 + 1; //32
	    public static final int UCNV_MAC_ARABIC = UCNV_IMAP_MAILBOX + 1; //33
	    public static final int UCNV_MAC_HEBREW = UCNV_MAC_ARABIC + 1; //34
	
	    /* Number of converter types for which we have conversion routines. */
	    public static final int UCNV_NUMBER_OF_SUPPORTED_CONVERTER_TYPES = UCNV_MAC_HEBREW + 1;
	
	}
	
	/**
	 * Enum for specifying which platform a converter ID refers to.
	 * The use of platform/CCSID is not recommended. See ucnv_openCCSID().
	 *
	 * @see ucnv_getPlatform
	 * @see ucnv_openCCSID
	 * @see ucnv_getCCSID
	 * @stable ICU 2.0
	 */
	public static final class UConverterPlatform {
	    public static final int UCNV_UNKNOWN = -1;
	    public static final int UCNV_IBM = 0;
	}

	static UConverterSharedData _MBCSData = null, /*_Latin1Data = null,*/ /*_UTF8Data = null,*/ /*_UTF16BEData = null,*/ /*_UTF16LEData = null,*/ /*_UTF32BEData = null,*/ /*_UTF32LEData = null,*/  /*_ISO2022Data = null,*/ _LMBCSData1 = null,_LMBCSData2 = null, _LMBCSData3 = null, _LMBCSData4 = null, _LMBCSData5 = null, _LMBCSData6 = null, _LMBCSData8 = null,_LMBCSData11 = null,_LMBCSData16 = null,_LMBCSData17 = null,_LMBCSData18 = null,_LMBCSData19 = null, _HZData = null, _SCSUData = null, /*_ISCIIData = null,*/ /*_ASCIIData = null,*/ _UTF7Data = null, _Bocu1Data = null, /*_UTF16Data = null, _UTF32Data = null,*/ _CESU8Data = null, _IMAPData = null;
	static UConverterSharedData[] converterData;
	static class cnvNameTypeClass {
	  String name;
		int type;
		cnvNameTypeClass(String name_, int type_) { name = name_; type = type_; }
	} 
	
	static cnvNameTypeClass cnvNameType[];
	
	static {
	/* Please keep this in binary sorted order for getAlgorithmicTypeFromName.
	   Also the name should be in lower case and all spaces, dashes and underscores
	   removed
	*/
		cnvNameType = new cnvNameTypeClass[] {
		  new cnvNameTypeClass( "bocu1", UConverterType.UCNV_BOCU1 ),
		  new cnvNameTypeClass( "cesu8", UConverterType.UCNV_CESU8 ),
		//#if !UCONFIG_NO_LEGACY_CONVERSION
		  new cnvNameTypeClass( "hz",UConverterType.UCNV_HZ ),
		//#endif
		  new cnvNameTypeClass( "imapmailboxname", UConverterType.UCNV_IMAP_MAILBOX ),
		//#if !UCONFIG_NO_LEGACY_CONVERSION
		  new cnvNameTypeClass( "iscii", UConverterType.UCNV_ISCII ),
		  new cnvNameTypeClass( "iso2022", UConverterType.UCNV_ISO_2022 ),
		//#endif
		  new cnvNameTypeClass( "iso88591", UConverterType.UCNV_LATIN_1 ),
		//#if !UCONFIG_NO_LEGACY_CONVERSION
		  new cnvNameTypeClass( "lmbcs1", UConverterType.UCNV_LMBCS_1 ),
		  new cnvNameTypeClass( "lmbcs11",UConverterType.UCNV_LMBCS_11 ),
		  new cnvNameTypeClass( "lmbcs16",UConverterType.UCNV_LMBCS_16 ),
		  new cnvNameTypeClass( "lmbcs17",UConverterType.UCNV_LMBCS_17 ),
		  new cnvNameTypeClass( "lmbcs18",UConverterType.UCNV_LMBCS_18 ),
		  new cnvNameTypeClass( "lmbcs19",UConverterType.UCNV_LMBCS_19 ),
		  new cnvNameTypeClass( "lmbcs2", UConverterType.UCNV_LMBCS_2 ),
		  new cnvNameTypeClass( "lmbcs3", UConverterType.UCNV_LMBCS_3 ),
		  new cnvNameTypeClass( "lmbcs4", UConverterType.UCNV_LMBCS_4 ),
		  new cnvNameTypeClass( "lmbcs5", UConverterType.UCNV_LMBCS_5 ),
		  new cnvNameTypeClass( "lmbcs6", UConverterType.UCNV_LMBCS_6 ),
		  new cnvNameTypeClass( "lmbcs8", UConverterType.UCNV_LMBCS_8 ),
		//#endif
		  new cnvNameTypeClass( "macarabic", UConverterType.UCNV_MAC_ARABIC ),
		  new cnvNameTypeClass( "machebrew", UConverterType.UCNV_MAC_HEBREW ),
		  new cnvNameTypeClass( "scsu", UConverterType.UCNV_SCSU ),
		  new cnvNameTypeClass( "usascii", UConverterType.UCNV_US_ASCII ),
		  new cnvNameTypeClass( "utf16", UConverterType.UCNV_UTF16 ),
		  new cnvNameTypeClass( "utf16be", UConverterType.UCNV_UTF16_BigEndian ),
		  new cnvNameTypeClass( "utf16le", UConverterType.UCNV_UTF16_LittleEndian ),
		//#if U_IS_BIG_ENDIAN
		  new cnvNameTypeClass( "utf16oppositeendian", UConverterType.UCNV_UTF16_LittleEndian ),
		  new cnvNameTypeClass( "utf16platformendian", UConverterType.UCNV_UTF16_BigEndian ),
		//#else
		  new cnvNameTypeClass( "utf16oppositeendian", UConverterType.UCNV_UTF16_BigEndian),
		  new cnvNameTypeClass( "utf16platformendian", UConverterType.UCNV_UTF16_LittleEndian ),
		//#endif
		  new cnvNameTypeClass( "utf32", UConverterType.UCNV_UTF32 ),
		  new cnvNameTypeClass( "utf32be", UConverterType.UCNV_UTF32_BigEndian ),
		  new cnvNameTypeClass( "utf32le", UConverterType.UCNV_UTF32_LittleEndian ),
		//#if U_IS_BIG_ENDIAN
		  new cnvNameTypeClass( "utf32oppositeendian", UConverterType.UCNV_UTF32_LittleEndian ),
		  new cnvNameTypeClass( "utf32platformendian", UConverterType.UCNV_UTF32_BigEndian ),
		//#else
		  new cnvNameTypeClass( "utf32oppositeendian", UConverterType.UCNV_UTF32_BigEndian ),
		  new cnvNameTypeClass( "utf32platformendian", UConverterType.UCNV_UTF32_LittleEndian ),
		//#endif
		  new cnvNameTypeClass( "utf7", UConverterType.UCNV_UTF7 ),
		  new cnvNameTypeClass( "utf8", UConverterType.UCNV_UTF8 )
		};
	
		converterData = new UConverterSharedData[/*UCNV_NUMBER_OF_SUPPORTED_CONVERTER_TYPES*/] {
		    /*0*/null, null,
		
		//#if UCONFIG_NO_LEGACY_CONVERSION
		/*
		    null,
		*/
		//#else
		    /*2*/_MBCSData,
		//#endif
		
		    /*3*/UConverterSharedData_Latin1._Latin1Data,
		    UConverterSharedData_UTF8._UTF8Data, UConverterSharedData_UTF16BE._UTF16BEData, UConverterSharedData_UTF16LE._UTF16LEData, UConverterSharedData_UTF32BE._UTF32BEData, UConverterSharedData_UTF32LE._UTF32LEData,
		    /*9*/null,
		
		//#if UCONFIG_NO_LEGACY_CONVERSION
		/*
		    null,
		    null, null, null, null, null, null,
		    null, null, null, null, null, null,
		    null,
		*/
		//#else
		    /*10*/UConverterSharedData_ISO2022._ISO2022Data,
		    _LMBCSData1,_LMBCSData2, _LMBCSData3, _LMBCSData4, _LMBCSData5, _LMBCSData6,
		    _LMBCSData8,_LMBCSData11,_LMBCSData16,_LMBCSData17,_LMBCSData18,_LMBCSData19,
		    /*23*/_HZData,
		//#endif
		
		    /*24*/_SCSUData,
		
		//#if UCONFIG_NO_LEGACY_CONVERSION
		/*
		    null,
		*/
		//#else
		    /*25*/UConverterSharedData_ISCII._ISCIIData,
		//#endif
		
		    /*26*/UConverterSharedData_ASCII._ASCIIData,
		    _UTF7Data, _Bocu1Data, UConverterSharedData_UTF16._UTF16Data, UConverterSharedData_UTF32._UTF32Data, _CESU8Data, _IMAPData,
		    
		    /*33*/UConverterSharedData_MacArabic._MacArabicData, UConverterSharedData_MacHebrew._MacHebrewData
		};
	}

	static final int MAXIMUM_UCS2 =            0x0000FFFF;
	static final int MAXIMUM_UTF =             0x0010FFFF;
	static final int MAXIMUM_UCS4 =            0x7FFFFFFF;
	static final int HALF_SHIFT =              10;
	static final int HALF_BASE =               0x0010000;
	static final int HALF_MASK =               0x3FF;
	static final int SURROGATE_HIGH_START =    0xD800;
	static final int SURROGATE_HIGH_END =      0xDBFF;
	static final int SURROGATE_LOW_START =     0xDC00;
	static final int SURROGATE_LOW_END =       0xDFFF;
	
	/* -SURROGATE_LOW_START + HALF_BASE */
	static final int SURROGATE_LOW_BASE =      9216;
}
