package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_UTF8 extends UConverterSharedData {

	public UConverterSharedData_UTF8(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_UTF8()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		ucnv_toUnicode_UTF8(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		ucnv_fromUnicode_UTF8(args, pErrorCode);
	}
	
	/* UTF-8 -------------------------------------------------------------------- */
	
	/* UTF-8 Conversion DATA
	 *   for more information see Unicode Strandard 2.0 , Transformation Formats Appendix A-9
	 */
	/*static const uint32_t REPLACEMENT_CHARACTER = 0x0000FFFD;*/
	
	static final long offsetsFromUTF8[/*7*/];
	static {
		offsetsFromUTF8 = new long[] {0,
	  0x00000000L, 0x00003080L, 0x000E2080L,
	  0x03C82080L, 0xFA082080L, 0x82082080L
	};
	}
	
	/* END OF UTF-8 Conversion DATA */
	
	static final byte bytesFromUTF8[/*256*/];
	static {
		bytesFromUTF8 = new byte[] {
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 0, 0
	};
	}
	
	/*
	 * Starting with Unicode 3.0.1:
	 * UTF-8 byte sequences of length N _must_ encode code points of or above utf8_minChar32[N];
	 * byte sequences with more than 4 bytes are illegal in UTF-8,
	 * which is tested with impossible values for them
	 */
	static final long utf8_minChar32[/*7*/];
	static {
		utf8_minChar32 = new long[] { 0L, 0L, 0x80L, 0x800L, 0x10000L, 0xffffffffL, 0xffffffffL };
	}
	
	//static void ucnv_toUnicode_UTF8 (UConverterToUnicodeArgs * args, UErrorCode * err)
	public final void ucnv_toUnicode_UTF8 (UConverterToUnicodeArgs args, int[] err)
	{
	    byte[] mySourceArray = args.sourceArray;
			int mySourceArrayIndex = args.sourceBegin;
	    char[] myTargetArray = args.targetArray;
			int myTargetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    byte[] toUBytesArray = args.converter.toUBytesArray;
			int toUBytesArrayIndex = args.converter.toUBytesBegin;
	    boolean isCESU8 = args.converter.sharedData == _CESU8Data;
	    long ch, ch2 = 0;
	    int i, inBytes;
	  
	    /* Restore size of current sequence */
			//agljport:add donefornow label moved here from below
	donefornow:
			{
	    if (args.converter.toUnicodeStatus != 0 && myTargetArrayIndex < targetLimit)
	    {
	        inBytes = args.converter.mode;            /* restore # of bytes to consume */
	        i = args.converter.toULength;             /* restore # of bytes consumed */
	
	        ch = args.converter.toUnicodeStatus;/*Stores the previously calculated ch from a previous call*/
	        args.converter.toUnicodeStatus = 0;
					//agljport:comment block labeled morebytes copied from below
	//morebytes:
					while (i < inBytes)
					{
						if (mySourceArrayIndex < sourceLimit)
						{
							toUBytesArray[i] = (byte) (ch2 = mySourceArray[mySourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK);
							if (!UConverterUTF8.U8_IS_TRAIL((byte)ch2))
							{
								break; /* i < inBytes */
							}
							ch = (ch << 6) + ch2;
							++mySourceArrayIndex;
							i++;
						}
						else
						{
							/* stores a partially calculated target*/
							args.converter.toUnicodeStatus = ch;
							args.converter.mode = inBytes;
							args.converter.toULength = (byte) i;
							break donefornow;
						}
					}
	
	            /* Remove the accumulated high bits */
	            ch -= offsetsFromUTF8[inBytes];
	
	            /*
	             * Legal UTF-8 byte sequences in Unicode 3.0.1 and up:
	             * - use only trail bytes after a lead byte (checked above)
	             * - use the right number of trail bytes for a given lead byte
	             * - encode a code point <= U+10ffff
	             * - use the fewest possible number of bytes for their code points
	             * - use at most 4 bytes (for i>=5 it is 0x10ffff<utf8_minChar32[])
	             *
	             * Starting with Unicode 3.2, surrogate code points must not be encoded in UTF-8.
	             * There are no irregular sequences any more.
	             * In CESU-8, only surrogates, not supplementary code points, are encoded directly.
	             */
	            if (i == inBytes && ch <= MAXIMUM_UTF && ch >= utf8_minChar32[i] && (isCESU8 ? i <= 3 : !UConverterUTF.U_IS_SURROGATE((int)ch)))
	            {
	                /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	                args.converter.toULength = 0;
	                if (ch <= MAXIMUM_UCS2) 
	                {
	                    /* fits in 16 bits */
	                    myTargetArray[myTargetArrayIndex++] = (char) ch;
	                }
	                else
	                {
	                    /* write out the surrogates */
	                    ch -= HALF_BASE;
	                    myTargetArray[myTargetArrayIndex++] = (char) ((ch >> HALF_SHIFT) + SURROGATE_HIGH_START);
	                    ch = (ch & HALF_MASK) + SURROGATE_LOW_START;
	                    if (myTargetArrayIndex < targetLimit)
	                    {
	                        myTargetArray[myTargetArrayIndex++] = (char)ch;
	                    }
	                    else
	                    {
	                        /* Put in overflow buffer (not handled here) */
	                        args.converter.UCharErrorBufferArray[0] = (char) ch;
	                        args.converter.UCharErrorBufferLength = 1;
	                        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                        break donefornow;
	                    }
	                }
	            }
	            else
	            {
	                args.converter.toULength = (byte)i;
	                err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                //agljport:change:change break;
	                break donefornow;
	            }
	    }
	
	
	    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit)
	    {
	        ch = mySourceArray[mySourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK;
	        if (ch < 0x80)        /* Simple case */
	        {
	            myTargetArray[myTargetArrayIndex++] = (char)ch;
	        }
	        else
	        {
	            /* store the first char */
	            toUBytesArray[0] = (byte)ch;
	            inBytes = bytesFromUTF8[(int)ch]; /* lookup current sequence length */
	            i = 1;
	
	//agljport:delete morebytes:
					while (i < inBytes)
					{
						if (mySourceArrayIndex < sourceLimit)
						{
							toUBytesArray[i] = (byte) (ch2 = mySourceArray[mySourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK);
							if (!UConverterUTF8.U8_IS_TRAIL((byte)ch2))
							{
								break; /* i < inBytes */
							}
							ch = (ch << 6) + ch2;
							++mySourceArrayIndex;
							i++;
						}
						else
						{
							/* stores a partially calculated target*/
							args.converter.toUnicodeStatus = ch;
							args.converter.mode = inBytes;
							args.converter.toULength = (byte) i;
							break donefornow;
						}
					}
	
	            /* Remove the accumulated high bits */
	            ch -= offsetsFromUTF8[inBytes];
	
	            /*
	             * Legal UTF-8 byte sequences in Unicode 3.0.1 and up:
	             * - use only trail bytes after a lead byte (checked above)
	             * - use the right number of trail bytes for a given lead byte
	             * - encode a code point <= U+10ffff
	             * - use the fewest possible number of bytes for their code points
	             * - use at most 4 bytes (for i>=5 it is 0x10ffff<utf8_minChar32[])
	             *
	             * Starting with Unicode 3.2, surrogate code points must not be encoded in UTF-8.
	             * There are no irregular sequences any more.
	             * In CESU-8, only surrogates, not supplementary code points, are encoded directly.
	             */
	            if (i == inBytes && ch <= MAXIMUM_UTF && ch >= utf8_minChar32[i] && (isCESU8 ? i <= 3 : !UConverterUTF.U_IS_SURROGATE((int)ch)))
	            {
	                /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	                args.converter.toULength = 0;
	                if (ch <= MAXIMUM_UCS2) 
	                {
	                    /* fits in 16 bits */
	                    myTargetArray[myTargetArrayIndex++] = (char) ch;
	                }
	                else
	                {
	                    /* write out the surrogates */
	                    ch -= HALF_BASE;
	                    myTargetArray[myTargetArrayIndex++] = (char) ((ch >>> HALF_SHIFT) + SURROGATE_HIGH_START);
	                    ch = (ch & HALF_MASK) + SURROGATE_LOW_START;
	                    if (myTargetArrayIndex < targetLimit)
	                    {
	                        myTargetArray[myTargetArrayIndex++] = (char)ch;
	                    }
	                    else
	                    {
	                        /* Put in overflow buffer (not handled here) */
	                        args.converter.UCharErrorBufferArray[0] = (char) ch;
	                        args.converter.UCharErrorBufferLength = 1;
	                        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                        break;
	                    }
	                }
	            }
	            else
	            {
	                args.converter.toULength = (byte)i;
	                err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                break;
	            }
	        }
	    }
	
			}
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0]))
	    {
	        /* End of target buffer */
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
	    args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
	    args.sourceBegin = mySourceArrayIndex;
	}
	
	//U_CFUNC void ucnv_fromUnicode_UTF8 (UConverterFromUnicodeArgs * args, UErrorCode * err)
	void ucnv_fromUnicode_UTF8 (UConverterFromUnicodeArgs args, int[] err)
	{
	    UConverter cnv = args.converter;
	    char[] mySourceArray = args.sourceArray;
			int mySourceArrayIndex = args.sourceBegin;
	    byte[] myTargetArray = args.targetArray;
			int myTargetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    boolean isCESU8 = args.converter.sharedData == _CESU8Data;
	    long ch, ch2;
	    short indexToWrite;
	    byte temp[/*4*/] = new byte[4];
	
			boolean doloop = true;
	    if (cnv.fromUChar32 != 0 && myTargetArrayIndex < targetLimit)
	    {
	        ch = cnv.fromUChar32;
	        cnv.fromUChar32 = 0;
					//agljport:comment copied block labeled lowsurrogate from inside while loop below
	//lowsurrogate:
	                    if (mySourceArrayIndex < sourceLimit) {
	                        /* test the following code unit */
	                        char trail=mySourceArray[mySourceArrayIndex];
	                        if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                            ++mySourceArrayIndex;
	                            ch=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)ch, trail);
	                            ch2 = 0;
	                            /* convert this supplementary code point */
	                            /* exit this condition tree */
	                        } else {
	                            /* this is an unmatched lead code unit (1st surrogate) */
	                            /* callback(illegal) */
	                            cnv.fromUChar32 = (int)ch;
	                            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
															doloop = false;
	                        }
	                    } else {
	                        /* no more input */
	                        cnv.fromUChar32 = (int)ch;
													doloop = false;
	                    }
							/*agljport:delete
	                } else {
	                    cnv->fromUChar32 = ch;
	                    *err = U_ILLEGAL_CHAR_FOUND;
	                    break;
	                }
	            }
							*/
	
	            if (ch < 0x10000)
	            {
	                indexToWrite = 2;
	                temp[2] = (byte) ((ch >>> 12) | 0xe0);
	            }
	            else
	            {
	                indexToWrite = 3;
	                temp[3] = (byte) ((ch >>> 18) | 0xf0);
	                temp[2] = (byte) (((ch >>> 12) & 0x3f) | 0x80);
	            }
	            temp[1] = (byte) (((ch >>> 6) & 0x3f) | 0x80);
	            temp[0] = (byte) ((ch & 0x3f) | 0x80);
	
	            for (; indexToWrite >= 0; indexToWrite--)
	            {
	                if (myTargetArrayIndex < targetLimit)
	                {
	                    myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
	                }
	                else
	                {
	                    cnv.charErrorBufferArray[cnv.charErrorBufferLength++] = temp[indexToWrite];
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                }
	            }
	    }
	
			if(doloop) {
	    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit)
	    {
	        ch = mySourceArray[mySourceArrayIndex++];
	
	        if (ch < 0x80)        /* Single byte */
	        {
	            myTargetArray[myTargetArrayIndex++] = (byte) ch;
	        }
	        else if (ch < 0x800)  /* Double byte */
	        {
	            myTargetArray[myTargetArrayIndex++] = (byte) ((ch >>> 6) | 0xc0);
	            if (myTargetArrayIndex < targetLimit)
	            {
	                myTargetArray[myTargetArrayIndex++] = (byte) ((ch & 0x3f) | 0x80);
	            }
	            else
	            {
	                cnv.charErrorBufferArray[0] = (byte) ((ch & 0x3f) | 0x80);
	                cnv.charErrorBufferLength = 1;
	                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            }
	        }
	        else
	        /* Check for surrogates */
	        {
	            if(UConverterUTF.U_IS_SURROGATE((int)ch) && !isCESU8) {
	                if(UConverterUTF.U_IS_SURROGATE_LEAD((int)ch)) {
	//agljport:delete lowsurrogate:
	                    if (mySourceArrayIndex < sourceLimit) {
	                        /* test the following code unit */
	                        char trail=mySourceArray[mySourceArrayIndex];
	                        if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                            ++mySourceArrayIndex;
	                            ch=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)ch, trail);
	                            ch2 = 0;
	                            /* convert this supplementary code point */
	                            /* exit this condition tree */
	                        } else {
	                            /* this is an unmatched lead code unit (1st surrogate) */
	                            /* callback(illegal) */
	                            cnv.fromUChar32 = (int)ch;
	                            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                            break;
	                        }
	                    } else {
	                        /* no more input */
	                        cnv.fromUChar32 = (int)ch;
	                        break;
	                    }
	                } else {
	                    cnv.fromUChar32 = (int)ch;
	                    err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                    break;
	                }
	            }
	
	            if (ch < 0x10000)
	            {
	                indexToWrite = 2;
	                temp[2] = (byte) ((ch >>> 12) | 0xe0);
	            }
	            else
	            {
	                indexToWrite = 3;
	                temp[3] = (byte) ((ch >>> 18) | 0xf0);
	                temp[2] = (byte) (((ch >>> 12) & 0x3f) | 0x80);
	            }
	            temp[1] = (byte) (((ch >>> 6) & 0x3f) | 0x80);
	            temp[0] = (byte) ((ch & 0x3f) | 0x80);
	
	            for (; indexToWrite >= 0; indexToWrite--)
	            {
	                if (myTargetArrayIndex < targetLimit)
	                {
	                    myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
	                }
	                else
	                {
	                    cnv.charErrorBufferArray[cnv.charErrorBufferLength++] = temp[indexToWrite];
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                }
	            }
	        }
	    }
			}
	
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0]))
	    {
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
	    args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
	    args.sourceBegin = mySourceArrayIndex;
	}
	
	/*agljport:change
	static const UConverterImpl _UTF8Impl={
	    UCNV_UTF8,
	
	    NULL,
	    NULL,
	
	    NULL,
	    NULL,
	    NULL,
	
	    ucnv_toUnicode_UTF8,
	    ucnv_toUnicode_UTF8_OFFSETS_LOGIC,
	    ucnv_fromUnicode_UTF8,
	    ucnv_fromUnicode_UTF8_OFFSETS_LOGIC,
	    ucnv_getNextUChar_UTF8,
	
	    NULL,
	    NULL,
	    NULL,
	    NULL,
	    ucnv_getNonSurrogateUnicodeSet
	};
	
	static const UConverterStaticData _UTF8StaticData={
	    sizeof(UConverterStaticData),
	    "UTF-8",
	    1208, UCNV_IBM, UCNV_UTF8,
	    1, 3,
	    { 0xef, 0xbf, 0xbd, 0 },3,FALSE,FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	
	
	const UConverterSharedData _UTF8Data={
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_UTF8StaticData, FALSE, &_UTF8Impl,
	    0
	};
	*/
	
	public static UConverterStaticData _UTF8StaticData;
	public static UConverterSharedData_UTF8 _UTF8Data;
	static 
	{
	/* The 1208 CCSID refers to any version of Unicode of UTF-8 */
	_UTF8StaticData = new UConverterStaticData(
	    UConverterStaticData.sizeofUConverterStaticData,
	    "UTF-8",
	    1208, (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_UTF8,
			(byte)1, (byte)3, /* max 3 bytes per UChar from UTF-8 (4 bytes from surrogate _pair_) */
	    new byte[]{ (byte)0xef, (byte)0xbf, (byte)0xbd, 0 }, (byte)3, (byte)0, (byte)0,
	    (short)0,
	    (byte)0,
	    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
	);
	
	_UTF8Data = new UConverterSharedData_UTF8(
	    sizeofUConverterSharedData, ~0,
	    /*NULL, NULL,*/ _UTF8StaticData, false, /*&_UTF8Impl,*/
	    0
			);
	}
}
