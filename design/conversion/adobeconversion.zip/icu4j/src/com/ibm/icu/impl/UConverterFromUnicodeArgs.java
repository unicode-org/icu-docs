package com.ibm.icu.impl;

import com.ibm.icu.converters.*;

/**
 * The structure for the fromUnicode callback function parameter.
 * @stable ICU 2.0
 */
public final class UConverterFromUnicodeArgs {
    //agljport:todo uint16_t size;              /**< The size of this struct. @stable ICU 2.0 */
    public boolean flush;                /**< The internal state of converter will be reset and data flushed if set to TRUE. @stable ICU 2.0    */
    public UConverter converter;      /**< Pointer to the converter that is opened and to which this struct is passed as an argument. @stable ICU 2.0  */
    public char[] sourceArray;        /**< Pointer to the source source buffer. @stable ICU 2.0    */
	public int sourceBegin;
    public int sourceLimit;   /**< Pointer to the limit (end + 1) of source buffer. @stable ICU 2.0    */
    public byte[] targetArray;               /**< Pointer to the target buffer. @stable ICU 2.0    */
	public int targetBegin;
    public int targetLimit;    /**< Pointer to the limit (end + 1) of target buffer. @stable ICU 2.0     */
    public int[] offsetsArray;           /**< Pointer to the buffer that recieves the offsets. *offset = blah ; offset++;. @stable ICU 2.0  */
	public int offsetsBegin;
	public UConverterFromUnicodeArgs()
	{
	}

	public UConverterFromUnicodeArgs(boolean flush_, UConverter converter_, char[] sourceArray_, int sourceBegin_, int sourceLimit_, byte[] targetArray_, int targetBegin_, int targetLimit_, int[] offsetsArray_, int offsetsBegin_)
	{
		flush = flush_;
		converter = converter_;
		sourceArray = sourceArray_;
		sourceBegin = sourceBegin_;
		sourceLimit = sourceLimit_;
		targetArray = targetArray_;
		targetBegin = targetBegin_;
		targetLimit = targetLimit_;
		offsetsArray = offsetsArray_;
		offsetsBegin = offsetsBegin_;
	}
}

