package com.ibm.icu.impl;

import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.InputStream;

import com.ibm.icu.converters.*;

public final class UDataMemory {
	public ByteBuffer pHeaderArray;
}


