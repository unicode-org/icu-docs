package com.ibm.icu.impl;

import com.ibm.icu.impl.ICUDebug;
import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.InputStream;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_MBCS extends UConverterSharedData {
	
	private final static boolean debug = ICUDebug.enabled("UConverterSharedData_MBCS");
	
	public UConverterSharedData_MBCS(UConverterDataReader r)
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
		dataReader = r;
	}
	
	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		ucnv_MBCSOpen(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		ucnv_MBCSToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		ucnv_MBCSFromUnicodeWithOffsets(args, pErrorCode);
	}
	
	//static void ucnv_MBCSOpen(UConverter *cnv, const char *name, const char *locale, uint32_t options, UErrorCode *pErrorCode) 
	private final void ucnv_MBCSOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode) 
	{
	    UConverterMBCSTable mbcsTable;
	    //int[] extIndexes;
			ByteBuffer extIndexes;
	    short outputType;
	    byte maxBytesPerUChar;
	
	    mbcsTable=cnv.sharedData.mbcs;
	    outputType=mbcsTable.outputType;
	
	    if(outputType==MBCS_OUTPUT_DBCS_ONLY) {
	        /* the swaplfnl option does not apply, remove it */
	        cnv.options=options&=~UConverter.UCNV_OPTION_SWAP_LFNL;
	    }
	
	    if((options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        /* do this because double-checked locking is broken */
	        boolean isCached;
	
	        //agljport:todo umtx_lock(NULL);
	        isCached=mbcsTable.swapLFNLStateTable!=null;
	        //agljport:todo umtx_unlock(NULL);
	
	        if(!isCached) {
	            //agljport:fix if(!_EBCDICSwapLFNL(cnv->sharedData, pErrorCode)) {
	                //agljport:fix if(U_FAILURE(*pErrorCode)) {
	                    //agljport:fix return; /* something went wrong */
	                //agljport:fix }
	
	                /* the option does not apply, remove it */
	                //agljport:fix cnv->options=options&=~UCNV_OPTION_SWAP_LFNL;
	            //agljport:fix }
	        }
	    }
	
			if(name.indexOf("18030") >= 0) {
	        if(name.indexOf("gb18030") >= 0 || name.indexOf("GB18030") >= 0) {
	            /* set a flag for GB 18030 mode, which changes the callback behavior */
	            cnv.options|=_MBCS_OPTION_GB18030;
	        }
	    }
	
	    /* fix maxBytesPerUChar depending on outputType and options etc. */
	    if(outputType==MBCS_OUTPUT_2_SISO) {
	        cnv.maxBytesPerUChar=3; /* SO+DBCS */
	    }
	
	    extIndexes=mbcsTable.extIndexes;
	    if(extIndexes!=null) {
	        maxBytesPerUChar=(byte)UConverterExt.UCNV_GET_MAX_BYTES_PER_UCHAR(extIndexes);
	        if(outputType==MBCS_OUTPUT_2_SISO) {
	            ++maxBytesPerUChar; /* SO + multiple DBCS */
	        }
	
	        if(maxBytesPerUChar>cnv.maxBytesPerUChar) {
	            cnv.maxBytesPerUChar=maxBytesPerUChar;
	        }
	    }
	
	}
	
	protected void doLoad(UConverterLoadArgs pArgs, /*short[] raw,*/ int[] pErrorCode)
	{
		ucnv_MBCSLoad(pArgs, /*raw,*/ pErrorCode);
	}
			
	private final void
	//ucnv_MBCSLoad(UConverterSharedData *sharedData, UConverterLoadArgs *pArgs, const uint8_t *raw, ErrorCode *pErrorCode) 
	ucnv_MBCSLoad(UConverterLoadArgs pArgs, /*short[] raw,*/ int[] pErrorCode) 
	{
	    //agljport:fix UDataInfo info;
	    UConverterMBCSTable mbcsTable = mbcs;
			_MBCSHeader header = new _MBCSHeader();
			try {
				dataReader.readMBCSHeader(header);	
			}
			catch(IOException e) {
				if(debug) System.err.println("Caught IOException: " + e.getMessage());
				pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
				return;
			}
	    int offset;
	
			int[] extIndexesArray = null;
			String baseNameString = null;
			int[][] stateTableArray = null;
			_MBCSToUFallback[] toUFallbacksArray = null;
			char[] unicodeCodeUnitsArray = null;
			char[] fromUnicodeTableArray = null;
			byte[] fromUnicodeBytesArray = null;
			
	    if(header.version[0]!=4) {
	        pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FORMAT;
	        return;
	    }
	
	    mbcsTable.outputType=(byte)header.flags;
	
	    /* extension data, header version 4.2 and higher */
	    offset=header.flags>>>8;
	    //if(offset!=0 && mbcsTable.outputType == MBCS_OUTPUT_EXT_ONLY) {
	    if(mbcsTable.outputType == MBCS_OUTPUT_EXT_ONLY) {
			try {
				baseNameString = dataReader.readBaseTableName();
				if(offset != 0) {
					//agljport:commment subtract 32 for sizeof(_MBCSHeader) and length of baseNameString and 1 null terminator byte all already read;
					mbcsTable.extIndexes=dataReader.readExtIndexes(offset - 32 - baseNameString.length() - 1);
				}
			}
			catch(IOException e) {
				if(debug) System.err.println("Caught IOException: " + e.getMessage());
				pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
				return;
			}
	    }
		/*
	    if(offset != 0) {
			try {
				//agljport:commment subtract 32 for sizeof(_MBCSHeader) and length of baseNameString and 1 null terminator byte all already read;
				int namelen = baseNameString != null? baseNameString.length() + 1: 0;
				mbcsTable.extIndexes=dataReader.readExtIndexes(offset - 32 - namelen);
				
			}
			catch(IOException e) {
				if(debug) System.err.println("Caught IOException: " + e.getMessage());
				pErrorCode[0] = UErrorCode.U_INVALID_FORMAT_ERROR;
				return;
			}
	    }
		*/
		//agljport:add this would be unnecessary if extIndexes were memory mapped
		if(mbcsTable.extIndexes != null) {
			/*
			try {
				//int nbytes = mbcsTable.extIndexes[UConverterExt.UCNV_EXT_TO_U_LENGTH]*4 + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_TO_U_UCHARS_LENGTH]*2 + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_FROM_U_LENGTH]*6 + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_FROM_U_BYTES_LENGTH] + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_FROM_U_STAGE_12_LENGTH]*2 + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_FROM_U_STAGE_3_LENGTH]*2 + mbcsTable.extIndexes[UConverterExt.UCNV_EXT_FROM_U_STAGE_3B_LENGTH]*4; 
				//int nbytes = mbcsTable.extIndexes[UConverterExt.UCNV_EXT_SIZE] 
				//byte[] extTables = dataReader.readExtTables(nbytes);
				//mbcsTable.extTables = ByteBuffer.wrap(extTables);
			}
			catch(IOException e) {
				System.err.println("Caught IOException: " + e.getMessage());
				pErrorCode[0] = UErrorCode.U_INVALID_FORMAT_ERROR;
				return;
			}
			*/
		}
	
	    if(mbcsTable.outputType==MBCS_OUTPUT_EXT_ONLY) {
	        UConverterLoadArgs args= new UConverterLoadArgs();
	        UConverterSharedData baseSharedData = null;
	        //int extIndexes[];
					ByteBuffer extIndexes;
	        String baseName;
	
	        /* extension-only file, load the base table and set values appropriately */
	        if((extIndexes=mbcsTable.extIndexes)==null) {
	            /* extension-only file without extension */
	            pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FORMAT;
	            return;
	        }
	
	        if(pArgs.nestedLoads!=1) {
	            /* an extension table must not be loaded as a base table */
	            pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FILE;
	            return;
	        }
	
	        /* load the base table */
	        baseName=baseNameString;
	        if(baseName.equals(staticData.name)) {
	            /* forbid loading this same extension-only file */
	            pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FORMAT;
	            return;
	        }
	
	        /* TODO parse package name out of the prefix of the base name in the extension .cnv file? */
	        //agljport:fix args.size=sizeof(UConverterLoadArgs);
	        args.nestedLoads=2;
	        args.reserved=pArgs.reserved;
	        args.options=pArgs.options;
	        args.pkg=pArgs.pkg;
	        args.name=baseName;
	        baseSharedData=ucnv_load(args, pErrorCode);
	        if(ErrorCode.isFailure(pErrorCode[0])) {
	            return;
	        }
	        if( baseSharedData.staticData.conversionType!=UConverterType.UCNV_MBCS ||
	            baseSharedData.mbcs.baseSharedData!=null
	        ) {
	            //agljport:fix ucnv_unload(baseSharedData);
	            pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FORMAT;
	            return;
	        }
	
	        /* copy the base table data */
					//agljport:comment deep copy in C changes mbcs through local reference mbcsTable; in java we probably don't need the deep copy so can just make sure mbcs and its local reference both refer to the same new object
					mbcsTable = mbcs = baseSharedData.mbcs;
	
	        /* overwrite values with relevant ones for the extension converter */
	        mbcsTable.baseSharedData=baseSharedData;
	        mbcsTable.extIndexes=extIndexes;
	
	        /*
	         * It would be possible to share the swapLFNL data with a base converter,
	         * but the generated name would have to be different, and the memory
	         * would have to be free'd only once.
	         * It is easier to just create the data for the extension converter
	         * separately when it is requested.
	         */
	        mbcsTable.swapLFNLStateTable=null;
	        mbcsTable.swapLFNLFromUnicodeBytes=null;
	        mbcsTable.swapLFNLName=null;
	
	        /*
	         * Set a special, runtime-only outputType if the extension converter
	         * is a DBCS version of a base converter that also maps single bytes.
	         */
	        if( staticData.conversionType==UConverterType.UCNV_DBCS ||
	                (staticData.conversionType==UConverterType.UCNV_MBCS &&
	                 staticData.minBytesPerChar>=2)
	        ) {
	            if(baseSharedData.mbcs.outputType==MBCS_OUTPUT_2_SISO) {
	                /* the base converter is SI/SO-stateful */
	                int entry;
	
	                /* get the dbcs state from the state table entry for SO=0x0e */
	                entry=mbcsTable.stateTable[0][0xe];
	                if( MBCS_ENTRY_IS_FINAL(entry) &&
	                    MBCS_ENTRY_FINAL_ACTION(entry)==MBCS_STATE_CHANGE_ONLY &&
	                    MBCS_ENTRY_FINAL_STATE(entry)!=0
	                ) {
	                    mbcsTable.dbcsOnlyState=(byte)MBCS_ENTRY_FINAL_STATE(entry);
	
	                    mbcsTable.outputType=MBCS_OUTPUT_DBCS_ONLY;
	                }
	            } else if(
	                baseSharedData.staticData.conversionType==UConverterType.UCNV_MBCS &&
	                baseSharedData.staticData.minBytesPerChar==1 &&
	                baseSharedData.staticData.maxBytesPerChar==2 &&
	                mbcsTable.countStates<=127
	            ) {
	                /* non-stateful base converter, need to modify the state table */
	                int newStateTable[][/*256*/];
									int state[]; // this works because java 2-D array is array of references and we can have state = newStateTable[i];
	                int i, count;
	
	                /* allocate a new state table and copy the base state table contents */
	                count=mbcsTable.countStates;
	                newStateTable=new int[(count+1)*1024][256];
	                if(newStateTable==null) {
	                    //agljport:todo ucnv_unload(baseSharedData);
	                    pErrorCode[0]=ErrorCode.U_MEMORY_ALLOCATION_ERROR;
	                    return;
	                }
	
									for(i = 0; i < mbcsTable.stateTable.length; ++i)
										System.arraycopy(mbcsTable.stateTable[i], 0, newStateTable[i], 0, mbcsTable.stateTable[i].length);
	
	                /* change all final single-byte entries to go to a new all-illegal state */
	                state=newStateTable[0];
	                for(i=0; i<256; ++i) {
	                    if(MBCS_ENTRY_IS_FINAL(state[i])) {
	                        state[i]=MBCS_ENTRY_TRANSITION(count, 0);
	                    }
	                }
	
	                /* build the new all-illegal state */
	                state=newStateTable[count];
	                for(i=0; i<256; ++i) {
	                    state[i]=MBCS_ENTRY_FINAL(0, MBCS_STATE_ILLEGAL, 0);
	                }
	                mbcsTable.stateTable=newStateTable;
	                mbcsTable.countStates=(byte)(count+1);
	                mbcsTable.stateTableOwned=true;
	
	                mbcsTable.outputType=MBCS_OUTPUT_DBCS_ONLY;
	            }
	        }
	
	        /*
	         * unlike below for files with base tables, do not get the unicodeMask
	         * from the sharedData; instead, use the base table's unicodeMask,
	         * which we copied in the memcpy above;
	         * this is necessary because the static data unicodeMask, especially
	         * the UCNV_HAS_SUPPLEMENTARY flag, is part of the base table data
	         */
	    } else {
	        /* conversion file with a base table; an additional extension table is optional */
	        /* make sure that the output type is known */
	        switch(mbcsTable.outputType) {
	        case MBCS_OUTPUT_1:
	        case MBCS_OUTPUT_2:
	        case MBCS_OUTPUT_3:
	        case MBCS_OUTPUT_4:
	        case MBCS_OUTPUT_3_EUC:
	        case MBCS_OUTPUT_4_EUC:
	        case MBCS_OUTPUT_2_SISO:
	            /* OK */
	            break;
	        default:
	            pErrorCode[0]=ErrorCode.U_INVALID_TABLE_FORMAT;
	            return;
	        }
	
					stateTableArray = new int[header.countStates][256];
					toUFallbacksArray = new _MBCSToUFallback[header.countToUFallbacks];
					for(int i = 0; i < toUFallbacksArray.length; ++i)
						toUFallbacksArray[i] = new _MBCSToUFallback();
					unicodeCodeUnitsArray = new char[(header.offsetFromUTable - header.offsetToUCodeUnits)/2];
					fromUnicodeTableArray = new char[(header.offsetFromUBytes - header.offsetFromUTable)/2];
					fromUnicodeBytesArray = new byte[header.fromUBytesLength];
					try {
						dataReader.readMBCSTable(stateTableArray, toUFallbacksArray, unicodeCodeUnitsArray, fromUnicodeTableArray, fromUnicodeBytesArray);
					}
					catch(IOException e) {
						if(debug) System.err.println("Caught IOException: " + e.getMessage());
						pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
					}
					
	        mbcsTable.countStates=(byte)header.countStates;
	        mbcsTable.countToUFallbacks=header.countToUFallbacks;
	        mbcsTable.stateTable=stateTableArray;
	        mbcsTable.toUFallbacks=toUFallbacksArray;
	        mbcsTable.unicodeCodeUnits=unicodeCodeUnitsArray;
	
	        mbcsTable.fromUnicodeTable=fromUnicodeTableArray;
	        mbcsTable.fromUnicodeBytes=fromUnicodeBytesArray;
	        mbcsTable.fromUBytesLength=header.fromUBytesLength;
	
	        /*
	         * converter versions 6.1 and up contain a unicodeMask that is
	         * used here to select the most efficient function implementations
	         */
	        //agljport:fix info.size=sizeof(UDataInfo);
	        //agljport:fix udata_getInfo((UDataMemory *)sharedData->dataMemory, &info);
	        //agljport:fix if(info.formatVersion[0]>6 || (info.formatVersion[0]==6 && info.formatVersion[1]>=1)) {
	            /* mask off possible future extensions to be safe */
	            mbcsTable.unicodeMask=(short)(staticData.unicodeMask&3);
	        //agljport:fix } else {
	            /* for older versions, assume worst case: contains anything possible (prevent over-optimizations) */
	            //agljport:fix mbcsTable->unicodeMask=UCNV_HAS_SUPPLEMENTARY|UCNV_HAS_SURROGATES;
	        //agljport:fix }
	    if(offset != 0) {
				try {
					//agljport:commment subtract 32 for sizeof(_MBCSHeader) and length of baseNameString and 1 null terminator byte all already read;
					//int namelen = baseNameString != null? baseNameString.length() + 1: 0;
					//mbcsTable.extIndexes=dataReader.readExtIndexes(offset - 32 - namelen);
					mbcsTable.extIndexes=dataReader.readExtIndexes(0);
					
				}
				catch(IOException e) {
					if(debug) System.err.println("Caught IOException: " + e.getMessage());
					pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
					return;
				}
	    }
	    }
	}
	
	/* MBCS-to-Unicode conversion functions ------------------------------------- */
	
	//static UChar32 ucnv_MBCSGetFallback(UConverterMBCSTable *mbcsTable, uint32_t offset) {
	int ucnv_MBCSGetFallback(UConverterMBCSTable mbcsTable, int offset) 
	{
	    _MBCSToUFallback[] toUFallbacks;
	    int i, start, limit;
	
	    limit=mbcsTable.countToUFallbacks;
	    if(limit>0) {
	        /* do a binary search for the fallback mapping */
	        toUFallbacks=mbcsTable.toUFallbacks;
	        start=0;
	        while(start<limit-1) {
	            i=(start+limit)/2;
	            if(offset<toUFallbacks[i].offset) {
	                limit=i;
	            } else {
	                start=i;
	            }
	        }
	
	        /* did we really find it? */
	        if(offset==toUFallbacks[start].offset) {
	            return toUFallbacks[start].codePoint;
	        }
	    }
	
	    return 0xfffe;
	}
	
	/* This version of ucnv_MBCSToUnicodeWithOffsets() is optimized for single-byte, single-state codepages. */
	//static void ucnv_MBCSSingleToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode) 
	final void ucnv_MBCSSingleToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    byte[] sourceArray;
			int sourceArrayIndex, sourceLimit;
	    char[] targetArray; 
			int targetArrayIndex, targetLimit;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
			int[][] stateTable;
	
	    int sourceIndex;
	
	    int entry;
	    char c;
	    byte action;
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    targetLimit=pArgs.targetLimit;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        stateTable=cnv.sharedData.mbcs.swapLFNLStateTable;
	    } else {
	        stateTable=cnv.sharedData.mbcs.stateTable;
	    }
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex=0;
	
	    /* conversion loop */
	    while(sourceArrayIndex<sourceLimit) {
	        /*
	         * This following test is to see if available input would overflow the output.
	         * It does not catch output of more than one code unit that
	         * overflows as a result of a surrogate pair or callback output
	         * from the last source byte.
	         * Therefore, those situations also test for overflows and will
	         * then break the loop, too.
	         */
	        if(targetArrayIndex>=targetLimit) {
	            /* target is full */
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	
	        entry=stateTable[0][sourceArray[sourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK];
	        /* MBCS_ENTRY_IS_FINAL(entry) */
	
	        /* test the most common case first */
	        if(MBCS_ENTRY_FINAL_IS_VALID_DIRECT_16(entry)) {
	            /* output BMP code point */
	            targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	            if(offsetsArray!=null) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	            }
	
	            /* normal end of action codes: prepare for a new character */
	            ++sourceIndex;
	            continue;
	        }
	
	        /*
	         * An if-else-if chain provides more reliable performance for
	         * the most common cases compared to a switch.
	         */
	        action=(byte)(MBCS_ENTRY_FINAL_ACTION(entry));
	        if(action==MBCS_STATE_VALID_DIRECT_20 ||
	           (action==MBCS_STATE_FALLBACK_DIRECT_20 && UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv))
	        ) {
	            entry=MBCS_ENTRY_FINAL_VALUE(entry);
	            /* output surrogate pair */
	            targetArray[targetArrayIndex++]=(char)(0xd800|(char)(entry>>>10));
	            if(offsetsArray!=null) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	            }
	            c=(char)(0xdc00|(char)(entry&0x3ff));
	            if(targetArrayIndex<targetLimit) {
	                targetArray[targetArrayIndex++]=c;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	            } else {
	                /* target overflow */
	                cnv.UCharErrorBufferArray[0]=c;
	                cnv.UCharErrorBufferLength=1;
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                break;
	            }
	
	            ++sourceIndex;
	            continue;
	        } else if(action==MBCS_STATE_FALLBACK_DIRECT_16) {
	            if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv)) {
	                /* output BMP code point */
	                targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	
	                ++sourceIndex;
	                continue;
	            }
	        } else if(action==MBCS_STATE_UNASSIGNED) {
	            /* just fall through */
	        } else if(action==MBCS_STATE_ILLEGAL) {
	            /* callback(illegal) */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        } else {
	            /* reserved, must never occur */
	            ++sourceIndex;
	            continue;
	        }
	
	        if(ErrorCode.isFailure(pErrorCode[0])) {
	            /* callback(illegal) */
	            break;
	        } else /* unassigned sequences indicated with byteIndex>0 */ {
	            /* try an extension mapping */
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
	            cnv.toUBytesArray[0]=sourceArray[(sourceArrayIndex-1)];
							int[] sourceArrayBegin = new int[] {sourceArrayIndex};
							int[] targetArrayBegin = new int[] {targetArrayIndex};
							int[] offsetsArrayBegin = new int[] {offsetsArrayIndex};
	            cnv.toULength=_extToU(cnv, cnv.sharedData, (byte)1, sourceArray, sourceArrayBegin, sourceLimit, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, pArgs.flush, pErrorCode);
							sourceArrayIndex = sourceArrayBegin[0];
							targetArrayIndex = targetArrayBegin[0];
							offsetsArrayIndex = offsetsArrayBegin[0];
	            sourceIndex+=1+(int)(sourceArrayIndex-pArgs.sourceBegin);
	
	            if(ErrorCode.isFailure(pErrorCode[0])) {
	                /* not mappable or buffer overflow */
	                break;
	            }
	        }
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/*
	 * This version of ucnv_MBCSSingleToUnicodeWithOffsets() is optimized for single-byte, single-state codepages
	 * that only map to and from the BMP.
	 * In addition to single-byte optimizations, the offset calculations
	 * become much easier.
	 */
	//static void ucnv_MBCSSingleToBMPWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	final void ucnv_MBCSSingleToBMPWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    byte[] sourceArray;
			int sourceArrayIndex;
			int sourceLimit, lastSource;
	    char[] targetArray;
			int targetArrayIndex;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
			int[][] stateTable;
	
	    int sourceIndex;
	
	    int entry;
	    byte action;
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
			sourceArray = pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        stateTable=cnv.sharedData.mbcs.swapLFNLStateTable;
	    } else {
	        stateTable=cnv.sharedData.mbcs.stateTable;
	    }
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex=0;
	    lastSource=sourceArrayIndex;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=sourceLimit-sourceArrayIndex;
	    if(length<targetCapacity) {
	        targetCapacity=length;
	    }
	
	//agljport:todo deleted MBCS_UNROLL_SINGLE_TO_BMP block that unrolled loop, is it relevant in Java?
	
	    /* conversion loop */
	    while(targetCapacity>0) {
	        entry=stateTable[0][sourceArray[sourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK];
	        /* MBCS_ENTRY_IS_FINAL(entry) */
	
	        /* test the most common case first */
	        if(MBCS_ENTRY_FINAL_IS_VALID_DIRECT_16(entry)) {
	            /* output BMP code point */
	            targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	            --targetCapacity;
	            continue;
	        }
	
	        /*
	         * An if-else-if chain provides more reliable performance for
	         * the most common cases compared to a switch.
	         */
	        action=(byte)(MBCS_ENTRY_FINAL_ACTION(entry));
	        if(action==MBCS_STATE_FALLBACK_DIRECT_16) {
	            if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv)) {
	                /* output BMP code point */
	                targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	                --targetCapacity;
	                continue;
	            }
	        } else if(action==MBCS_STATE_UNASSIGNED) {
	            /* just fall through */
	        } else if(action==MBCS_STATE_ILLEGAL) {
	            /* callback(illegal) */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        } else {
	            /* reserved, must never occur */
	            continue;
	        }
	
	        /* set offsets since the start or the last extension */
	        if(offsetsArray!=null) {
	            int count=sourceArrayIndex-lastSource;
	
	            /* predecrement: do not set the offset for the callback-causing character */
	            while(--count>0) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            }
	            /* offset and sourceIndex are now set for the current character */
	        }
	
	        if(ErrorCode.isFailure(pErrorCode[0])) {
	            /* callback(illegal) */
	            break;
	        } else /* unassigned sequences indicated with byteIndex>0 */ {
	            /* try an extension mapping */
	            lastSource=sourceArrayIndex;
	            cnv.toUBytesArray[0]=sourceArray[(sourceArrayIndex-1)];
							int[] sourceArrayBegin = new int[] {sourceArrayIndex};
							int[] targetArrayBegin = new int[] {targetArrayIndex};
							int[] offsetsArrayBegin = new int[] {offsetsArrayIndex};
	            cnv.toULength=_extToU(cnv, cnv.sharedData, (byte)1, sourceArray, sourceArrayBegin, sourceLimit, targetArray, targetArrayBegin, targetArrayIndex + targetCapacity, offsetsArray, offsetsArrayBegin, sourceIndex, pArgs.flush, pErrorCode);
							sourceArrayIndex = sourceArrayBegin[0];
							targetArrayIndex = targetArrayBegin[0];
							offsetsArrayIndex = offsetsArrayBegin[0];
	
	            sourceIndex+=1+(int)(sourceArrayIndex-lastSource);
	
	            if(ErrorCode.isFailure(pErrorCode[0])) {
	                /* not mappable or buffer overflow */
	                break;
	            }
	
	            /* recalculate the targetCapacity after an extension mapping */
	            targetCapacity=pArgs.targetLimit-targetArrayIndex;
	            length=sourceLimit-sourceArrayIndex;
	            if(length<targetCapacity) {
	                targetCapacity=length;
	            }
	        }
	
	//agljport:todo deleted MBCS_UNROLL_SINGLE_TO_BMP block that unrolled loop, is it relevant in Java?
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0]) && sourceArrayIndex<sourceLimit && targetArrayIndex>=pArgs.targetLimit) {
	        /* target is full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* set offsets since the start or the last callback */
	    if(offsetsArray!=null) {
	        int count=sourceArrayIndex-lastSource;
	        while(count>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --count;
	        }
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
			pArgs.targetArray = targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	//U_CFUNC void ucnv_MBCSToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	void ucnv_MBCSToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[]/*UErrorCode*/ pErrorCode)
	{
	    UConverter cnv;
			byte[] sourceArray;
	    int sourceArrayIndex, sourceLimit;
	    char[] targetArray;
			int targetArrayIndex;
	    int targetLimit;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
			/*agljport:change 
	    const int32_t (*stateTable)[256];
	    const uint16_t *unicodeCodeUnits;
			*/
	    int stateTable[][/*256*/];
	    char[] unicodeCodeUnits;
	
			/*agljport:change
	    uint32_t offset;
	    uint8_t state;
	    int8_t byteIndex;
	    uint8_t *bytes;
	
	    int32_t sourceIndex, nextSourceIndex;
	
	    int32_t entry;
	    UChar c;
	    uint8_t action;
			*/
	
	    int offset;
	    byte state;
	    byte byteIndex;
	    byte[] bytes;
	
	    int sourceIndex, nextSourceIndex;
	
	    int entry = 0;
	    char c;
	    byte action;
	
	    /* use optimized function if possible */
	    cnv=pArgs.converter;
	
	    if(cnv.preToULength>0) {
	        /*
	         * pass sourceIndex=-1 because we continue from an earlier buffer
	         * in the future, this may change with continuous offsets
	         */
	        UConverterExt.ucnv_extContinueMatchToU(cnv, pArgs, -1, pErrorCode);
	
	        if(ErrorCode.isFailure(pErrorCode[0]) || cnv.preToULength<0) {
	            return;
	        }
	    }
	
	    if(cnv.sharedData.mbcs.countStates==1) {
	        if((cnv.sharedData.mbcs.unicodeMask&UConverter.UCNV_HAS_SUPPLEMENTARY) == 0) {
	            ucnv_MBCSSingleToBMPWithOffsets(pArgs, pErrorCode);
	        } else {
	            ucnv_MBCSSingleToUnicodeWithOffsets(pArgs, pErrorCode);
	        }
	        return;
	    }
	
	    /* set up the local pointers */
			sourceArray = pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
			targetArray = pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    targetLimit=pArgs.targetLimit;
	    offsetsArray=pArgs.offsetsArray;
			offsetsArrayIndex = pArgs.offsetsBegin;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        stateTable=cnv.sharedData.mbcs.swapLFNLStateTable;
	    } else {
	        stateTable=cnv.sharedData.mbcs.stateTable;
	    }
	    unicodeCodeUnits=cnv.sharedData.mbcs.unicodeCodeUnits;
	
	    /* get the converter state from UConverter */
	    offset=(int)cnv.toUnicodeStatus;
	    byteIndex=cnv.toULength;
	    bytes=cnv.toUBytesArray;
	
	    /*
	     * if we are in the SBCS state for a DBCS-only converter,
	     * then load the DBCS state from the MBCS data
	     * (dbcsOnlyState==0 if it is not a DBCS-only converter)
	     */
	    if((state=(byte)(cnv.mode))==0) {
	        state=cnv.sharedData.mbcs.dbcsOnlyState;
	    }
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex=byteIndex==0 ? 0 : -1;
	    nextSourceIndex=0;
	
	    /* conversion loop */
	    while(sourceArrayIndex<sourceLimit) {
	        /*
	         * This following test is to see if available input would overflow the output.
	         * It does not catch output of more than one code unit that
	         * overflows as a result of a surrogate pair or callback output
	         * from the last source byte.
	         * Therefore, those situations also test for overflows and will
	         * then break the loop, too.
	         */
	        if(targetArrayIndex>=targetLimit) {
	            /* target is full */
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	
	        if(byteIndex==0) {
	            /* optimized loop for 1/2-byte input and BMP output */
	            if(offsetsArray==null) {
	                do {
	                    entry=stateTable[state][sourceArray[sourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK];
	                    if(MBCS_ENTRY_IS_TRANSITION(entry)) {
	                        state=(byte)MBCS_ENTRY_TRANSITION_STATE(entry);
	                        offset=MBCS_ENTRY_TRANSITION_OFFSET(entry);
	
	                        ++sourceArrayIndex;
	                        if( sourceArrayIndex<sourceLimit && 
															MBCS_ENTRY_IS_FINAL(entry=stateTable[state][sourceArray[sourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK]) && 
															MBCS_ENTRY_FINAL_ACTION(entry)==MBCS_STATE_VALID_16 && 
															(c=unicodeCodeUnits[offset+MBCS_ENTRY_FINAL_VALUE_16(entry)])<0xfffe) {
	                            ++sourceArrayIndex;
	                            targetArray[targetArrayIndex++]=c;
	                            state=(byte)MBCS_ENTRY_FINAL_STATE(entry); /* typically 0 */
	                            offset=0;
	                        } else {
	                            /* set the state and leave the optimized loop */
	                            bytes[0]=sourceArray[(sourceArrayIndex-1)];
	                            byteIndex=1;
	                            break;
	                        }
	                    } else {
	                        if(MBCS_ENTRY_FINAL_IS_VALID_DIRECT_16(entry)) {
	                            /* output BMP code point */
	                            ++sourceArrayIndex;
	                            targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	                            state=(byte)MBCS_ENTRY_FINAL_STATE(entry); /* typically 0 */
	                        } else {
	                            /* leave the optimized loop */
	                            break;
	                        }
	                    }
	                } while(sourceArrayIndex<sourceLimit && targetArrayIndex<targetLimit);
	            } else /* offsets!=NULL */ {
								//agljport:todo see ucnvmbcs.c for deleted block
	                do {
	                    entry=stateTable[state][sourceArray[sourceArrayIndex]];
	                    if(MBCS_ENTRY_IS_TRANSITION(entry)) {
	                        state=(byte)MBCS_ENTRY_TRANSITION_STATE(entry);
	                        offset=MBCS_ENTRY_TRANSITION_OFFSET(entry);
	
	                        ++sourceArrayIndex;
	                        if( sourceArrayIndex<sourceLimit &&
	                            MBCS_ENTRY_IS_FINAL(entry=stateTable[state][sourceArray[sourceArrayIndex]]) &&
	                            MBCS_ENTRY_FINAL_ACTION(entry)==MBCS_STATE_VALID_16 &&
	                            (c=unicodeCodeUnits[offset+MBCS_ENTRY_FINAL_VALUE_16(entry)])<0xfffe
	                        ) {
	                            ++sourceArrayIndex;
	                            targetArray[targetArrayIndex++]=c;
	                            if(offsetsArray!=null) {
	                                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                                sourceIndex=(nextSourceIndex+=2);
	                            }
	                            state=(byte)MBCS_ENTRY_FINAL_STATE(entry); /* typically 0 */
	                            offset=0;
	                        } else {
	                            /* set the state and leave the optimized loop */
	                            ++nextSourceIndex;
	                            bytes[0]=sourceArray[sourceArrayIndex-1];
	                            byteIndex=1;
	                            break;
	                        }
	                    } else {
	                        if(MBCS_ENTRY_FINAL_IS_VALID_DIRECT_16(entry)) {
	                            /* output BMP code point */
	                            ++sourceArrayIndex;
	                            targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	                            if(offsetsArray!=null) {
	                                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                                sourceIndex=++nextSourceIndex;
	                            }
	                            state=(byte)MBCS_ENTRY_FINAL_STATE(entry); /* typically 0 */
	                        } else {
	                            /* leave the optimized loop */
	                            break;
	                        }
	                    }
	                } while(sourceArrayIndex<sourceLimit && targetArrayIndex<targetLimit);
	            }
	
	            /*
	             * these tests and break statements could be put inside the loop
	             * if C had "break outerLoop" like Java
	             */
	            if(sourceArrayIndex>=sourceLimit) {
	                break;
	            }
	            if(targetArrayIndex>=targetLimit) {
	                /* target is full */
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                break;
	            }
	
	            ++nextSourceIndex;
	            bytes[byteIndex++]=sourceArray[sourceArrayIndex++];
	        } else /* byteIndex>0 */ {
	            ++nextSourceIndex;
	            entry=stateTable[state][(bytes[byteIndex++]=sourceArray[sourceArrayIndex++]) & UConverterUtility.UNSIGNED_BYTE_MASK];
	        }
	
	        if(MBCS_ENTRY_IS_TRANSITION(entry)) {
	            state=(byte)MBCS_ENTRY_TRANSITION_STATE(entry);
	            offset+=MBCS_ENTRY_TRANSITION_OFFSET(entry);
	            continue;
	        }
	
	        /* save the previous state for proper extension mapping with SI/SO-stateful converters */
	        cnv.mode=state;
	
	        /* set the next state early so that we can reuse the entry variable */
	        state=(byte)MBCS_ENTRY_FINAL_STATE(entry); /* typically 0 */
	
	        /*
	         * An if-else-if chain provides more reliable performance for
	         * the most common cases compared to a switch.
	         */
	        action=(byte)(MBCS_ENTRY_FINAL_ACTION(entry));
	        if(action==MBCS_STATE_VALID_16) {
	            offset+=MBCS_ENTRY_FINAL_VALUE_16(entry);
	            c=unicodeCodeUnits[offset];
	            if(c<0xfffe) {
	                /* output BMP code point */
	                targetArray[targetArrayIndex++]=c;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                byteIndex=0;
	            } else if(c==0xfffe) {
	                if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv) && (entry=(int)ucnv_MBCSGetFallback(cnv.sharedData.mbcs, offset))!=0xfffe) {
	                    /* output fallback BMP code point */
	                    targetArray[targetArrayIndex++]=(char)entry;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                    byteIndex=0;
	                }
	            } else {
	                /* callback(illegal) */
	                pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            }
	        } else if(action==MBCS_STATE_VALID_DIRECT_16) {
	            /* output BMP code point */
	            targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	            if(offsetsArray!=null) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	            }
	            byteIndex=0;
	        } else if(action==MBCS_STATE_VALID_16_PAIR) {
	            offset+=MBCS_ENTRY_FINAL_VALUE_16(entry);
	            c=unicodeCodeUnits[offset++];
	            if(c<0xd800) {
	                /* output BMP code point below 0xd800 */
	                targetArray[targetArrayIndex++]=c;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                byteIndex=0;
	            } else if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv) ? c<=0xdfff : c<=0xdbff) {
	                /* output roundtrip or fallback surrogate pair */
	                targetArray[targetArrayIndex++]=(char)(c&0xdbff);
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                byteIndex=0;
	                if(targetArrayIndex<targetLimit) {
	                    targetArray[targetArrayIndex++]=unicodeCodeUnits[offset];
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                } else {
	                    /* target overflow */
	                    cnv.UCharErrorBufferArray[0]=unicodeCodeUnits[offset];
	                    cnv.UCharErrorBufferLength=1;
	                    pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	
	                    offset=0;
	                    break;
	                }
	            } else if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv) ? (c&0xfffe)==0xe000 : c==0xe000) {
	                /* output roundtrip BMP code point above 0xd800 or fallback BMP code point */
	                targetArray[targetArrayIndex++]=unicodeCodeUnits[offset];
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                byteIndex=0;
	            } else if(c==0xffff) {
	                /* callback(illegal) */
	                pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            }
	        } else if(action==MBCS_STATE_VALID_DIRECT_20 ||
	                  (action==MBCS_STATE_FALLBACK_DIRECT_20 && UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv))
	        ) {
	            entry=MBCS_ENTRY_FINAL_VALUE(entry);
	            /* output surrogate pair */
	            targetArray[targetArrayIndex++]=(char)(0xd800|(char)(entry>>10));
	            if(offsetsArray!=null) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex;
	            }
	            byteIndex=0;
	            c=(char)(0xdc00|(char)(entry&0x3ff));
	            if(targetArrayIndex<targetLimit) {
	                targetArray[targetArrayIndex++]=c;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	            } else {
	                /* target overflow */
	                cnv.UCharErrorBufferArray[0]=c;
	                cnv.UCharErrorBufferLength=1;
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	
	                offset=0;
	                break;
	            }
	        } else if(action==MBCS_STATE_CHANGE_ONLY) {
	            /*
	             * This serves as a state change without any output.
	             * It is useful for reading simple stateful encodings,
	             * for example using just Shift-In/Shift-Out codes.
	             * The 21 unused bits may later be used for more sophisticated
	             * state transitions.
	             */
	            if(cnv.sharedData.mbcs.dbcsOnlyState==0) {
	                byteIndex=0;
	            } else {
	                /* SI/SO are illegal for DBCS-only conversion */
	                state=(byte)(cnv.mode); /* restore the previous state */
	
	                /* callback(illegal) */
	                pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            }
	        } else if(action==MBCS_STATE_FALLBACK_DIRECT_16) {
	            if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv)) {
	                /* output BMP code point */
	                targetArray[targetArrayIndex++]=(char)MBCS_ENTRY_FINAL_VALUE_16(entry);
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                byteIndex=0;
	            }
	        } else if(action==MBCS_STATE_UNASSIGNED) {
	            /* just fall through */
	        } else if(action==MBCS_STATE_ILLEGAL) {
	            /* callback(illegal) */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        } else {
	            /* reserved, must never occur */
	            byteIndex=0;
	        }
	
	        /* end of action codes: prepare for a new character */
	        offset=0;
	
	        if(byteIndex==0) {
	            sourceIndex=nextSourceIndex;
	        } else if(ErrorCode.isFailure(pErrorCode[0])) {
	            /* callback(illegal) */
	            break;
	        } else /* unassigned sequences indicated with byteIndex>0 */ {
	            /* try an extension mapping */
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
							int[] sourceArrayBegin = new int[] {sourceArrayIndex};
							int[] targetArrayBegin = new int[] {targetArrayIndex};
							int[] offsetsArrayBegin = new int[] {offsetsArrayIndex};
	            byteIndex=_extToU(cnv, cnv.sharedData, byteIndex, sourceArray, sourceArrayBegin, sourceLimit, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, pArgs.flush, pErrorCode);
							sourceArrayIndex = sourceArrayBegin[0];
							targetArrayIndex = targetArrayBegin[0];
							offsetsArrayIndex = offsetsArrayBegin[0];
	            sourceIndex=nextSourceIndex+(int)(sourceArrayIndex-pArgs.sourceBegin);
	
	            if(ErrorCode.isFailure(pErrorCode[0])) {
	                /* not mappable or buffer overflow */
	                break;
	            }
	        }
	    }
	
	    /* set the converter state back into UConverter */
	    cnv.toUnicodeStatus=offset;
	    cnv.mode=state;
	    cnv.toULength=byteIndex;
	
	    /* write back the updated pointers */
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetBegin=targetArrayIndex;
			pArgs.offsetsArray = offsetsArray;
			pArgs.offsetsBegin = offsetsArrayIndex;
	}
	
	/* MBCS-from-Unicode conversion functions ----------------------------------- */
	
	// function made out of block labeled unassigned in ucnv_MBCSDoubleFromUnicodeWithOffsets
	private final boolean unassignedDouble(UConverter cnv, UConverterFromUnicodeArgs pArgs, char[] sourceArray, int sourceLimit, int sourceIndex, byte[] targetArray, SideEffectsDouble x, int[] pErrorCode)
	{
	/*agljport:change original block
	unassigned:
		pArgs->source=source;
		c=_extFromU(cnv, cnv->sharedData,
				c, &source, sourceLimit,
				(char **)&target, (char *)target+targetCapacity,
				&offsets, sourceIndex,
				pArgs->flush,
				pErrorCode);
		nextSourceIndex+=(int32_t)(source-pArgs->source);
	
		if(U_FAILURE(*pErrorCode)) {
			break;
		} else {
	
			targetCapacity=pArgs->targetLimit-(char *)target;
			sourceIndex=nextSourceIndex;
			continue;
		}
	*/
		/* try an extension mapping */
		pArgs.sourceArray=sourceArray;
		pArgs.sourceBegin = x.sourceArrayIndex;
		int[] sourceArrayIndex = new int[] {x.sourceArrayIndex};
		int[] targetArrayIndex = new int[] {x.targetArrayIndex};
		int[] offsetsArrayIndex = new int[] {0};
		x.c=_extFromU(cnv, cnv.sharedData, x.c, sourceArray, sourceArrayIndex, sourceLimit, targetArray, targetArrayIndex, x.targetArrayIndex+x.targetCapacity, null, offsetsArrayIndex, sourceIndex, pArgs.flush, pErrorCode);
		x.sourceArrayIndex = sourceArrayIndex[0];
		x.targetArrayIndex = targetArrayIndex[0];
	
		x.nextSourceIndex+=x.sourceArrayIndex-pArgs.sourceBegin;
	
		if(ErrorCode.isFailure(pErrorCode[0])) {
			/* not mappable or buffer overflow */
			return false;
		} else {
			/* a mapping was written to the target, continue */
	
			/* recalculate the targetCapacity after an extension mapping */
			x.targetCapacity=pArgs.targetLimit-x.targetArrayIndex;
	
			/* normal end of conversion: prepare for a new character */
			x.sourceIndex=x.nextSourceIndex;
			return true;
		}
	}
	
	private final class SideEffectsDouble {
		int c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity;
		public SideEffectsDouble(int c_, int sourceArrayIndex_, int sourceIndex_, int nextSourceIndex_, int targetArrayIndex_, int targetCapacity_)
		{
			c = c_;
			sourceArrayIndex = sourceArrayIndex_;
			sourceIndex = sourceIndex_;
			nextSourceIndex = nextSourceIndex_;
			targetArrayIndex = targetArrayIndex_;
			targetCapacity = targetCapacity_;
		}
	}
	
	// function made out of block labeled getTrail in ucnv_MBCSDoubleFromUnicodeWithOffsets
	// assumes input c is lead surrogate
	private final boolean getTrailDouble(UConverter cnv, UConverterFromUnicodeArgs pArgs, char[] sourceArray, int sourceLimit, int sourceIndex, byte[] targetArray, int unicodeMask, SideEffectsDouble x, int[] pErrorCode)
	{
	/*agljport:change original block
	getTrail:
		if(source<sourceLimit) {
			UChar trail=*source;
			if(UTF_IS_SECOND_SURROGATE(trail)) {
				++source;
				++nextSourceIndex;
				c=UTF16_GET_PAIR_VALUE(c, trail);
				if(!(unicodeMask&UCNV_HAS_SUPPLEMENTARY)) {
					goto unassigned;
				}
			} else {
				*pErrorCode=U_ILLEGAL_CHAR_FOUND;
				break;
			}
		} else {
			break;
		}
	*/
		if(x.sourceArrayIndex<sourceLimit) {
			/* test the following code unit */
			char trail=sourceArray[x.sourceArrayIndex];
			if(UConverterUTF16.U16_IS_TRAIL(trail)) {
				++x.sourceArrayIndex;
				++x.nextSourceIndex;
				x.c=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)x.c, trail);
				if((unicodeMask&UConverter.UCNV_HAS_SUPPLEMENTARY) == 0) {
					/* BMP-only codepages are stored without stage 1 entries for supplementary code points */
					/* callback(unassigned) */
					return unassignedDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, x, pErrorCode);
				}
				/* convert this supplementary code point */
				/* exit this condition tree */
			} else {
				/* this is an unmatched lead code unit (1st surrogate) */
				/* callback(illegal) */
				pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
				return false;
			}
		} else {
			/* no more input */
			return false;
		}
		return true;
	}
	/* This version of ucnv_MBCSFromUnicodeWithOffsets() is optimized for double-byte codepages. */
	//static void ucnv_MBCSDoubleFromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode) 
	void ucnv_MBCSDoubleFromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode) 
	{
	    UConverter cnv;
	    char[] sourceArray;
			int sourceArrayIndex,	sourceLimit;
	    byte[] targetArray;
			int targetArrayIndex;
	    int targetCapacity;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    char[] table;
	    byte[] bytes;
	
	    int c;
	
	    int sourceIndex, nextSourceIndex;
	
			/*agljport:change
	    uint32_t stage2Entry;
	    uint32_t value;
	    int32_t length;
	    uint8_t unicodeMask;
			*/
	    int stage2Entry;
	    int value;
	    int length;
	    short unicodeMask;
	
	    /* use optimized function if possible */
	    cnv=pArgs.converter;
	    unicodeMask=cnv.sharedData.mbcs.unicodeMask;
	
	    /* set up the local pointers */
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
			targetArrayIndex = pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    table=cnv.sharedData.mbcs.fromUnicodeTable;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        bytes=cnv.sharedData.mbcs.swapLFNLFromUnicodeBytes;
	    } else {
	        bytes=cnv.sharedData.mbcs.fromUnicodeBytes;
	    }
	
	    /* get the converter state from UConverter */
	    c=cnv.fromUChar32;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex= c==0 ? 0 : -1;
	    nextSourceIndex=0;
	
	    /* conversion loop */
			boolean doloop = true;
	    if(c!=0 && targetCapacity>0) {
					SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
					doloop = getTrailDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
					c = x.c;
					sourceArrayIndex = x.sourceArrayIndex;
					sourceIndex = x.sourceIndex;
					nextSourceIndex = x.nextSourceIndex;
					targetArrayIndex = x.targetArrayIndex;
					targetCapacity = x.targetCapacity;
	    }
	
			if(doloop) {
	    while(sourceArrayIndex<sourceLimit) {
	        /*
	         * This following test is to see if available input would overflow the output.
	         * It does not catch output of more than one byte that
	         * overflows as a result of a multi-byte character or callback output
	         * from the last source character.
	         * Therefore, those situations also test for overflows and will
	         * then break the loop, too.
	         */
	        if(targetCapacity>0) {
	            /*
	             * Get a correct Unicode code point:
	             * a single UChar for a BMP code point or
	             * a matched surrogate pair for a "supplementary code point".
	             */
	            c=sourceArray[sourceArrayIndex++];
	            ++nextSourceIndex;
	            /*
	             * This also tests if the codepage maps single surrogates.
	             * If it does, then surrogates are not paired but mapped separately.
	             * Note that in this case unmatched surrogates are not detected.
	             */
	            if(UConverterUTF.U_IS_SURROGATE(c) && (unicodeMask&UConverter.UCNV_HAS_SURROGATES) == 0) {
	                if(UConverterUTF.U_IS_SURROGATE_LEAD(c)) {
	//getTrail:
										SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
										doloop = getTrailDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
										c = x.c;
										sourceArrayIndex = x.sourceArrayIndex;
										sourceIndex = x.sourceIndex;
										nextSourceIndex = x.nextSourceIndex;
										targetArrayIndex = x.targetArrayIndex;
										targetCapacity = x.targetCapacity;
										if(doloop)
											continue;
										else
											break;
	                } else {
	                    /* this is an unmatched trail code unit (2nd surrogate) */
	                    /* callback(illegal) */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                    break;
	                }
	            }
	
	            /* convert the Unicode code point in c into codepage bytes */
	            stage2Entry=MBCS_STAGE_2_FROM_U(table, c);
	
	            /* get the bytes and the length for the output */
	            /* MBCS_OUTPUT_2 */
	            value=MBCS_VALUE_2_FROM_STAGE_2(bytes, stage2Entry, c);
							if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                length=1;
	            } else {
	                length=2;
	            }
	
	            /* is this code point assigned, or do we use fallbacks? */
	            if(!(MBCS_FROM_U_IS_ROUNDTRIP(stage2Entry, c) || (UConverterUtility.UCNV_FROM_U_USE_FALLBACK(cnv, c) && value!=0))
	            ) {
	                /*
	                 * We allow a 0 byte output if the "assigned" bit is set for this entry.
	                 * There is no way with this data structure for fallback output
	                 * to be a zero byte.
	                 */
	
	//unassigned:
								SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
								doloop = unassignedDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, x, pErrorCode);
								c = x.c;
								sourceArrayIndex = x.sourceArrayIndex;
								sourceIndex = x.sourceIndex;
								nextSourceIndex = x.nextSourceIndex;
								targetArrayIndex = x.targetArrayIndex;
								targetCapacity = x.targetCapacity;
								if(doloop)
									continue;
								else
									break;
	            }
	
	            /* write the output character bytes from value and length */
	            /* from the first if in the loop we know that targetCapacity>0 */
	            if(length==1) {
	                /* this is easy because we know that there is enough space */
	                targetArray[targetArrayIndex++]=(byte)value;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                --targetCapacity;
	            } else /* length==2 */ {
	                targetArray[targetArrayIndex++]=(byte)(value>>>8);
	                if(2<=targetCapacity) {
	                    targetArray[targetArrayIndex++]=(byte)value;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                    targetCapacity-=2;
	                } else {
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                    cnv.charErrorBufferArray[0]=(byte)value;
	                    cnv.charErrorBufferLength=1;
	
	                    /* target overflow */
	                    targetCapacity=0;
	                    pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    c=0;
	                    break;
	                }
	            }
	
	            /* normal end of conversion: prepare for a new character */
	            c=0;
	            sourceIndex=nextSourceIndex;
	            continue;
	        } else {
	            /* target is full */
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	    }
			}
	
	    /* set the converter state back into UConverter */
	    cnv.fromUChar32=c;
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/* This version of ucnv_MBCSFromUnicodeWithOffsets() is optimized for single-byte codepages. */
	//static void ucnv_MBCSSingleFromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	void ucnv_MBCSSingleFromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    char[] sourceArray;
			int sourceArrayIndex,	sourceLimit;
	    byte[] targetArray;
			int targetArrayIndex;
	    int targetCapacity;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    char[] table;
	    byte[] results; //agljport:comment results is used to to get 16-bit values out of byte[] array
	
	    int c;
	
	    int sourceIndex, nextSourceIndex;
	
	    char value, minValue;
	    //agljport:delete UBool hasSupplementary;
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
	    short unicodeMask;
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
			targetArrayIndex = pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    table=cnv.sharedData.mbcs.fromUnicodeTable;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        results=cnv.sharedData.mbcs.swapLFNLFromUnicodeBytes; //agljport:comment should swapLFNLFromUnicodeBytes be a ByteBuffer so results can be a 16-bit view of it?
	    } else {
	        results=cnv.sharedData.mbcs.fromUnicodeBytes; //agljport:comment should swapLFNLFromUnicodeBytes be a ByteBuffer so results can be a 16-bit view of it?
	    }
	
	    if(cnv.useFallback) {
	        /* use all roundtrip and fallback results */
	        minValue=0x800;
	    } else {
	        /* use only roundtrips and fallbacks from private-use characters */
	        minValue=0xc00;
	    }
			//agljport:comment hasSupplementary only used in getTrail block which now simply repeats the mask operation
	    unicodeMask=cnv.sharedData.mbcs.unicodeMask;
	
	    /* get the converter state from UConverter */
	    c=cnv.fromUChar32;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex= c==0 ? 0 : -1;
	    nextSourceIndex=0;
	
	    /* conversion loop */
			/*agljport:change 
	    if(c!=0 && targetCapacity>0) {
	        goto getTrail;
	    }
			*/
			boolean doloop = true;
	    if(c!=0 && targetCapacity>0) {
					SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
					doloop = getTrailDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
					c = x.c;
					sourceArrayIndex = x.sourceArrayIndex;
					sourceIndex = x.sourceIndex;
					nextSourceIndex = x.nextSourceIndex;
					targetArrayIndex = x.targetArrayIndex;
					targetCapacity = x.targetCapacity;
	    }
	
			if(doloop) {
	    while(sourceArrayIndex<sourceLimit) {
	        /*
	         * This following test is to see if available input would overflow the output.
	         * It does not catch output of more than one byte that
	         * overflows as a result of a multi-byte character or callback output
	         * from the last source character.
	         * Therefore, those situations also test for overflows and will
	         * then break the loop, too.
	         */
	        if(targetCapacity>0) {
	            /*
	             * Get a correct Unicode code point:
	             * a single UChar for a BMP code point or
	             * a matched surrogate pair for a "supplementary code point".
	             */
	            c=sourceArray[sourceArrayIndex++];
	            ++nextSourceIndex;
	            if(UConverterUTF.U_IS_SURROGATE(c)) {
	                if(UConverterUTF.U_IS_SURROGATE_LEAD(c)) {
	//getTrail:
										SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
										doloop = getTrailDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
										c = x.c;
										sourceArrayIndex = x.sourceArrayIndex;
										sourceIndex = x.sourceIndex;
										nextSourceIndex = x.nextSourceIndex;
										targetArrayIndex = x.targetArrayIndex;
										targetCapacity = x.targetCapacity;
										if(doloop)
											continue;
										else
											break;
	                } else {
	                    /* this is an unmatched trail code unit (2nd surrogate) */
	                    /* callback(illegal) */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                    break;
	                }
	            }
	
	            /* convert the Unicode code point in c into codepage bytes */
	            value=MBCS_SINGLE_RESULT_FROM_U(table, results, c);
	
	            /* is this code point assigned, or do we use fallbacks? */
	            if(value>=minValue) {
	                /* assigned, write the output character bytes from value and length */
	                /* length==1 */
	                /* this is easy because we know that there is enough space */
	                targetArray[targetArrayIndex++]=(byte)value;
	                if(offsetsArray!=null) {
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                }
	                --targetCapacity;
	
	                /* normal end of conversion: prepare for a new character */
	                c=0;
	                sourceIndex=nextSourceIndex;
	            } else { /* unassigned */
	//unassigned:
	                /* try an extension mapping */
								SideEffectsDouble x = new SideEffectsDouble(c, sourceArrayIndex, sourceIndex, nextSourceIndex, targetArrayIndex, targetCapacity);
								doloop = unassignedDouble(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, x, pErrorCode);
								c = x.c;
								sourceArrayIndex = x.sourceArrayIndex;
								sourceIndex = x.sourceIndex;
								nextSourceIndex = x.nextSourceIndex;
								targetArrayIndex = x.targetArrayIndex;
								targetCapacity = x.targetCapacity;
								if(!doloop)
									break;
	            }
	        } else {
	            /* target is full */
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	    }
			}
	
	    /* set the converter state back into UConverter */
	    cnv.fromUChar32=c;
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	private final class SideEffectsSingleBMP {
		int c, sourceArrayIndex;
		public SideEffectsSingleBMP(int c_, int sourceArrayIndex_)
		{
			c = c_;
			sourceArrayIndex = sourceArrayIndex_;
		}
	}
	
	// function made out of block labeled getTrail in ucnv_MBCSDoubleFromUnicodeWithOffsets
	// assumes input c is lead surrogate
	private final boolean getTrailSingleBMP(char[] sourceArray, int sourceLimit, SideEffectsSingleBMP x, int[] pErrorCode)
	{
	/*agljport:change original block
	getTrail:
		if(source<sourceLimit) {
			UChar trail=*source;
			if(UTF_IS_SECOND_SURROGATE(trail)) {
				++source;
				c=UTF16_GET_PAIR_VALUE(c, trail);
			} else {
				*pErrorCode=U_ILLEGAL_CHAR_FOUND;
				break;
			}
		} else {
			break;
		}
	*/
		if(x.sourceArrayIndex<sourceLimit) {
			/* test the following code unit */
			char trail=sourceArray[x.sourceArrayIndex];
			if(UConverterUTF16.U16_IS_TRAIL(trail)) {
				++x.sourceArrayIndex;
				x.c=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)x.c, trail);
				/* this codepage does not map supplementary code points */
				/* callback(unassigned) */
			} else {
				/* this is an unmatched lead code unit (1st surrogate) */
				/* callback(illegal) */
				pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
				return false;
			}
		} else {
			/* no more input */
			return false;
		}
		return true;
	}
	/*
	 * This version of ucnv_MBCSFromUnicode() is optimized for single-byte codepages
	 * that map only to and from the BMP.
	 * In addition to single-byte/state optimizations, the offset calculations
	 * become much easier.
	 */
	//static void ucnv_MBCSSingleFromBMPWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	void ucnv_MBCSSingleFromBMPWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
			char[] sourceArray;
	    int sourceArrayIndex, sourceLimit, lastSource;
	    byte[] targetArray;
			int targetArrayIndex;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    char[] table;
	    byte[] results;
	
	    int c;
	
	    int sourceIndex;
	
	    char value, minValue;
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
			targetArrayIndex = pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    table=cnv.sharedData.mbcs.fromUnicodeTable;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        results=cnv.sharedData.mbcs.swapLFNLFromUnicodeBytes; //agljport:comment should swapLFNLFromUnicodeBytes be a ByteBuffer so results can be a 16-bit view of it?
	    } else {
	        results=cnv.sharedData.mbcs.fromUnicodeBytes; //agljport:comment should swapLFNLFromUnicodeBytes be a ByteBuffer so results can be a 16-bit view of it?
	    }
	
	    if(cnv.useFallback) {
	        /* use all roundtrip and fallback results */
	        minValue=0x800;
	    } else {
	        /* use only roundtrips and fallbacks from private-use characters */
	        minValue=0xc00;
	    }
	
	    /* get the converter state from UConverter */
	    c=cnv.fromUChar32;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex= c==0 ? 0 : -1;
	    lastSource=sourceArrayIndex;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=sourceLimit-sourceArrayIndex;
	    if(length<targetCapacity) {
	        targetCapacity=length;
	    }
	
	    /* conversion loop */
			/*agljport:change 
	    if(c!=0 && targetCapacity>0) {
	        goto getTrail;
	    }
			*/
			boolean doloop = true;
	    if(c!=0 && targetCapacity>0) {
					SideEffectsSingleBMP x = new SideEffectsSingleBMP(c, sourceArrayIndex);
					doloop = getTrailSingleBMP(sourceArray, sourceLimit, x, pErrorCode);
					c = x.c;
					sourceArrayIndex = x.sourceArrayIndex;
	    }
	
	//agljport:delete #if MBCS_UNROLL_SINGLE_FROM_BMP
	//agljport:delete unrolled:
	//agljport:comment deleted unrolled loop
	//agljport:delete #endif
	
			if(doloop) {
	    while(targetCapacity>0) {
	        /*
	         * Get a correct Unicode code point:
	         * a single UChar for a BMP code point or
	         * a matched surrogate pair for a "supplementary code point".
	         */
	        c=sourceArray[sourceArrayIndex++];
	        /*
	         * Do not immediately check for single surrogates:
	         * Assume that they are unassigned and check for them in that case.
	         * This speeds up the conversion of assigned characters.
	         */
	        /* convert the Unicode code point in c into codepage bytes */
	        value=MBCS_SINGLE_RESULT_FROM_U(table, results, c);
	
	        /* is this code point assigned, or do we use fallbacks? */
	        if(value>=minValue) {
	            /* assigned, write the output character bytes from value and length */
	            /* length==1 */
	            /* this is easy because we know that there is enough space */
	            targetArray[targetArrayIndex++]=(byte)value;
	            --targetCapacity;
	
	            /* normal end of conversion: prepare for a new character */
	            c=0;
	            continue;
	        } else if(!UConverterUTF.U_IS_SURROGATE(c)) {
	            /* normal, unassigned BMP character */
	        } else if(UConverterUTF.U_IS_SURROGATE_LEAD(c)) {
	//getTrail:
							SideEffectsSingleBMP x = new SideEffectsSingleBMP(c, sourceArrayIndex);
							doloop = getTrailSingleBMP(sourceArray, sourceLimit, x, pErrorCode);
							c = x.c;
							sourceArrayIndex = x.sourceArrayIndex;
							if(!doloop)
								break;
	        } else {
	            /* this is an unmatched trail code unit (2nd surrogate) */
	            /* callback(illegal) */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break;
	        }
	
	        /* c does not have a mapping */
	
	        /* get the number of code units for c to correctly advance sourceIndex */
	        length=UConverterUTF16.U16_LENGTH(c);
	
	        /* set offsets since the start or the last extension */
	        if(offsetsArray!=null) {
	            int count=sourceArrayIndex-lastSource;
	
	            /* do not set the offset for this character */
	            count-=length;
	
	            while(count>0) {
	                offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	                --count;
	            }
	            /* offsets and sourceIndex are now set for the current character */
	        }
	
	        /* try an extension mapping */
	        lastSource=sourceArrayIndex;
					int[] sourceBegin = new int[] {sourceArrayIndex};
					int[] targetBegin = new int[] {targetArrayIndex};
					int[] offsetsBegin = new int[] {offsetsArrayIndex};
	        c=_extFromU(cnv, cnv.sharedData, c, sourceArray, sourceBegin, sourceLimit, targetArray, targetBegin, targetArrayIndex+targetCapacity, offsetsArray, offsetsBegin, sourceIndex, pArgs.flush, pErrorCode);
					sourceArrayIndex = sourceBegin[0];
					targetArrayIndex = targetBegin[0];
					offsetsArrayIndex = offsetsBegin[0];
	        sourceIndex+=length+(sourceArrayIndex-lastSource);
	        lastSource=sourceArrayIndex;
	
	        if(ErrorCode.isFailure(pErrorCode[0])) {
	            /* not mappable or buffer overflow */
	            break;
	        } else {
	            /* a mapping was written to the target, continue */
	
	            /* recalculate the targetCapacity after an extension mapping */
	            targetCapacity=pArgs.targetLimit-targetArrayIndex;
	            length=sourceLimit-sourceArrayIndex;
	            if(length<targetCapacity) {
	                targetCapacity=length;
	            }
	        }
	
	//agljport:delete #if MBCS_UNROLL_SINGLE_FROM_BMP
	        /* unrolling makes it slower on Pentium III/Windows 2000?! */
	        //agljport:delete goto unrolled;
	//agljport:delete #endif
	    }
			}
	
	    if(ErrorCode.isSuccess(pErrorCode[0]) && sourceArrayIndex<sourceLimit && targetArrayIndex>=pArgs.targetLimit) {
	        /* target is full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* set offsets since the start or the last callback */
	    if(offsetsArray!=null) {
	        int count=sourceArrayIndex-lastSource;
	        while(count>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --count;
	        }
	    }
	
	    /* set the converter state back into UConverter */
	    cnv.fromUChar32=c;
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	
	// function made out of block labeled unassigned in ucnv_MBCSFromUnicodeWithOffsets
	private final boolean unassigned(UConverter cnv, UConverterFromUnicodeArgs pArgs, char[] sourceArray, int sourceLimit, int sourceIndex, byte[] targetArray, int[] offsets, SideEffects x, int[] pErrorCode)
	{
	/*agljport:change original block
	unassigned:
		pArgs->source=source;
		c=_extFromU(cnv, cnv->sharedData,
				c, &source, sourceLimit,
				(char **)&target, (char *)target+targetCapacity,
				&offsets, sourceIndex,
				pArgs->flush,
				pErrorCode);
		nextSourceIndex+=(int32_t)(source-pArgs->source);
		prevLength=cnv->fromUnicodeStatus;
	
		if(U_FAILURE(*pErrorCode)) {
			break;
		} else {
	
			targetCapacity=pArgs->targetLimit-(char *)target;
	
			if(offsets!=NULL) {
				prevSourceIndex=sourceIndex;
				sourceIndex=nextSourceIndex;
			}
			continue;
		}
	*/
		/* try an extension mapping */
		pArgs.sourceArray=sourceArray;
		pArgs.sourceBegin = x.sourceArrayIndex;
		int[] sourceArrayIndex = new int[] {x.sourceArrayIndex};
		int[] targetArrayIndex = new int[] {x.targetArrayIndex};
		int[] offsetsArrayIndex = new int[] {0};
		x.c=_extFromU(cnv, cnv.sharedData, x.c, sourceArray, sourceArrayIndex, sourceLimit, targetArray, targetArrayIndex, x.targetArrayIndex+x.targetCapacity, null, offsetsArrayIndex, sourceIndex, pArgs.flush, pErrorCode);
		x.sourceArrayIndex = sourceArrayIndex[0];
		x.targetArrayIndex = targetArrayIndex[0];
	
		x.nextSourceIndex+=x.sourceArrayIndex-pArgs.sourceBegin;
		x.prevLength=(int)cnv.fromUnicodeStatus;
	
		if(ErrorCode.isFailure(pErrorCode[0])) {
			/* not mappable or buffer overflow */
			return false;
		} else {
			/* a mapping was written to the target, continue */
	
			/* recalculate the targetCapacity after an extension mapping */
			x.targetCapacity=pArgs.targetLimit-x.targetArrayIndex;
	
			/* normal end of conversion: prepare for a new character */
			if(offsets!=null) {
				x.prevSourceIndex=x.sourceIndex;
				x.sourceIndex=x.nextSourceIndex;
			}
			return true;
		}
	}
	
	private final class SideEffects {
		int c, sourceArrayIndex, sourceIndex, nextSourceIndex, prevSourceIndex, targetArrayIndex, targetCapacity, prevLength;
		public SideEffects(int c_, int sourceArrayIndex_, int sourceIndex_, int nextSourceIndex_, int prevSourceIndex_, int targetArrayIndex_, int targetCapacity_, int prevLength_)
		{
			c = c_;
			sourceArrayIndex = sourceArrayIndex_;
			sourceIndex = sourceIndex_;
			nextSourceIndex = nextSourceIndex_;
			prevSourceIndex = prevSourceIndex_;
			targetArrayIndex = targetArrayIndex_;
			targetCapacity = targetCapacity_;
			prevLength = prevLength_;
		}
	}
	
	// function made out of block labeled getTrail in ucnv_MBCSFromUnicodeWithOffsets
	// assumes input c is lead surrogate
	private final boolean getTrail(UConverter cnv, UConverterFromUnicodeArgs pArgs, char[] sourceArray, int sourceLimit, int sourceIndex, byte[] targetArray, int unicodeMask, SideEffects x, int[] pErrorCode)
	{
	/*agljport:change original block
	getTrail:
		if(source<sourceLimit) {
			UChar trail=*source;
			if(UTF_IS_SECOND_SURROGATE(trail)) {
				++source;
				++nextSourceIndex;
				c=UTF16_GET_PAIR_VALUE(c, trail);
				if(!(unicodeMask&UCNV_HAS_SUPPLEMENTARY)) {
					cnv->fromUnicodeStatus=prevLength;
					goto unassigned;
				}
			} else {
				*pErrorCode=U_ILLEGAL_CHAR_FOUND;
				break;
			}
		} else {
			break;
		}
	*/
		if(x.sourceArrayIndex<sourceLimit) {
			/* test the following code unit */
			char trail=sourceArray[x.sourceArrayIndex];
			if(UConverterUTF16.U16_IS_TRAIL(trail)) {
				++x.sourceArrayIndex;
				++x.nextSourceIndex;
				x.c=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)x.c, trail);
				if((unicodeMask&UConverter.UCNV_HAS_SUPPLEMENTARY) == 0) {
					/* BMP-only codepages are stored without stage 1 entries for supplementary code points */
					cnv.fromUnicodeStatus=x.prevLength; /* save the old state */
					/* callback(unassigned) */
					return unassigned(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, null, x, pErrorCode);
				}
				/* convert this supplementary code point */
				/* exit this condition tree */
			} else {
				/* this is an unmatched lead code unit (1st surrogate) */
				/* callback(illegal) */
				pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
				return false;
			}
		} else {
			/* no more input */
			return false;
		}
		return true;
	}
	
	//U_CFUNC void ucnv_MBCSFromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	void ucnv_MBCSFromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] /*UErrorCode* */pErrorCode)
	{
	    UConverter cnv;
	    char[] sourceArray;
			int sourceArrayIndex,	sourceLimit;
	    byte[] targetArray;
			int targetArrayIndex;
	    int targetCapacity;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    char[] table;
	    byte[] pArray, bytes;
			int pArrayIndex;
			int outputType;
	
	    int c;
	
	    int prevSourceIndex, sourceIndex, nextSourceIndex;
	
			/*agljport:change
	    uint32_t stage2Entry;
	    uint32_t value;
	    int32_t length, prevLength;
	    uint8_t unicodeMask;
			*/
	    int stage2Entry;
	    int value;
	    int length, prevLength;
	    short unicodeMask;
	
	    cnv=pArgs.converter;
	
	    if(cnv.preFromUFirstCP>=0) {
	        /*
	         * pass sourceIndex=-1 because we continue from an earlier buffer
	         * in the future, this may change with continuous offsets
	         */
	        UConverterExt.ucnv_extContinueMatchFromU(cnv, pArgs, -1, pErrorCode);
	
	        if(ErrorCode.isFailure(pErrorCode[0]) || cnv.preFromULength<0) {
	            return;
	        }
	    }
	
	    /* use optimized function if possible */
	    outputType=cnv.sharedData.mbcs.outputType;
	    unicodeMask=cnv.sharedData.mbcs.unicodeMask;
	    if(outputType==MBCS_OUTPUT_1 && (unicodeMask&UConverter.UCNV_HAS_SURROGATES) == 0) {
	        if((unicodeMask&UConverter.UCNV_HAS_SUPPLEMENTARY) == 0) {
	            ucnv_MBCSSingleFromBMPWithOffsets(pArgs, pErrorCode);
	        } else {
	            ucnv_MBCSSingleFromUnicodeWithOffsets(pArgs, pErrorCode);
	        }
	        return;
	    } else if(outputType==MBCS_OUTPUT_2) {
	        ucnv_MBCSDoubleFromUnicodeWithOffsets(pArgs, pErrorCode);
	        return;
	    }
	
	    /* set up the local pointers */
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex = pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
	    targetArray=pArgs.targetArray;
			targetArrayIndex = pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    table=cnv.sharedData.mbcs.fromUnicodeTable;
	
	    if((cnv.options&UConverter.UCNV_OPTION_SWAP_LFNL)!=0) {
	        bytes=cnv.sharedData.mbcs.swapLFNLFromUnicodeBytes;
	    } else {
	        bytes=cnv.sharedData.mbcs.fromUnicodeBytes;
	    }
	
	    /* get the converter state from UConverter */
	    c=cnv.fromUChar32;
	
	    if(outputType==MBCS_OUTPUT_2_SISO) {
	        prevLength=(int)cnv.fromUnicodeStatus;
	        if(prevLength==0) {
	            /* set the real value */
	            prevLength=1;
	        }
	    } else {
	        /* prevent fromUnicodeStatus from being set to something non-0 */
	        prevLength=0;
	    }
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    prevSourceIndex=-1;
	    sourceIndex= c==0 ? 0 : -1;
	    nextSourceIndex=0;
	
	    /* conversion loop */
	    /*
	     * This is another piece of ugly code:
	     * A goto into the loop if the converter state contains a first surrogate
	     * from the previous function call.
	     * It saves me to check in each loop iteration a check of if(c==0)
	     * and duplicating the trail-surrogate-handling code in the else
	     * branch of that check.
	     * I could not find any other way to get around this other than
	     * using a function call for the conversion and callback, which would
	     * be even more inefficient.
	     *
	     * Markus Scherer 2000-jul-19
	     */
			boolean doloop = true;
	    if(c!=0 && targetCapacity>0) {
					SideEffects x = new SideEffects(c, sourceArrayIndex, sourceIndex, nextSourceIndex, prevSourceIndex, targetArrayIndex, targetCapacity, prevLength);
					doloop = getTrail(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
					c = x.c;
					sourceArrayIndex = x.sourceArrayIndex;
					sourceIndex = x.sourceIndex;
					nextSourceIndex = x.nextSourceIndex;
					prevSourceIndex = x.prevSourceIndex;
					targetArrayIndex = x.targetArrayIndex;
					targetCapacity = x.targetCapacity;
					prevLength = x.prevLength;
	    }
	
			if(doloop) {
	    while(sourceArrayIndex<sourceLimit) {
	        /*
	         * This following test is to see if available input would overflow the output.
	         * It does not catch output of more than one byte that
	         * overflows as a result of a multi-byte character or callback output
	         * from the last source character.
	         * Therefore, those situations also test for overflows and will
	         * then break the loop, too.
	         */
	        if(targetCapacity>0) {
	            /*
	             * Get a correct Unicode code point:
	             * a single UChar for a BMP code point or
	             * a matched surrogate pair for a "supplementary code point".
	             */
	            c=sourceArray[sourceArrayIndex++];
	            ++nextSourceIndex;
	            /*
	             * This also tests if the codepage maps single surrogates.
	             * If it does, then surrogates are not paired but mapped separately.
	             * Note that in this case unmatched surrogates are not detected.
	             */
	            if(UConverterUTF.U_IS_SURROGATE(c) && (unicodeMask&UConverter.UCNV_HAS_SURROGATES) == 0) {
	                if(UConverterUTF.U_IS_SURROGATE_LEAD(c)) {
	//getTrail:
										SideEffects x = new SideEffects(c, sourceArrayIndex, sourceIndex, nextSourceIndex, prevSourceIndex, targetArrayIndex, targetCapacity, prevLength);
										doloop = getTrail(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, unicodeMask, x, pErrorCode);
										c = x.c;
										sourceArrayIndex = x.sourceArrayIndex;
										sourceIndex = x.sourceIndex;
										nextSourceIndex = x.nextSourceIndex;
										prevSourceIndex = x.prevSourceIndex;
										targetArrayIndex = x.targetArrayIndex;
										if(doloop)
											continue;
										else
											break;
	                } else {
	                    /* this is an unmatched trail code unit (2nd surrogate) */
	                    /* callback(illegal) */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                    break;
	                }
	            }
	
	            /* convert the Unicode code point in c into codepage bytes */
	
	            /*
	             * The basic lookup is a triple-stage compact array (trie) lookup.
	             * For details see the beginning of this file.
	             *
	             * Single-byte codepages are handled with a different data structure
	             * by _MBCSSingle... functions.
	             *
	             * The result consists of a 32-bit value from stage 2 and
	             * a pointer to as many bytes as are stored per character.
	             * The pointer points to the character's bytes in stage 3.
	             * Bits 15..0 of the stage 2 entry contain the stage 3 index
	             * for that pointer, while bits 31..16 are flags for which of
	             * the 16 characters in the block are roundtrip-assigned.
	             *
	             * For 2-byte and 4-byte codepages, the bytes are stored as uint16_t
	             * respectively as uint32_t, in the platform encoding.
	             * For 3-byte codepages, the bytes are always stored in big-endian order.
	             *
	             * For EUC encodings that use only either 0x8e or 0x8f as the first
	             * byte of their longest byte sequences, the first two bytes in
	             * this third stage indicate with their 7th bits whether these bytes
	             * are to be written directly or actually need to be preceeded by
	             * one of the two Single-Shift codes. With this, the third stage
	             * stores one byte fewer per character than the actual maximum length of
	             * EUC byte sequences.
	             *
	             * Other than that, leading zero bytes are removed and the other
	             * bytes output. A single zero byte may be output if the "assigned"
	             * bit in stage 2 was on.
	             * The data structure does not support zero byte output as a fallback,
	             * and also does not allow output of leading zeros.
	             */
	            stage2Entry=MBCS_STAGE_2_FROM_U(table, c);
	
	            /* get the bytes and the length for the output */
	            switch(outputType) {
	            case MBCS_OUTPUT_2:
	                value=MBCS_VALUE_2_FROM_STAGE_2(bytes, stage2Entry, c);
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    length=1;
	                } else {
	                    length=2;
	                }
	                break;
	            case MBCS_OUTPUT_2_SISO:
	                /* 1/2-byte stateful with Shift-In/Shift-Out */
	                /*
	                 * Save the old state in the converter object
	                 * right here, then change the local prevLength state variable if necessary.
	                 * Then, if this character turns out to be unassigned or a fallback that
	                 * is not taken, the callback code must not save the new state in the converter
	                 * because the new state is for a character that is not output.
	                 * However, the callback must still restore the state from the converter
	                 * in case the callback function changed it for its output.
	                 */
	                cnv.fromUnicodeStatus=prevLength; /* save the old state */
	                value=MBCS_VALUE_2_FROM_STAGE_2(bytes, stage2Entry, c);
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    if(value==0 && MBCS_FROM_U_IS_ROUNDTRIP(stage2Entry, c)==false) {
	                        /* no mapping, leave value==0 */
	                        length=0;
	                    } else if(prevLength<=1) {
	                        length=1;
	                    } else {
	                        /* change from double-byte mode to single-byte */
	                        value|=UConverter.UCNV_SI<<8;
	                        length=2;
	                        prevLength=1;
	                    }
	                } else {
	                    if(prevLength==2) {
	                        length=2;
	                    } else {
	                        /* change from single-byte mode to double-byte */
	                        value|=UConverter.UCNV_SO<<16;
	                        length=3;
	                        prevLength=2;
	                    }
	                }
	                break;
	            case MBCS_OUTPUT_DBCS_ONLY:
	                /* table with single-byte results, but only DBCS mappings used */
	                value=MBCS_VALUE_2_FROM_STAGE_2(bytes, stage2Entry, c);
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    /* no mapping or SBCS result, not taken for DBCS-only */
	                    value=stage2Entry=0; /* stage2Entry=0 to reset roundtrip flags */
	                    length=0;
	                } else {
	                    length=2;
	                }
	                break;
	            case MBCS_OUTPUT_3:
									pArray = bytes;
	                pArrayIndex=MBCS_POINTER_3_FROM_STAGE_2(bytes, stage2Entry, c);
	                value=((pArray[pArrayIndex]&UConverterUtility.UNSIGNED_BYTE_MASK)<<16)|((pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+2]&UConverterUtility.UNSIGNED_BYTE_MASK);
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    length=1;
	                } else if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xffff) {
	                    length=2;
	                } else {
	                    length=3;
	                }
	                break;
	            case MBCS_OUTPUT_4:
	                value=MBCS_VALUE_4_FROM_STAGE_2(bytes, stage2Entry, c);
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    length=1;
	                } else if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xffff) {
	                    length=2;
	                } else if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xffffff) {
	                    length=3;
	                } else {
	                    length=4;
	                }
	                break;
	            case MBCS_OUTPUT_3_EUC:
	                value=MBCS_VALUE_2_FROM_STAGE_2(bytes, stage2Entry, c);
	                /* EUC 16-bit fixed-length representation */
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    length=1;
	                } else if((value&0x8000)==0) {
	                    value|=0x8e8000;
	                    length=3;
	                } else if((value&0x80)==0) {
	                    value|=0x8f0080;
	                    length=3;
	                } else {
	                    length=2;
	                }
	                break;
	            case MBCS_OUTPUT_4_EUC:
									pArray = bytes;
	                pArrayIndex=MBCS_POINTER_3_FROM_STAGE_2(bytes, stage2Entry, c);
	                value=((pArray[pArrayIndex]&UConverterUtility.UNSIGNED_BYTE_MASK)<<16)|((pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+2]&UConverterUtility.UNSIGNED_BYTE_MASK);
	                /* EUC 16-bit fixed-length representation applied to the first two bytes */
	                if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xff) {
	                    length=1;
	                } else if((value & UConverterUtility.UNSIGNED_INT_MASK) <=0xffff) {
	                    length=2;
	                } else if((value&0x800000)==0) {
	                    value|=0x8e800000;
	                    length=4;
	                } else if((value&0x8000)==0) {
	                    value|=0x8f008000;
	                    length=4;
	                } else {
	                    length=3;
	                }
	                break;
	            default:
	                /* must not occur */
	                /*
	                 * To avoid compiler warnings that value & length may be
	                 * used without having been initialized, we set them here.
	                 * In reality, this is unreachable code.
	                 * Not having a default branch also causes warnings with
	                 * some compilers.
	                 */
	                value=stage2Entry=0; /* stage2Entry=0 to reset roundtrip flags */
	                length=0;
	                break;
	            }
	
	            /* is this code point assigned, or do we use fallbacks? */
	            if(!(MBCS_FROM_U_IS_ROUNDTRIP(stage2Entry, c) || (UConverterUtility.UCNV_FROM_U_USE_FALLBACK(cnv, c) && value!=0))
	            ) {
	                /*
	                 * We allow a 0 byte output if the "assigned" bit is set for this entry.
	                 * There is no way with this data structure for fallback output
	                 * to be a zero byte.
	                 */
	
	//unassigned:
								SideEffects x = new SideEffects(c, sourceArrayIndex, sourceIndex, nextSourceIndex, prevSourceIndex, targetArrayIndex, targetCapacity, prevLength);
								doloop = unassigned(cnv, pArgs, sourceArray, sourceLimit, sourceIndex, targetArray, null, x, pErrorCode);
								c = x.c;
								sourceArrayIndex = x.sourceArrayIndex;
								sourceIndex = x.sourceIndex;
								nextSourceIndex = x.nextSourceIndex;
								prevSourceIndex = x.prevSourceIndex;
								targetArrayIndex = x.targetArrayIndex;
								targetCapacity = x.targetCapacity;
								prevLength = x.prevLength;
								if(doloop)
									continue;
								else
									break;
	            }
	
	            /* write the output character bytes from value and length */
	            /* from the first if in the loop we know that targetCapacity>0 */
	            if(length<=targetCapacity) {
	                if(offsetsArray==null) {
	                    switch(length) {
	                        /* each branch falls through to the next one */
	                    case 4:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>24);
	                    case 3:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>16);
	                    case 2:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>8);
	                    case 1:
	                        targetArray[targetArrayIndex++]=(byte)value;
	                    default:
	                        /* will never occur */
	                        break;
	                    }
	                } else {
	                    switch(length) {
	                        /* each branch falls through to the next one */
	                    case 4:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>24);
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    case 3:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>16);
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    case 2:
	                        targetArray[targetArrayIndex++]=(byte)(value>>>8);
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    case 1:
	                        targetArray[targetArrayIndex++]=(byte)value;
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    default:
	                        /* will never occur */
	                        break;
	                    }
	                }
	                targetCapacity-=length;
	            } else {
	                byte[] charErrorBufferArray;
									int charErrorBufferArrayIndex;
	
	                /*
	                 * We actually do this backwards here:
	                 * In order to save an intermediate variable, we output
	                 * first to the overflow buffer what does not fit into the
	                 * regular target.
	                 */
	                /* we know that 1<=targetCapacity<length<=4 */
	                length-=targetCapacity;
	                charErrorBufferArray=cnv.charErrorBufferArray;
									charErrorBufferArrayIndex = cnv.charErrorBufferBegin;
	                switch(length) {
	                    /* each branch falls through to the next one */
	                case 3:
	                    charErrorBufferArray[charErrorBufferArrayIndex++]=(byte)(value>>>16);
	                case 2:
	                    charErrorBufferArray[charErrorBufferArrayIndex++]=(byte)(value>>>8);
	                case 1:
	                    charErrorBufferArray[charErrorBufferArrayIndex]=(byte)value;
	                default:
	                    /* will never occur */
	                    break;
	                }
	                cnv.charErrorBufferLength=(byte)length;
	
	                /* now output what fits into the regular target */
	                value>>>=8*length; /* length was reduced by targetCapacity */
	                switch(targetCapacity) {
	                    /* each branch falls through to the next one */
	                case 3:
	                    targetArray[targetArrayIndex++]=(byte)(value>>>16);
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                case 2:
	                    targetArray[targetArrayIndex++]=(byte)(value>>>8);
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                case 1:
	                    targetArray[targetArrayIndex++]=(byte)value;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                default:
	                    /* will never occur */
	                    break;
	                }
	
	                /* target overflow */
	                targetCapacity=0;
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                c=0;
	                break;
	            }
	
	            /* normal end of conversion: prepare for a new character */
	            c=0;
	            if(offsetsArray!=null) {
	                prevSourceIndex=sourceIndex;
	                sourceIndex=nextSourceIndex;
	            }
	            continue;
	        } else {
	            /* target is full */
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	    }
			}
	
	    /*
	     * the end of the input stream and detection of truncated input
	     * are handled by the framework, but for EBCDIC_STATEFUL conversion
	     * we need to emit an SI at the very end
	     *
	     * conditions:
	     *   successful
	     *   EBCDIC_STATEFUL in DBCS mode
	     *   end of input and no truncated input
	     */
	    if( ErrorCode.isSuccess(pErrorCode[0]) &&
	        outputType==MBCS_OUTPUT_2_SISO && prevLength==2 &&
	        pArgs.flush && sourceArrayIndex>=sourceLimit && c==0
	    ) {
	        /* EBCDIC_STATEFUL ending with DBCS: emit an SI to return the output stream to SBCS */
	        if(targetCapacity>0) {
	            targetArray[targetArrayIndex++]=(byte)UConverter.UCNV_SI;
	            if(offsetsArray!=null) {
	                /* set the last source character's index (sourceIndex points at sourceLimit now) */
	                offsetsArray[offsetsArrayIndex++]=prevSourceIndex;
	            }
	        } else {
	            /* target is full */
	            cnv.charErrorBufferArray[0]=(byte)UConverter.UCNV_SI;
	            cnv.charErrorBufferLength=1;
	            pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	        }
	        prevLength=1; /* we switched into SBCS */
	    }
	
	    /* set the converter state back into UConverter */
	    cnv.fromUChar32=c;
	    cnv.fromUnicodeStatus=prevLength;
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	////////////////
	//Begin Masa's code
	///////////////
	
	// mhokari: This method should be in UConverterSharedData_MBCS
	/*
	 * This is a simple version of _MBCSGetNextUChar() that is used
	 * by other converter implementations.
	 * It only returns an "assigned" result if it consumes the entire input.
	 * It does not use state from the converter, nor error codes.
	 * It does not handle the EBCDIC swaplfnl option (set in UConverter).
	 * It handles conversion extensions but not GB 18030.
	 *
	 * Return value:
	 * U+fffe   unassigned
	 * U+ffff   illegal
	 * otherwise the Unicode code point
	 */
	//U_CFUNC UChar32 ucnv_MBCSSimpleGetNextUChar(UConverterSharedData *sharedData, const char *source, int32_t length, UBool useFallback)
	public int ucnv_MBCSSimpleGetNextUChar(UConverterSharedData sharedData, final byte[] sourceArray, final int sourceBegin, final int length, boolean useFallback)
	{
		final UConverter cnv = null;
		int[/*256*/][] stateTable;
		char[] unicodeCodeUnits;
	
		int offset;
		byte state, action;
	
		int c;
		int i, entry;
	
		if(length<=0) {
			/* no input at all: "illegal" */
			return 0xffff;
		}
	
		/* set up the local pointers */
		stateTable=sharedData.mbcs.stateTable;
		unicodeCodeUnits=sharedData.mbcs.unicodeCodeUnits;
	
		/* converter state */
		offset=0;
		state=sharedData.mbcs.dbcsOnlyState;
	
		/* conversion loop */
		for(i=0;;) {
			entry=stateTable[state][sourceArray[i++]];
			if(MBCS_ENTRY_IS_TRANSITION(entry)) {
				state=(byte)MBCS_ENTRY_TRANSITION_STATE(entry);
				offset+=MBCS_ENTRY_TRANSITION_OFFSET(entry);
	
				if(i==length) {
					return 0xffff; /* truncated character */
				}
			} else {
				/*
				 * An if-else-if chain provides more reliable performance for
				 * the most common cases compared to a switch.
				 */
				action=(byte)(MBCS_ENTRY_FINAL_ACTION(entry));
				if(action==MBCS_STATE_VALID_16) {
					offset+=MBCS_ENTRY_FINAL_VALUE_16(entry);
					c=unicodeCodeUnits[offset];
					if(c!=0xfffe) {
						/* done */
					} else if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv)) {
						c=ucnv_MBCSGetFallback(sharedData.mbcs, offset);
						/* else done with 0xfffe */
					}
					break;
				} else if(action==MBCS_STATE_VALID_DIRECT_16) {
					/* output BMP code point */
					c=MBCS_ENTRY_FINAL_VALUE_16(entry);
					break;
				} else if(action==MBCS_STATE_VALID_16_PAIR) {
					offset+=MBCS_ENTRY_FINAL_VALUE_16(entry);
					c=unicodeCodeUnits[offset++];
					if(c<0xd800) {
						/* output BMP code point below 0xd800 */
					} else if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv) ? c<=0xdfff : c<=0xdbff) {
						/* output roundtrip or fallback supplementary code point */
						c=((c&0x3ff)<<10)+unicodeCodeUnits[offset]+(0x10000-0xdc00);
					} else if(UConverterUtility.UCNV_TO_U_USE_FALLBACK(cnv) ? (c&0xfffe)==0xe000 : c==0xe000) {
						/* output roundtrip BMP code point above 0xd800 or fallback BMP code point */
						c=unicodeCodeUnits[offset];
					} else if(c==0xffff) {
						return 0xffff;
					} else {
						c=0xfffe;
					}
					break;
				} else if(action==MBCS_STATE_VALID_DIRECT_20) {
					/* output supplementary code point */
					c=0x10000+MBCS_ENTRY_FINAL_VALUE(entry);
					break;
				} else if(action==MBCS_STATE_FALLBACK_DIRECT_16) {
					if(!UConverterUtility.TO_U_USE_FALLBACK(useFallback)) {
						c=0xfffe;
						break;
					}
					/* output BMP code point */
					c=MBCS_ENTRY_FINAL_VALUE_16(entry);
					break;
				} else if(action==MBCS_STATE_FALLBACK_DIRECT_20) {
					if(!UConverterUtility.TO_U_USE_FALLBACK(useFallback)) {
						c=0xfffe;
						break;
					}
					/* output supplementary code point */
					c=0x10000+MBCS_ENTRY_FINAL_VALUE(entry);
					break;
				} else if(action==MBCS_STATE_UNASSIGNED) {
					c=0xfffe;
					break;
				}
	
				/*
				 * forbid MBCS_STATE_CHANGE_ONLY for this function,
				 * and MBCS_STATE_ILLEGAL and reserved action codes
				 */
				return 0xffff;
			}
		}
	
		if(i!=length) {
			/* illegal for this function: not all input consumed */
			return 0xffff;
		}
	
		// mhokari: Is section this needed?
		if(c==0xfffe) {
		    /* try an extension mapping */
		    ByteBuffer cx=sharedData.mbcs.extIndexes;
		    if(cx!=null) {
		        return UConverterExt.ucnv_extSimpleMatchToU(cx, sourceArray, sourceBegin, length, useFallback);
		    }
		}
	
		return c;
	}
	////////////
	//End Masa's code
	////////////
	
	/* conversion extensions for input not in the main table -------------------- */
	
	/*
	 * Hardcoded extension handling for GB 18030.
	 * Definition of LINEAR macros and gb18030Ranges see near the beginning of the file.
	 *
	 * In the future, conversion extensions may handle m:n mappings and delta tables,
	 * see http://oss.software.ibm.com/cvs/icu/~checkout~/icuhtml/design/conversion/conversion_extensions.html
	 *
	 * If an input character cannot be mapped, then these functions set an error
	 * code. The framework will then call the callback function.
	 */
	
	/*
	 * @return if(U_FAILURE) return the code point for cnv->fromUChar32
	 *         else return 0 after output has been written to the target
	 */
	//static UChar32 _extFromU(UConverter *cnv, const UConverterSharedData *sharedData, UChar32 cp, const UChar **source, const UChar *sourceLimit, char **target, const char *targetLimit, int32_t **offsets, int32_t sourceIndex, UBool flush, UErrorCode *pErrorCode)
	int _extFromU(UConverter cnv, UConverterSharedData sharedData, int cp_, char[] sourceArray, int[] sourceArrayBegin, int sourceLimit, byte[] targetArray, int[] targetArrayBegin, int targetLimit, int[] offsetsArray, int[] offsetsArrayBegin, int sourceIndex, boolean flush, int[] pErrorCode)
	{
	    //int[] cx;
			ByteBuffer cx;
			long cp = cp_ & UConverterUtility.UNSIGNED_INT_MASK;
	
	    cnv.useSubChar1=false;
	
	    if( (cx=sharedData.mbcs.extIndexes)!=null && UConverterExt.ucnv_extInitialMatchFromU(cnv, cx, (int)cp, sourceArray, sourceArrayBegin, sourceLimit, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, flush, pErrorCode)) {
	        return 0; /* an extension mapping handled the input */
	    }
	
	    /* GB 18030 */
	    if((cnv.options&_MBCS_OPTION_GB18030)!=0) {
	        long[] range;
	        int i;
	
	        range=gb18030Ranges[0];
	        for(i=0; i<gb18030Ranges.length/gb18030Ranges[0].length; range=gb18030Ranges[i], ++i) {
	            if(range[0]<=cp && cp<=range[1]) {
	                /* found the Unicode code point, output the four-byte sequence for it */
	                long linear;
	                byte bytes[] = new byte[4];;
	
	                /* get the linear value of the first GB 18030 code in this range */
	                linear=range[2]-LINEAR_18030_BASE;
	
	                /* add the offset from the beginning of the range */
	                linear+=(cp-range[0]);
	
	                /* turn this into a four-byte sequence */
									/*agljport:change
	                bytes[3]=(char)(0x30+linear%10); linear/=10;
	                bytes[2]=(char)(0x81+linear%126); linear/=126;
	                bytes[1]=(char)(0x30+linear%10); linear/=10;
	                bytes[0]=(char)(0x81+linear);
									*/
	                bytes[3]=(byte)(0x30+linear%10); linear/=10;
	                bytes[2]=(byte)(0x81+linear%126); linear/=126;
	                bytes[1]=(byte)(0x30+linear%10); linear/=10;
	                bytes[0]=(byte)(0x81+linear);
	
	                /* output this sequence */
	                UConverterUtility.ucnv_fromUWriteBytes(cnv, bytes, 0, 4, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, pErrorCode);
	                return 0;
	            }
	        }
	    }
	
	    /* no mapping */
	    pErrorCode[0]=ErrorCode.U_INVALID_CHAR_FOUND;
	    return (int)cp;
	}
	/*
	 * Input sequence: cnv->toUBytes[0..length[
	 * @return if(U_FAILURE) return the length (toULength, byteIndex) for the input
	 *         else return 0 after output has been written to the target
	 */
	//static int8_t _extToU(UConverter *cnv, const UConverterSharedData *sharedData, int8_t length, const char **source, const char *sourceLimit, UChar **target, const UChar *targetLimit, int32_t **offsets, int32_t sourceIndex, UBool flush, UErrorCode *pErrorCode)
	byte _extToU(UConverter cnv, UConverterSharedData sharedData, byte length, byte[] sourceArray, int[] sourceArrayBegin, int sourceLimit, char[] targetArray, int[] targetArrayBegin, int targetLimit, int[] offsetsArray, int[] offsetsArrayBegin, int sourceIndex, boolean flush, int[]/*UErrorCode*/ pErrorCode)
	{
	    //int[] cx;
			ByteBuffer cx;
	
	    if( (cx=sharedData.mbcs.extIndexes)!=null &&
	        UConverterExt.ucnv_extInitialMatchToU(cnv, cx, length, sourceArray, sourceArrayBegin, sourceLimit, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, flush, pErrorCode)
	    ) {
	        return 0; /* an extension mapping handled the input */
	    }
	
	    /* GB 18030 */
	    if(length==4 && (cnv.options&_MBCS_OPTION_GB18030)!=0) {
	        long[] range;
	        long linear;
	        int i;
	
	        linear=LINEAR_18030(cnv.toUBytesArray[0], cnv.toUBytesArray[1], cnv.toUBytesArray[2], cnv.toUBytesArray[3]);
	        range=gb18030Ranges[0];
	        for(i=0; i<gb18030Ranges.length/gb18030Ranges[0].length; range=gb18030Ranges[++i]) {
	            if(range[2]<=linear && linear<=range[3]) {
	                /* found the sequence, output the Unicode code point for it */
	                pErrorCode[0]=ErrorCode.U_ZERO_ERROR;
	
	                /* add the linear difference between the input and start sequences to the start code point */
	                linear=range[0]+(linear-range[2]);
	
	                /* output this code point */
	                cnv.ucnv_toUWriteCodePoint((int)linear, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, sourceIndex, pErrorCode);
	
	                return 0;
	            }
	        }
	    }
	
	    /* no mapping */
	    pErrorCode[0]=ErrorCode.U_INVALID_CHAR_FOUND;
	    return length;
	}
	
	/* MBCS converter data and state -------------------------------------------- */
	
	    public static final int MBCS_MAX_STATE_COUNT=128;
	
	/**
	 * MBCS action codes for conversions to Unicode.
	 * These values are in bits 23..20 of the state table entries.
	 */
	    public static final int MBCS_STATE_VALID_DIRECT_16 = 0;
	    public static final int MBCS_STATE_VALID_DIRECT_20 = MBCS_STATE_VALID_DIRECT_16 + 1;
	
	    public static final int MBCS_STATE_FALLBACK_DIRECT_16 = MBCS_STATE_VALID_DIRECT_20 + 1;
	    public static final int MBCS_STATE_FALLBACK_DIRECT_20 = MBCS_STATE_FALLBACK_DIRECT_16 + 1;
	
	    public static final int MBCS_STATE_VALID_16 = MBCS_STATE_FALLBACK_DIRECT_20 + 1;
	    public static final int MBCS_STATE_VALID_16_PAIR = MBCS_STATE_VALID_16 + 1;
	
	    public static final int MBCS_STATE_UNASSIGNED = MBCS_STATE_VALID_16_PAIR + 1;
	    public static final int MBCS_STATE_ILLEGAL = MBCS_STATE_UNASSIGNED + 1;
	
	    public static final int MBCS_STATE_CHANGE_ONLY = MBCS_STATE_ILLEGAL + 1;
	
	/* Macros for state table entries */
	int MBCS_ENTRY_TRANSITION(int state, int offset) {return (state<<24L)|offset; }
			/*
	#define MBCS_ENTRY_TRANSITION_SET_OFFSET(entry, offset) (int32_t)(((entry)&0xff000000)|(offset))
	#define MBCS_ENTRY_TRANSITION_ADD_OFFSET(entry, offset) (int32_t)((entry)+(offset))
	
	*/
	int MBCS_ENTRY_FINAL(int state, int action, int value) {return (int)(0x80000000|((int)(state)<<24L)|((action)<<20L)|(value));}
	/*
	#define MBCS_ENTRY_SET_FINAL(entry) (int32_t)((entry)|0x80000000)
	#define MBCS_ENTRY_FINAL_SET_ACTION(entry, action) (int32_t)(((entry)&0xff0fffff)|((int32_t)(action)<<20L))
	#define MBCS_ENTRY_FINAL_SET_VALUE(entry, value) (int32_t)(((entry)&0xfff00000)|(value))
	#define MBCS_ENTRY_FINAL_SET_ACTION_VALUE(entry, action, value) (int32_t)(((entry)&0xff000000)|((int32_t)(action)<<20L)|(value))
	
	#define MBCS_ENTRY_SET_STATE(entry, state) (int32_t)(((entry)&0x80ffffff)|((int32_t)(state)<<24L))
	
	#define MBCS_ENTRY_STATE(entry) (((entry)>>24)&0x7f)
	
	*/
	/*agljport:change
	#define MBCS_ENTRY_IS_TRANSITION(entry) ((entry)>=0)
	#define MBCS_ENTRY_IS_FINAL(entry) ((entry)<0)
	*/
	static final boolean MBCS_ENTRY_IS_TRANSITION(int entry) {return (entry)>=0; }
	static final boolean MBCS_ENTRY_IS_FINAL(int entry) {return (entry)<0;}
	static final int MBCS_ENTRY_TRANSITION_STATE(int entry) {return ((entry)>>>24);}
	static final int MBCS_ENTRY_TRANSITION_OFFSET(int entry) {return ((entry)&0xffffff);}
	static final int MBCS_ENTRY_FINAL_STATE(int entry) {return ((entry)>>>24)&0x7f;}
	static final boolean MBCS_ENTRY_FINAL_IS_VALID_DIRECT_16(int entry) {return ((entry)<0x80100000);}
	static final int MBCS_ENTRY_FINAL_ACTION(int entry) {return ((entry)>>>20)&0xf;}
	static final int MBCS_ENTRY_FINAL_VALUE(int entry) {return ((entry)&0xfffff); }
	static final char MBCS_ENTRY_FINAL_VALUE_16(int entry) {return (char)(entry);}
	
	// mhokari: This method should be in UConverterSharedData_MBCS
	/**
	 * This macro version of _MBCSSingleSimpleGetNextUChar() gets a code point from a byte.
	 * It works for single-byte, single-state codepages that only map
	 * to and from BMP code points, and it always
	 * returns fallback values.
	 */
	/*agljport:change
	#define _MBCS_SINGLE_SIMPLE_GET_NEXT_BMP(sharedData, b) \
	    (UChar)MBCS_ENTRY_FINAL_VALUE_16((sharedData)->mbcs.stateTable[0][(uint8_t)(b)])
			*/
	protected final char
	_MBCS_SINGLE_SIMPLE_GET_NEXT_BMP(final int b)
	{
		return MBCS_ENTRY_FINAL_VALUE_16(mbcs.stateTable[0][b & UConverterUtility.UNSIGNED_BYTE_MASK]);
	}
	
	/* single-byte fromUnicode: get the 16-bit result word */
	//#define MBCS_SINGLE_RESULT_FROM_U(table, results, c) (results)[ (table)[ (table)[(c)>>10] +(((c)>>4)&0x3f) ] +((c)&0xf) ]
	static final char MBCS_SINGLE_RESULT_FROM_U(char[] table, byte[] results, int c) 
	{
		int i1 = table[c>>>10] +((c>>>4)&0x3f);
		int i = 2* (table[i1] +(c&0xf)); // used as index into byte[] array treated as char[] array
		return (char)(((results[i] & UConverterUtility.UNSIGNED_BYTE_MASK) <<8) | (results[i+1] & UConverterUtility.UNSIGNED_BYTE_MASK));
	}
	
	/* multi-byte fromUnicode: get the 32-bit stage 2 entry */
	static int MBCS_STAGE_2_FROM_U(char[] table, int c)
	{
		int i = 2 * (table[(c)>>>10] +((c>>>4)&0x3f)); // 2x because used as index into char[] array treated as int[] array
		return ((table[i] & UConverterUtility.UNSIGNED_SHORT_MASK) <<16) | (table[i+1] & UConverterUtility.UNSIGNED_SHORT_MASK);
	}
	static boolean MBCS_FROM_U_IS_ROUNDTRIP(int stage2Entry, int c) {return ( ((stage2Entry) & (1<< (16+((c)&0xf)) )) !=0);}
	
	static char MBCS_VALUE_2_FROM_STAGE_2(byte[] bytes, int stage2Entry, int c)
	{
		int i = 2 * (16*((char)stage2Entry & UConverterUtility.UNSIGNED_SHORT_MASK)+(c&0xf));
		return (char)(((bytes[i] & UConverterUtility.UNSIGNED_BYTE_MASK) <<8) | (bytes[i+1] & UConverterUtility.UNSIGNED_BYTE_MASK));
	}
	static int MBCS_VALUE_4_FROM_STAGE_2(byte[] bytes, int stage2Entry, int c)
	{
		int i = 4 * (16*((char)stage2Entry & UConverterUtility.UNSIGNED_SHORT_MASK)+(c&0xf));
		return ((bytes[i] & UConverterUtility.UNSIGNED_BYTE_MASK) <<24) | 
			((bytes[i+1] & UConverterUtility.UNSIGNED_BYTE_MASK) <<16) | 
			((bytes[i+2] & UConverterUtility.UNSIGNED_BYTE_MASK) <<8) | 
			(bytes[i+3] & UConverterUtility.UNSIGNED_BYTE_MASK);
	}
	
	static int MBCS_POINTER_3_FROM_STAGE_2(byte[] bytes, int stage2Entry, int c)
	{
		return ((16*((char)(stage2Entry) & UConverterUtility.UNSIGNED_SHORT_MASK)+((c)&0xf))*3);
	}
	
	/**
	 * MBCS output types for conversions from Unicode.
	 * These per-converter types determine the storage method in stage 3 of the lookup table,
	 * mostly how many bytes are stored per entry.
	 */
	    public static final int MBCS_OUTPUT_1 = 0;          /* 0 */
	    public static final int MBCS_OUTPUT_2 = MBCS_OUTPUT_1 + 1;          /* 1 */
	    public static final int MBCS_OUTPUT_3 = MBCS_OUTPUT_2 + 1;          /* 2 */
	    public static final int MBCS_OUTPUT_4 = MBCS_OUTPUT_3 + 1;          /* 3 */
	
	    public static final int MBCS_OUTPUT_3_EUC=8;    /* 8 */
	    public static final int MBCS_OUTPUT_4_EUC = MBCS_OUTPUT_3_EUC + 1;      /* 9 */
	
	    public static final int MBCS_OUTPUT_2_SISO=12;  /* c */
	    public static final int MBCS_OUTPUT_2_HZ = MBCS_OUTPUT_2_SISO + 1;       /* d */
	
	    public static final int MBCS_OUTPUT_EXT_ONLY = MBCS_OUTPUT_2_HZ + 1;   /* e */
	
	    public static final int MBCS_OUTPUT_COUNT = MBCS_OUTPUT_EXT_ONLY + 1;
	
	    public static final int MBCS_OUTPUT_DBCS_ONLY=0xdb;  /* runtime-only type for DBCS-only handling of SISO tables */
	
	/* GB 18030 data ------------------------------------------------------------ */
	
	/* helper macros for linear values for GB 18030 four-byte sequences */
	static final long LINEAR_18030(long a, long b, long c, long d) {return ((((a)*10+(b))*126L+(c))*10L+(d));}
	
	static final long LINEAR_18030_BASE = LINEAR_18030(0x81, 0x30, 0x81, 0x30);
	
	static final long LINEAR(long x) {return LINEAR_18030(x>>>24, (x>>>16)&0xff, (x>>>8)&0xff, x&0xff);}
	
	/*
	 * Some ranges of GB 18030 where both the Unicode code points and the
	 * GB four-byte sequences are contiguous and are handled algorithmically by
	 * the special callback functions below.
	 * The values are start & end of Unicode & GB codes.
	 *
	 * Note that single surrogates are not mapped by GB 18030
	 * as of the re-released mapping tables from 2000-nov-30.
	 */
	static final long gb18030Ranges[/*13*/][/*4*/];
	static
	{
		gb18030Ranges = new long[/*13*/][/*4*/]{
		 	{0x10000L, 0x10FFFFL, LINEAR(0x90308130L), LINEAR(0xE3329A35L)},
	    {0x9FA6L, 0xD7FFL, LINEAR(0x82358F33L), LINEAR(0x8336C738L)},
	    {0x0452L, 0x200FL, LINEAR(0x8130D330L), LINEAR(0x8136A531L)},
	    {0xE865L, 0xF92BL, LINEAR(0x8336D030L), LINEAR(0x84308534L)},
	    {0x2643L, 0x2E80L, LINEAR(0x8137A839L), LINEAR(0x8138FD38L)},
	    {0xFA2AL, 0xFE2FL, LINEAR(0x84309C38L), LINEAR(0x84318537L)},
	    {0x3CE1L, 0x4055L, LINEAR(0x8231D438L), LINEAR(0x8232AF32L)},
	    {0x361BL, 0x3917L, LINEAR(0x8230A633L), LINEAR(0x8230F237L)},
	    {0x49B8L, 0x4C76L, LINEAR(0x8234A131L), LINEAR(0x8234E733L)},
	    {0x4160L, 0x4336L, LINEAR(0x8232C937L), LINEAR(0x8232F837L)},
	    {0x478EL, 0x4946L, LINEAR(0x8233E838L), LINEAR(0x82349638L)},
	    {0x44D7L, 0x464BL, LINEAR(0x8233A339L), LINEAR(0x8233C931L)},
	    {0xFFE6L, 0xFFFFL, LINEAR(0x8431A234L), LINEAR(0x8431A439L)}
	};
	
	}
	
	/* bit flag for UConverter.options indicating GB 18030 special handling */
	public static final int _MBCS_OPTION_GB18030 = 0x8000;
	
	/*agljport:delete
	static const UConverterImpl _MBCSImpl={
	    UCNV_MBCS,
	
	    ucnv_MBCSLoad,
	    ucnv_MBCSUnload,
	
	    ucnv_MBCSOpen,
	    NULL,
	    NULL,
	
	    ucnv_MBCSToUnicodeWithOffsets,
	    ucnv_MBCSToUnicodeWithOffsets,
	    ucnv_MBCSFromUnicodeWithOffsets,
	    ucnv_MBCSFromUnicodeWithOffsets,
	    ucnv_MBCSGetNextUChar,
	
	    ucnv_MBCSGetStarters,
	    ucnv_MBCSGetName,
	    ucnv_MBCSWriteSub,
	    NULL,
	    ucnv_MBCSGetUnicodeSet
	};
	*/
}

