package com.ibm.icu.impl;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.CharBuffer;

import com.ibm.icu.common.ErrorCode;

import com.ibm.icu.converters.UConverter;

public final class UConverterExt {
/*
******************************************************************************
*
*   Copyright (C) 2003-2004, International Business Machines
*   Corporation and others.  All Rights Reserved.
*
******************************************************************************
*   file name:  ucnv_ext.c
*   encoding:   US-ASCII
*   tab size:   8 (not used)
*   indentation:4
*
*   created on: 2003jun13
*   created by: Markus W. Scherer
*
*   Conversion extensions
*/

// begin ucnv_ext.h

    public static final int UCNV_EXT_INDEXES_LENGTH = 0;            /* 0 */

    public static final int UCNV_EXT_TO_U_INDEX = UCNV_EXT_INDEXES_LENGTH + 1;                /* 1 */
    public static final int UCNV_EXT_TO_U_LENGTH = UCNV_EXT_TO_U_INDEX + 1;
    public static final int UCNV_EXT_TO_U_UCHARS_INDEX = UCNV_EXT_TO_U_LENGTH + 1;
    public static final int UCNV_EXT_TO_U_UCHARS_LENGTH = UCNV_EXT_TO_U_UCHARS_INDEX + 1;

    public static final int UCNV_EXT_FROM_U_UCHARS_INDEX = UCNV_EXT_TO_U_UCHARS_LENGTH + 1;       /* 5 */
    public static final int UCNV_EXT_FROM_U_VALUES_INDEX = UCNV_EXT_FROM_U_UCHARS_INDEX + 1;
    public static final int UCNV_EXT_FROM_U_LENGTH = UCNV_EXT_FROM_U_VALUES_INDEX + 1;
    public static final int UCNV_EXT_FROM_U_BYTES_INDEX = UCNV_EXT_FROM_U_LENGTH + 1;
    public static final int UCNV_EXT_FROM_U_BYTES_LENGTH = UCNV_EXT_FROM_U_BYTES_INDEX + 1;

    public static final int UCNV_EXT_FROM_U_STAGE_12_INDEX = UCNV_EXT_FROM_U_BYTES_LENGTH + 1;     /* 10 */
    public static final int UCNV_EXT_FROM_U_STAGE_1_LENGTH = UCNV_EXT_FROM_U_STAGE_12_INDEX + 1;
    public static final int UCNV_EXT_FROM_U_STAGE_12_LENGTH = UCNV_EXT_FROM_U_STAGE_1_LENGTH + 1;
    public static final int UCNV_EXT_FROM_U_STAGE_3_INDEX = UCNV_EXT_FROM_U_STAGE_12_LENGTH + 1;
    public static final int UCNV_EXT_FROM_U_STAGE_3_LENGTH = UCNV_EXT_FROM_U_STAGE_3_INDEX + 1;
    public static final int UCNV_EXT_FROM_U_STAGE_3B_INDEX = UCNV_EXT_FROM_U_STAGE_3_LENGTH + 1;
    public static final int UCNV_EXT_FROM_U_STAGE_3B_LENGTH = UCNV_EXT_FROM_U_STAGE_3B_INDEX + 1;

    public static final int UCNV_EXT_COUNT_BYTES = UCNV_EXT_FROM_U_STAGE_3B_LENGTH + 1;               /* 17 */
    public static final int UCNV_EXT_COUNT_UCHARS = UCNV_EXT_COUNT_BYTES + 1;
    public static final int UCNV_EXT_FLAGS = UCNV_EXT_COUNT_UCHARS + 1;

    public static final int UCNV_EXT_RESERVED_INDEX = UCNV_EXT_FLAGS + 1;            /* 20, moves with additional indexes */

    public static final int UCNV_EXT_SIZE=31;
    public static final int UCNV_EXT_INDEXES_MIN_LENGTH=32;

	/* get the pointer to an extension array from indexes[index] */
	/*agljport:change
	#define UCNV_EXT_ARRAY(indexes, index, itemType) \
	    ((const itemType *)((const char *)(indexes)+(indexes)[index]))
			*/
	public static Buffer UCNV_EXT_ARRAY(ByteBuffer indexes, int index, Class itemType)
	{
		int oldpos = indexes.position();
		Buffer b;
	
		indexes.position(indexes.getInt(index*4));
		if(itemType == int.class)
			b = indexes.asIntBuffer();
		else if(itemType == short.class)
			b = indexes.asShortBuffer();
		else if(itemType == byte.class)
			b = indexes.slice();
		else if(itemType == char.class)
			b = indexes.asCharBuffer();
		else
			b = indexes.slice();
		indexes.position(oldpos);
		return b;
	}
	
	//public static int UCNV_GET_MAX_BYTES_PER_UCHAR(int[] indexes) {return (indexes[UCNV_EXT_COUNT_BYTES]&0xff); }
	public static int UCNV_GET_MAX_BYTES_PER_UCHAR(ByteBuffer indexes) 
	{
		indexes.position(0);
		IntBuffer a = indexes.asIntBuffer();
		int n;
		if(a.hasArray())
			n = a.array()[UCNV_EXT_COUNT_BYTES];
		else
			n = a.get(UCNV_EXT_COUNT_BYTES);
		
		return indexes.getInt(4*UCNV_EXT_COUNT_BYTES)&0xff; 
	}
	
	/* toUnicode helpers -------------------------------------------------------- */
	
	public static final int UCNV_EXT_TO_U_BYTE_SHIFT = 24;
	public static final int UCNV_EXT_TO_U_VALUE_MASK = 0xffffff;
	public static final int UCNV_EXT_TO_U_MIN_CODE_POINT = 0x1f0000;
	public static final int UCNV_EXT_TO_U_MAX_CODE_POINT = 0x2fffff;
	public static final int UCNV_EXT_TO_U_ROUNDTRIP_FLAG = (1<<23);
	public static final int UCNV_EXT_TO_U_INDEX_MASK = 0x3ffff;
	public static final int UCNV_EXT_TO_U_LENGTH_SHIFT = 18;
	public static final int UCNV_EXT_TO_U_LENGTH_OFFSET = 12;
	
	/* maximum number of indexed UChars */
	public static final int UCNV_EXT_MAX_UCHARS = 19;
	
	public static final int UCNV_EXT_TO_U_GET_BYTE(int word)
	{
		return word>>>UCNV_EXT_TO_U_BYTE_SHIFT;
	}
	
	public static final int UCNV_EXT_TO_U_GET_VALUE(int word)
	{
		return word&UCNV_EXT_TO_U_VALUE_MASK;
	}
	
	public static boolean UCNV_EXT_TO_U_IS_ROUNDTRIP(int value)
	{
		return (value&UCNV_EXT_TO_U_ROUNDTRIP_FLAG)!=0;
	}
	
	public static final boolean UCNV_EXT_TO_U_IS_PARTIAL(int value)
	{
		return (value&UConverterUtility.UNSIGNED_INT_MASK)<UCNV_EXT_TO_U_MIN_CODE_POINT;
	}
	
	public static final int UCNV_EXT_TO_U_GET_PARTIAL_INDEX(int value)
	{
		return value;
	}
	
	public static final int UCNV_EXT_TO_U_MASK_ROUNDTRIP(int value)
	{
		return value&~UCNV_EXT_TO_U_ROUNDTRIP_FLAG;
	}
	
	public static final int UCNV_EXT_TO_U_MAKE_WORD(byte b, int value)
	{
		return ((b&UConverterUtility.UNSIGNED_BYTE_MASK)<<UCNV_EXT_TO_U_BYTE_SHIFT)|value;
	}
	
	/* use after masking off the roundtrip flag */
	public static boolean UCNV_EXT_TO_U_IS_CODE_POINT(int value)
	{
		return (value&UConverterUtility.UNSIGNED_INT_MASK)<=UCNV_EXT_TO_U_MAX_CODE_POINT;
	}
	
	public static int UCNV_EXT_TO_U_GET_CODE_POINT(int value)
	{
		return (int)((value&UConverterUtility.UNSIGNED_INT_MASK)-UCNV_EXT_TO_U_MIN_CODE_POINT);
	}
	
	public static int UCNV_EXT_TO_U_GET_INDEX(int value)
	{
		return value&UCNV_EXT_TO_U_INDEX_MASK;
	}
	
	public static final int UCNV_EXT_TO_U_GET_LENGTH(int value)
	{
		return (value>>>UCNV_EXT_TO_U_LENGTH_SHIFT)-UCNV_EXT_TO_U_LENGTH_OFFSET;
	}
	
	/* fromUnicode helpers ------------------------------------------------------ */
	
	/* most trie constants are shared with ucnvmbcs.h */
	
	/* see similar utrie.h UTRIE_INDEX_SHIFT and UTRIE_DATA_GRANULARITY */
	public static final int UCNV_EXT_STAGE_2_LEFT_SHIFT = 2;
	public static final int UCNV_EXT_STAGE_3_GRANULARITY = 4;
	
	/* trie access, returns the stage 3 value=index to stage 3b; s1Index=c>>10 */
	public static final int UCNV_EXT_FROM_U(CharBuffer stage12, CharBuffer stage3, int s1Index, int c)
	{
		return stage3.get(stage3.position() + ((int)stage12.get( stage12.position() + (stage12.get(stage12.position()+s1Index) +((c>>>4)&0x3f)) )<<UCNV_EXT_STAGE_2_LEFT_SHIFT) +(c&0xf) );
	}
	
	public static final int UCNV_EXT_FROM_U_LENGTH_SHIFT = 24;
	public static final int UCNV_EXT_FROM_U_ROUNDTRIP_FLAG = 1<<31;
	public static final int UCNV_EXT_FROM_U_RESERVED_MASK = 0x60000000;
	public static final int UCNV_EXT_FROM_U_DATA_MASK = 0xffffff;
	
	/* special value for "no mapping" to <subchar1> (impossible roundtrip to 0 bytes, value 01) */
	public static final int UCNV_EXT_FROM_U_SUBCHAR1 = 0x80000001;
	
	/* at most 3 bytes in the lower part of the value */
	public static final int UCNV_EXT_FROM_U_MAX_DIRECT_LENGTH = 3;
	
	/* maximum number of indexed bytes */
	public static final int UCNV_EXT_MAX_BYTES = 0x1f;
	
	public static final boolean UCNV_EXT_FROM_U_IS_PARTIAL(int value) {return (value>>>UCNV_EXT_FROM_U_LENGTH_SHIFT)==0;}
	public static final int UCNV_EXT_FROM_U_GET_PARTIAL_INDEX(int value) {return value;}
	
	public static final boolean UCNV_EXT_FROM_U_IS_ROUNDTRIP(int value) {return (value&UCNV_EXT_FROM_U_ROUNDTRIP_FLAG)!=0;}
	public static final int UCNV_EXT_FROM_U_MASK_ROUNDTRIP(int value) {return value&~UCNV_EXT_FROM_U_ROUNDTRIP_FLAG;}
	
	/* use after masking off the roundtrip flag */
	public static final int UCNV_EXT_FROM_U_GET_LENGTH(int value) {return (value>>>UCNV_EXT_FROM_U_LENGTH_SHIFT)&UCNV_EXT_MAX_BYTES;}
	
	/* get bytes or bytes index */
	public static final int UCNV_EXT_FROM_U_GET_DATA(int value) {return value&UCNV_EXT_FROM_U_DATA_MASK;}
	
	// end ucnv_ext.h
	
	
	/* to Unicode --------------------------------------------------------------- */
	
	/*
	 * @return lookup value for the byte, if found; else 0
	 */
	//static U_INLINE uint32_t ucnv_extFindToU(const uint32_t *toUSection, int32_t length, uint8_t byte)
	static int ucnv_extFindToU(IntBuffer toUSection, int length, short byt)
	{
	    long word0, word;
	    int i, start, limit;
	
	    /* check the input byte against the lowest and highest section bytes */
			//agljport:comment instead of receiving a start position parameter for toUSection we'll rely on its position property
	    start=UCNV_EXT_TO_U_GET_BYTE(toUSection.get(toUSection.position()));
	    limit=UCNV_EXT_TO_U_GET_BYTE(toUSection.get(toUSection.position() + length-1));
	    if(byt<start || limit<byt) {
	        return 0; /* the byte is out of range */
	    }
	
	    if(length==((limit-start)+1)) {
	        /* direct access on a linear array */
	        return UCNV_EXT_TO_U_GET_VALUE(toUSection.get(toUSection.position()+byt-start)); /* could be 0 */
	    }
	
	    /* word0 is suitable for <=toUSection[] comparison, word for <toUSection[] */
	    word0=UCNV_EXT_TO_U_MAKE_WORD((byte)byt, 0) & UConverterUtility.UNSIGNED_INT_MASK;
	
	    /*
	     * Shift byte once instead of each section word and add 0xffffff.
	     * We will compare the shifted/added byte (bbffffff) against
	     * section words which have byte values in the same bit position.
	     * If and only if byte bb < section byte ss then bbffffff<ssvvvvvv
	     * for all v=0..f
	     * so we need not mask off the lower 24 bits of each section word.
	     */
	    word=word0|UCNV_EXT_TO_U_VALUE_MASK;
	
	    /* binary search */
	    start=0;
	    limit=length;
	    for(;;) {
	        i=limit-start;
	        if(i<=1) {
	            break; /* done */
	        }
	        /* start<limit-1 */
	
	        if(i<=4) {
	            /* linear search for the last part */
	            if(word0<=(toUSection.get(toUSection.position()+start) & UConverterUtility.UNSIGNED_INT_MASK)) {
	                break;
	            }
	            if(++start<limit && word0<=(toUSection.get(toUSection.position()+start)&UConverterUtility.UNSIGNED_INT_MASK)) {
	                break;
	            }
	            if(++start<limit && word0<=(toUSection.get(toUSection.position()+start)&UConverterUtility.UNSIGNED_INT_MASK)) {
	                break;
	            }
	            /* always break at start==limit-1 */
	            ++start;
	            break;
	        }
	
	        i=(start+limit)/2;
	        if(word<(toUSection.get(toUSection.position()+i)&UConverterUtility.UNSIGNED_INT_MASK)) {
	            limit=i;
	        } else {
	            start=i;
	        }
	    }
	
	    /* did we really find it? */
	    if(start<limit && byt==UCNV_EXT_TO_U_GET_BYTE((int)(word=(toUSection.get(toUSection.position()+start)&UConverterUtility.UNSIGNED_INT_MASK)))) {
	        return UCNV_EXT_TO_U_GET_VALUE((int)word); /* never 0 */
	    } else {
	        return 0; /* not found */
	    }
	}
	
	/*
	 * TRUE if not an SI/SO stateful converter,
	 * or if the match length fits with the current converter state
	 */
	/*agljport:change 
	#define UCNV_EXT_TO_U_VERIFY_SISO_MATCH(sisoState, match) \
	    ((sisoState)<0 || ((sisoState)==0) == (match==1))
			*/
	static boolean UCNV_EXT_TO_U_VERIFY_SISO_MATCH(byte sisoState, int match)
	{
		return sisoState<0 || (sisoState==0) == (match==1);
	}
	
	/*
	 * this works like ucnv_extMatchFromU() except
	 * - the first character is in pre
	 * - no trie is used
	 * - the returned matchLength is not offset by 2
	 */
	//static int32_t ucnv_extMatchToU(const int32_t *cx, int8_t sisoState, const char *pre, int32_t preLength, const char *src, int32_t srcLength, uint32_t *pMatchValue, UBool useFallback, UBool flush)
	static int ucnv_extMatchToU(ByteBuffer cx, byte sisoState, byte[] preArray, int preArrayBegin, int preLength, byte[] srcArray, int srcArrayBegin, int srcLength, int[] pMatchValue, boolean useFallback, boolean flush)
	{
	    IntBuffer toUTable, toUSection;
	
	    int value, matchValue;
	    int i, j, index, length, matchLength;
	    short b;
	
			int tmpint = cx.asIntBuffer().get(UCNV_EXT_TO_U_LENGTH);
	    if(cx==null || cx.asIntBuffer().get(UCNV_EXT_TO_U_LENGTH)<=0) {
	        return 0; /* no extension data, no match */
	    }
	
	    /* initialize */
	    toUTable=(IntBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_TO_U_INDEX, int.class);
	    index=0;
	
	    matchValue=0;
	    i=j=matchLength=0;
	
	    if(sisoState==0) {
	        /* SBCS state of an SI/SO stateful converter, look at only exactly 1 byte */
	        if(preLength>1) {
	            return 0; /* no match of a DBCS sequence in SBCS mode */
	        } else if(preLength==1) {
	            srcLength=0;
	        } else /* preLength==0 */ {
	            if(srcLength>1) {
	                srcLength=1;
	            }
	        }
	        flush=true;
	    }
	
	    /* we must not remember fallback matches when not using fallbacks */
	
	    /* match input units until there is a full match or the input is consumed */
	    for(;;) {
	        /* go to the next section */
					int oldpos = toUTable.position();
	        toUSection=((IntBuffer)toUTable.position(index)).slice();
					toUTable.position(oldpos);
	
	        /* read first pair of the section */
	        value=toUSection.get();
	        length=UCNV_EXT_TO_U_GET_BYTE(value);
	        value=UCNV_EXT_TO_U_GET_VALUE(value);
	        if( value!=0 &&
	            (UCNV_EXT_TO_U_IS_ROUNDTRIP(value) ||
	             UConverterUtility.TO_U_USE_FALLBACK(useFallback)) &&
	            UCNV_EXT_TO_U_VERIFY_SISO_MATCH(sisoState, i+j)
	        ) {
	            /* remember longest match so far */
	            matchValue=value;
	            matchLength=i+j;
	        }
	
	        /* match pre[] then src[] */
	        if(i<preLength) {
	            b=(short)(preArray[preArrayBegin + i++] & UConverterUtility.UNSIGNED_BYTE_MASK);
	        } else if(j<srcLength) {
	            b=(short)(srcArray[srcArrayBegin + j++] & UConverterUtility.UNSIGNED_BYTE_MASK);
	        } else {
	            /* all input consumed, partial match */
	            if(flush || (length=(i+j))>UCNV_EXT_MAX_BYTES) {
	                /*
	                 * end of the entire input stream, stop with the longest match so far
	                 * or: partial match must not be longer than UCNV_EXT_MAX_BYTES
	                 * because it must fit into state buffers
	                 */
	                break;
	            } else {
	                /* continue with more input next time */
	                return -length;
	            }
	        }
	
	        /* search for the current UChar */
	        value=ucnv_extFindToU(toUSection, length, b);
	        if(value==0) {
	            /* no match here, stop with the longest match so far */
	            break;
	        } else {
	            if(UCNV_EXT_TO_U_IS_PARTIAL(value)) {
	                /* partial match, continue */
	                index=UCNV_EXT_TO_U_GET_PARTIAL_INDEX(value);
	            } else {
	                if( (UCNV_EXT_TO_U_IS_ROUNDTRIP(value) ||
	                		UConverterUtility.TO_U_USE_FALLBACK(useFallback)) &&
	                    UCNV_EXT_TO_U_VERIFY_SISO_MATCH(sisoState, i+j)
	                ) {
	                    /* full match, stop with result */
	                    matchValue=value;
	                    matchLength=i+j;
	                } else {
	                    /* full match on fallback not taken, stop with the longest match so far */
	                }
	                break;
	            }
	        }
	    }
	
	    if(matchLength==0) {
	        /* no match at all */
	        return 0;
	    }
	
	    /* return result */
	    pMatchValue[0]=UCNV_EXT_TO_U_MASK_ROUNDTRIP(matchValue);
	    return matchLength;
	}
	
	//static U_INLINE void ucnv_extWriteToU(UConverter *cnv, const int32_t *cx, uint32_t value, UChar **target, const UChar *targetLimit, int32_t **offsets, int32_t srcIndex, UErrorCode *pErrorCode)
	static void ucnv_extWriteToU(UConverter cnv, ByteBuffer cx, int value, char[] targetArray, int[] targetArrayBegin, int targetLimit, int[] offsetsArray, int[] offsetsArrayBegin, int srcIndex, int[] pErrorCode)
	{
	    /* output the result */
	    if(UCNV_EXT_TO_U_IS_CODE_POINT(value)) {
	        /* output a single code point */
	        cnv.ucnv_toUWriteCodePoint(UCNV_EXT_TO_U_GET_CODE_POINT(value), targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, srcIndex, pErrorCode);
	    } else {
	        /* output a string - with correct data we have resultLength>0 */
		
			char[] a = new char[UCNV_EXT_TO_U_GET_LENGTH(value)];
			CharBuffer cb = ((CharBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_TO_U_UCHARS_INDEX, char.class));
			cb.position(UCNV_EXT_TO_U_GET_INDEX(value));
			cb.get(a, 0, a.length);
	        UConverterUtility.ucnv_toUWriteUChars(cnv, a, 0, a.length, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, srcIndex, pErrorCode);
	    }
	}
	
	/*
	 * get the SI/SO toU state (state 0 is for SBCS, 1 for DBCS),
	 * or 1 for DBCS-only,
	 * or -1 if the converter is not SI/SO stateful
	 *
	 * Note: For SI/SO stateful converters getting here,
	 * cnv->mode==0 is equivalent to firstLength==1.
	 */
	/*agljport:change
	#define UCNV_SISO_STATE(cnv) \
	    ((cnv)->sharedData->mbcs.outputType==MBCS_OUTPUT_2_SISO ? (int8_t)(cnv)->mode : \
	     (cnv)->sharedData->mbcs.outputType==MBCS_OUTPUT_DBCS_ONLY ? 1 : -1)
			 */
	
	static int UCNV_SISO_STATE(UConverter cnv)
	{
	   return cnv.sharedData.mbcs.outputType==UConverterSharedData_MBCS.MBCS_OUTPUT_2_SISO ? (byte)cnv.mode :
	     cnv.sharedData.mbcs.outputType==UConverterSharedData_MBCS.MBCS_OUTPUT_DBCS_ONLY ? 1 : -1;
	}
	
	/*
	 * target<targetLimit; set error code for overflow
	 */
	//U_CFUNC UBool ucnv_extInitialMatchToU(UConverter *cnv, const int32_t *cx, int32_t firstLength, const char **src, const char *srcLimit, UChar **target, const UChar *targetLimit, int32_t **ofErrorCode32_t srcIndex, UBool flush, UErrorCode *pErrorCode)
	public static boolean ucnv_extInitialMatchToU(UConverter cnv, ByteBuffer cx, int firstLength, byte[] srcArray, int[] srcArrayBegin, int srcLimit, char[] targetArray, int[] targetArrayBegin, int targetLimit, int[] offsetsArray, int[] offsetsArrayBegin, int srcIndex, boolean flush, int[] pErrorCode)
	{
	    int[] value = new int[1];
	    int match = 0;
	
	    /* try to match */
	    match=ucnv_extMatchToU(cx, (byte)UCNV_SISO_STATE(cnv), cnv.toUBytesArray, cnv.toUBytesBegin, firstLength, srcArray, srcArrayBegin[0], srcLimit-srcArrayBegin[0], value, cnv.useFallback, flush);
	    if(match>0) {
	        /* advance src pointer for the consumed input */
	        srcArrayBegin[0]+=match-firstLength;
	
	        /* write result to target */
	        ucnv_extWriteToU(cnv, cx, value[0], targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, srcIndex, pErrorCode);
	        return true;
	    } else if(match<0) {
	        /* save state for partial match */
					byte[] sArray;
					int sArrayIndex;
	        int j;
	
	        /* copy the first code point */
	        sArray=cnv.toUBytesArray;
					sArrayIndex = cnv.toUBytesBegin;
	        cnv.preToUFirstLength=(byte)firstLength;
	        for(j=0; j<firstLength; ++j) {
	            cnv.preToUArray[j]=sArray[sArrayIndex++];
	        }
	
	        /* now copy the newly consumed input */
	        sArray=srcArray;
					sArrayIndex = srcArrayBegin[0];
	        match=-match;
	        for(; j<match; ++j) {
	            cnv.preToUArray[j]=sArray[sArrayIndex++];
	        }
	        srcArray=sArray; /* same as *src=srcLimit; because we reached the end of input */
					srcArrayBegin[0] = sArrayIndex;
	        cnv.preToULength=(byte)match;
	        return true;
	    } else /* match==0 no match */ {
	        return false;
	    }
	}
	
	public static final int ucnv_extSimpleMatchToU(ByteBuffer cx, byte[] sourceArray, int sourceArrayBegin, int length, boolean useFallback)
	{
	    int[] value = new int[1];
	    int match;
	
	    if(length<=0) {
	        return 0xffff;
	    }
	
	    /* try to match */
	    match=ucnv_extMatchToU(cx, (byte)-1, sourceArray, sourceArrayBegin, length, null, 0, 0, value, useFallback, true);
	    if(match==length) {
	        /* write result for simple, single-character conversion */
	        if(UCNV_EXT_TO_U_IS_CODE_POINT(value[0])) {
	            return UCNV_EXT_TO_U_GET_CODE_POINT(value[0]);
	        }
	    }
	
	    /*
	     * return no match because
	     * - match>0 && value points to string: simple conversion cannot handle multiple code points
	     * - match>0 && match!=length: not all input consumed, forbidden for this function
	     * - match==0: no match found in the first place
	     * - match<0: partial match, not supported for simple conversion (and flush==TRUE)
	     */
	    return 0xfffe;
	}
	
	/*
	 * continue partial match with new input
	 * never called for simple, single-character conversion
	 */
	//U_CFUNC void ucnv_extContinueMatchToU(UConverter *cnv, UConverterToUnicodeArgs *pArgs, int32_t srcIndex, UErrorCode *pErrorCode)
	public static void ucnv_extContinueMatchToU(UConverter cnv, UConverterToUnicodeArgs pArgs, int srcIndex, int[] pErrorCode)
	{
	    int[] value = new int[1];
	    int match, length;
	
	    match=ucnv_extMatchToU(cnv.sharedData.mbcs.extIndexes, (byte)UCNV_SISO_STATE(cnv), cnv.preToUArray, cnv.preToUBegin, cnv.preToULength, pArgs.sourceArray, pArgs.sourceBegin, (int)(pArgs.sourceLimit-pArgs.sourceBegin), value, cnv.useFallback, pArgs.flush);
	
	    if(match>0) {
	        if(match>=cnv.preToULength) {
	            /* advance src pointer for the consumed input */
	            pArgs.sourceBegin+=match-cnv.preToULength;
	            cnv.preToULength=0;
	        } else {
	            /* the match did not use all of preToU[] - keep the rest for replay */
	            length=cnv.preToULength-match;
	            UConverterUtility.uprv_memmove(cnv.preToUArray, cnv.preToUBegin, cnv.preToUArray, cnv.preToUBegin+match, length);
	            cnv.preToULength=(byte)-length;
	        }
	
	        /* write result */
					int[] offsetsBegin = {pArgs.offsetsBegin};
					int[] targetBegin = {pArgs.targetBegin};
	        ucnv_extWriteToU(cnv, cnv.sharedData.mbcs.extIndexes, value[0], pArgs.targetArray, targetBegin, pArgs.targetLimit, pArgs.offsetsArray, offsetsBegin, srcIndex, pErrorCode);
					pArgs.targetBegin = targetBegin[0];
					pArgs.offsetsBegin = offsetsBegin[0];
	    } else if(match<0) {
	        /* save state for partial match */
	        byte[] sArray;
					int sArrayIndex;
	        int j;
	
	        /* just _append_ the newly consumed input to preToU[] */
	        sArray=pArgs.sourceArray;
					sArrayIndex = pArgs.sourceBegin;
	        match=-match;
	        for(j=cnv.preToULength; j<match; ++j) {
	            cnv.preToUArray[j]=sArray[sArrayIndex++];
	        }
	        pArgs.sourceBegin=sArrayIndex; /* same as *src=srcLimit; because we reached the end of input */
	        cnv.preToULength=(byte)match;
	    } else /* match==0 */ {
	        /*
	         * no match
	         *
	         * We need to split the previous input into two parts:
	         *
	         * 1. The first codepage character is unmappable - that's how we got into
	         *    trying the extension data in the first place.
	         *    We need to move it from the preToU buffer
	         *    to the error buffer, set an error code,
	         *    and prepare the rest of the previous input for 2.
	         *
	         * 2. The rest of the previous input must be converted once we
	         *    come back from the callback for the first character.
	         *    At that time, we have to try again from scratch to convert
	         *    these input characters.
	         *    The replay will be handled by the ucnv.c conversion code.
	         */
	
	        /* move the first codepage character to the error field */
	        UConverterUtility.uprv_memcpy(cnv.toUBytesArray, cnv.toUBytesBegin, cnv.preToUArray, cnv.preToUBegin, cnv.preToUFirstLength);
	        cnv.toULength=cnv.preToUFirstLength;
	
	        /* move the rest up inside the buffer */
	        length=cnv.preToULength-cnv.preToUFirstLength;
	        if(length>0) {
	            UConverterUtility.uprv_memmove(cnv.preToUArray, cnv.preToUBegin, cnv.preToUArray, cnv.preToUBegin+cnv.preToUFirstLength, length);
	        }
	
	        /* mark preToU for replay */
	        cnv.preToULength=(byte)-length;
	
	        /* set the error code for unassigned */
	        pErrorCode[0]=ErrorCode.U_INVALID_CHAR_FOUND;
	    }
	}
	
	/* from Unicode ------------------------------------------------------------- */
	
	/*
	 * @return index of the UChar, if found; else <0
	 */
	//static U_INLINE int32_t ucnv_extFindFromU(const UChar *fromUSection, int32_t length, UChar u)
	static int ucnv_extFindFromU(CharBuffer fromUSection, int length, char u)
	{
	    int i, start, limit;
	
	    /* binary search */
	    start=0;
	    limit=length;
	    for(;;) {
	        i=limit-start;
	        if(i<=1) {
	            break; /* done */
	        }
	        /* start<limit-1 */
	
	        if(i<=4) {
	            /* linear search for the last part */
	            if(u<=fromUSection.get(fromUSection.position() + start)) {
	                break;
	            }
	            if(++start<limit && u<=fromUSection.get(fromUSection.position() +start)) {
	                break;
	            }
	            if(++start<limit && u<=fromUSection.get(fromUSection.position() + start)) {
	                break;
	            }
	            /* always break at start==limit-1 */
	            ++start;
	            break;
	        }
	
	        i=(start+limit)/2;
	        if(u<fromUSection.get(fromUSection.position() +i)) {
	            limit=i;
	        } else {
	            start=i;
	        }
	    }
	
	    /* did we really find it? */
	    if(start<limit && u==fromUSection.get(fromUSection.position() +start)) {
	        return start;
	    } else {
	        return -1; /* not found */
	    }
	}
	
	/*
	 * @param cx pointer to extension data; if NULL, returns 0
	 * @param firstCP the first code point before all the other UChars
	 * @param pre UChars that must match; !initialMatch: partial match with them
	 * @param preLength length of pre, >=0
	 * @param src UChars that can be used to complete a match
	 * @param srcLength length of src, >=0
	 * @param pMatchValue [out] output result value for the match from the data structure
	 * @param useFallback "use fallback" flag, usually from cnv->useFallback
	 * @param flush TRUE if the end of the input stream is reached
	 * @return >1: matched, return value=total match length (number of input units matched)
	 *          1: matched, no mapping but request for <subchar1>
	 *             (only for the first code point)
	 *          0: no match
	 *         <0: partial match, return value=negative total match length
	 *             (partial matches are never returned for flush==TRUE)
	 *             (partial matches are never returned as being longer than UCNV_EXT_MAX_UCHARS)
	 *         the matchLength is 2 if only firstCP matched, and >2 if firstCP and
	 *         further code units matched
	 */
	//static int32_t ucnv_extMatchFromU(const int32_t *cx, UChar32 firstCP, const UChar *pre, int32_t preLength, const UChar *src, int32_t srcLength, uint32_t *pMatchValue, UBool useFallback, UBool flush)
	static int ucnv_extMatchFromU(ByteBuffer cx, int firstCP, char[] preArray, int preArrayBegin, int preLength, char[] srcArray, int srcArrayBegin, int srcLength, int[] pMatchValue, boolean useFallback, boolean flush)
	{
	    CharBuffer stage12, stage3;
	    IntBuffer stage3b;
	
	    CharBuffer fromUTableUChars, fromUSectionUChars;
	    IntBuffer fromUTableValues, fromUSectionValues;
	
	    int value, matchValue;
	    int i, j, index, length, matchLength;
	    char c;
	
	    if(cx==null) {
	        return 0; /* no extension data, no match */
	    }
	
	    /* trie lookup of firstCP */
	    index=firstCP>>>10; /* stage 1 index */
	    if(index>=cx.asIntBuffer().get(UCNV_EXT_FROM_U_STAGE_1_LENGTH)) {
	        return 0; /* the first code point is outside the trie */
	    }
	
	    stage12=(CharBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_STAGE_12_INDEX, char.class);
	    stage3=(CharBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_STAGE_3_INDEX, char.class);
	    index=UCNV_EXT_FROM_U(stage12, stage3, index, firstCP);
	
	    stage3b=(IntBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_STAGE_3B_INDEX, int.class);
	    value=stage3b.get(stage3b.position() + index);
	    if(value==0) {
	        return 0;
	    }
	
	    if(UCNV_EXT_TO_U_IS_PARTIAL(value)) {
	        /* partial match, enter the loop below */
	        index=UCNV_EXT_FROM_U_GET_PARTIAL_INDEX(value);
	
	        /* initialize */
	        fromUTableUChars=(CharBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_UCHARS_INDEX, char.class);
	        fromUTableValues=(IntBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_VALUES_INDEX, int.class);
	
	        matchValue=0;
	        i=j=matchLength=0;
	
	        /* we must not remember fallback matches when not using fallbacks */
	
	        /* match input units until there is a full match or the input is consumed */
	        for(;;) {
	            /* go to the next section */
							int oldpos = fromUTableUChars.position();
	            fromUSectionUChars=((CharBuffer)fromUTableUChars.position(index)).slice();
							fromUTableUChars.position(oldpos);
							oldpos = fromUTableValues.position();
	            fromUSectionValues=((IntBuffer)fromUTableValues.position(index)).slice();
							fromUTableValues.position(oldpos);
	
	            /* read first pair of the section */
	            length=fromUSectionUChars.get();
	            value=fromUSectionValues.get();
	            if( value!=0 &&
	                (UCNV_EXT_FROM_U_IS_ROUNDTRIP(value) ||
            		 UConverterUtility.FROM_U_USE_FALLBACK(useFallback, firstCP))
	            ) {
	                /* remember longest match so far */
	                matchValue=value;
	                matchLength=2+i+j;
	            }
	
	            /* match pre[] then src[] */
	            if(i<preLength) {
	                c=preArray[preArrayBegin + i++];
	            } else if(j<srcLength) {
	                c=srcArray[srcArrayBegin + j++];
	            } else {
	                /* all input consumed, partial match */
	                if(flush || (length=(i+j))>UCNV_EXT_MAX_UCHARS) {
	                    /*
	                     * end of the entire input stream, stop with the longest match so far
	                     * or: partial match must not be longer than UCNV_EXT_MAX_UCHARS
	                     * because it must fit into state buffers
	                     */
	                    break;
	                } else {
	                    /* continue with more input next time */
	                    return -(2+length);
	                }
	            }
	
	            /* search for the current UChar */
	            index=ucnv_extFindFromU(fromUSectionUChars, length, c);
	            if(index<0) {
	                /* no match here, stop with the longest match so far */
	                break;
	            } else {
	                value=fromUSectionValues.get(fromUSectionValues.position() + index);
	                if(UCNV_EXT_FROM_U_IS_PARTIAL(value)) {
	                    /* partial match, continue */
	                    index=UCNV_EXT_FROM_U_GET_PARTIAL_INDEX(value);
	                } else {
	                    if( UCNV_EXT_FROM_U_IS_ROUNDTRIP(value) ||
                    		UConverterUtility.FROM_U_USE_FALLBACK(useFallback, firstCP)
	                    ) {
	                        /* full match, stop with result */
	                        matchValue=value;
	                        matchLength=2+i+j;
	                    } else {
	                        /* full match on fallback not taken, stop with the longest match so far */
	                    }
	                    break;
	                }
	            }
	        }
	
	        if(matchLength==0) {
	            /* no match at all */
	            return 0;
	        }
	    } else /* result from firstCP trie lookup */ {
	        if( UCNV_EXT_FROM_U_IS_ROUNDTRIP(value) ||
        		UConverterUtility.FROM_U_USE_FALLBACK(useFallback, firstCP)
	        ) {
	            /* full match, stop with result */
	            matchValue=value;
	            matchLength=2;
	        } else {
	            /* fallback not taken */
	            return 0;
	        }
	    }
	
	    if((matchValue&UCNV_EXT_FROM_U_RESERVED_MASK) != 0) {
	        /* do not interpret values with reserved bits used, for forward compatibility */
	        return 0;
	    }
	
	    /* return result */
	    if(matchValue==UCNV_EXT_FROM_U_SUBCHAR1) {
	        return 1; /* assert matchLength==2 */
	    }
	
	    pMatchValue[0]=UCNV_EXT_FROM_U_MASK_ROUNDTRIP(matchValue);
	    return matchLength;
	}
	
	//static U_INLINE void ucnv_extWriteFromU(UConverter *cnv, const int32_t *cx, uint32_t value, char **target, const char *targetLimit, int32_t **offsets, int32_t srcIndex, UErrorCode *pErrorCode)
	static void ucnv_extWriteFromU(UConverter cnv, ByteBuffer cx, int value, byte[] targetArray, int[] targetArrayBegin, int targetLimit, int[]  offsetsArray, int[] offsetsArrayBegin, int srcIndex, int[] pErrorCode)
	{
	    byte bufferArray[/*1+UCNV_EXT_MAX_BYTES*/] = new byte[1+UCNV_EXT_MAX_BYTES];
			int bufferArrayIndex = 0;
	    byte[] resultArray;
			int resultArrayIndex;
	    int length, prevLength;
	
	    length=UCNV_EXT_FROM_U_GET_LENGTH(value);
	    value=UCNV_EXT_FROM_U_GET_DATA(value);
	
	    /* output the result */
	    if(length<=UCNV_EXT_FROM_U_MAX_DIRECT_LENGTH) {
	        /*
	         * Generate a byte array and then write it below.
	         * This is not the fastest possible way, but it should be ok for
	         * extension mappings, and it is much simpler.
	         * Offset and overflow handling are only done once this way.
	         */
	        int p=bufferArrayIndex+1; /* reserve buffer[0] for shiftByte below */
	        switch(length) {
	        case 3:
	            bufferArray[p++]=(byte)(value>>>16);
	        case 2:
	            bufferArray[p++]=(byte)(value>>>8);
	        case 1:
	            bufferArray[p++]=(byte)value;
	        default:
	            break; /* will never occur */
	        }
	        resultArray=bufferArray;
	        resultArrayIndex=bufferArrayIndex+1;
	    } else {
			byte[] slice = new byte[length];
	        
			// ((ByteBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_BYTES_INDEX, byte.class)).get(slice, cx.position() + value, slice.length);
			// Fixed above code to the following:
			ByteBuffer bb = ((ByteBuffer)UCNV_EXT_ARRAY(cx, UCNV_EXT_FROM_U_BYTES_INDEX, byte.class));
			bb.position(value);
			bb.get(slice, 0, slice.length);
			
			resultArray = slice;
			resultArrayIndex = 0;
	    }
	
	    /* with correct data we have length>0 */
	
	    if((prevLength=(int)cnv.fromUnicodeStatus)!=0) {
	        /* handle SI/SO stateful output */
	        byte shiftByte;
	
	        if(prevLength>1 && length==1) {
	            /* change from double-byte mode to single-byte */
	            shiftByte=(byte)UConverter.UCNV_SI;
	            cnv.fromUnicodeStatus=1;
	        } else if(prevLength==1 && length>1) {
	            /* change from single-byte mode to double-byte */
	            shiftByte=(byte)UConverter.UCNV_SO;
	            cnv.fromUnicodeStatus=2;
	        } else {
	            shiftByte=0;
	        }
	
	        if(shiftByte!=0) {
	            /* prepend the shift byte to the result bytes */
	            bufferArray[0]=shiftByte;
	            if(resultArray != bufferArray || resultArrayIndex!=bufferArrayIndex+1) {
	                UConverterUtility.uprv_memcpy(bufferArray, bufferArrayIndex+1, resultArray, resultArrayIndex, length);
	            }
	            resultArray=bufferArray;
	            resultArrayIndex=bufferArrayIndex;
	            ++length;
	        }
	    }
	
	    UConverterUtility.ucnv_fromUWriteBytes(cnv, resultArray, resultArrayIndex, length, targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, srcIndex, pErrorCode);
	}
	
	/*
	 * target<targetLimit; set error code for overflow
	 */
	//U_CFUNC UBool ucnv_extInitialMatchFromU(UConverter *cnv, const int32_t *cx, UChar32 cp, const UChar **src, const UChar *srcLimit, char **target, const char *targetLimit, int32_t **offsets, int32_t srcIndex, UBool flush, UErrorCode *pErrorCode)
	public static boolean ucnv_extInitialMatchFromU(UConverter cnv, ByteBuffer cx, int cp, char[] srcArray, int[] srcArrayBegin, int srcLimit, byte[] targetArray, int[] targetArrayBegin, int targetLimit, int[] offsetsArray, int[] offsetsArrayBegin, int srcIndex, boolean flush, int[] pErrorCode)
	{
	    int[] value = new int[1];
	    int match;
	
	    /* try to match */
	    match=ucnv_extMatchFromU(cx, cp, null, 0, 0, srcArray, srcArrayBegin[0], srcLimit-srcArrayBegin[0], value, cnv.useFallback, flush);
	
	    /* reject a match if the result is a single byte for DBCS-only */
	    if( match>=2 &&
	        !(UCNV_EXT_FROM_U_GET_LENGTH(value[0])==1 &&
	          cnv.sharedData.mbcs.outputType==UConverterSharedData_MBCS.MBCS_OUTPUT_DBCS_ONLY)
	    ) {
	        /* advance src pointer for the consumed input */
	        srcArrayBegin[0]+=match-2; /* remove 2 for the initial code point */
	
	        /* write result to target */
	        ucnv_extWriteFromU(cnv, cx, value[0], targetArray, targetArrayBegin, targetLimit, offsetsArray, offsetsArrayBegin, srcIndex, pErrorCode);
	        return true;
	    } else if(match<0) {
	        /* save state for partial match */
	        char[] sArray;
					int sArrayIndex;
	        int j;
	
	        /* copy the first code point */
	        cnv.preFromUFirstCP=cp;
	
	        /* now copy the newly consumed input */
					sArray = srcArray;
	        sArrayIndex=srcArrayBegin[0];
	        match=-match-2; /* remove 2 for the initial code point */
	        for(j=0; j<match; ++j) {
	            cnv.preFromUArray[j]=sArray[sArrayIndex++];
	        }
	        srcArrayBegin[0]=sArrayIndex; /* same as *src=srcLimit; because we reached the end of input */
	        cnv.preFromULength=(byte)match;
	        return true;
	    } else if(match==1) {
	        /* matched, no mapping but request for <subchar1> */
	        cnv.useSubChar1=true;
	        return false;
	    } else /* match==0 no match */ {
	        return false;
	    }
	}
	
	//U_CFUNC int32_t ucnv_extSimpleMatchFromU(const int32_t *cx, UChar32 cp, uint32_t *pValue, UBool useFallback)
	int ucnv_extSimpleMatchFromU(ByteBuffer cx, int cp, int[] pValue, boolean useFallback)
	{
	    int[] value = new int[1];
	    int match;
	
	    /* try to match */
	    match=ucnv_extMatchFromU(cx, cp, null, 0, 0, null, 0, 0, value, useFallback, true);
	    if(match>=2) {
	        /* write result for simple, single-character conversion */
	        int length;
	        
	        length=UCNV_EXT_FROM_U_GET_LENGTH(value[0]);
	        value[0]=UCNV_EXT_FROM_U_GET_DATA(value[0]);
	
	        if(length<=UCNV_EXT_FROM_U_MAX_DIRECT_LENGTH) {
	            pValue[0]=value[0];
	            return length;
							//agljport:deleted #if 0 block
	        }
	    }
	
	    /*
	     * return no match because
	     * - match>1 && resultLength>4: result too long for simple conversion
	     * - match==1: no match found, <subchar1> preferred
	     * - match==0: no match found in the first place
	     * - match<0: partial match, not supported for simple conversion (and flush==TRUE)
	     */
	    return 0;
	}
	
	/*
	 * continue partial match with new input, requires cnv->preFromUFirstCP>=0
	 * never called for simple, single-character conversion
	 */
	//U_CFUNC void ucnv_extContinueMatchFromU(UConverter *cnv, UConverterFromUnicodeArgs *pArgs, int32_t srcIndex, UErrorCode *pErrorCode)
	public static void ucnv_extContinueMatchFromU(UConverter cnv, UConverterFromUnicodeArgs pArgs, int srcIndex, int[] pErrorCode)
	{
	    int[] value = new int[1];
	    int match;
	
	    match=ucnv_extMatchFromU(cnv.sharedData.mbcs.extIndexes, cnv.preFromUFirstCP, cnv.preFromUArray, cnv.preFromUBegin, cnv.preFromULength, pArgs.sourceArray, pArgs.sourceBegin, pArgs.sourceLimit-pArgs.sourceBegin, value, cnv.useFallback, pArgs.flush);
	    if(match>=2) {
	        match-=2; /* remove 2 for the initial code point */
	
	        if(match>=cnv.preFromULength) {
	            /* advance src pointer for the consumed input */
	            pArgs.sourceBegin+=match-cnv.preFromULength;
	            cnv.preFromULength=0;
	        } else {
	            /* the match did not use all of preFromU[] - keep the rest for replay */
	            int length=cnv.preFromULength-match;
	            UConverterUtility.uprv_memmove(cnv.preFromUArray, cnv.preFromUBegin, cnv.preFromUArray, cnv.preFromUBegin+match, length);
	            cnv.preFromULength=(byte)-length;
	        }
	
	        /* finish the partial match */
	        cnv.preFromUFirstCP=UConverter.U_SENTINEL;
	
	        /* write result */
					int[] targetBegin = {pArgs.targetBegin};
					int[] offsetsBegin = {pArgs.offsetsBegin};
	        ucnv_extWriteFromU(cnv, cnv.sharedData.mbcs.extIndexes, value[0], pArgs.targetArray, targetBegin, pArgs.targetLimit, pArgs.offsetsArray, offsetsBegin, srcIndex, pErrorCode);
					pArgs.targetBegin = targetBegin[0];
					pArgs.offsetsBegin = offsetsBegin[0];
	    } else if(match<0) {
	        /* save state for partial match */
	        char[] sArray;
					int sArrayIndex;
	        int j;
	
	        /* just _append_ the newly consumed input to preFromU[] */
	        sArray=pArgs.sourceArray;
	        sArrayIndex=pArgs.sourceBegin;
	        match=-match-2; /* remove 2 for the initial code point */
	        for(j=cnv.preFromULength; j<match; ++j) {
	            cnv.preFromUArray[j]=sArray[sArrayIndex++];
	        }
	        pArgs.sourceArray=sArray; /* same as *src=srcLimit; because we reached the end of input */
	        pArgs.sourceBegin=sArrayIndex; /* same as *src=srcLimit; because we reached the end of input */
	        cnv.preFromULength=(byte)match;
	    } else /* match==0 or 1 */ {
	        /*
	         * no match
	         *
	         * We need to split the previous input into two parts:
	         *
	         * 1. The first code point is unmappable - that's how we got into
	         *    trying the extension data in the first place.
	         *    We need to move it from the preFromU buffer
	         *    to the error buffer, set an error code,
	         *    and prepare the rest of the previous input for 2.
	         *
	         * 2. The rest of the previous input must be converted once we
	         *    come back from the callback for the first code point.
	         *    At that time, we have to try again from scratch to convert
	         *    these input characters.
	         *    The replay will be handled by the ucnv.c conversion code.
	         */
	
	        if(match==1) {
	            /* matched, no mapping but request for <subchar1> */
	            cnv.useSubChar1=true;
	        }
	
	        /* move the first code point to the error field */
	        cnv.fromUChar32=cnv.preFromUFirstCP;
	        cnv.preFromUFirstCP=UConverter.U_SENTINEL;
	
	        /* mark preFromU for replay */
	        cnv.preFromULength=(byte)-cnv.preFromULength;
	
	        /* set the error code for unassigned */
	        pErrorCode[0]=ErrorCode.U_INVALID_CHAR_FOUND;
	    }
	}

}
