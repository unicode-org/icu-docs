package com.ibm.icu.impl;

public final class UMachine {

	/** The largest value a 32 bit unsigned integer can hold @stable ICU 2.0 */
	public static final long UINT32_MAX = 4294967295L;
	/** Number of bytes in a UChar. @stable ICU 2.0 */
	public static final int U_SIZEOF_UCHAR = 2;

}

