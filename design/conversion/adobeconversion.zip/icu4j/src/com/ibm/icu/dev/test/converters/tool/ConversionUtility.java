package com.ibm.icu.dev.test.converters.tool;

import java.math.BigInteger;

/**
 * A conversion utility class
 * @author nhantawe
 */
public class ConversionUtility{
	
	final static char hexarray[] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
    
	/**
	 * Convert the hexadecimal String to byte array
	 * @param hexStr String in hexadecimal format
	 */
	public static byte[] convHexStringToByteArray(String hexStr){
		
		byte[] bytes = null;
		byte[] bArray = new BigInteger(hexStr, 16).toByteArray();
				
		if (hexStr.length()==(bArray.length<<1)){
			bytes = bArray;			
		}
		else if (hexStr.length()<(bArray.length<<1)){
			int len = (int)Math.ceil(hexStr.length()/2.0);
			if (len==bArray.length){
				bytes = bArray;
			}
			else{
				// Eliminate the optional minus sign bit
				bytes = new byte[len];
				System.arraycopy(bArray, 1, bytes, 0, bytes.length);
			}
		}
		else{
			// Add 0+ in the front
			int len = (int)Math.ceil(hexStr.length()/2.0);
			bytes = new byte[len];
			System.arraycopy(bArray, 0, bytes, len-bArray.length, bArray.length);
		}
		return bytes;
	}		
	
	/**
	 * Convert the byte array to hexadecimal String
	 * @param byte array
	 */
	public static String convByteArrayToHexString(byte[] bytes){
		
		StringBuffer hexStr = new StringBuffer();
		for (int i=0; i<bytes.length; i++) {
            hexStr.append(hex2(bytes[i])+" ");
        }
		return hexStr.toString();
	}		

	/**
	 * Convert the char array to hexadecimal String
	 * @param char array
	 */
	public static String convCharArrayToHexString(char[] chars){
		
		StringBuffer hexStr = new StringBuffer();
		for (int i=0; i<chars.length; i++) {
            hexStr.append(hex4(chars[i])+" ");
        }
		return hexStr.toString();
	}	
	
	/**
	 * Convert the String to hexadecimal String
	 * @param str String
	 */
	public static String convStringToHexString(String str){
		
		return convCharArrayToHexString(str.toCharArray());
	}
	
    /**
     * Create a 4 character string representing a short int
     * @param short int
     */
	public static String hex4(int val) {
        char hexs[] = new char[4];
        hexs[0] = hexarray[(val>>12)&0x0f];
        hexs[1] = hexarray[(val>>8)&0x0f];
        hexs[2] = hexarray[(val>>4)&0x0f];
        hexs[3] = hexarray[val&0x0f];
        return new String(hexs);
    }
    
    /**
     * Create a 2 character string representing a short int
     * @param short int
     */
	public static String hex2(int val) {
        char hexs[] = new char[2];
        hexs[0] = hexarray[(val>>4)&0x0f];
        hexs[1] = hexarray[val&0x0f];
        return new String(hexs);
    }
}