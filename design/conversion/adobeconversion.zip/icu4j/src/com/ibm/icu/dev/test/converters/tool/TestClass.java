package com.ibm.icu.dev.test.converters.tool;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.Vector;
import java.util.Iterator;
import java.util.Hashtable;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * To provide Data Driven Test for AGL-Java converters
 * @see 		TestDataFromUToU
 * @see 		TestDataToUFromU
 * @see 		TestCase
 * @author Niti Hantaweepant 
 */
public class TestClass {

	// Current output file
	private URI outputPathURI = null;
	private BufferedWriter out = null;
	
	// Test Suite information
	private URI testSuiteURI = null;
	private String testSuiteId = null;
	private Vector testCases = new Vector();
	private Iterator caseIterator = null;
	private Hashtable testCaseHash = new Hashtable();
	private TestCase curTestCase = null;
	
	/**
	* Constructor without specifying output path for the output testing result.
    */	
	public TestClass(){
		
	}
	
	/**
	* Constructor with specifying output path (absolute URI) for the output testing result.
	* @param 	outputPath Absolute URI of the output directory
	* @throws	Exception See setOutputPath method's exception
    */	
	public TestClass(String outputPath) throws Exception{
		setOutputPath(outputPath);
	}

	/**
	* Set the output path (URI) for the output testing result, otherwise, default as <test suite file directory>/output
	* @param 	outputPath Absolute URI of the output directory
	* @throws	NullPointerException If outputPath is null
	* @throws	IllegalArgumentException If outputPath is not an absolute URI
	* @throws	FileNotFoundException If outputPath does not exist or is not a directory
	* @throws	URISyntaxException If outputPath URI is syntax error
	*/	
	public void setOutputPath(String outputPath) throws NullPointerException, IllegalArgumentException, FileNotFoundException, URISyntaxException{
	
		outputPathURI = new URI(outputPath);
		File outputPathFile = new File(outputPathURI);		
		
		if (!outputPathFile.exists() || !outputPathFile.isDirectory()){
			outputPathURI = null;
			throw new FileNotFoundException("The specified output path does not exist");
		}
		if (testSuiteId!=null){
			outputPathURI = outputPathURI.resolve(testSuiteId+"/");
			//new File(outputPathURI).mkdir();
		}
	}
	
	/**
	 * Clear the current test suite
	 */
	public void clearTestSuite() {

		// Try closing the output file writer
		if (out!=null){
			try{
				out.close();				
			}
			catch(IOException e){
				e.printStackTrace();
			}
			out = null;
		}
		if (testSuiteId!=null)
			outputPathURI = outputPathURI.resolve("../");
		testSuiteURI = null;
		testSuiteId = null;
		testCases.clear();
		caseIterator = null;
		testCaseHash.clear();
		System.gc();
	}

	/**
	 * Get an id of the currently loaded test suite
	 * @return	String of Test Suite id
	 */
	public String getTestSuiteId(){

		return testSuiteId;
	}
	
	/**
	 * Get an array of id of test cases in the currently loaded test suite
	 * @return	String array of test case id
	 */
	public String[] getTestCaseIds(){
		
		String[] testCaseIds = new String[testCases.size()];
		for (int i=0; i<testCases.size(); i++){
			testCaseIds[i] = ((TestCase)testCases.elementAt(i)).getId();			
		}
		return testCaseIds;
	}
	
	/**
	 * Get test case in the current suite, one by one (iterator); 
	 * null will be returned when there is no more test case. 
	 * This method automatically keeps track of which test case
	 * is being used in the test result file
	 * @return		Next test case in the suite
	 */
	public TestCase getTestCase(){
		try{
			if (out!=null){
				// Close the previous file
				out.close();
			}
			if (caseIterator!=null && caseIterator.hasNext()){
				curTestCase = (TestCase)caseIterator.next();
				System.out.println("Test Case: "+curTestCase.getId()+"	Encoding:"+curTestCase.getEncoding());
				
				new File(outputPathURI).mkdirs();
				out = new BufferedWriter(new FileWriter(new File(outputPathURI.resolve(curTestCase.getId()+".txt")),true));
			}
			else
				curTestCase = null;
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
		return curTestCase;
	}
	
	/**
	 * Get test case by specifying an id. This method automatically keeps track 
	 * of which test case is being used in the test result file.
	 * @param		id String id of test case
	 * @return		Test case
	 */
	public TestCase getTestCase(String id){
		
		try{
			if (out!=null){
				// Close the previous file
				out.close();
			}
			curTestCase = (TestCase)testCaseHash.get(id);
			if (curTestCase!=null){
				
				System.out.println("Test Case: "+curTestCase.getId()+"	Encoding:"+curTestCase.getEncoding());
				new File(outputPathURI).mkdirs();
				out = new BufferedWriter(new FileWriter(new File(outputPathURI.resolve(curTestCase.getId()+".txt")),true));
			}
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
		return curTestCase;
	}
	
	/**
	 * Get test case by specifying the index. This method automatically keeps track 
	 * of which test case is being used in the test result file.
	 * @param		index Index of test case in current test suite
	 * @return		Test case
	 */
	public TestCase getTestCase(int index) {
		
		try{
			if (out!=null){
				// Close the previous file
				out.close();
			}
			curTestCase = (TestCase)testCases.elementAt(index);
			System.out.println("Test Case: "+curTestCase.getId()+"	Encoding:"+curTestCase.getEncoding());
			
			new File(outputPathURI).mkdirs();
			out = new BufferedWriter(new FileWriter(new File(outputPathURI.resolve(curTestCase.getId()+".txt")),true));
		}
		catch(ArrayIndexOutOfBoundsException ae){
			curTestCase = null;
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
		return curTestCase;
	}
	
	/**
	 * Get an array of all test cases in the current loaded suite
	 * @return		Test case array
	 */
	public TestCase[] getTestCases(){
		
		return (TestCase[])testCases.toArray(new TestCase[testCases.size()]);
	}
	
	/**
	 * Set the current test case being used by specifying the id if the automatic log tracking does not 
	 * apply (for example if the test cases are retrieved by TestCase[] getTestCase()).
	 * @param		id String id
	 */
	public void setCurrentTestCase(String id){
		
		try{
			if (out!=null){
				// Close the previous file
				out.close();
			}
			curTestCase = (TestCase)testCaseHash.get(id);
			if (curTestCase!=null){
				
				System.out.println("Test Case: "+curTestCase.getId()+"	Encoding:"+curTestCase.getEncoding());
				
				new File(outputPathURI).mkdirs();
				out = new BufferedWriter(new FileWriter(new File(outputPathURI.resolve(curTestCase.getId()+".txt")),true));
			}
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	/**
	 * Set the current test case being used by specifying the index (starting from 0 in test suite)
	 * if the automatic log tracking does not apply (for example if the test cases are retrieved by 
	 * TestCase[] getTestCase())
	 * @param		index Index of test case in current test suite
	 */
	public void setCurrentTestCase(int index){
		
		try{
			if (out!=null){
				// Close the previous file
				out.close();
			}
			curTestCase = (TestCase)testCases.elementAt(index);
			System.out.println("Test Case: "+curTestCase.getId()+"	Encoding:"+curTestCase.getEncoding());
			
			new File(outputPathURI).mkdirs();
			out = new BufferedWriter(new FileWriter(new File(outputPathURI.resolve(curTestCase.getId()+".txt")),true));
		}
		catch(ArrayIndexOutOfBoundsException ae){
			curTestCase = null;
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
	}
	
	/**
	 * Load input test suite by input file path (absolute URI)
	 * If the output path has not been set, the default is <test suite directory>/output
	 * @param filePath Absolute URI of the input test suite file
	 * @throws Exception
	 */
	public void loadTestSuite(String filePath){
		
		// Clear the previous test suite
		clearTestSuite();
		
		try{
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			testSuiteURI = new URI(filePath);
			Document doc = docBuilder.parse(new File(testSuiteURI));
	
			// normalize text representation
			doc.getDocumentElement().normalize();
			testSuiteId = doc.getDocumentElement().getAttribute("id");
			System.out.println("Begin loading test suite id: "+testSuiteId);
			NodeList listOfTestCases = doc.getElementsByTagName("testcase");
			
			// Initialize test cases in the current test suite
			for(int i=0; i<listOfTestCases.getLength(); i++){
	
				Node testCaseNode = listOfTestCases.item(i);
				Element testCaseElement = (Element)testCaseNode; 
				initTestCase(testCaseElement.getAttribute("path"));
			}
			caseIterator = testCases.iterator();
			
		}catch (SAXParseException err) {
			System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
			System.out.println(" " + err.getMessage ());

		}catch (SAXException e) {
			Exception x = e.getException ();
			((x == null) ? e : x).printStackTrace ();

		}catch (Throwable t) {
			t.printStackTrace ();
		}
	
		if (outputPathURI==null){
			// Set default output directory as <test suite file directory>/output
			outputPathURI = testSuiteURI.resolve("output/");			
		}
		outputPathURI = outputPathURI.resolve(testSuiteId+"/");
	}
	
	/**
	 * Encode all Unicode character represented by \\uXXXX in str String
	 * to the real Unicode encoding
	 * @param str String to be encoded
	 * @return Encoded Unicode String
	 */
	private String encodeUnicode(String str){

		String codePoint = null;
		int index = 0;
		StringBuffer encStr = new StringBuffer();
		while((index=str.indexOf("\\u"))!=-1){
			if (index+5>=str.length()){
				break;
			}
			codePoint = str.substring(index,index+6);
			try{									
				codePoint = new String(ConversionUtility.convHexStringToByteArray(codePoint.substring(2)),"UTF-16");
				encStr.append(str.substring(0, index));
				encStr.append(codePoint);
				index += 6;
				if (index>=str.length()){
					str = "";
				}
				else{
					str = str.substring(index);
				}
			}
			catch(NumberFormatException e){
				index += 2;
				encStr.append(str.substring(0, index));
				str = str.substring(index);								
			}
			catch(UnsupportedEncodingException e){
				index += 2;
				encStr.append(str.substring(0, index));
				str = str.substring(index);								
			}
		}	
		if (str.length()>0){
			encStr.append(str);
		}
		return encStr.toString();
	}
	
	/**
	 * Initiaiize test case from the input file path (URI)
	 * @param filePath URI of the input test case file
	 */
	private void initTestCase(String filePath){
		
		TestCase testCase = null;
		String id = null;
		String encoding = null;
		Vector fromUToU = new Vector();
		Vector toUFromU = new Vector();
		
		try{
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = null;
			
			URI testCaseURI = new URI(filePath);
			if (!testCaseURI.isAbsolute()){
				// Convert the relative URI to absolute URI based on test suite URI
				doc = docBuilder.parse(new File(testSuiteURI.resolve(testCaseURI)));
			}
			else{
				// Use the provided absolute URI
				doc = docBuilder.parse(new File(testCaseURI));
			}
	
			// normalize text representation
			doc.getDocumentElement().normalize();
			id = doc.getDocumentElement().getAttribute("id");
			System.out.println("Begin loading test case id: "+id);
			
			// If the id is null, this test case is ignored
			if (id==null){
				throw new Exception("The test case id is null, this case is ignored.");
			}
			
			// If the id already exists in the previous loaded test case, this test case is ignored
			if (testCaseHash.get(id)!=null){
				throw new Exception("The test case id: "+id+" is duplicated, this case is ignored.");
			}			
			
			encoding = doc.getDocumentElement().getAttribute("encoding");
			
			// Initialize FromUToU Test Data
			NodeList listOfFromUToU = doc.getElementsByTagName("fromutou");
			if (listOfFromUToU.getLength()>0){
				
				NodeList testDataFromUToUList = ((Element)listOfFromUToU.item(0)).getElementsByTagName("testdata");
				
				if (testDataFromUToUList.getLength()>0){
					System.out.println("FromUToU #rows: "+testDataFromUToUList.getLength());
					for (int i=0; i<testDataFromUToUList.getLength(); i++){
							
						Element testDataElement = (Element)((Node)testDataFromUToUList.item(i));
						NodeList tempNL = null;
						
						String uin = null;
						tempNL = testDataElement.getElementsByTagName("uin");
						if (tempNL.getLength()>0 && 
								tempNL.item(0).getChildNodes().getLength()>0){
							uin = encodeUnicode(tempNL.item(0).getChildNodes().item(0).getNodeValue());
							System.out.println(ConversionUtility.convStringToHexString(uin));
						}
						byte[] cp = null;
						tempNL = testDataElement.getElementsByTagName("cp");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							cp = ConversionUtility.convHexStringToByteArray(tempNL.item(0).getChildNodes().item(0).getNodeValue());
							System.out.println(ConversionUtility.convByteArrayToHexString(cp));
						}				
						String uout = null;
						tempNL = testDataElement.getElementsByTagName("uout");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							uout = encodeUnicode(tempNL.item(0).getChildNodes().item(0).getNodeValue());
						}
						String exception = null;
						tempNL = testDataElement.getElementsByTagName("exception");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							exception = tempNL.item(0).getChildNodes().item(0).getNodeValue();
						}
						
						fromUToU.add(new TestDataFromUToU(uin, cp, uout, exception));
					}
				}
			}	
			
			// Initialize ToUFromU Test Data
			NodeList listOfToUFromU = doc.getElementsByTagName("toufromu");
			if (listOfToUFromU.getLength()>0){
				
				NodeList testDataToUFromUList = ((Element)listOfToUFromU.item(0)).getElementsByTagName("testdata");
				
				if (testDataToUFromUList.getLength()>0){
					System.out.println("ToUFromU #rows: "+testDataToUFromUList.getLength());
					for (int i=0; i<testDataToUFromUList.getLength(); i++){
							
						Element testDataElement = (Element)((Node)testDataToUFromUList.item(i));
						NodeList tempNL = null;
						
						byte[] cpIn = null;
						tempNL = testDataElement.getElementsByTagName("cpin");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							cpIn = ConversionUtility.convHexStringToByteArray(tempNL.item(0).getChildNodes().item(0).getNodeValue());
						}
						
						String u = null;
						tempNL = testDataElement.getElementsByTagName("u");
						if (tempNL.getLength()>0 && 
								tempNL.item(0).getChildNodes().getLength()>0){
							u = encodeUnicode(tempNL.item(0).getChildNodes().item(0).getNodeValue());
						}
						
						byte[] cpOut = null;
						tempNL = testDataElement.getElementsByTagName("cpout");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							cpOut = ConversionUtility.convHexStringToByteArray(tempNL.item(0).getChildNodes().item(0).getNodeValue());
						}				
						
						String exception = null;
						tempNL = testDataElement.getElementsByTagName("exception");
						if (tempNL.getLength()>0 &&
								tempNL.item(0).getChildNodes().getLength()>0){
							exception = tempNL.item(0).getChildNodes().item(0).getNodeValue();
						}
						
						toUFromU.add(new TestDataToUFromU(cpIn, u, cpOut, exception));
					}
				}
			}
			
			// Add initialized test case to the current test suite
			testCase = new TestCase(id, encoding, fromUToU, toUFromU);
			testCases.add(testCase);
			testCaseHash.put(id, testCase);
			
		}catch (SAXParseException err) {
			System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
			System.out.println(" " + err.getMessage ());

		}catch (SAXException e) {
			Exception x = e.getException ();
			((x == null) ? e : x).printStackTrace ();

		}catch (Throwable t) {
			t.printStackTrace ();
		}
	}
	
	/**
	 * Output the testing summary of the current test suite to the console, 
	 * this method automatically clears the number of errors for the current test suite
	 */
	public void printTestSuiteSummary(){
		System.out.println("Test Suite:"+testSuiteId+" Summary");
		int errorNumber = 0;
		TestCase testCase;
		for (int i=0; i<testCases.size(); i++){
			testCase = (TestCase)testCases.elementAt(i);
			errorNumber += testCase.getErrorNumber();
			System.out.println("	Test Case:"+testCase.getId()+"	"+testCase.getErrorNumber()+" errors");
			testCase.clearErrorNumber();
		}
		System.out.println("Total: "+errorNumber+" errors");
	}
	
	/**
	 * Reset the number of errors to 0 for all test cases in the current test suite
	 */
	public void clearErrorNumber(){
		
		for (int i=0; i<testCases.size(); i++){
			((TestCase)testCases.elementAt(i)).clearErrorNumber();			
		}		
	}
	
	/**
	 * Output the testing summary of the current test case to the console
	 */
	public void printTestCaseSummary(){
		if (curTestCase==null){
			System.out.println("There is no current Test Case");
			return;
		}
		
		System.out.println("Test Case:"+curTestCase.getId()+" Summary");
		System.out.println("	"+curTestCase.getErrorNumber()+" errors");
	}
	
	/**
	 * Log any FYI message to the test result file of the current test case
	 * @param msg String message
	 */
	public void logInfo(String msg){		
		TestUtility.logInfo(msg, out);
	}
	
	/**
	 * Log any FYI message to the test result file of the current test case
	 * @param msg String message
	 */
	public void logError(String msg){
		TestUtility.logError(msg, out, curTestCase);
	}	
	
	/**
	 * Assert two Unicode Strings if they are the same, along with logging the result for the current test case
	 * @param 	str1 First String to compare with 
	 * @param 	str2 Second String to compare with
	 * @return 	boolean value whether two Strings are equal
	 */
	public boolean assertUString(String str1, String str2){
		return TestUtility.assertUString(str1, str2, out, curTestCase);
	}
	
	/**
	 * Assert two char arrays if they are the same, along with logging the result for the current test case
	 * @param 	array1 First char array to compare with 
	 * @param 	array2 Second char array to compare with
	 * @return 	boolean value whether two char arrays are equal
	 */
	public boolean assertCharArray(char[] array1, char[] array2){
		return TestUtility.assertCharArray(array1, array2, out, curTestCase);
	}
	
	/**
	 * Assert two byte arrays if they are the same, along with logging the result for the current test case
	 * @param 	array1 First byte array to compare with 
	 * @param 	array2 Second byte array to compare with
	 * @return 	boolean value whether two byte arrays are equal
	 */
	public boolean assertByteArray(byte[] array1, byte[] array2){
		return TestUtility.assertByteArray(array1, array2, out, curTestCase);
	}
	
	/**
	 * Assert the boolean value if it is true, along with logging the result for the current test case
	 * @param 	bValue boolean value 
	 * @return 	boolean value whether the input boolean value is true
	 */
	public boolean assertTrue(boolean bValue){
		return TestUtility.assertTrue(bValue, out, curTestCase);
	}

	/**
	 * Assert the boolean value if it is false, along with logging the result for the current test case
	 * @param 	bValue boolean value 
	 * @return 	boolean value whether the input boolean value is false
	 */
	public boolean assertFalse(boolean bValue){
		return TestUtility.assertFalse(bValue, out, curTestCase);
	}
	
	/**
	 * Assert the object if it is not null, along with logging the result for the current test case
	 * @param 	obj Object 
	 * @return 	boolean value whether the object is not null
	 */
	public boolean assertNotNull(Object obj){
		return TestUtility.assertNotNull(obj, out, curTestCase);
	}
	
	/**
	 * Assert the Exception object if it is the same exception as e2Name, along with logging the result for the current test case
	 * @param 	e1 Exception object
	 * @param	e2Name String exception name
	 * @return 	boolean value whether the Exception object is e2Name type
	 */
	public boolean assertException(Exception e1, String e2Name){
		return TestUtility.assertException(e1, e2Name, out, curTestCase);
	}
	
	/**
	 * Nested static class for testing utility
	 * @see ConversionUtility
	 */
	static class TestUtility{
				
		/**
		 * Log any FYI message to the test result file of the current test case
		 * @param msg String message
		 */
		static void logInfo(String msg, BufferedWriter out){
			
			if (out!=null){			
				try{
					out.write(msg);
					out.newLine();
					out.flush();
				}					
				catch(IOException e){
					e.printStackTrace();
				}					
			}
			else
				System.out.println(msg);
		}
		
		/**
		 * Log any FYI message to the test result file of the current test case
		 * @param msg String message
		 */
		static void logError(String msg, BufferedWriter out, TestCase curTestCase){
			
			if (curTestCase!=null)
				curTestCase.incErrorNumber();
			if (out!=null){			
				try{
					out.write(msg);
					out.newLine();
					out.flush();
				}					
				catch(IOException e){
					e.printStackTrace();
				}					
			}
			else
				System.out.println(msg);
		}		
		
		/**
		 * Assert two Unicode Strings if they are the same, along with logging the result for the current test case
		 * @param 	str1 First String to compare with 
		 * @param 	str2 Second String to compare with
		 * @return 	boolean value whether two Strings are equal
		 */
		static boolean assertUString(String str1, String str2, BufferedWriter out, TestCase curTestCase){
			
			boolean result = true;
			String strResult = "OK";
	
			if (str1==null || str2==null || !str1.equals(str2)){
				result = false;
				strResult = "FAILED";				
			}
			
			strResult += "	comparing UString	"+((str1==null) ? str1 : ConversionUtility.convStringToHexString(str1))+"	and	"+((str2==null) ? str2 : ConversionUtility.convStringToHexString(str2));
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert two char arrays if they are the same, along with logging the result for the current test case
		 * @param 	array1 First char array to compare with 
		 * @param 	array2 Second char array to compare with
		 * @return 	boolean value whether two char arrays are equal
		 */
		static boolean assertCharArray(char[] array1, char[] array2, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
	
			if (array1==null || array2==null || !new String(array1).equals(new String(array2))){				
				result = false;
				strResult = "FAILED";
			}
			
			strResult += "	comparing char array	"+((array1==null) ? "null" : ConversionUtility.convCharArrayToHexString(array1))+"	and	"+((array2==null) ? "null" : ConversionUtility.convCharArrayToHexString(array2));
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert two byte arrays if they are the same, along with logging the result for the current test case
		 * @param 	array1 First byte array to compare with 
		 * @param 	array2 Second byte array to compare with
		 * @return 	boolean value whether two byte arrays are equal
		 */
		static boolean assertByteArray(byte[] array1, byte[] array2, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
	
	        if (array1==null || array2==null || array1.length!=array2.length){
	        	result = false;
	        	strResult = "FAILED";
	        }
	        else{
		        for (int i=0; i<array1.length; i++) {
		            if (array1[i]!=array2[i]){
		                result = false;
		                strResult = "FAILED";
		                break;
		            }
		        }
	        }
	        
			strResult += "	comparing byte array	"+((array1==null) ? "null" :ConversionUtility.convByteArrayToHexString(array1))+"	and	"+((array2==null) ? "null" : ConversionUtility.convByteArrayToHexString(array2));
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert the boolean value if it is true, along with logging the result for the current test case
		 * @param 	bValue boolean value 
		 * @return 	boolean value whether the input boolean value is true
		 */
		static boolean assertTrue(boolean bValue, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
	
	        if (bValue==false){
	        	result = false;
	        	strResult = "FAILED";
	        }
	        
			strResult += "	comparing true boolean,	boolean value: "+bValue;
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert the boolean value if it is false, along with logging the result for the current test case
		 * @param 	bValue boolean value 
		 * @return 	boolean value whether the input boolean value is false
		 */
		static boolean assertFalse(boolean bValue, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
	
	        if (bValue==true){
	        	result = false;
	        	strResult = "FAILED";
	        }
	        
			strResult += "	comparing false boolean,	boolean value: "+bValue;
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert the object if it is not null, along with logging the result for the current test case
		 * @param 	obj Object 
		 * @return 	boolean value whether the object is not null
		 */
		static boolean assertNotNull(Object obj, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
	
	        if (obj==null){
	        	result = false;
	        	strResult = "FAILED";
	        }
	        
			strResult += "	comparing not null object	object is: "+obj;
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
		
		/**
		 * Assert the Exception object if it is the same exception as e2Name, along with logging the result for the current test case
		 * @param 	e1 Exception object
		 * @param	e2Name String exception name
		 * @return 	boolean value whether the Exception object is e2Name type
		 */
		static boolean assertException(Exception e1, String e2Name, BufferedWriter out, TestCase curTestCase){
		
			boolean result = true;
			String strResult = "OK";
			String className = null;
			
			if (e1!=null){
				if (e2Name==null){
					result = false;
		        	strResult = "FAILED";
				}
				else{
					className = e1.getClass().getName();
					if (e2Name.indexOf('.')==-1){
						// Provided exception name doesn't contain the full package
						if (!className.substring(className.lastIndexOf('.')+1).equals(e2Name)){
							result = false;
				        	strResult = "FAILED";
				        }
					}
					else{
						if (!className.equals(e2Name)){
							result = false;
				        	strResult = "FAILED";
				        }
					}
				}
			}
			else if (e2Name!=null){
				result = false;
	        	strResult = "FAILED";
			}
	        
			strResult += "	comparing	Exception object:"+className+"	and	expected Exception Name:"+e2Name;
			
			if (result)
				logInfo(strResult, out);
			else
				logError(strResult, out, curTestCase);
		
			return result;
		}
	}	
	
	// For testing purpose
	public static void main(String[] args) {
        	
		char[] c1 = {'C','D','C'};
		byte[] b1 = {(byte)0xa2, (byte)0xa3, (byte)0xa4};
		
		try{
			// Initiate TestClass instance with the output path specified
			// TestClass tc = new TestClass("file:///c:/p4_redcloud1820/esg/users/nhantawe/aglj/testing/data/");
			TestClass tc = new TestClass();
			// Load test suite file
			//tc.loadTestSuite("file:///C:/p4/redcloud1820/globaldev/third_party/icu_tp/icu32/icu/source/data/mappings/xml/testsuite.xml");
			tc.loadTestSuite("file:///c:/p4/redcloud1820/esg/users/nhantawe/aglj/testing/data/testsuite.xml");
			
			TestCase c = null;
			// Iterate through each TestCase
			while ((c=tc.getTestCase())!=null){
				// Iterate through each TestDataFromUToU
				TestDataFromUToU[] fromUToUArray = c.getFromUToU();
				for (int i=0; i<fromUToUArray.length; i++){
					// To access TestData
					System.out.println(fromUToUArray[i].getUIn());
					System.out.println(fromUToUArray[i].getCP());
					System.out.println(fromUToUArray[i].getUOut());
					System.out.println(fromUToUArray[i].getException());
					// To use Assertion Utility
					tc.assertUString(fromUToUArray[i].getUIn(),"CDE");
					tc.assertCharArray(fromUToUArray[i].getUIn().toCharArray(), c1);
					tc.assertByteArray(fromUToUArray[i].getCP(), b1);
					tc.assertTrue(true);
					tc.assertFalse(true);
					tc.assertNotNull(fromUToUArray[i]);
					tc.assertException(new UnsupportedEncodingException(),fromUToUArray[i].getException());
					// Print testing result of the current TestCase
					tc.printTestCaseSummary();
				}
				// Iterate through each TestDataToUFromU
				TestDataToUFromU[] toUFromUArray = c.getToUFromU();
				for (int i=0; i<toUFromUArray.length; i++){
					// To access Test Data
					System.out.println(toUFromUArray[i].getCPIn());
					System.out.println(toUFromUArray[i].getU());
					System.out.println(toUFromUArray[i].getCPOut());
					System.out.println(toUFromUArray[i].getException());					
				}				
			}						
			
			// Print testing result - number of errors occured in each TestCase
			tc.printTestSuiteSummary();			
			/* Please see detail testing result under output directory */
		}
		catch(Exception e){
			e.printStackTrace();
		}
    }
	
}
