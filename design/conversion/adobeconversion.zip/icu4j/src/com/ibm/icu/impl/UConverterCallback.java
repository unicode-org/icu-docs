package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;

public class UConverterCallback {
	/**
	 * Function pointer for error callback in the unicode to codepage direction.
	 * Called when an error has occured in conversion from unicode, or on open/close of the callback (see reason).
	 * @param context Pointer to the callback's private data
	 * @param args Information about the conversion in progress
	 * @param codeUnits Points to 'length' UChars of the concerned Unicode sequence
	 * @param length Size (in bytes) of the concerned codepage sequence
	 * @param codePoint Single UChar32 (UTF-32) containing the concerend Unicode codepoint.
	 * @param reason Defines the reason the callback was invoked
	 * @param pErrorCode    ICU error code in/out parameter.
	 *                      For converter callback functions, set to a conversion error
	 *                      before the call, and the callback may reset it to U_ZERO_ERROR.
	 * @see ucnv_setFromUCallBack
	 * @stable ICU 2.0
	 */
	// typedef void (U_EXPORT2 *UConverterFromUCallback) ( const void* context, UConverterFromUnicodeArgs *args, const UChar* codeUnits, int32_t length, UChar32 codePoint, UConverterCallbackReason reason, UErrorCode *pErrorCode);
	public interface UConverterFromUCallback {
		public void call(byte[] contextArray, UConverterFromUnicodeArgs args, char[] codeUnitsArray, int codeUnitsBegin, int length, int codePoint, int /*UConverterCallbackReason*/ reason, int[] err);
	}
	
	/**
	 * Function pointer for error callback in the codepage to unicode direction.
	 * Called when an error has occured in conversion to unicode, or on open/close of the callback (see reason).
	 * @param context Pointer to the callback's private data
	 * @param args Information about the conversion in progress
	 * @param codeUnits Points to 'length' bytes of the concerned codepage sequence
	 * @param length Size (in bytes) of the concerned codepage sequence
	 * @param reason Defines the reason the callback was invoked
	 * @param pErrorCode    ICU error code in/out parameter.
	 *                      For converter callback functions, set to a conversion error
	 *                      before the call, and the callback may reset it to U_ZERO_ERROR.
	 * @see ucnv_setToUCallBack
	 * @see UConverterToUnicodeArgs
	 * @stable ICU 2.0
	 */
	//typedef void (U_EXPORT2 *UConverterToUCallback) ( const void* context, UConverterToUnicodeArgs *args, const char *codeUnits, int32_t length, UConverterCallbackReason reason, UErrorCode *pErrorCode););
	public interface UConverterToUCallback {
		public void call(byte[] contextArray, UConverterToUnicodeArgs args, byte[] codeUnitsArray, int codeUnitsBegin, int length, int /*UConverterCallbackReason*/ reason, int[] /*UErrorCode*/ err);
	}
	
	//U_CAPI void    U_EXPORT2 UCNV_FROM_U_CALLBACK_SKIP (                  const void *context, UConverterFromUnicodeArgs *fromUArgs, const UChar* codeUnits, int32_t length, UChar32 codePoint, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_FROM_U_CALLBACK_SKIP implements UConverterFromUCallback {
		public void call(byte[] contextArray, UConverterFromUnicodeArgs fromUArgs, char[] codeUnitsArray, int codeUnitsArrayBegin, int length, int codePoint, int /*UConverterCallbackReason*/ reason, int[] err)
		{
		    if(contextArray==null)
		    {
		        if (reason <= UConverterConstants.UConverterCallbackReason.UCNV_IRREGULAR)
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            return;
		        }
		
		    }
		    else if(contextArray[0]=='i')
		    {
		        if(reason != UConverterConstants.UConverterCallbackReason.UCNV_UNASSIGNED)
		        {
		            /* the caller must have set 
		             * the error code accordingly
		             */
		            return;
		        }
		        else
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            return;
		        }
		    }
		}
	}

	//U_CAPI void  U_EXPORT2 UCNV_TO_U_CALLBACK_SKIP ( const void *context, UConverterToUnicodeArgs *toArgs, const char* codeUnits, int32_t length, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_TO_U_CALLBACK_SKIP implements UConverterToUCallback {
		public void call(byte[] context, UConverterToUnicodeArgs toArgs, byte[] codeUnitsArray, int codeUnitsArrayBegin, int length, int /*UConverterCallbackReason*/ reason, int[] err)
		{
		    if(context==null)
		    {
		        if (reason <= UConverterConstants.UConverterCallbackReason.UCNV_IRREGULAR)
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            return;
		        }
		
		    }
		    else if(context[0]==(byte)'i')
		    {
		        if(reason != UConverterConstants.UConverterCallbackReason.UCNV_UNASSIGNED)
		        {
		            /* the caller must have set 
		             * the error code accordingly
		             */
		            return;
		        }
		        else
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            return;
		        }
    		}
		}
	}

	//U_CAPI void    U_EXPORT2 UCNV_TO_U_CALLBACK_SUBSTITUTE ( const void *context, UConverterToUnicodeArgs *toArgs, const char* codeUnits, int32_t length, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_TO_U_CALLBACK_SUBSTITUTE implements UConverterToUCallback {
	
		public void call(byte[] contextArray, UConverterToUnicodeArgs toArgs, byte[] codeUnitsArray, int codeUnitsBegin, int length, int /*UConverterCallbackReason*/ reason, int[] /*UErrorCode*/ err)
		{
		    if(contextArray == null)
		    {
		        if (reason > UConverterConstants.UConverterCallbackReason.UCNV_IRREGULAR)
		        {
		            return;
		        }
		    
		        err[0] = ErrorCode.U_ZERO_ERROR;
		        UConverterUtility.ucnv_cbToUWriteSub(toArgs,0,err);
		        return;
		    }
		    else if((char)contextArray[0]=='i')
		    {
		        if(reason != UConverterConstants.UConverterCallbackReason.UCNV_UNASSIGNED)
		        {
		            /* the caller must have set 
		             * the error code accordingly
		             */
		            return;
		        }
		        else
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            UConverterUtility.ucnv_cbToUWriteSub(toArgs,0,err);
		            return;
		        }
		    }		
		}
	}

	//U_CAPI void    U_EXPORT2 UCNV_FROM_U_CALLBACK_SUBSTITUTE ( const void *context, UConverterFromUnicodeArgs *fromArgs, const UChar* codeUnits, int32_t length, UChar32 codePoint, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_FROM_U_CALLBACK_SUBSTITUTE implements UConverterFromUCallback {
		public void call(byte[] contextArray, UConverterFromUnicodeArgs fromArgs, char[] codeUnitsArray, int codeUnitsBegin, int length, int codePoint, int /*UConverterCallbackReason*/ reason, int[] err)
		{
		    if(contextArray == null)
		    {
		        if (reason > UConverterConstants.UConverterCallbackReason.UCNV_IRREGULAR)
		        {
		            return;
		        }
		    
		        err[0] = ErrorCode.U_ZERO_ERROR;
		        UConverterUtility.ucnv_cbFromUWriteSub(fromArgs, 0, err);
		        return;
		    }
		    else if((char)contextArray[0]=='i')
		    {
		        if(reason != UConverterConstants.UConverterCallbackReason.UCNV_UNASSIGNED)
		        {
		            /* the caller must have set 
		             * the error code accordingly
		             */
		            return;
		        }
		        else
		        {
		            err[0] = ErrorCode.U_ZERO_ERROR;
		            UConverterUtility.ucnv_cbFromUWriteSub(fromArgs, 0, err);
		            return;
		        }
		    }
		}
	}

	/*Function Pointer STOPS at the ILLEGAL_SEQUENCE */
	//U_CAPI void    U_EXPORT2 UCNV_FROM_U_CALLBACK_STOP ( const void *context, UConverterFromUnicodeArgs *fromUArgs, const UChar* codeUnits, int32_t length, UChar32 codePoint, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_FROM_U_CALLBACK_STOP implements UConverterFromUCallback {
		
		public void call(byte[] contextArray, UConverterFromUnicodeArgs fromUArgs, char[] codeUnitsArray, int codeUnitsBegin, int length, int codePoint, int /*UConverterCallbackReason*/ reason, int[] err)
		{
		  /* the caller must have set the error code accordingly */
		  return;
		}
	}

	/*Function Pointer STOPS at the ILLEGAL_SEQUENCE */
	//U_CAPI void    U_EXPORT2 UCNV_TO_U_CALLBACK_STOP ( const void *context, UConverterToUnicodeArgs *toUArgs, const char* codePoints, int32_t length, UConverterCallbackReason reason, UErrorCode * err)
	public static class UCNV_TO_U_CALLBACK_STOP implements UConverterToUCallback {
		public void call(byte[] contextArray, UConverterToUnicodeArgs toUArgs, byte[] codePointsArray, int codePointsArrayBegin, int length, int /*UConverterCallbackReason*/ reason, int[] err)
		{
		  /* the caller must have set the error code accordingly */
		  return;
		}
	}			
}
