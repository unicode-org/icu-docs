package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;;

class UConverterSharedData_Latin1 extends UConverterSharedData {

	public UConverterSharedData_Latin1(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_Latin1()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		_Latin1ToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		_Latin1FromUnicodeWithOffsets(args, pErrorCode);
	}
	
	/* ISO 8859-1 --------------------------------------------------------------- */
	
	/* This is a table-less and callback-less version of ucnv_MBCSSingleToBMPWithOffsets(). */
	//static void _Latin1ToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	final void _Latin1ToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    byte[] sourceArray;
			int sourceArrayIndex;
	    char[] targetArray;
			int targetArrayIndex;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    int sourceIndex;
	
	    /* set up the local pointers */
	    sourceArray=pArgs.sourceArray;
			sourceArrayIndex=pArgs.sourceBegin;
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
			offsetsArrayIndex=pArgs.offsetsBegin;
	
	    sourceIndex=0;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=pArgs.sourceLimit-sourceArrayIndex;
	    if(length<=targetCapacity) {
	        targetCapacity=length;
	    } else {
	        /* target will be full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	        length=targetCapacity;
	    }
	
	//agljport:delete #if LATIN1_UNROLL_TO_UNICODE
			//agljport:delete unrolled loop
	//agljport:delete #endif
	
	    /* conversion loop */
	    while(targetCapacity>0) {
	        targetArray[targetArrayIndex++]=(char)(sourceArray[sourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK);
	        --targetCapacity;
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	
	    /* set offsets */
	    if(offsetsArray!=null) {
	        while(length>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --length;
	        }
	        pArgs.offsetsArray=offsetsArray;
	        pArgs.offsetsBegin=offsetsArrayIndex;
	    }
	}
	
	/* This is a table-less version of ucnv_MBCSSingleFromBMPWithOffsets(). */
	//static void _Latin1FromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	final void _Latin1FromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    char[] sourceArray;
			int sourceArrayIndex, sourceLimit;
	    byte[] targetArray;
			int targetArrayIndex, oldTarget;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    int cp;
	    char c, max;
	
	    int sourceIndex;
	
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
			sourceArray = pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
			targetArray = pArgs.targetArray;
	    targetArrayIndex=oldTarget=pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
			offsetsArrayIndex=pArgs.offsetsBegin;
	
	
	    //agljport:delete if(cnv->sharedData==&_Latin1Data) {
	        max=0xff; /* Latin-1 */
	    //agljport:delete } else {
	        //agljport:delete max=0x7f; /* US-ASCII */
	    //agljport:delete }
	
	    /* get the converter state from UConverter */
	    cp=cnv.fromUChar32;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex= cp==0 ? 0 : -1;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=sourceLimit-sourceArrayIndex;
	    if(length<targetCapacity) {
	        targetCapacity=length;
	    }
	
	    /* conversion loop */
			boolean goto_getTrail = false;
			boolean goto_noMoreInput = false;
	    if(cp!=0 && targetCapacity>0) {
					goto_getTrail = true;
					//agljport:comment inserted getTrail block below
	            if(sourceArrayIndex<sourceLimit) {
	                /* test the following code unit */
	                char trail=sourceArray[sourceArrayIndex];
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    ++sourceArrayIndex;
	                    cp=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)cp, trail);
	                    /* this codepage does not map supplementary code points */
	                    /* callback(unassigned) */
	                } else {
	                    /* this is an unmatched lead code unit (1st surrogate) */
	                    /* callback(illegal) */
	                }
	            } else {
	                /* no more input */
	                cnv.fromUChar32=cp;
									goto_noMoreInput = true;
	            }
							if(!goto_noMoreInput) {
								pErrorCode[0]= UConverterUTF.U_IS_SURROGATE(cp) ? ErrorCode.U_ILLEGAL_CHAR_FOUND : ErrorCode.U_INVALID_CHAR_FOUND;
								cnv.fromUChar32=cp;
							}
	    }
	
	//agljport:delete #if LATIN1_UNROLL_FROM_UNICODE
	//agljport:delete unrolled loop code
	//agljport:delete #endif
	
	    /* conversion loop */
			if(!goto_noMoreInput) {
	    c=0;
	    while(targetCapacity>0 && (c=sourceArray[sourceArrayIndex++])<=max) {
	        /* convert the Unicode code point */
	        targetArray[targetArrayIndex++]=(byte)c;
	        --targetCapacity;
	    }
	
	    if(c>max) {
	        cp=c;
	        if(!UConverterUTF.U_IS_SURROGATE(cp)) {
	            /* callback(unassigned) */
	        } else if(UConverterUTF.U_IS_SURROGATE_LEAD(cp)) {
	getTrail:
	            if(sourceArrayIndex<sourceLimit) {
	                /* test the following code unit */
	                char trail=sourceArray[sourceArrayIndex];
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    ++sourceArrayIndex;
	                    cp=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)cp, trail);
	                    /* this codepage does not map supplementary code points */
	                    /* callback(unassigned) */
	                } else {
	                    /* this is an unmatched lead code unit (1st surrogate) */
	                    /* callback(illegal) */
	                }
	            } else {
	                /* no more input */
	                cnv.fromUChar32=cp;
									goto_noMoreInput = true;
	            }
	        } else {
	            /* this is an unmatched trail code unit (2nd surrogate) */
	            /* callback(illegal) */
	        }
	
					if(!goto_noMoreInput) {
	        pErrorCode[0]= UConverterUTF.U_IS_SURROGATE(cp) ? ErrorCode.U_ILLEGAL_CHAR_FOUND : ErrorCode.U_INVALID_CHAR_FOUND;
	        cnv.fromUChar32=cp;
					}
	    }
			}
	noMoreInput:
	
	    /* set offsets since the start */
	    if(offsetsArray!=null) {
	        int count=targetArrayIndex-oldTarget;
	        while(count>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --count;
	        }
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0]) && sourceArrayIndex<sourceLimit && targetArrayIndex>=pArgs.targetLimit) {
	        /* target is full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
			pArgs.targetArray = targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
			pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/*agljport:delete
	static const UConverterImpl _Latin1Impl={
	    UCNV_LATIN_1,
	
	    NULL,
	    NULL,
	
	    NULL,
	    NULL,
	    NULL,
	
	    _Latin1ToUnicodeWithOffsets,
	    _Latin1ToUnicodeWithOffsets,
	    _Latin1FromUnicodeWithOffsets,
	    _Latin1FromUnicodeWithOffsets,
	    _Latin1GetNextUChar,
	
	    NULL,
	    NULL,
	    NULL,
	    NULL,
	    _Latin1GetUnicodeSet
	};
	*/
	
	/*agljport:change 
	static const UConverterStaticData _Latin1StaticData={
	    sizeof(UConverterStaticData),
	    "ISO-8859-1",
	    819, UCNV_IBM, UCNV_LATIN_1, 1, 1,
	    { 0x1a, 0, 0, 0 }, 1, FALSE, FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	
	const UConverterSharedData _Latin1Data={
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_Latin1StaticData, FALSE, &_Latin1Impl, 
	    0
	};
	*/
	public static UConverterStaticData _Latin1StaticData;
	public static UConverterSharedData_Latin1 _Latin1Data;
	static 
	{
	_Latin1StaticData = new UConverterStaticData(
	    UConverterStaticData.sizeofUConverterStaticData,
	    "ISO-8859-1",
	    819, (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_LATIN_1, (byte)1, (byte)1,
	    new byte[]{ 0x1a, 0, 0, 0 }, (byte)1, (byte)0, (byte)0,
	    (short)0,
	    (byte)0,
	    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
	);
	
	_Latin1Data = new UConverterSharedData_Latin1(
	    sizeofUConverterSharedData, ~0,
	    /*NULL, NULL,*/ _Latin1StaticData, false, /*&_Latin1Impl,*/
	    0
			);
	}
}
