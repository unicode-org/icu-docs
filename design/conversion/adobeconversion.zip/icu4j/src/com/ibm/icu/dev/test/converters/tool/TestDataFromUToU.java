package com.ibm.icu.dev.test.converters.tool;

/**
 * To provide the test data class for conversion testing from Unicode to code page,
 * and from code page back to Unicode which is not necessary a round trip.
 * @see 		TestDataToUFromU
 * @see 		TestCase
 * @see 		TestClass
 * @author Niti Hantaweepant
 */
public class TestDataFromUToU {

	private String uIn = null;
	private byte[] cp = null;
	private String uOut = null;
	private String exception = null;
	
	/**
	* Constructor to initialize test data
	* @param 	uIn Unicode as input
	* @param 	cp Code page
	* @param 	uOut Unicode as output
	* @param 	exception Expected exception 
    */	
	public TestDataFromUToU(String uIn, byte[] cp, String uOut, String exception){
		this.uIn = uIn;
		this.cp = cp;
		this.uOut = uOut;
		this.exception = exception;		
	}
	
	/**
	* Get a value of Unicode as input
	* @return Unicode String
    */	
	public String getUIn(){
		return uIn;
	}
	
	/**
	* Get a value of code page
	* @return byte array of code page
    */	
	public byte[] getCP(){
		return cp;
	}
	
	/**
	* Get a value of Unicode as output
	* @return Unicode String
    */	
	public String getUOut(){
		return uOut;
	}
	
	/**
	* Get the expected exception name that should occur with this test data, otherwise null is returned
	* @return Exception name
    */		
	public String getException(){
		return exception;
	}
}
