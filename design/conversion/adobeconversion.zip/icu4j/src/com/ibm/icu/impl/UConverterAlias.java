package com.ibm.icu.impl;

import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.InputStream;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

public final class UConverterAlias {

	//begin ucnv_io.h
	public static final int UCNV_AMBIGUOUS_ALIAS_MAP_BIT = 0x8000;
	public static final int UCNV_CONVERTER_INDEX_MASK = 0xFFF;
	public static final int UCNV_NUM_RESERVED_TAGS = 2;
	public static final int UCNV_NUM_HIDDEN_TAGS = 1;
	//end ucnv_io.h
	
	//begin ucnv_io.c
	static int[] gConverterListArray = null;
	static int gConverterListArrayIndex;
	static int[] gTagListArray = null;
	static int gTagListArrayIndex;
	static int[] gAliasListArray = null;
	static int gAliasListArrayIndex;
	static int[] gUntaggedConvArrayArray = null;
	static int gUntaggedConvArrayArrayIndex;
	static int[] gTaggedAliasArrayArray = null;
	static int gTaggedAliasArrayArrayIndex;
	static int[] gTaggedAliasListsArray = null;
	static int gTaggedAliasListsArrayIndex;
	static byte[] gStringTableArray = null;
	static int gStringTableArrayIndex;

	static long gConverterListSize;
	static long gTagListSize;
	static long gAliasListSize;
	static long gUntaggedConvArraySize;
	static long gTaggedAliasArraySize;
	static long gTaggedAliasListsSize;
	static long gStringTableSize;
	
	static final String GET_STRING(int idx) { return new String(gStringTableArray, 2*idx, (int)UConverterUtility.uprv_strlen(gStringTableArray, 2*idx)); }
	
	public static final int    tocLengthIndex=0;
	public static final int    converterListIndex=1;
	public static final int    tagListIndex=2;
	public static final int    aliasListIndex=3;
	public static final int    untaggedConvArrayIndex=4;
	public static final int    taggedAliasArrayIndex=5;
	public static final int    taggedAliasListsIndex=6;
	public static final int    reservedIndex1=7;
	public static final int    stringTableIndex=8;
	public static final int    minTocLength=8; /* min. tocLength in the file, does not count the tocLengthIndex! */
	public static final int    offsetsCount = minTocLength + 1;    /* length of the swapper's temporary offsets[] */
	
	static UDataMemory gAliasData=null;
	
	//end ucnv_io.c

	//static U_INLINE UBool isAlias(const char *alias, UErrorCode *pErrorCode) {
	private static final boolean isAlias(String alias, int[] pErrorCode) 
	{
	    if(alias==null) {
	        pErrorCode[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return false;
	    } else if(alias.length() == 0) {
	        return false;
	    } else {
	        return true;
	    }
	}
	
	private static final String CNVALIAS_DATA_FILE_NAME = ICUResourceBundle.ICU_BUNDLE+"/cnvalias.icu";
	
	/**
     * Default buffer size of datafile
     */
	private static final int CNVALIAS_DATA_BUFFER_SIZE = 25000;

	private static final boolean haveAliasData(int[] pErrorCode)
	{
	    boolean needInit;
	
	    if(pErrorCode==null || ErrorCode.isFailure(pErrorCode[0])) {
	        return false;
	    }
	
	    //agljport:todo umtx_lock(NULL);
	    needInit = gAliasData==null;
	
	    /* load converter alias data from file if necessary */
	    if (needInit) {
	        UDataMemory data = null;
					long[] tableArray = null;
	        long tableArrayIndex;
	        long tableStart;
	        long currOffset;
	        long reservedSize1;
					byte[] reservedBytes = null;
	
	        //agljport:fix data = udata_openChoice(NULL, DATA_TYPE, DATA_NAME, isAcceptable, NULL, pErrorCode);
	        //data = udata_openChoice(null, DATA_TYPE, DATA_NAME, 0, isAcceptable, null, pErrorCode);
					try {
						InputStream i = ICUData.getRequiredStream(CNVALIAS_DATA_FILE_NAME);
						BufferedInputStream b = new BufferedInputStream(i, CNVALIAS_DATA_BUFFER_SIZE);
						UConverterAliasDataReader reader = new UConverterAliasDataReader(b);
						tableArray = reader.readToc(offsetsCount);
	
						tableStart      = tableArray[0];
						if (tableStart < minTocLength) {
							pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
							//agljport:fix udata_close(data);
							return false;
						}
						gConverterListSize = tableArray[1];
						gTagListSize = tableArray[2];
						gAliasListSize = tableArray[3];
						gUntaggedConvArraySize = tableArray[4];
						gTaggedAliasArraySize = tableArray[5];
						gTaggedAliasListsSize = tableArray[6];
						reservedSize1 = tableArray[7] * 2;
						gStringTableSize = tableArray[8] * 2;
	
						gConverterListArray = new int[(int)gConverterListSize];
						gTagListArray = new int[(int)gTagListSize];
						gAliasListArray = new int[(int)gAliasListSize];
						gUntaggedConvArrayArray = new int[(int)gUntaggedConvArraySize];
						gTaggedAliasArrayArray = new int[(int)gTaggedAliasArraySize];
						gTaggedAliasListsArray = new int[(int)gTaggedAliasListsSize];
						reservedBytes = new byte[(int)reservedSize1];
						gStringTableArray = new byte[(int)gStringTableSize];
	
						reader.read(gConverterListArray, gTagListArray, gAliasListArray, gUntaggedConvArrayArray, gTaggedAliasArrayArray, gTaggedAliasListsArray, reservedBytes, gStringTableArray);
					}
					catch(IOException e) {
						System.err.println("Caught IOException: " + e.getMessage());
						pErrorCode[0] = ErrorCode.U_INVALID_FORMAT_ERROR;
					}
	        if(ErrorCode.isFailure(pErrorCode[0])) {
	            return false;
	        }
					data = new UDataMemory(); // dummy UDataMemory object in absence of memory mapping
	
	
	
	
	        //agljport:todo umtx_lock(NULL);
	        if(gAliasData==null) {
	            gAliasData = data;
	            data=null;
	
	
	
	            //agljport:fix ucln_common_registerCleanup(UCLN_COMMON_UCNV_IO, ucnv_io_cleanup);
	        }
	        //agljport:todo umtx_unlock(NULL);
	
	        /* if a different thread set it first, then close the extra data */
	        if(data!=null) {
	            //agljport:fix udata_close(data); /* NULL if it was set correctly */
	        }
	    }
	
	    return true;
	}
	
	//U_CFUNC const char * ucnv_io_getConverterName(const char *alias, UErrorCode *pErrorCode)
	public static final String ucnv_io_getConverterName(String alias, int[] pErrorCode) 
	{
	    if(haveAliasData(pErrorCode) && isAlias(alias, pErrorCode)) {
	        long convNum = findConverter(alias, pErrorCode);
	        if (convNum < gConverterListSize) {
	            return GET_STRING(gConverterListArray[(int)convNum]);
	        }
	        /* else converter not found */
	    }
	    return null;
	}
	
	/*
	 * search for an alias
	 * return the converter number index for gConverterList
	 */
	//static U_INLINE uint32_t findConverter(const char *alias, UErrorCode *pErrorCode) 
	private static final long findConverter(String alias, int[] pErrorCode)
	{
	    long mid, start, limit;
	    long lastMid;
	    long result;
	
	    /* do a binary search for the alias */
	    start = 0;
	    limit = gUntaggedConvArraySize;
	    mid = limit;
	    lastMid = UMachine.UINT32_MAX;
	
	    for (;;) {
	        mid = (start + limit) / 2;
	        if (lastMid == mid) {   /* Have we moved? */
	            break;  /* We haven't moved, and it wasn't found. */
	        }
	        lastMid = mid;
	        result = ucnv_compareNames(alias, GET_STRING(gAliasListArray[(int)mid]));
	
	        if (result < 0) {
	            limit = mid;
	        } else if (result > 0) {
	            start = mid;
	        } else {
	            /* Since the gencnval tool folds duplicates into one entry,
	             * this alias in gAliasList is unique, but different standards
	             * may map an alias to different converters.
	             */
	            if ((gUntaggedConvArrayArray[(int)mid] & UCNV_AMBIGUOUS_ALIAS_MAP_BIT) != 0) {
	                pErrorCode[0] = ErrorCode.U_AMBIGUOUS_ALIAS_WARNING;
	            }
	            return gUntaggedConvArrayArray[(int)mid] & UCNV_CONVERTER_INDEX_MASK;
	        }
	    }
	
	    return UMachine.UINT32_MAX;
	}
	
	/**
	 * \var ucnv_io_stripForCompare
	 * Remove the underscores, dashes and spaces from the name, and convert
	 * the name to lower case.
	 * @param dst The destination buffer, which is <= the buffer of name.
	 * @param dst The destination buffer, which is <= the buffer of name.
	 * @return the destination buffer.
	 */
	//#if U_CHARSET_FAMILY==U_ASCII_FAMILY
	public static final StringBuffer ucnv_io_stripForCompare(StringBuffer dst, String name)	
	{
		return ucnv_io_stripASCIIForCompare(dst, name);
	}
	
	//#elif U_CHARSET_FAMILY==U_EBCDIC_FAMILY
	//#   define ucnv_io_stripForCompare ucnv_io_stripEBCDICForCompare
	//#else
	//#   error U_CHARSET_FAMILY is not valid
	//#endif
	
	/* @see ucnv_compareNames */
	static final StringBuffer ucnv_io_stripASCIIForCompare(StringBuffer dst, String name) {
			name = name.concat("\000");
			int nameIndex = 0;
	    char c1 = name.charAt(0);
	    int dstItr = 0;
	
	    while (c1 != 0) {
	        /* Ignore delimiters '-', '_', and ' ' */
	        while ((c1 = name.charAt(nameIndex)) == 0x2d || c1 == 0x5f || c1 == 0x20) {
	            ++nameIndex;
	        }
	
	        /* lowercase for case-insensitive comparison */
	        dst.append(UConverterUtility.uprv_asciitolower(c1));
					++dstItr;
	        ++nameIndex;
	    }
			if(dst.length() > 0)
				dst.deleteCharAt(dst.length() - 1);
	    return dst;
	}
	
	/**
	 * Do a fuzzy compare of a two converter/alias names.  The comparison
	 * is case-insensitive.  It also ignores the characters '-', '_', and
	 * ' ' (dash, underscore, and space).  Thus the strings "UTF-8",
	 * "utf_8", and "Utf 8" are exactly equivalent.
	 *
	 * This is a symmetrical (commutative) operation; order of arguments
	 * is insignificant.  This is an important property for sorting the
	 * list (when the list is preprocessed into binary form) and for
	 * performing binary searches on it at run time.
	 *
	 * @param name1 a converter name or alias, zero-terminated
	 * @param name2 a converter name or alias, zero-terminated
	 * @return 0 if the names match, or a negative value if the name1
	 * lexically precedes name2, or a positive value if the name1
	 * lexically follows name2.
	 *
	 * @see ucnv_io_stripForCompare
	 */
	//U_CAPI int U_EXPORT2 ucnv_compareNames(const char *name1, const char *name2) {
	public static final int ucnv_compareNames(String name1_, String name2_)
	{
	    int rc;
	    char c1, c2;
			String name1 = name1_.concat("\000");
			String name2 = name2_.concat("\000");
			int name1idx = 0, name2idx = 0;
	
	    for (;;) {
	        /* Ignore delimiters '-', '_', and ' ' */
	        while ((c1 = name1.charAt(name1idx)) == '-' || c1 == '_' || c1 == ' ') {
	            ++name1idx;
	        }
	        while ((c2 = name2.charAt(name2idx)) == '-' || c2 == '_' || c2 == ' ') {
	            ++name2idx;
	        }
	
	        /* If we reach the ends of both strings then they match */
	        if (c1 == '\000' && c2 == '\000') {
	            return 0;
	        }
	
	        /* Case-insensitive comparison */
	        rc = (int)UConverterUtility.uprv_tolower(c1) - (int)UConverterUtility.uprv_tolower(c2);
	        if (rc != 0) {
	            return rc;
	        }
	        ++name1idx;
	        ++name2idx;
	    }
	}

	//U_CFUNC uint16_t ucnv_io_countAliases(const char *alias, UErrorCode *pErrorCode)
	public static int ucnv_io_countAliases(String alias, int[] pErrorCode)
	{
	    if(haveAliasData(pErrorCode) && isAlias(alias, pErrorCode)) {
	        long convNum = findConverter(alias, pErrorCode);
	        if (convNum < gConverterListSize) {
	            /* tagListNum - 1 is the ALL tag */
	            int listOffset = gTaggedAliasArrayArray[(int)((gTagListSize - 1)*gConverterListSize + convNum)];
	
	            if (listOffset != 0) {
	                return gTaggedAliasListsArray[listOffset];
	            }
	            /* else this shouldn't happen. internal program error */
	        }
	        /* else converter not found */
	    }
	    return 0;
	}

	/**
	 * Return the number of all aliases (and converter names).
	 * @param pErrorCode The error code
	 * @return the number of all aliases
	 */
	//U_CFUNC uint16_t ucnv_io_countTotalAliases(UErrorCode *pErrorCode);	
	public static int ucnv_io_countTotalAliases(int[] pErrorCode)
	{
	    if (haveAliasData(pErrorCode)) {
	        return (int)gAliasListSize;
	    }
	    return 0;
	}
	
	//U_CFUNC const char * ucnv_io_getAlias(const char *alias, uint16_t n, UErrorCode *pErrorCode)
	public static String ucnv_io_getAlias(String alias, int n, int[] pErrorCode)
	{
	    if(haveAliasData(pErrorCode) && isAlias(alias, pErrorCode)) {
	        long convNum = findConverter(alias, pErrorCode);
	        if (convNum < gConverterListSize) {
	            /* tagListNum - 1 is the ALL tag */
	            int listOffset = gTaggedAliasArrayArray[(int)((gTagListSize - 1)*gConverterListSize + convNum)];
	
	            if (listOffset != 0) {
	                long listCount = gTaggedAliasListsArray[listOffset];
	                /* +1 to skip listCount */
					int[] currListArray = gTaggedAliasListsArray;	
	                int currListArrayIndex = listOffset + 1;
	
	                if (n < listCount)  {
	                    return GET_STRING(currListArray[currListArrayIndex + n]);
	                }
	                pErrorCode[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	            }
	            /* else this shouldn't happen. internal program error */
	        }
	        /* else converter not found */
	    }
	    return null;
	}
	
	//U_CFUNC uint16_t ucnv_io_countStandards(UErrorCode *pErrorCode) {
	public static int ucnv_io_countStandards(int[] pErrorCode)
	{
	    if(haveAliasData(pErrorCode)){
	    	return (int)(gTagListSize - UCNV_NUM_HIDDEN_TAGS);
	    }
	    return 0;
	}
	
	//U_CAPI const char * U_EXPORT2ucnv_getStandard(uint16_t n, UErrorCode *pErrorCode)
	public static String ucnv_getStandard(int n, int[] pErrorCode)
	{
	    if(haveAliasData(pErrorCode)) {
	    	if (n<gTagListSize - UCNV_NUM_HIDDEN_TAGS){
	    		return GET_STRING(gTagListArray[n]);
	    	}
	       	pErrorCode[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	        
	    }
	    return null;
	}
		
	//U_CAPI const char * U_EXPORT2 ucnv_getStandardName(const char *alias, const char *standard, UErrorCode *pErrorCode)
	public static final String ucnv_getStandardName(String alias, String standard, int[] pErrorCode) 
	{
		if(haveAliasData(pErrorCode) && isAlias(alias, pErrorCode)) {
			long listOffset = findTaggedAliasListsOffset(alias, standard, pErrorCode);
	  	
			if (0<listOffset && listOffset < gTaggedAliasListsSize){
				int[] currListArray = gTaggedAliasListsArray;
				long currListArrayIndex = listOffset + 1;
				if (currListArray[0]!=0){
					return GET_STRING(currListArray[(int)currListArrayIndex]);
				}
			}
		}
		return null;
	}
	
	//	U_CAPI uint16_t U_EXPORT2 ucnv_countAliases(const char *alias, UErrorCode *pErrorCode)
	public static int ucnv_countAliases(String alias, int[] pErrorCode)
	{
	    return ucnv_io_countAliases(alias, pErrorCode);
	}
	
	//U_CAPI const char* U_EXPORT2 ucnv_getAlias(const char *alias, uint16_t n, UErrorCode *pErrorCode)
	public static String ucnv_getAlias(String alias, int n, int[] pErrorCode)
	{
	    return ucnv_io_getAlias(alias, n, pErrorCode);
	}
	
	//U_CFUNC uint16_t ucnv_countStandards(void) 
	public static int ucnv_countStandards()
	{
		int[] err = new int[] {ErrorCode.U_ZERO_ERROR};
		return ucnv_io_countStandards(err);
	}
	
	//U_CAPI const char * U_EXPORT2 ucnv_getCanonicalName(const char *alias, const char *standard, UErrorCode *pErrorCode) {
	public static String ucnv_getCanonicalName(String alias, String standard, int[] pErrorCode) 
	{
		if (haveAliasData(pErrorCode) && isAlias(alias, pErrorCode)) {
	        long convNum = findTaggedConverterNum(alias, standard, pErrorCode);

	        if (convNum < gConverterListSize) {
	            return GET_STRING(gConverterListArray[(int)convNum]);
	        }
	    }

	    return null;
	}
	
	//U_CAPI UEnumeration * U_EXPORT2 ucnv_openStandardNames(const char *convName, const char *standard, UErrorCode *pErrorCode)
	public static final UConverterAliasesEnumeration ucnv_openStandardNames(String convName, String standard, int[] pErrorCode)
	{
	    UConverterAliasesEnumeration enum = null;
	    if (haveAliasData(pErrorCode) && isAlias(convName, pErrorCode)) {
	        long listOffset = findTaggedAliasListsOffset(convName, standard, pErrorCode);
	
	        /* When listOffset == 0, we want to acknowledge that the
	           converter name and standard are okay, but there
	           is nothing to enumerate. */
	        if (listOffset < gTaggedAliasListsSize) {
	          
	        	UConverterAliasesEnumeration.UAliasContext context = new UConverterAliasesEnumeration.UAliasContext(listOffset, 0);
	        	enum = new UConverterAliasesEnumeration();
	        	enum.setContext(context);
	        }
	        /* else converter or tag not found */
	    }
	    return enum;
	}
	
	//static uint32_t getTagNumber(const char *tagname)
	private static long getTagNumber(String tagName) {
	    if (gTagListArray!=null) {
	        long tagNum;
	        for (tagNum = 0; tagNum < gTagListSize; tagNum++) {
	            if (tagName.equals(GET_STRING(gTagListArray[(int)tagNum]))) {
	                return tagNum;
	            }
	        }
	    }
	
	    return UMachine.UINT32_MAX;
	}
	
	//static uint32_t findTaggedAliasListsOffset(const char *alias, const char *standard, UErrorCode *pErrorCode) 
	private static long findTaggedAliasListsOffset(String alias, String standard, int[] pErrorCode)
	{
		long idx;
	    long listOffset;
	    long convNum;
	    int[] myErr = {ErrorCode.U_ZERO_ERROR};
	    long tagNum = getTagNumber(standard);
	
	    /* Make a quick guess. Hopefully they used a TR22 canonical alias. */
	    convNum = findConverter(alias, myErr);
	    if (myErr[0] != ErrorCode.U_ZERO_ERROR) {
	        pErrorCode = myErr;
	    }
	
	    if (tagNum < (gTagListSize - UCNV_NUM_HIDDEN_TAGS) && convNum < gConverterListSize) {
	        listOffset = gTaggedAliasArrayArray[(int)(tagNum*gConverterListSize + convNum)];
	        if (listOffset!=0 && gTaggedAliasListsArray[(int)listOffset + 1]!=0) {
	            return listOffset;
	        }
	        if (myErr[0] == ErrorCode.U_AMBIGUOUS_ALIAS_WARNING) {
	             /*Uh Oh! They used an ambiguous alias.
	               We have to search the whole swiss cheese starting
	               at the highest standard affinity.
	               This may take a while. */
	            
	            for (idx = 0; idx < gTaggedAliasArraySize; idx++) {
	                listOffset = gTaggedAliasArrayArray[(int)idx];
	                if (listOffset!=0 && isAliasInList(alias, listOffset)) {
	                    long currTagNum = idx/gConverterListSize;
	                    long currConvNum = (idx - currTagNum*gConverterListSize);
	                    long tempListOffset = gTaggedAliasArrayArray[(int)(tagNum*gConverterListSize + currConvNum)];
	                    if (tempListOffset!=0 && gTaggedAliasListsArray[(int)tempListOffset + 1]!=0) {
	                        return tempListOffset;
	                    }
	                    /* else keep on looking 
	                     We could speed this up by starting on the next row
	                       because an alias is unique per row, right now.
	                       This would change if alias versioning appears. */
	                }
	            }
	            /* The standard doesn't know about the alias */ 
	        }
	        /* else no default name */ 
	        return 0;
	    }
	    /* else converter or tag not found */ 
	
	    return UMachine.UINT32_MAX;
	}
	
	/* Return the canonical name */
	//static uint32_t findTaggedConverterNum(const char *alias, const char *standard, UErrorCode *pErrorCode)
	private static long findTaggedConverterNum(String alias, String standard, int[] pErrorCode)
	{
	    long idx;
	    long listOffset;
	    long convNum;
	    int[] myErr = {ErrorCode.U_ZERO_ERROR};
	    long tagNum = getTagNumber(standard);

	    /* Make a quick guess. Hopefully they used a TR22 canonical alias. */
	    convNum = findConverter(alias, myErr);
	    if (myErr[0] != ErrorCode.U_ZERO_ERROR) {
	        pErrorCode = myErr;
	    }

	    if (tagNum < (gTagListSize - UCNV_NUM_HIDDEN_TAGS) && convNum < gConverterListSize) {
	        listOffset = gTaggedAliasArrayArray[(int)(tagNum*gConverterListSize + convNum)];
	        if (listOffset!=0 && isAliasInList(alias, listOffset)) {
	            return convNum;
	        }
	        if (myErr[0] == ErrorCode.U_AMBIGUOUS_ALIAS_WARNING) {
	            /* Uh Oh! They used an ambiguous alias.
	               We have to search one slice of the swiss cheese.
	               We search only in the requested tag, not the whole thing.
	               This may take a while.
	            */
	            long convStart = (tagNum)*gConverterListSize;
	            long convLimit = (tagNum+1)*gConverterListSize;
	            for (idx = convStart; idx < convLimit; idx++) {
	                listOffset = gTaggedAliasArrayArray[(int)idx];
	                if (listOffset!=0 && isAliasInList(alias, listOffset)) {
	                    return idx-convStart;
	                }
	            }
	            /* The standard doesn't know about the alias */
	        }
	        /* else no canonical name */
	    }
	    /* else converter or tag not found */

	    return UMachine.UINT32_MAX;
	}
	
	//static U_INLINE UBool isAliasInList(const char *alias, uint32_t listOffset) 
	private static boolean isAliasInList(String alias, long listOffset)
	{
	    if (listOffset!=0) {
	        long currAlias;
	        long listCount = gTaggedAliasListsArray[(int)listOffset];
	        /* +1 to skip listCount */
	        int[] currList = gTaggedAliasListsArray;
	        long currListArrayIndex = listOffset + 1;
	        for (currAlias = 0; currAlias < listCount; currAlias++) {
	            if (currList[(int)(currAlias+currListArrayIndex)]!=0
	                && ucnv_compareNames(alias, GET_STRING(currList[(int)(currAlias+currListArrayIndex)]))==0)
	            {
	                return true;
	            }
	        }
	    }
	    return false;
	}
	
	//begin ucnv_bld.c
	static String[] gAvailableConverters = null;
	static int gAvailableConverterCount = 0;
	
	static byte[] gDefaultConverterNameBuffer; //[UCNV_MAX_CONVERTER_NAME_LENGTH + 1]; /* +1 for NULL */
	static String gDefaultConverterName = null;	
	
	//static UBool haveAvailableConverterList(UErrorCode *pErrorCode)
	static boolean haveAvailableConverterList(int[] pErrorCode)
	{
	    if (gAvailableConverters == null) {
	        int idx;
	        int localConverterCount;
	        int[] status = new int[1];
	        String converterName;
	        String[] localConverterList;
	
	        if (!haveAliasData(pErrorCode)) {
	            return false;
	        }
	
	        /* We can't have more than "*converterTable" converters to open */
	        localConverterList = new String[(int)gConverterListSize];
	        if (localConverterList == null) {
	            pErrorCode[0] = ErrorCode.U_MEMORY_ALLOCATION_ERROR;
	            return false;
	        }
	
	        localConverterCount = 0;
	
	        for (idx = 0; idx < gConverterListSize; idx++) {
	            status[0] = ErrorCode.U_ZERO_ERROR;
	            converterName = GET_STRING(gConverterListArray[idx]);
				UConverter cnv = UConverter.ucnv_open(converterName, status);
	            if (ErrorCode.isSuccess(status[0])) {
					cnv.ucnv_close();
					localConverterList[localConverterCount++] = converterName;
	            }
	        }
	
	        //agljport:todo umtx_lock(NULL);
	        if (gAvailableConverters == null) {
	            gAvailableConverters = localConverterList;
	            gAvailableConverterCount = localConverterCount;
	            /* haveData should have already registered the cleanup function */
	        }
	        else {
	            //agljport:todo uprv_free((char **)localConverterList);
	        }
	        //agljport:todo umtx_unlock(NULL);
	    }
	    return true;
	}
	
	//U_CFUNC uint16_t ucnv_bld_countAvailableConverters(UErrorCode *pErrorCode)
	public static int ucnv_bld_countAvailableConverters(int[] pErrorCode)
	{
	    if (haveAvailableConverterList(pErrorCode)) {
	        return gAvailableConverterCount;
	    }
	    return 0;
	}
	
	//U_CFUNC const char * ucnv_bld_getAvailableConverter(uint16_t n, UErrorCode *pErrorCode)
	public static String ucnv_bld_getAvailableConverter(int n, int[] pErrorCode)
	{
	    if (haveAvailableConverterList(pErrorCode)) {
	        if (n < gAvailableConverterCount) {
	            return gAvailableConverters[n];
	        }
	        pErrorCode[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	    }
	    return null;
	}
	
	/* default converter name --------------------------------------------------- */
	
	/*
	 * In order to be really thread-safe, the get function would have to take
	 * a buffer parameter and copy the current string inside a mutex block.
	 * This implementation only tries to be really thread-safe while
	 * setting the name.
	 * It assumes that setting a pointer is atomic.
	 */
	
	// U_CFUNC const char * ucnv_getDefaultName()
	public static final String ucnv_getDefaultName() 
	{
	    /* local variable to be thread-safe */
		String name;
	
	    //agljport:todo umtx_lock(null);
	    name=gDefaultConverterName;
	    //agljport:todo umtx_unlock(null);
	
	    if(name==null) {
	        int[] errorCode = new int[1]; errorCode[0] = ErrorCode.U_ZERO_ERROR;
	        UConverter cnv = null;
	        long length = 0;
	
	        name = UConverterUtility.uprv_getDefaultCodepage();
	
	        /* if the name is there, test it out and get the canonical name with options */
	        if(name != null) {
	            cnv = UConverter.ucnv_open(name, errorCode);
	            if(ErrorCode.isSuccess(errorCode[0]) && cnv != null) {
	                name = cnv.ucnv_getName(cnv, errorCode);
	            }
	        }
	
	        if(name == null || name.length() == 0
	            || ErrorCode.isFailure(errorCode[0]) || cnv == null
	            || length>=gDefaultConverterNameBuffer.length)
	        {
	            /* Panic time, let's use a fallback. */
	//#if (U_CHARSET_FAMILY == U_ASCII_FAMILY)
	            name = new String("US-ASCII");
	            /* there is no 'algorithmic' converter for EBCDIC */
	//#elif defined(OS390)
	//            name = "ibm-1047_P100-1995" UCNV_SWAP_LFNL_OPTION_STRING;
	//#else
	//            name = "ibm-37_P100-1995";
	//#endif
	        }
	
	        //length=(int32_t)(uprv_strlen(name));
	
	        /* Copy the name before we close the converter. */
	        //agljport:todo umtx_lock(null);
	        //agljport:delete uprv_memcpy(gDefaultConverterNameBuffer, name, length);
	        //agljport:delete gDefaultConverterNameBuffer[length]=0;
	        //agljport:delete gDefaultConverterName = gDefaultConverterNameBuffer;
	        name = gDefaultConverterName;
	        //agljport:todo ucln_common_registerCleanup(UCLN_COMMON_UCNV_IO, ucnv_io_cleanup);
	        //agljport:todo umtx_unlock(null);
	
	        /* The close may make the current name go away. */
	        cnv.ucnv_close();
	    }
	
	    return name;
	}
	
	//end ucnv_bld.c
}