package com.ibm.icu.impl;

/**
 * C struct UEnumeration
 * */
public interface UEnumeration {

	/** 
     * these are functions that will 
     * be used for APIs
     */
	/* called from uenum_close */
    //public void close();
	/* called from uenum_count */
    public int count(int[] status);
    /* called from uenum_unext */
    public String uNext(int[] status);
    /* called from uenum_next */
    //public byte[] next(int[] status);
    /* called from uenum_reset */
    public void reset(int[] status);
	
}
