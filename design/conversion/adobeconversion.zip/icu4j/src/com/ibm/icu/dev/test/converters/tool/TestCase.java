package com.ibm.icu.dev.test.converters.tool;

import java.util.Vector;

/**
 * To provide test case class for particular test suite 
 * @see 		TestDataFromUToU
 * @see 		TestDataToUFromU
 * @see 		TestClass
 * @author Niti Hantaweepant
 */
public class TestCase {

	private String id = null;
	private String encoding = null;
	private Vector fromUToU = null;
	private Vector toUFromU = null;
	private int errorNumber = 0;
	
	/**
	* Constructor to initialize test case
	* @param 	id Test case identifier
	* @param 	encoding 
	* @param 	fromUToU Array of FromUToU test data
	* @param 	toUFromU Array of ToUFromU test data 
    */	
	public TestCase(String id, String encoding, Vector fromUToU, Vector toUFromU){
		this.id = id;
		this.encoding = encoding;
		this.fromUToU = fromUToU;
		this.toUFromU = toUFromU;
	}
	
	/**
	* Get the test case id
	* @return String of Test case id 
    */
	public String getId(){
		return id;
	}
	
	/**
	* Get the encoding of the particular test case
	* @return String of encoding
    */
	public String getEncoding(){
		return encoding;
	}
	
	/**
	* Get all FromUToU test data
	* @return TestDataFromUToU array
    */
	public TestDataFromUToU[] getFromUToU(){
		return (TestDataFromUToU[])fromUToU.toArray(new TestDataFromUToU[fromUToU.size()]);
	}
	
	/**
	* Get all UToUFromU test data
	* @return TestDataToUFromU array
    */
	public TestDataToUFromU[] getToUFromU(){
		return (TestDataToUFromU[])toUFromU.toArray(new TestDataToUFromU[toUFromU.size()]);
	}
	
	/**
	* Get the number of errors occurring during testing
	* @return integer of error number
    */
	public int getErrorNumber(){
		return errorNumber;		
	}
	
	/**
	* Increase the error number from testing of particular test case
    */
	protected void incErrorNumber(){
		errorNumber++;
	}
	
	/**
	* Reset the number of errors to 0 
    */ 
	protected void clearErrorNumber(){
		errorNumber = 0;
	}
	
}
