/*
**********************************************************************
*   Copyright (C) 2000-2004, International Business Machines
*   Corporation and others.  All Rights Reserved.
**********************************************************************
*   file name:  ucnv2022.c
*   encoding:   US-ASCII
*   tab size:   8 (not used)
*   indentation:4
*
*   created on: 2000feb03
*   created by: Markus W. Scherer
*
*   Change history:
*
*   06/29/2000  helena  Major rewrite of the callback APIs.
*   08/08/2000  Ram     Included support for ISO-2022-JP-2
*                       Changed implementation of toUnicode
*                       function
*   08/21/2000  Ram     Added support for ISO-2022-KR
*   08/29/2000  Ram     Seperated implementation of EBCDIC to
*                       ucnvebdc.c
*   09/20/2000  Ram     Added support for ISO-2022-CN
*                       Added implementations for getNextUChar()
*                       for specific 2022 country variants.
*   10/31/2000  Ram     Implemented offsets logic functions
*/

package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;
import com.ibm.icu.impl.UConverterSharedData.UConverterPlatform;
import com.ibm.icu.impl.UConverterSharedData.UConverterType;

public class UConverterSharedData_ISO2022 extends UConverterSharedData
{
	public UConverterSharedData_ISO2022(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}

	public UConverterSharedData_ISO2022()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}

	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		_ISO2022Open(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		if (args.converter.sharedData == _ISO2022JPData)
		{
			UConverter_toUnicode_ISO_2022_JP_OFFSETS_LOGIC(args, pErrorCode);
		}
		else if (args.converter.sharedData == _ISO2022KRData)
		{
			UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC(args, pErrorCode);
		}
		else if (args.converter.sharedData == _ISO2022CNData)
		{
			UConverter_toUnicode_ISO_2022_CN_OFFSETS_LOGIC(args, pErrorCode);
		}
		else
		{
			assert false;	// args.converter.sharedData should have been set properly when _ISO2022Open()/ucnv_open() was called.
		}
	}

	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		if (args.converter.sharedData == _ISO2022JPData)
		{
			UConverter_fromUnicode_ISO_2022_JP_OFFSETS_LOGIC(args, pErrorCode);
		}
		else if (args.converter.sharedData == _ISO2022KRData)
		{
			UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC(args, pErrorCode);
		}
		else if (args.converter.sharedData == _ISO2022CNData)
		{
			UConverter_fromUnicode_ISO_2022_CN_OFFSETS_LOGIC(args, pErrorCode);
		}
		else
		{
			assert false;	// args.converter.sharedData should have been set properly when _ISO2022Open()/ucnv_open() was called.
		}
	}
	
	// mhokari: This data should be in UConverter
	/* this is used in fromUnicode DBCS tables as an "unassigned" marker */
	protected static final char missingCharMarker = 0xFFFF;

	protected static final byte[] SHIFT_IN_STR  = { (byte)0x0F };
	protected static final byte[] SHIFT_OUT_STR = { (byte)0x0E };
	
	protected static final byte CR      = (byte)0x0D;
	protected static final byte LF      = (byte)0x0A;
	protected static final byte H_TAB   = (byte)0x09;
	protected static final byte V_TAB   = (byte)0x0B;
	protected static final byte SPACE   = (byte)0x20;
	
	/*
	 * ISO 2022 control codes must not be converted from Unicode
	 * because they would mess up the byte stream.
	 * The bit mask 0x0800c000 has bits set at bit positions 0xe, 0xf, 0x1b
	 * corresponding to SO, SI, and ESC.
	 */
	protected static boolean IS_2022_CONTROL(int c) { return (((c)<0x20) && (((long)1<<(c))&0x0800c000)!=0); }
	
	/* for ISO-2022-JP and -CN implementations */
	//private enum  StateEnum
	//{
		/* shared values */
		protected static final byte INVALID_STATE	=	-1;
		protected static final byte ASCII			=	0;
			
		protected static final byte SS2_STATE		=	0x10 + 0;
		protected static final byte SS3_STATE		=	0x10 + 1;
		
		/* JP */
		protected static final byte ISO8859_1		= 1;
		protected static final byte ISO8859_7		= 2;
		protected static final byte JISX201			= 3;
		protected static final byte JISX208			= 4;
		protected static final byte JISX212			= 5;
		protected static final byte GB2312			= 6;
		protected static final byte KSC5601			= 7;
		protected static final byte HWKANA_7BIT		= 8;    /* Halfwidth Katakana 7 bit */
		
		/* CN */
		/* the first few enum constants must keep their values because they correspond to myConverterArray[] */
		protected static final byte GB2312_1			= 1;
		protected static final byte ISO_IR_165		= 2;
		protected static final byte CNS_11643		= 3;
		
		/*
		 * these are used in StateEnum and ISO2022State variables,
		 * but CNS_11643 must be used to index into myConverterArray[]
		 */
		protected static final byte CNS_11643_0		= 0x20 + 0;
		protected static final byte CNS_11643_1		= 0x20 + 1;
		protected static final byte CNS_11643_2		= 0x20 + 2;
		protected static final byte CNS_11643_3		= 0x20 + 3;
		protected static final byte CNS_11643_4		= 0x20 + 4;
		protected static final byte CNS_11643_5		= 0x20 + 5;
		protected static final byte CNS_11643_6		= 0x20 + 6;
		protected static final byte CNS_11643_7		= 0x20 + 7;
	//}
	
	/* is the StateEnum charset value for a DBCS charset? */
	protected static boolean IS_JP_DBCS(final byte cs)
	{
		return JISX208 <= cs && cs <= KSC5601;
	}

	protected static short CSM(final byte cs)
	{
		return (short)(1 << cs);
	}
	
	/*
	 * Each of these charset masks (with index x) contains a bit for a charset in exact correspondence
	 * to whether that charset is used in the corresponding version x of ISO_2022,locale=ja,version=x
	 *
	 * Note: The converter uses some leniency:
	 * - The escape sequence ESC ( I for half-width 7-bit Katakana is recognized in
	 *   all versions, not just JIS7 and JIS8.
	 * - ICU does not distinguish between different versions of JIS X 0208.
	 */
	protected static final short[] jpCharsetMasks =
	{
	    (short)(CSM(ASCII) | CSM(JISX201) | CSM(JISX208) | CSM(HWKANA_7BIT)),
	    (short)(CSM(ASCII) | CSM(JISX201) | CSM(JISX208) | CSM(HWKANA_7BIT) | CSM(JISX212)),
		(short)(CSM(ASCII) | CSM(JISX201) | CSM(JISX208) | CSM(HWKANA_7BIT) | CSM(JISX212) | CSM(GB2312) | CSM(KSC5601) | CSM(ISO8859_1) | CSM(ISO8859_7)),
		(short)(CSM(ASCII) | CSM(JISX201) | CSM(JISX208) | CSM(HWKANA_7BIT) | CSM(JISX212) | CSM(GB2312) | CSM(KSC5601) | CSM(ISO8859_1) | CSM(ISO8859_7)),
		(short)(CSM(ASCII) | CSM(JISX201) | CSM(JISX208) | CSM(HWKANA_7BIT) | CSM(JISX212) | CSM(GB2312) | CSM(KSC5601) | CSM(ISO8859_1) | CSM(ISO8859_7))
	};
	
	//private enum Cnv2022Type
	//{
		protected static final byte ASCII1	= 0;
		protected static final byte LATIN1	= 1;
		protected static final byte SBCS	= 2;
		protected static final byte DBCS	= 3;
		protected static final byte MBCS	= 4;
	protected static final byte HWKANA	= 5;
	//}
	
	protected static final class ISO2022State
	{
	    public byte	cs[/*4*/];	/* charset number for SI (G0)/SO (G1)/SS2 (G2)/SS3 (G3) */
	    public byte	g;			/* 0..3 for G0..G3 (SI/SO/SS2/SS3) */
	    public byte	prevG;		/* g before single shift (SS2 or SS3) */
	    
	    public ISO2022State()
	    {
	    	reset();
	    }
	    
	    public void reset()
	    {
		    cs		= new byte [/*4*/] { 0, 0, 0, 0 };
		    g		= 0;
		    prevG	= 0;
	    }
	}
	
	protected static final long	UCNV_OPTIONS_VERSION_MASK	=	0xf;
	protected static final byte	UCNV_2022_MAX_CONVERTERS	=	10;
	
	protected static final class UConverterDataISO2022
	{
		public UConverter currentConverter;
	    public byte /*Cnv2022Type*/ currentType;
	    public ISO2022State toU2022State;
	    public ISO2022State fromU2022State;
	    public UConverterSharedData[/*UCNV_2022_MAX_CONVERTERS*/] myConverterArray;
	    public int key;
	    public int	version;
	    public String locale;
	    public String	name;
	    
	    public UConverterDataISO2022()
	    {
	    	reset();
	    }
	    
	    public void reset()
	    {
			currentConverter = null;
		    currentType = 0;
		    toU2022State = new ISO2022State();
		    fromU2022State = new ISO2022State();
		    myConverterArray = new UConverterSharedData [UCNV_2022_MAX_CONVERTERS];
		    key = 0;
		    version = 0;
		    locale = "";
		    name = "";
	    }
	}
	
	/* Protos */
	/* ISO-2022 ----------------------------------------------------------------- */
	
	/*Forward declaration */

	protected static final byte ESC_2022 = 0x1B; /*ESC*/
	
	//private enum UCNV_TableStates_2022
	//{
		protected static final byte INVALID_2022				= -1;	/*Doesn't correspond to a valid iso 2022 escape sequence*/
		protected static final byte VALID_NON_TERMINAL_2022		= 0;	/*so far corresponds to a valid iso 2022 escape sequence*/
		protected static final byte VALID_TERMINAL_2022			= 1;	/*corresponds to a valid iso 2022 escape sequence*/
		protected static final byte VALID_MAYBE_TERMINAL_2022	= 2;	/*so far matches one iso 2022 escape sequence, but by adding more characters might match another escape sequence*/
	//}
	
	/*
	* The way these state transition arrays work is:
	* ex : ESC$B is the sequence for JISX208
	*      a) First Iteration: char is ESC
	*          i) Get the value of ESC from normalize_esq_chars_2022[] with int value of ESC as index
	*             int x = normalize_esq_chars_2022[27] which is equal to 1
	*         ii) Search for this value in escSeqStateTable_Key_2022[]
	*             value of x is stored at escSeqStateTable_Key_2022[0]
	*        iii) Save this index as offset
	*         iv) Get state of this sequence from escSeqStateTable_Value_2022[]
	*             escSeqStateTable_Value_2022[offset], which is VALID_NON_TERMINAL_2022
	*     b) Switch on this state and continue to next char
	*          i) Get the value of $ from normalize_esq_chars_2022[] with int value of $ as index
	*             which is normalize_esq_chars_2022[36] == 4
	*         ii) x is currently 1(from above)
	*               x<<=5 -- x is now 32
	*               x+=normalize_esq_chars_2022[36]
	*               now x is 36
	*        iii) Search for this value in escSeqStateTable_Key_2022[]
	*             value of x is stored at escSeqStateTable_Key_2022[2], so offset is 2
	*         iv) Get state of this sequence from escSeqStateTable_Value_2022[]
	*             escSeqStateTable_Value_2022[offset], which is VALID_NON_TERMINAL_2022
	*     c) Switch on this state and continue to next char
	*        i)  Get the value of B from normalize_esq_chars_2022[] with int value of B as index
	*        ii) x is currently 36 (from above)
	*            x<<=5 -- x is now 1152
	*            x+=normalize_esq_chars_2022[66]
	*            now x is 1161
	*       iii) Search for this value in escSeqStateTable_Key_2022[]
	*            value of x is stored at escSeqStateTable_Key_2022[21], so offset is 21
	*        iv) Get state of this sequence from escSeqStateTable_Value_2022[21]
	*            escSeqStateTable_Value_2022[offset], which is VALID_TERMINAL_2022
	*         v) Get the converter name form escSeqStateTable_Result_2022[21] which is JISX208
	*/
	
	
	/*Below are the 3 arrays depicting a state transition table*/
	protected static final byte normalize_esq_chars_2022[/*256*/] =
	{
	/*       0      1       2       3       4      5       6        7       8       9           */
	
	         0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,1      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,4      ,7      ,29      ,0
	        ,2     ,24     ,26     ,27     ,0      ,3      ,23     ,6      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,5      ,8      ,9      ,10     ,11     ,12
	        ,13    ,14     ,15     ,16     ,17     ,18     ,19     ,20     ,25     ,28
	        ,0     ,0      ,21     ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,22    ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0      ,0
	        ,0     ,0      ,0      ,0      ,0      ,0
	};
	
	protected static final byte MAX_STATES_2022 = 74;
	protected static final int escSeqStateTable_Key_2022[/*MAX_STATES_2022*/] =
	{
	/*   0           1           2           3           4           5           6           7           8           9           */
	
	     1          ,34         ,36         ,39         ,55         ,57         ,60         ,61         ,1093       ,1096
	    ,1097       ,1098       ,1099       ,1100       ,1101       ,1102       ,1103       ,1104       ,1105       ,1106
	    ,1109       ,1154       ,1157       ,1160       ,1161       ,1176       ,1178       ,1179       ,1254       ,1257
	    ,1768       ,1773       ,1957       ,35105      ,36933      ,36936      ,36937      ,36938      ,36939      ,36940
	    ,36942      ,36943      ,36944      ,36945      ,36946      ,36947      ,36948      ,37640      ,37642      ,37644
	    ,37646      ,37711      ,37744      ,37745      ,37746      ,37747      ,37748      ,40133      ,40136      ,40138
	    ,40139      ,40140      ,40141      ,1123363    ,35947624   ,35947625   ,35947626   ,35947627   ,35947629   ,35947630
	    ,35947631   ,35947635   ,35947636   ,35947638
	};
	
	protected static final byte /*UCNV_TableStates_2022*/ escSeqStateTable_Value_2022[/*MAX_STATES_2022*/] =
	{
	/*          0                           1                         2                             3                           4                           5                               6                        7                          8                           9       */
	     VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022     ,VALID_NON_TERMINAL_2022   ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_NON_TERMINAL_2022    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_MAYBE_TERMINAL_2022  ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_NON_TERMINAL_2022    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022    ,VALID_NON_TERMINAL_2022    ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_NON_TERMINAL_2022    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_NON_TERMINAL_2022    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	    ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022        ,VALID_TERMINAL_2022
	};
	
	
	/* Type def for refactoring changeState_2022 code*/
	//private enum Variant2022
	//{
		protected static final byte ISO_2022_JP	=	1;
		protected static final byte ISO_2022_KR	=	2;
		protected static final byte ISO_2022_CN	=	3;
	//};
	
	
	/*************** Converter implementations ******************/
	
	protected static void 
	setInitialStateToUnicodeKR(final UConverter converter, final UConverterDataISO2022 myConverterData)
	{
	    if (myConverterData.version == 1) {
	        UConverter cnv = myConverterData.currentConverter;
	
	        cnv.toUnicodeStatus=0;     /* offset */
	        cnv.mode=0;                /* state */
	        cnv.toULength=0;           /* byteIndex */
	    }
	}
	
	protected static void 
	setInitialStateFromUnicodeKR(final UConverter converter, final UConverterDataISO2022 myConverterData)
	{
	   /* in ISO-2022-KR the designator sequence appears only once
	    * in a file so we append it only once
	    */
	    if ( converter.charErrorBufferLength==0){
	
	        assert converter.charErrorBufferArray.length >= 4;
	        converter.charErrorBufferLength = 4;
	        converter.charErrorBufferBegin = 0;
	        converter.charErrorBufferArray[0] = 0x1b;
	        converter.charErrorBufferArray[1] = 0x24;
	        converter.charErrorBufferArray[2] = 0x29;
	        converter.charErrorBufferArray[3] = 0x43;
	    }
	    if (myConverterData.version == 1) {
	        UConverter cnv = myConverterData.currentConverter;
	
	        cnv.fromUChar32=0;
	        cnv.fromUnicodeStatus=1;   /* prevLength */
	    }
	}
	
	private void _ISO2022Open(UConverter cnv, final String name, final String locale, final long options, final int[] /*UErrorCode*/ errorCode)
	{
	
		String myLocale = "      ";	// 6 spaces
	
		cnv.extraInfo = new UConverterDataISO2022();
		if (cnv.extraInfo != null) {
			UConverterDataISO2022 myConverterData = (UConverterDataISO2022)cnv.extraInfo;
			int version;
	
			myConverterData.currentConverter = null;
			myConverterData.currentType = ASCII1;
			myConverterData.key = 0;
			cnv.fromUnicodeStatus = /*false*/ 0;
			if (locale != null){
				myLocale = locale + myLocale;
			}
			myConverterData.version= 0;
			version = (int)(options & UCNV_OPTIONS_VERSION_MASK);
			if (myLocale.charAt(0)=='j' && (myLocale.charAt(1)=='a'|| myLocale.charAt(1)=='p') && 
					(myLocale.charAt(2)=='_' || myLocale.charAt(2)==' ')){
				/* open the required converters and cache them */
				if ((jpCharsetMasks[version] & CSM(ISO8859_7)) != 0) {
					myConverterData.myConverterArray[ISO8859_7]= UConverter.ucnv_loadSharedData("ISO8859_7", null, errorCode);
				}
				myConverterData.myConverterArray[JISX201]      = UConverter.ucnv_loadSharedData("JISX0201", null, errorCode);
				myConverterData.myConverterArray[JISX208]      = UConverter.ucnv_loadSharedData("jisx-208", null, errorCode);
				if ((jpCharsetMasks[version] & CSM(JISX212)) != 0) {
					myConverterData.myConverterArray[JISX212]  = UConverter.ucnv_loadSharedData("jisx-212", null, errorCode);
				}
				if ((jpCharsetMasks[version] & CSM(GB2312)) != 0) {
					myConverterData.myConverterArray[GB2312]   = UConverter.ucnv_loadSharedData("ibm-5478", null, errorCode);   /* gb_2312_80-1 */
				}
				if ((jpCharsetMasks[version] & CSM(KSC5601)) != 0) {
					myConverterData.myConverterArray[KSC5601]  = UConverter.ucnv_loadSharedData("ksc_5601", null, errorCode);
				}
	
				/* set the function pointers to appropriate funtions */
				cnv.sharedData=_ISO2022JPData;
				myConverterData.locale = "ja";
	
				myConverterData.version = version;
				myConverterData.name = "ISO_2022,locale=ja,version=";
				myConverterData.name += (char)(myConverterData.version+(int)'0');
					}
			else if (myLocale.charAt(0)=='k' && (myLocale.charAt(1)=='o'|| myLocale.charAt(1)=='r') && 
					(myLocale.charAt(2)=='_' || myLocale.charAt(2)==' ')){
	
				if ((options  & UCNV_OPTIONS_VERSION_MASK)==1){
					myConverterData.version = 1;
					myConverterData.currentConverter=
						UConverter.ucnv_open("icu-internal-25546",errorCode);
	
					if (ErrorCode.isFailure(errorCode[0])) {
						_ISO2022Close(cnv);
						return;
					}
	
					myConverterData.name = "ISO_2022,locale=ko,version=1";
					System.arraycopy(
							myConverterData.currentConverter.subCharArray,
							myConverterData.currentConverter.subCharBegin,
							cnv.subCharArray,
							cnv.subCharBegin,
							4);
					cnv.subCharLen = myConverterData.currentConverter.subCharLen;
				}else{
					myConverterData.currentConverter=UConverter.ucnv_open("ibm-949",errorCode);
	
					if (ErrorCode.isFailure(errorCode[0])) {
						_ISO2022Close(cnv);
						return;
					}
	
					myConverterData.version = 0;
					myConverterData.name = "ISO_2022,locale=ko,version=0";
				}
	
				/* initialize the state variables */
				setInitialStateToUnicodeKR(cnv, myConverterData);
				setInitialStateFromUnicodeKR(cnv,myConverterData);
	
				/* set the function pointers to appropriate funtions */
				cnv.sharedData = _ISO2022KRData;
				myConverterData.locale = "ko";
					}
			else if (((myLocale.charAt(0)=='z' && myLocale.charAt(1)=='h') || (myLocale.charAt(0)=='c'&& myLocale.charAt(1)=='n'))&& 
					(myLocale.charAt(2)=='_' || myLocale.charAt(2)==' ')){
	
				/* open the required converters and cache them */
				myConverterData.myConverterArray[GB2312_1]         = UConverter.ucnv_loadSharedData("ibm-5478", null, errorCode);
				if (version==1) {
					myConverterData.myConverterArray[ISO_IR_165]   = UConverter.ucnv_loadSharedData("iso-ir-165", null, errorCode);
				}
				myConverterData.myConverterArray[CNS_11643]        = UConverter.ucnv_loadSharedData("cns-11643-1992", null, errorCode);
	
	
				/* set the function pointers to appropriate funtions */
				cnv.sharedData=_ISO2022CNData;
				myConverterData.locale = "cn";
	
				if ((options  & UCNV_OPTIONS_VERSION_MASK)==1){
					myConverterData.version = 1;
					myConverterData.name = "ISO_2022,locale=zh,version=1";
				}else{
					myConverterData.name = "ISO_2022,locale=zh,version=0";
					myConverterData.version = 0;
				}
					}
			else{
				errorCode[0] = ErrorCode.U_UNSUPPORTED_ERROR;
				return;
			}
	
			cnv.maxBytesPerUChar=cnv.sharedData.staticData.maxBytesPerChar;
	
			if (ErrorCode.isFailure(errorCode[0])) {
				_ISO2022Close(cnv);
			}
		} else {
			errorCode[0] = ErrorCode.U_MEMORY_ALLOCATION_ERROR;
		}
	}
		
		
	private static void _ISO2022Close(final UConverter converter)
	{
		UConverterDataISO2022 myData = (UConverterDataISO2022)converter.extraInfo;
		UConverterSharedData[] array = myData.myConverterArray;
		int i;
	
		if (converter.extraInfo != null) {
			/*close the array of converter pointers and free the memory*/
			for (i=0; i<UCNV_2022_MAX_CONVERTERS; i++) {
				if (array[i]!=null) {
					UConverter.ucnv_unloadSharedDataIfReady(array[i]);
				}
			}
	
			myData.currentConverter.ucnv_close();
	
			if (!converter.isExtraLocal){
				converter.extraInfo = null;
			}
		}
	}
	
	//private static void
	//_ISO2022Reset(final UConverter converter, final /*UConverterResetChoice*/ int choice) {
	//    UConverterDataISO2022 myConverterData=(UConverterDataISO2022)(converter.extraInfo);
	//    if (choice<=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	//        myConverterData.toU2022State.reset();
	//        myConverterData.key = 0;
	//    }
	//    if (choice!=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	//        myConverterData.fromU2022State.reset();
	//    }
	//    /* reset the state variables */
	//    if (myConverterData.locale[0] == 'k'){
	//        if (choice<=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	//            setInitialStateToUnicodeKR(converter, myConverterData);
	//        }
	//        if (choice!=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	//            setInitialStateFromUnicodeKR(converter, myConverterData);
	//        }
	//    }
	//}
	
	private static final String _ISO2022getName(final UConverter cnv)
	{
		if (cnv.extraInfo != null){
			UConverterDataISO2022 myData= (UConverterDataISO2022)cnv.extraInfo;
			return myData.name;
		}
		return null;
	}
	
	
	/*************** to unicode *******************/
	/****************************************************************************
	 * Recognized escape sequences are
	 * <ESC>(B  ASCII
	 * <ESC>.A  ISO-8859-1
	 * <ESC>.F  ISO-8859-7
	 * <ESC>(J  JISX-201
	 * <ESC>(I  JISX-201
	 * <ESC>$B  JISX-208
	 * <ESC>$@  JISX-208
	 * <ESC>$(D JISX-212
	 * <ESC>$A  GB2312
	 * <ESC>$(C KSC5601
	 */
	protected static final /*StateEnum*/ byte[/*MAX_STATES_2022*/] nextStateToUnicodeJP = {
	/*      0                1               2               3               4               5               6               7               8               9    */
	    INVALID_STATE   ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,SS2_STATE      ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,ASCII          ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,JISX201        ,HWKANA_7BIT    ,JISX201        ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,JISX208        ,GB2312         ,JISX208        ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,ISO8859_1      ,ISO8859_7      ,JISX208        ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,KSC5601        ,JISX212        ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	};
	
	/*************** to unicode *******************/
	protected static final /*StateEnum*/ byte[/*MAX_STATES_2022*/] nextStateToUnicodeCN = {
	/*      0                1               2               3               4               5               6               7               8               9    */
	     INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,SS2_STATE      ,SS3_STATE      ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,GB2312_1       ,INVALID_STATE  ,ISO_IR_165
	    ,CNS_11643_1    ,CNS_11643_2    ,CNS_11643_3    ,CNS_11643_4    ,CNS_11643_5    ,CNS_11643_6    ,CNS_11643_7    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	    ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE  ,INVALID_STATE
	};
	
	protected static /*UCNV_TableStates_2022*/ byte getKey_2022(byte c, final int[] key, final int[] offset) 
	{
		int togo;
		int low = 0;
		int hi = MAX_STATES_2022;
		int oldmid=0;
	
		togo = normalize_esq_chars_2022[c & 0xFF];
		if (togo == 0) {
			/* not a valid character anywhere in an escape sequence */
			key[0] = 0;
			offset[0] = 0;
			return INVALID_2022;
		}
		togo = (key[0] << 5) + togo;
	
		while (hi != low)  /*binary search*/{
	
			int mid = (hi+low) >> 1; /*Finds median*/
	
			if (mid == oldmid) 
				break;
	
			if (escSeqStateTable_Key_2022[mid] > togo){
				hi = mid;
			}
			else if (escSeqStateTable_Key_2022[mid] < togo){
				low = mid;
			}
			else /*we found it*/{
				key[0] = togo;
				offset[0] = mid;
				return escSeqStateTable_Value_2022[mid];
			}
			oldmid = mid;
	
		}
	
		key[0] = 0;
		offset[0] = 0;
		return INVALID_2022;
	}
	
	/*runs through a state machine to determine the escape sequence - codepage correspondance
	 */
	protected static void changeState_2022(final UConverter			_this, final byte[]				sourceArray, final int[]				sourceIndex, final int					sourceLimit, final /*Variant2022*/ byte	var, /*UErrorCode*/ int[]		err)
	{
		/*UCNV_TableStates_2022*/ byte value;
		UConverterDataISO2022 myData2022 = (UConverterDataISO2022)_this.extraInfo;
		final int[] key = new int [] { myData2022.key };
		final int[] offset = {0};
		byte c;
	
		value = VALID_NON_TERMINAL_2022;
	DONE:
		while (sourceIndex[0] < sourceLimit) {
			c = sourceArray[sourceIndex[0]++];
			_this.toUBytesArray[_this.toULength++] = c;
			value = getKey_2022(c, key, offset);
	
			switch (value){
	
				case VALID_NON_TERMINAL_2022 :
					/* continue with the loop */
					break;
	
				case VALID_TERMINAL_2022:
					key[0] = 0;
					break DONE;
	
				case INVALID_2022:
					break DONE;
	
				case VALID_MAYBE_TERMINAL_2022:
					{
						/* not ISO_2022 itself, finish here */
						value = VALID_TERMINAL_2022;
						key[0] = 0;
						break DONE;
					}
			}
		}
	
		myData2022.key = key[0];
	
		if (value == VALID_NON_TERMINAL_2022) {
			/* indicate that the escape sequence is incomplete: key!=0 */
			return;
		} else if (value == INVALID_2022 ) {
			err[0] = ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE;
			return;
		} else /* value == VALID_TERMINAL_2022 */ {
			switch (var){
				case ISO_2022_JP:
					{
						/*StateEnum*/ byte tempState=nextStateToUnicodeJP[offset[0]];
						switch (tempState) {
							case INVALID_STATE:
								err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
								break;
							case SS2_STATE:
								if (myData2022.toU2022State.cs[2]!=0) {
									if (myData2022.toU2022State.g<2) {
										myData2022.toU2022State.prevG=myData2022.toU2022State.g;
									}
									myData2022.toU2022State.g=2;
								} else {
									/* illegal to have SS2 before a matching designator */
									err[0] = ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE;
								}
								break;
								/* case SS3_STATE: not used in ISO-2022-JP-x */
							case ISO8859_1:
							case ISO8859_7:
								if ((jpCharsetMasks[myData2022.version] & CSM(tempState)) == 0) {
									err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
								} else {
									/* G2 charset for SS2 */
									myData2022.toU2022State.cs[2]=tempState;
								}
								break;
							default:
								if ((jpCharsetMasks[myData2022.version] & CSM(tempState)) == 0) {
									err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
								} else {
									/* G0 charset */
									myData2022.toU2022State.cs[0]=tempState;
								}
								break;
						}
					}
					break;
				case ISO_2022_CN:
					{
						/*StateEnum*/ byte tempState=nextStateToUnicodeCN[offset[0]];
						switch (tempState) {
							case INVALID_STATE:
								err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
								break;
							case SS2_STATE:
								if (myData2022.toU2022State.cs[2]!=0) {
									if (myData2022.toU2022State.g<2) {
										myData2022.toU2022State.prevG=myData2022.toU2022State.g;
									}
									myData2022.toU2022State.g=2;
								} else {
									/* illegal to have SS2 before a matching designator */
									err[0] = ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE;
								}
								break;
							case SS3_STATE:
								if (myData2022.toU2022State.cs[3]!=0) {
									if (myData2022.toU2022State.g<2) {
										myData2022.toU2022State.prevG=myData2022.toU2022State.g;
									}
									myData2022.toU2022State.g=3;
								} else {
									/* illegal to have SS3 before a matching designator */
									err[0] = ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE;
								}
								break;
							case ISO_IR_165:
								if (myData2022.version==0) {
									err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
									break;
								}
							case GB2312_1:
							case CNS_11643_1:
								myData2022.toU2022State.cs[1]=tempState;
								break;
							case CNS_11643_2:
								myData2022.toU2022State.cs[2]=tempState;
								break;
							default:
								/* other CNS 11643 planes */
								if (myData2022.version==0) {
									err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
								} else {
									myData2022.toU2022State.cs[3]=tempState;
								}
								break;
						}
					}
					break;
				case ISO_2022_KR:
					if (offset[0]==0x30){
						/* nothing to be done, just accept this one escape sequence */
					} else {
						err[0] = ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE;
					}
					break;
	
				default:
					err[0] = ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE;
					break;
			}
		}
		if (ErrorCode.isSuccess(err[0])) {
			_this.toULength = 0;
		}
	}
		
		/*Checks the characters of the buffer against valid 2022 escape sequences
		*if the match we return a pointer to the initial start of the sequence otherwise
		*we return sourceLimit
		*/
		/*for 2022 looks ahead in the stream
		 *to determine the longest possible convertible
		 *data stream
		 */
	protected static int getEndOfBuffer_2022(final byte[]	sourceArray, final int		sourceBegin, final int		sourceLimit, boolean			flush)
	{
	
		int sourceIndex = sourceBegin;
	
		while (sourceIndex < sourceLimit && sourceArray[sourceIndex] != ESC_2022) {
			++sourceIndex;
		}
		return sourceIndex;
	}
		
		
		/* This inline function replicates code in _MBCSFromUChar32() function in ucnvmbcs.c
		 * any future change in _MBCSFromUChar32() function should be reflected in 
		 * this macro
		 */
	protected static void MBCS_FROM_UCHAR32_ISO2022(final UConverterSharedData sharedData, /*UChar32*/ int c, long[] value, boolean useFallback, int[] length, int outputType)
	{
		final int[] cx;
		final char[] table;
		int stage2Entry;
		int myValue;
		int fromUnicodeBytesIndex;
		/* BMP-only codepages are stored without stage 1 entries for supplementary code points */
		if (c<0x10000 || ((sharedData.mbcs.unicodeMask & UConverter.UCNV_HAS_SUPPLEMENTARY) != 0)) {
			table=sharedData.mbcs.fromUnicodeTable;
			stage2Entry=UConverterSharedData_MBCS.MBCS_STAGE_2_FROM_U(table, c);
			/* get the bytes and the length for the output */
			if (outputType==UConverterSharedData_MBCS.MBCS_OUTPUT_2){
				//myValue=MBCS_VALUE_2_FROM_STAGE_2(sharedData.mbcs.fromUnicodeBytes, stage2Entry, c);
				myValue=UConverterSharedData_MBCS.MBCS_VALUE_2_FROM_STAGE_2(sharedData.mbcs.fromUnicodeBytes, stage2Entry, c);
				if (myValue<=0xff) {
					length[0]=1;
				} else {
					length[0]=2;
				}
			} else /* outputType==MBCS_OUTPUT_3 */ {
				//p=MBCS_POINTER_3_FROM_STAGE_2(sharedData.mbcs.fromUnicodeBytes, stage2Entry, c);
				final byte[] fromUnicodeBytes = sharedData.mbcs.fromUnicodeBytes;
				fromUnicodeBytesIndex = UConverterSharedData_MBCS.MBCS_POINTER_3_FROM_STAGE_2(null, stage2Entry, c);
				myValue	=	((int)fromUnicodeBytes[fromUnicodeBytesIndex]     << 16) & 0xFF0000
					|	((int)fromUnicodeBytes[fromUnicodeBytesIndex + 1] <<  8) & 0xFF00
					|	 (int)fromUnicodeBytes[fromUnicodeBytesIndex + 2]        & 0xFF;
				if (myValue<=0xff) {
					length[0]=1;
				} else if (myValue<=0xffff) {
					length[0]=2;
				} else {
					length[0]=3;
				}
			}
			/* is this code point assigned, or do we use fallbacks? */
			if ( (stage2Entry&(1<<(16+(c&0xf))))!=0 ||
					(UConverterUtility.FROM_U_USE_FALLBACK(useFallback, c) && myValue!=0)
				 ) {
				/*
				 * We allow a 0 byte output if the "assigned" bit is set for this entry.
				 * There is no way with this data structure for fallback output
				 * to be a zero byte.
				 */
				/* assigned */
				value[0]=myValue;
				return;
				 }
		}
	
		/* mhokari: Is this section needed?
			 cx=sharedData.mbcs.extIndexes;
			 if (cx!=null) {
			 length[0]=ucnv_extSimpleMatchFromU(cx, c, value, useFallback);
			 return;
			 }
			 */
	
		/* unassigned */
		length[0]=0;
	}
		
		/* This inline function replicates code in _MBCSSingleFromUChar32() function in ucnvmbcs.c
		 * any future change in _MBCSSingleFromUChar32() function should be reflected in 
		 * this macro
		 */
	protected static void MBCS_SINGLE_FROM_UCHAR32(final UConverterSharedData sharedData, int c, int[] retval, boolean useFallback)
	{
		final char[] table; 
		int value;
		/* BMP-only codepages are stored without stage 1 entries for supplementary code points */
		if (c>=0x10000 && !((sharedData.mbcs.unicodeMask & UConverter.UCNV_HAS_SUPPLEMENTARY) != 0)) {
			retval[0]=(-1) & 0xFFFF;
			return;
		}
		/* convert the Unicode code point in c into codepage bytes (same as in _MBCSFromUnicodeWithOffsets) */
		table=sharedData.mbcs.fromUnicodeTable;
		/* get the byte for the output */
		value=UConverterSharedData_MBCS.MBCS_SINGLE_RESULT_FROM_U(table, sharedData.mbcs.fromUnicodeBytes, c);
		/* is this code point assigned, or do we use fallbacks? */
		if (useFallback ? value>=0x800 : value>=0xc00) {
			value &=0xff;
		} else {
			value= -1;
		}
		retval[0]=value & 0xFFFF;
	}
		
		
		/*
		 * To Unicode Callback helper function
		 */
	protected static void toUnicodeCallback(UConverter cnv, final int sourceChar, final int targetUniChar, /*UErrorCode*/ int[] err)
	{
		if (sourceChar>0xff){
			cnv.toUBytesArray[0] = (byte)(sourceChar>>8);
			cnv.toUBytesArray[1] = (byte)sourceChar;
			cnv.toULength = 2;
		}
		else{
			cnv.toUBytesArray[0] =(byte) sourceChar;
			cnv.toULength = 2;
		}
	
		if (targetUniChar == (missingCharMarker-1/*0xfffe*/)){
			err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
		}
		else{
			err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		}
	}
		
		
	protected static void _ISO_2022_WriteSub(final UConverterFromUnicodeArgs args, int offsetIndex, final /*UErrorCode*/ int[] err) 
	{
		final UConverter cnv = args.converter;
		final UConverterDataISO2022 myConverterData=(UConverterDataISO2022)cnv.extraInfo;
		ISO2022State pFromU2022State=myConverterData.fromU2022State;
		int		bufferIndex = 0; /* was p in ICU4C */
		byte[]	subcharArray;
		int		subcharBegin;
		byte[]	buffer = new byte [8];
		int		length;
	
		subcharArray=cnv.subCharArray;
		subcharBegin=cnv.subCharBegin;
		length=cnv.subCharLen; /* assume length==1 for most variants */
	
		bufferIndex = 0;
		switch (myConverterData.locale.charAt(0)){
			case 'j':
				{
					byte cs;
	
					if (pFromU2022State.g == 1) {
						/* JIS7: switch from G1 to G0 */
						pFromU2022State.g = 0;
						buffer[bufferIndex++] = UConverter.UCNV_SI;
					}
	
					cs = pFromU2022State.cs[0];
					if (cs != ASCII && cs != JISX201) {
						/* not in ASCII or JIS X 0201: switch to ASCII */
						pFromU2022State.cs[0] = ASCII;
						buffer[bufferIndex++] = 0x1b;
						buffer[bufferIndex++] = 0x28;
						buffer[bufferIndex++] = 0x42;
					}
	
					buffer[bufferIndex++] = subcharArray[subcharBegin + 0];
					break;
				}
			case 'c':
				if (pFromU2022State.g != 0) {
					/* not in ASCII mode: switch to ASCII */
					pFromU2022State.g = 0;
					buffer[bufferIndex++] = UConverter.UCNV_SI;
				}
				buffer[bufferIndex++] = subcharArray[subcharBegin + 0];
				break;
			case 'k':
				if (myConverterData.version == 0) {
					if (length == 1) {
						if (args.converter.fromUnicodeStatus != 0) {
							/* in DBCS mode: switch to SBCS */
							args.converter.fromUnicodeStatus = 0;
							buffer[bufferIndex++] = UConverter.UCNV_SI;
						}
						buffer[bufferIndex++] = subcharArray[subcharBegin + 0];
					} else /* length == 2*/ {
						if (args.converter.fromUnicodeStatus == 0) {
							/* in SBCS mode: switch to DBCS */
							args.converter.fromUnicodeStatus = 1;
							buffer[bufferIndex++] = UConverter.UCNV_SO;
						}
						buffer[bufferIndex++] = subcharArray[subcharBegin + 0];
						buffer[bufferIndex++] = subcharArray[subcharBegin + 1];
					}
					break;
				} else {
					/* let the subconverter write the subchar */
					args.converter = myConverterData.currentConverter;
					System.arraycopy(
							subcharArray,
							subcharBegin,
							myConverterData.currentConverter.subCharArray,
							myConverterData.currentConverter.subCharBegin,
							4);
					myConverterData.currentConverter.subCharLen = (byte)length;
	
					myConverterData.currentConverter.fromUChar32 = cnv.fromUChar32;
					UConverterUtility.ucnv_cbFromUWriteSub(args, 0, err);
					cnv.fromUChar32 = myConverterData.currentConverter.fromUChar32;
	
					if (err[0] == ErrorCode.U_BUFFER_OVERFLOW_ERROR) {
						if (myConverterData.currentConverter.charErrorBufferLength > 0) {
							System.arraycopy(
									myConverterData.currentConverter.charErrorBufferArray,
									myConverterData.currentConverter.charErrorBufferBegin,
									cnv.charErrorBufferArray,
									cnv.charErrorBufferBegin,
									myConverterData.currentConverter.charErrorBufferLength);
						}
						cnv.charErrorBufferLength = myConverterData.currentConverter.charErrorBufferLength;
						myConverterData.currentConverter.charErrorBufferLength = 0;
					}
					args.converter = cnv;
					return;
				}
			default:
				/* not expected */
				break;
		}
		UConverterUtility.ucnv_cbFromUWriteBytes(args,
				buffer, 0, bufferIndex,
				offsetIndex, err);
	}
	
	/**************************************ISO-2022-JP*************************************************/
	
	/************************************** IMPORTANT **************************************************
	* The UConverter_fromUnicode_ISO2022_JP converter does not use ucnv_fromUnicode() functions for SBCS,DBCS and
	* MBCS; instead, the values are obtained directly by calling _MBCSFromUChar32().
	* The converter iterates over each Unicode codepoint 
	* to obtain the equivalent codepoints from the codepages supported. Since the source buffer is 
	* processed one char at a time it would make sense to reduce the extra processing a canned converter 
	* would do as far as possible.
	*
	* If the implementation of these macros or structure of sharedData struct change in the future, make 
	* sure that ISO-2022 is also changed. 
	***************************************************************************************************
	*/
	
	/***************************************************************************************************
	* Rules for ISO-2022-jp encoding
	* (i)   Escape sequences must be fully contained within a line they should not 
	*       span new lines or CRs
	* (ii)  If the last character on a line is represented by two bytes then an ASCII or
	*       JIS-Roman character escape sequence should follow before the line terminates
	* (iii) If the first character on the line is represented by two bytes then a two 
	*       byte character escape sequence should precede it    
	* (iv)  If no escape sequence is encountered then the characters are ASCII
	* (v)   Latin(ISO-8859-1) and Greek(ISO-8859-7) characters must be designated to G2,
	*       and invoked with SS2 (ESC N).
	* (vi)  If there is any G0 designation in text, there must be a switch to
	*       ASCII or to JIS X 0201-Roman before a space character (but not
	*       necessarily before "ESC 4/14 2/0" or "ESC N ' '") or control
	*       characters such as tab or CRLF.
	* (vi)  Supported encodings:
	*          ASCII, JISX201, JISX208, JISX212, GB2312, KSC5601, ISO-8859-1,ISO-8859-7
	*
	*  source : RFC-1554
	*
	*          JISX201, JISX208,JISX212 : new .cnv data files created
	*          KSC5601 : alias to ibm-949 mapping table
	*          GB2312 : alias to ibm-1386 mapping table
	*          ISO-8859-1 : Algorithmic implemented as LATIN1 case
	*          ISO-8859-7 : alisas to ibm-9409 mapping table
	*/
	
	/* preference order of JP charsets */
	private static final /*StateEnum*/ byte jpCharsetPref[]={
	    ASCII,
	    JISX201,
	    ISO8859_1,
	    ISO8859_7,
	    JISX208,
	    JISX212,
	    GB2312,
	    KSC5601,
	    HWKANA_7BIT
	};
	
	/*
	 * The escape sequences must be in order of the enum constants like JISX201  = 3,
	 * not in order of jpCharsetPref[]!
	 */
	private static final byte[][/*6*/] escSeqChars ={
	    new byte[] { 0x1B, 0x28, 0x42 },         /* <ESC>(B  ASCII       */
	    new byte[] { 0x1B, 0x2E, 0x41 },         /* <ESC>.A  ISO-8859-1  */
	   	new byte[] { 0x1B, 0x2E, 0x46 },         /* <ESC>.F  ISO-8859-7  */
	   	new byte[] { 0x1B, 0x28, 0x4A },         /* <ESC>(J  JISX-201    */
	   	new byte[] { 0x1B, 0x24, 0x42 },         /* <ESC>$B  JISX-208    */
	   	new byte[] { 0x1B, 0x24, 0x28, 0x44 },   /* <ESC>$(D JISX-212    */
	   	new byte[] { 0x1B, 0x24, 0x41 },         /* <ESC>$A  GB2312      */
	   	new byte[] { 0x1B, 0x24, 0x28, 0x43 },   /* <ESC>$(C KSC5601     */
	   	new byte[] { 0x1B, 0x28, 0x49 }          /* <ESC>(I  HWKANA_7BIT */
	};
	
	private static  final int escSeqCharsLen[] ={
	    3, /* length of <ESC>(B  ASCII       */
	    3, /* length of <ESC>.A  ISO-8859-1  */
	    3, /* length of <ESC>.F  ISO-8859-7  */
	    3, /* length of <ESC>(J  JISX-201    */
	    3, /* length of <ESC>$B  JISX-208    */
	    4, /* length of <ESC>$(D JISX-212    */
	    3, /* length of <ESC>$A  GB2312      */
	    4, /* length of <ESC>$(C KSC5601     */
	    3  /* length of <ESC>(I  HWKANA_7BIT */
	};
	
	/*
	* The iteration over various code pages works this way:
	* i)   Get the currentState from myConverterData.currentState
	* ii)  Check if the character is mapped to a valid character in the currentState
	*      Yes .  a) set the initIterState to currentState
	*       b) remain in this state until an invalid character is found
	*      No  .  a) go to the next code page and find the character
	* iii) Before changing the state increment the current state check if the current state 
	*      is equal to the intitIteration state
	*      Yes .  A character that cannot be represented in any of the supported encodings
	*       break and return a U_INVALID_CHARACTER error
	*      No  .  Continue and find the character in next code page
	*
	*
	* TODO: Implement a priority technique where the users are allowed to set the priority of code pages 
	*/
	
	private static void UConverter_fromUnicode_ISO_2022_JP_OFFSETS_LOGIC(final UConverterFromUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
		UConverterDataISO2022	converterData;
		ISO2022State	pFromU2022State;
		final byte[]	targetArray		= args.targetArray;
		int				targetIndex		= args.targetBegin;
		final int		targetLimit		= args.targetLimit;
		final char[]	sourceArray		= args.sourceArray;
		int				sourceIndex		= args.sourceBegin;
		final int		sourceLimit		= args.sourceLimit;
		final int[]	offsetsArray	= args.offsetsArray;
		int				offsetsIndex	= args.offsetsBegin;
		int				sourceChar;
		final byte[]	buffer = new byte [8];
		int				len, outLen;
		final byte[]	choices = new byte [10];
		int				choiceCount;
		int				targetValue = 0;
		boolean			useFallback;
	
		int				i;
		byte			cs, g;
		boolean			goto_getTrail = false;
	
		/* set up the state */
		converterData     = (UConverterDataISO2022)args.converter.extraInfo;
		pFromU2022State   = converterData.fromU2022State;
		useFallback       = args.converter.useFallback;
	
		choiceCount = 0;
	
		/* check if the last codepoint of previous buffer was a lead surrogate*/
		if ((sourceChar = args.converter.fromUChar32)!=0 && targetIndex < targetLimit) {
			goto_getTrail = true;
		}
	
		while (goto_getTrail || (sourceIndex < sourceLimit)) {
			if (goto_getTrail || (targetIndex < targetLimit)) {
	
				if (!goto_getTrail) {
					sourceChar  = sourceArray[sourceIndex++];
				}
				/*check if the char is a First surrogate*/
				if (goto_getTrail || UConverterUTF.U_IS_SURROGATE(sourceChar)) {
					if (goto_getTrail || UConverterUTF.U_IS_SURROGATE_LEAD(sourceChar)) {
	getTrail:
						goto_getTrail = false;
						/*look ahead to find the trail surrogate*/
						if (sourceIndex < sourceLimit) {
							/* test the following code unit */
							char trail=(char)(sourceArray[sourceIndex] & 0xFF);
							if (UConverterUTF16.U16_IS_TRAIL(trail)) {
								sourceIndex++;
								sourceChar=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)sourceChar, trail);
								args.converter.fromUChar32=0x00;
								/* convert this supplementary code point */
								/* exit this condition tree */
							} else {
								/* this is an unmatched lead code unit (1st surrogate) */
								/* callback(illegal) */
								err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
								args.converter.fromUChar32=sourceChar;
								break;
							}
						} else {
							/* no more input */
							args.converter.fromUChar32=sourceChar;
							break;
						}
					} else {
						/* this is an unmatched trail code unit (2nd surrogate) */
						/* callback(illegal) */
						err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
						args.converter.fromUChar32=sourceChar;
						break;
					}
				}
				
				/* do not convert SO/SI/ESC */
	            if(IS_2022_CONTROL(sourceChar)) {
	                /* callback(illegal) */
	                err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                args.converter.fromUChar32=sourceChar;
	                break;
	            }
	
				/* do the conversion */
	
				if (choiceCount == 0) {
					short csm;
	
					/*
					 * The csm variable keeps track of which charsets are allowed
					 * and not used yet while building the choices[].
					 */
					csm = jpCharsetMasks[converterData.version];
					choiceCount = 0;
	
					/* JIS7/8: try single-byte half-width Katakana before JISX208 */
					if (converterData.version == 3 || converterData.version == 4) {
						choices[choiceCount++] = cs = HWKANA_7BIT;
						csm &= ~CSM(cs);
					}
	
					/* try the current G0 charset */
					choices[choiceCount++] = cs = pFromU2022State.cs[0];
					csm &= ~CSM(cs);
	
					/* try the current G2 charset */
					if ((cs = pFromU2022State.cs[2]) != 0) {
						choices[choiceCount++] = cs;
						csm &= ~CSM(cs);
					}
	
					/* try all the other possible charsets */
					for (i = 0; i < jpCharsetPref.length; ++i) {
						cs = jpCharsetPref[i];
						if ((CSM(cs) & csm) != 0) {
							choices[choiceCount++] = cs;
							csm &= ~CSM(cs);
						}
					}
				}
	
				cs = g = 0;
				len = 0;
	
				for (i = 0; i < choiceCount && len == 0; ++i) {
					cs = choices[i];
					switch (cs) {
						case ASCII:
							if (sourceChar <= 0x7f) {
								targetValue = sourceChar;
								len = 1;
							}
							break;
						case ISO8859_1:
							if (0x80 <= sourceChar && sourceChar <= 0xff) {
								targetValue = sourceChar - 0x80;
								len = 1;
								g = 2;
							}
							break;
						case HWKANA_7BIT:
							if ((int)(0xff9f-sourceChar)<=(0xff9f-0xff61)) {
								targetValue = sourceChar - (0xff61 - 0x21);
								len = 1;
	
								if (converterData.version==3) {
									/* JIS7: use G1 (SO) */
									pFromU2022State.cs[1] = cs; /* do not output an escape sequence */
									g = 1;
								} else if (converterData.version==4) {
									/* JIS8: use 8-bit bytes with any single-byte charset, see escape sequence output below */
									byte cs0;
	
									targetValue += 0x80;
	
									cs0 = pFromU2022State.cs[0];
									if (IS_JP_DBCS(cs0)) {
										/* switch from a DBCS charset to JISX201 */
										cs = JISX201;
									} else {
										/* stay in the current G0 charset */
										cs = cs0;
									}
								}
							}
							break;
						case JISX201:
							/* G0 SBCS */
							{
								final int[] targetValueLocal = { targetValue };
								MBCS_SINGLE_FROM_UCHAR32(
										converterData.myConverterArray[cs],
										sourceChar, targetValueLocal,
										useFallback);
								targetValue = targetValueLocal[0];
							}
							if (targetValue <= 0x7f) {
								len = 1;
							}
							break;
						case ISO8859_7:
							{
								final int[] targetValueLocal = { targetValue };
								/* G0 SBCS forced to 7-bit output */
								MBCS_SINGLE_FROM_UCHAR32(
										converterData.myConverterArray[cs],
										sourceChar, targetValueLocal,
										useFallback);
								targetValue = targetValueLocal[0];
							}
							if (0x80 <= targetValue && targetValue <= 0xff) {
								targetValue -= 0x80;
								len = 1;
								g = 2;
							}
							break;
						default:
							/* G0 DBCS */
							{
								final long[] targetValueLocal = { targetValue };
								final int[] lenLocal = { len };
								MBCS_FROM_UCHAR32_ISO2022(
										converterData.myConverterArray[cs],
										sourceChar, targetValueLocal,
										useFallback, lenLocal, UConverterSharedData_MBCS.MBCS_OUTPUT_2);
								targetValue = (int)targetValueLocal[0];
								len = lenLocal[0];
							}
							if (len != 2) {
								len = 0;
							}
							break;
					}
				}
	
				if (len > 0) {
					outLen = 0; /* count output bytes */
	
					/* write SI if necessary (only for JIS7) */
					if (pFromU2022State.g == 1 && g == 0) {
						buffer[outLen++] = UConverter.UCNV_SI;
						pFromU2022State.g = 0;
					}
	
					/* write the designation sequence if necessary */
					if (cs != pFromU2022State.cs[g]) {
						int escLen = escSeqCharsLen[cs];
						System.arraycopy(escSeqChars[cs], 0, buffer, 0, escLen);
						outLen += escLen;
						pFromU2022State.cs[g] = cs;
	
						/* invalidate the choices[] */
						choiceCount = 0;
					}
	
					/* write the shift sequence if necessary */
					if (g != pFromU2022State.g) {
						switch (g) {
							/* case 0 handled before writing escapes */
							case 1:
								buffer[outLen++] = UConverter.UCNV_SO;
								pFromU2022State.g = 1;
								break;
							default: /* case 2 */
								buffer[outLen++] = 0x1b;
								buffer[outLen++] = 0x4e;
								break;
								/* no case 3: no SS3 in ISO-2022-JP-x */
						}
					}
	
					/* write the output bytes */
					if (len == 1) {
						buffer[outLen++] = (byte)targetValue;
					} else /* len == 2 */ {
						buffer[outLen++] = (byte)(targetValue >> 8);
						buffer[outLen++] = (byte)targetValue;
					}
				} else {
					/*
					 * if we cannot find the character after checking all codepages 
					 * then this is an error
					 */
					err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
					args.converter.fromUChar32=sourceChar;
					break;
				}
	
				if (sourceChar == CR || sourceChar == LF) {
					/* reset the G2 state at the end of a line (conversion got us into ASCII or JISX201 already) */
					pFromU2022State.cs[2] = 0;
					choiceCount = 0;
				}
	
				/* output outLen>0 bytes in buffer[] */
				if (outLen == 1) {
					targetArray[targetIndex++] = buffer[0];
					if (offsetsArray != null) {
						offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1; /* -1: known to be ASCII */
					}
				} else if (outLen == 2 && (targetIndex + 2) <= targetLimit) {
					targetArray[targetIndex++] = buffer[0];
					targetArray[targetIndex++] = buffer[1];
					if (offsetsArray != null) {
						int sourceIndexLocal = sourceIndex - args.sourceBegin - UConverterUTF16.U16_LENGTH(sourceChar);
						offsetsArray[offsetsIndex++] = sourceIndexLocal;
						offsetsArray[offsetsIndex++] = sourceIndexLocal;
					}
				} else {
					final int[] targetIndexLocal  = { targetIndex };
					final int[] offsetsIndexLocal = { offsetsIndex };
					UConverterUtility.ucnv_fromUWriteBytes(
							args.converter,
							buffer,
							0,
							outLen,
							targetArray,
							targetIndexLocal,
							targetLimit,
							offsetsArray,
							offsetsIndexLocal,
							sourceIndex - args.sourceBegin- UConverterUTF16.U16_LENGTH(sourceChar),
							err);
					targetIndex  = targetIndexLocal[0];
					offsetsIndex = offsetsIndexLocal[0];
					if (ErrorCode.isFailure(err[0])) {
						break;
					}
				}
			} /* end if (myTargetIndex<myTargetLength) */
			else{
				err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
				break;
			}
	
		}/* end while (mySourceIndex<mySourceLength) */
	
		/*
		 * the end of the input stream and detection of truncated input
		 * are handled by the framework, but for ISO-2022-JP conversion
		 * we need to be in ASCII mode at the very end
		 *
		 * conditions:
		 *   successful
		 *   in SO mode or not in ASCII mode
		 *   end of input and no truncated input
		 */
		if ( ErrorCode.isSuccess(err[0]) &&
				(pFromU2022State.g!=0 || pFromU2022State.cs[0]!=ASCII) &&
				args.flush && sourceIndex>=sourceLimit && args.converter.fromUChar32==0
			 ) {
			int sourceIndexLocal;
	
			outLen = 0;
	
			if (pFromU2022State.g != 0) {
				buffer[outLen++] = UConverter.UCNV_SI;
				pFromU2022State.g = 0;
			}
	
			if (pFromU2022State.cs[0] != ASCII) {
				final int escLen = escSeqCharsLen[ASCII];
				System.arraycopy(escSeqChars[ASCII], 0, buffer, outLen, escLen);
				outLen += escLen;
				pFromU2022State.cs[0] = ASCII;
			}
	
			/* get the source index of the last input character */
			/*
			 * TODO this would be simpler and more reliable if we used a pair
			 * of sourceIndex/prevSourceIndex like in ucnvmbcs.c
			 * so that we could simply use the prevSourceIndex here;
			 * this code gives an incorrect result for the rare case of an unmatched
			 * trail surrogate that is alone in the last buffer of the text stream
			 */
			sourceIndexLocal=sourceIndex-args.sourceBegin;
			if (sourceIndexLocal>0) {
				--sourceIndexLocal;
				if ( UConverterUTF16.U16_IS_TRAIL(args.sourceArray[sourceIndexLocal]) &&
						(sourceIndexLocal==0 || UConverterUTF16.U16_IS_LEAD(args.sourceArray[sourceIndexLocal-1]))
					 ) {
					--sourceIndexLocal;
					 }
			} else {
				sourceIndexLocal=-1;
			}
	
			{
				final int[] targetIndexLocal  = { targetIndex };
				final int[] offsetsIndexLocal = { offsetsIndex };
				UConverterUtility.ucnv_fromUWriteBytes(
						args.converter,
						buffer,
						0,
						outLen,
						targetArray,
						targetIndexLocal,
						targetLimit,
						offsetsArray,
						offsetsIndexLocal,
						sourceIndexLocal,
						err);
				targetIndex  = targetIndexLocal[0];
				offsetsIndex = offsetsIndexLocal[0];
			}
			 }
	
		/*save the state and return */
		args.sourceBegin = sourceIndex;
		args.targetBegin = targetIndex;
	}
		
		/*************** to unicode *******************/
		
	private static void UConverter_toUnicode_ISO_2022_JP_OFFSETS_LOGIC(final UConverterToUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
		final byte[]	tempBuf			= new byte [3];
		final byte[]	mySourceArray	= args.sourceArray;
		int				mySourceIndex	= args.sourceBegin;
		final char[]	myTargetArray	= args.targetArray;
		int				myTargetIndex	= args.targetBegin;
		final int		mySourceLimit	= args.sourceLimit;
		int				targetUniChar	= 0x0000;
		int				mySourceChar	= 0x0000;
		UConverterDataISO2022	myData;
		ISO2022State			pToU2022State;
		/*StateEnum*/ byte		cs;
	
		myData=(UConverterDataISO2022)(args.converter.extraInfo);
		pToU2022State = myData.toU2022State;
	
		if (myData.key != 0) {
			/* continue with a partial escape sequence */
			//goto escape;
			{	// begin of goto expansion
				{
					final int[] mySourceIndexLocal = { mySourceIndex };
					changeState_2022(args.converter, mySourceArray, mySourceIndexLocal, 
							mySourceLimit, ISO_2022_JP,err);
					mySourceIndex = mySourceIndexLocal[0];
				}
	
				/* invalid or illegal escape sequence */
				if (ErrorCode.isFailure(err[0])){
					args.targetBegin = myTargetIndex;
					args.sourceBegin = mySourceIndex;
					return;
				}
				//continue;
			}	// end of goto expansion
		} else if (args.converter.toULength == 1 && mySourceIndex < mySourceLimit && myTargetIndex < args.targetLimit) {
			/* continue with a partial double-byte character */
			mySourceChar = args.converter.toUBytesArray[0];
			args.converter.toULength = 0;
			cs = pToU2022State.cs[pToU2022State.g];
			//goto getTrailByte;	// following block has been copied from the loop
			{	// begin of goto expansion
				{
					char trailByte;
					tempBuf[0] = (byte)mySourceChar;
					tempBuf[1] = (byte)(trailByte = (char)(mySourceArray[mySourceIndex++] & 0xFF));
					mySourceChar = (mySourceChar << 8) | (trailByte & 0xFF);
					targetUniChar = ((UConverterSharedData_MBCS)myData.myConverterArray[cs]).ucnv_MBCSSimpleGetNextUChar(myData.myConverterArray[cs], tempBuf, 0, 2, false);
				}
				if (targetUniChar < (missingCharMarker-1/*0xfffe*/)){
					if (args.offsetsArray != null){
						args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else if (targetUniChar > missingCharMarker){
					/* disassemble the surrogate pair and write to output*/
					targetUniChar-=0x0010000;
					myTargetArray[myTargetIndex] = (char)(0xd800+(char)(targetUniChar>>10));
					if (args.offsetsArray != null){
						args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					++myTargetIndex;
					if (myTargetIndex < args.targetLimit){ 
						myTargetArray[myTargetIndex] = (char)(0xdc00+(char)(targetUniChar&0x3ff));
						if (args.offsetsArray != null){
							args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
						}
						++myTargetIndex;
					}else{
						args.converter.UCharErrorBufferArray[args.converter.UCharErrorBufferLength++]=
							(char)(0xdc00+(char)(targetUniChar&0x3ff));
					}
	
				}
				else{
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					//break;
				}
			}	// end of goto expansion
		}
	
	endloop:
		while (mySourceIndex < mySourceLimit){
	
			targetUniChar =missingCharMarker;
	
			if (myTargetIndex < args.targetLimit){
	
				mySourceChar= mySourceArray[mySourceIndex++] & 0xFF;
	
				switch (mySourceChar) {
					case UConverter.UCNV_SI:
						if (myData.version==3) {
							pToU2022State.g=0;
							continue;
						} else {
							/* only JIS7 uses SI/SO, not ISO-2022-JP-x */
							break;
						}
	
					case UConverter.UCNV_SO:
						if (myData.version==3) {
							/* JIS7: switch to G1 half-width Katakana */
							pToU2022State.cs[1] = HWKANA_7BIT;
							pToU2022State.g=1;
							continue;
						} else {
							/* only JIS7 uses SI/SO, not ISO-2022-JP-x */
							break;
						}
	
					case ESC_2022:
						mySourceIndex--;
	escape:
	
						{
							final int[] mySourceIndexLocal = { mySourceIndex };
							changeState_2022(args.converter, mySourceArray, mySourceIndexLocal, 
									mySourceLimit, ISO_2022_JP,err);
							mySourceIndex = mySourceIndexLocal[0];
						}
	
						/* invalid or illegal escape sequence */
						if (ErrorCode.isFailure(err[0])){
							args.targetBegin = myTargetIndex;
							args.sourceBegin = mySourceIndex;
							return;
						}
						continue;
	
						/* ISO-2022-JP does not use single-byte (C1) SS2 and SS3 */
	
					case CR:
						/*falls through*/
					case LF:
						/* automatically reset to single-byte mode */
						if (pToU2022State.cs[0] != ASCII && pToU2022State.cs[0] != JISX201) {
							pToU2022State.cs[0] = ASCII;
						}
						pToU2022State.cs[2] = 0;
						pToU2022State.g = 0;
						/* falls through */
					default:
						/* convert one or two bytes */
						cs = pToU2022State.cs[pToU2022State.g];
						if ( (((int)mySourceChar & 0xFF) - 0xa1) <= (0xdf - 0xa1) && myData.version==4 &&
								!IS_JP_DBCS(cs)
							 ) {
							/* 8-bit halfwidth katakana in any single-byte mode for JIS8 */
							targetUniChar = mySourceChar + (0xff61 - 0xa1);
	
							/* return from a single-shift state to the previous one */
							if (pToU2022State.g >= 2) {
								pToU2022State.g=pToU2022State.prevG;
							}
						} else switch (cs) {
							case ASCII:
								if (mySourceChar <= 0x7f) {
									targetUniChar = mySourceChar;
								}
								break;
							case ISO8859_1:
								if (mySourceChar <= 0x7f) {
									targetUniChar = mySourceChar + 0x80;
								}
								/* return from a single-shift state to the previous one */
								pToU2022State.g=pToU2022State.prevG;
								break;
							case ISO8859_7:
								if (mySourceChar <= 0x7f) {
									/* convert mySourceChar+0x80 to use a normal 8-bit table */
									targetUniChar =
										//_MBCS_SINGLE_SIMPLE_GET_NEXT_BMP(myData.myConverterArray[cs], mySourceChar + 0x80);
										((UConverterSharedData_MBCS)myData.myConverterArray[cs])._MBCS_SINGLE_SIMPLE_GET_NEXT_BMP(mySourceChar + 0x80);
								}
								/* return from a single-shift state to the previous one */
								pToU2022State.g=pToU2022State.prevG;
								break;
							case JISX201:
								if (mySourceChar <= 0x7f) {
									targetUniChar =
										//_MBCS_SINGLE_SIMPLE_GET_NEXT_BMP( myData.myConverterArray[cs], mySourceChar);
										((UConverterSharedData_MBCS)myData.myConverterArray[cs])._MBCS_SINGLE_SIMPLE_GET_NEXT_BMP(mySourceChar);
								}
								break;
							case HWKANA_7BIT:
								if (((mySourceChar - 0x21) & 0xFF) <= (0x5f - 0x21)) {
									/* 7-bit halfwidth Katakana */
									targetUniChar = mySourceChar + (0xff61 - 0x21);
								}
								break;
							default:
								/* G0 DBCS */
								if (mySourceIndex < mySourceLimit) {
									char trailByte;
	getTrailByte:
									tempBuf[0] = (byte)mySourceChar;
									tempBuf[1] = (byte)(trailByte = (char)(mySourceArray[mySourceIndex++] & 0xFF));
									mySourceChar = (mySourceChar << 8) | (trailByte & 0xFF);
									targetUniChar = ((UConverterSharedData_MBCS)myData.myConverterArray[cs]).ucnv_MBCSSimpleGetNextUChar(myData.myConverterArray[cs], tempBuf, 0, 2, false);
								} else {
									args.converter.toUBytesArray[0] = (byte)mySourceChar;
									args.converter.toULength = 1;
									break endloop;
								}
						}
						break;
				}
				if (targetUniChar < (missingCharMarker-1/*0xfffe*/)){
					if (args.offsetsArray != null){
						args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else if (targetUniChar > missingCharMarker){
					/* disassemble the surrogate pair and write to output*/
					targetUniChar-=0x0010000;
					myTargetArray[myTargetIndex] = (char)(0xd800+(char)(targetUniChar>>10));
					if (args.offsetsArray != null){
						args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					++myTargetIndex;
					if (myTargetIndex < args.targetLimit){ 
						myTargetArray[myTargetIndex] = (char)(0xdc00+(char)(targetUniChar&0x3ff));
						if (args.offsetsArray != null){
							args.offsetsArray[myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
						}
						++myTargetIndex;
					}else{
						args.converter.UCharErrorBufferArray[args.converter.UCharErrorBufferLength++]=
							(char)(0xdc00+(char)(targetUniChar&0x3ff));
					}
	
				}
				else{
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					break;
				}
			}
			else{
				err[0] =ErrorCode.U_BUFFER_OVERFLOW_ERROR;
				break;
			}
		}
		args.targetBegin = myTargetIndex;
		args.sourceBegin = mySourceIndex;
	}	
	
	/*************************** ISO-2022-KR *********************************
	*   Rules for ISO-2022-KR encoding
	*   i) The KSC5601 designator sequence should appear only once in a file, 
	*      at the begining of a line before any KSC5601 characters. This usually
	*      means that it appears by itself on the first line of the file
	*  ii) There are only 2 shifting sequences SO to shift into double byte mode
	*      and SI to shift into single byte mode
	*/
	private static void UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC_IBM(final UConverterFromUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
	
		final UConverter saveConv = args.converter;
		UConverterDataISO2022 myConverterData=(UConverterDataISO2022)saveConv.extraInfo;
		args.converter=myConverterData.currentConverter;
	
		myConverterData.currentConverter.fromUChar32 = saveConv.fromUChar32;
		((UConverterSharedData_MBCS)args.converter.sharedData).ucnv_MBCSFromUnicodeWithOffsets(args,err);
		saveConv.fromUChar32 = myConverterData.currentConverter.fromUChar32;
	
		if(err[0] == ErrorCode.U_BUFFER_OVERFLOW_ERROR) {
			if(myConverterData.currentConverter.charErrorBufferLength > 0) {
				System.arraycopy(
						myConverterData.currentConverter.charErrorBufferArray,
						myConverterData.currentConverter.charErrorBufferBegin,
						saveConv.charErrorBufferArray,
						saveConv.charErrorBufferBegin,
						myConverterData.currentConverter.charErrorBufferLength);
			}
			saveConv.charErrorBufferLength = myConverterData.currentConverter.charErrorBufferLength;
			myConverterData.currentConverter.charErrorBufferLength = 0;
		}
		args.converter=saveConv;
	}

	private static void UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC(final UConverterFromUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
	
		final char[]	sourceArray		=	args.sourceArray;
		int				sourceIndex		=	args.sourceBegin;
		final int		sourceLimit		=	args.sourceLimit;
		final byte[]	targetArray		=	args.targetArray;	// unsigned
		int				targetIndex		=	args.targetBegin;
		final int  	targetLimit		=	args.targetLimit;
		final int[]	offsetsArray	=	args.offsetsArray;
		int				offsetsIndex	=	args.offsetsBegin;
		int				targetByteUnit	=	0x0000;
		int				sourceChar		=	0x0000;
		boolean					isTargetByteDBCS;
		boolean					oldIsTargetByteDBCS;
		UConverterDataISO2022	converterData;
		UConverterSharedData	sharedData;
		boolean					useFallback;
		int						length =0;
	
		converterData=(UConverterDataISO2022)args.converter.extraInfo;
		/* if the version is 1 then the user is requesting 
		 * conversion with ibm-25546 pass the arguments to 
		 * MBCS converter and return
		 */
		if(converterData.version==1){
			UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC_IBM(args,err);
			return;
		}
	
		/* initialize data */
		sharedData = converterData.currentConverter.sharedData;
		useFallback = args.converter.useFallback;
		isTargetByteDBCS=(args.converter.fromUnicodeStatus != 0);
		oldIsTargetByteDBCS = isTargetByteDBCS;
	
		isTargetByteDBCS   = (args.converter.fromUnicodeStatus != 0);
		if((sourceChar = args.converter.fromUChar32)!=0 && targetIndex <targetLimit) {
			//goto getTrail;
			// expanded due to goto getTrail
			/*look ahead to find the trail surrogate*/
			if(sourceIndex <  sourceLimit) {
				/* test the following code unit */
				char trail= sourceArray[sourceIndex];
				if(UConverterUTF16.U16_IS_TRAIL(trail)) {
					sourceIndex++;
					sourceChar=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)sourceChar, trail);
					err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
					/* convert this surrogate code point */
					/* exit this condition tree */
				} else {
					/* this is an unmatched lead code unit (1st surrogate) */
					/* callback(illegal) */
					err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
				}
			}
			args.converter.fromUChar32=sourceChar;
			args.converter.fromUnicodeStatus = isTargetByteDBCS ? 1: 0;
		}
		else {
			while(sourceIndex < sourceLimit){
	
				targetByteUnit = missingCharMarker;
	
				if(targetIndex < args.targetLimit){
					sourceChar = sourceArray[sourceIndex++];
					
		            /* do not convert SO/SI/ESC */
		            if(IS_2022_CONTROL(sourceChar)) {
		                /* callback(illegal) */
		                err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                args.converter.fromUChar32=sourceChar;
		                break;
		            }
		            
					/* length= ucnv_MBCSFromUChar32(converterData.currentConverter.sharedData,
						 sourceChar,&targetByteUnit,args.converter.useFallback);*/
					{
						final long[] targetByteUnitLocal = { targetByteUnit };
						final int[] lengthLocal = { length };
						MBCS_FROM_UCHAR32_ISO2022(sharedData, sourceChar, targetByteUnitLocal, useFallback, lengthLocal, UConverterSharedData_MBCS.MBCS_OUTPUT_2);
						targetByteUnit = (int)targetByteUnitLocal[0];
						length = lengthLocal[0];
					}
					/* only DBCS or SBCS characters are expected*/
					/* DB characters with high bit set to 1 are expected */
					if(length > 2 || length==0 ||(((targetByteUnit & 0x8080) != 0x8080)&& length==2)){
						targetByteUnit=missingCharMarker;
					}
					if (targetByteUnit != missingCharMarker){
	
						oldIsTargetByteDBCS = isTargetByteDBCS;
						isTargetByteDBCS = (targetByteUnit>0x00FF);
						/* append the shift sequence */
						if (oldIsTargetByteDBCS != isTargetByteDBCS ){
	
							if (isTargetByteDBCS) 
								targetArray[targetIndex++] = UConverter.UCNV_SO;
							else 
								targetArray[targetIndex++] = UConverter.UCNV_SI;
							if(offsetsArray != null)
								offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1;
						}
						/* write the targetUniChar  to target */
						if(targetByteUnit <= 0x00FF){
							if( targetIndex < targetLimit){
								targetArray[targetIndex++] = (/*unsigned*/ byte) targetByteUnit;
								if(offsetsArray != null){
									offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1;
								}
	
							}else{
								args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = (/*unsigned*/ byte)targetByteUnit;
								err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
							}
						}else{
							if(targetIndex < targetLimit){
								targetArray[targetIndex++] =(/*unsigned*/ byte) ((targetByteUnit>>8) -0x80);
								if(offsetsArray != null){
									offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1;
								}
								if(targetIndex < targetLimit){
									targetArray[targetIndex++] =(/*unsigned*/ byte) (targetByteUnit -0x80);
									if(offsetsArray != null){
										offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1;
									}
								}else{
									args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = (/*unsigned*/ byte) (targetByteUnit -0x80);
									err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
								}
							}else{
								args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = (/*unsigned*/ byte) ((targetByteUnit>>8) -0x80);
								args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = (/*unsigned*/ byte) (targetByteUnit-0x80);
								err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
							}
						}
	
					}
					else{
						/* oops.. the code point is unassingned
						 * set the error and reason
						 */
	
						/*check if the byte is a First surrogate*/
						if(UConverterUTF.U_IS_SURROGATE(sourceChar)) {
							if(UConverterUTF.U_IS_SURROGATE_LEAD(sourceChar)) {
	getTrail:
								/*look ahead to find the trail surrogate*/
								if(sourceIndex <  sourceLimit) {
									/* test the following code unit */
									char trail= sourceArray[sourceIndex];
									if(UConverterUTF16.U16_IS_TRAIL(trail)) {
										sourceIndex++;
										sourceChar=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)sourceChar, trail);
										err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
										/* convert this surrogate code point */
										/* exit this condition tree */
									} else {
										/* this is an unmatched lead code unit (1st surrogate) */
										/* callback(illegal) */
										err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
									}
								} else {
									/* no more input */
									err[0] = ErrorCode.U_ZERO_ERROR;
								}
							} else {
								/* this is an unmatched trail code unit (2nd surrogate) */
								/* callback(illegal) */
								err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
							}
						} else {
							/* callback(unassigned) for a BMP code point */
							err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
						}
	
						args.converter.fromUChar32=sourceChar;
						break;
					}
				} /* end if(myTargetIndex<myTargetLength) */
				else{
					err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
					break;
				}
	
			}/* end while(mySourceIndex<mySourceLength) */
		}
	
		/*
		 * the end of the input stream and detection of truncated input
		 * are handled by the framework, but for ISO-2022-KR conversion
		 * we need to be in ASCII mode at the very end
		 *
		 * conditions:
		 *   successful
		 *   not in ASCII mode
		 *   end of input and no truncated input
		 */
		if( ErrorCode.isSuccess(err[0]) &&
				isTargetByteDBCS &&
				args.flush && sourceIndex>=sourceLimit && args.converter.fromUChar32==0
			) {
			int sourceIndex2;
	
			/* we are switching to ASCII */
			isTargetByteDBCS=false;
	
			/* get the source index of the last input character */
			/*
			 * TODO this would be simpler and more reliable if we used a pair
			 * of sourceIndex/prevSourceIndex like in ucnvmbcs.c
			 * so that we could simply use the prevSourceIndex here;
			 * this code gives an incorrect result for the rare case of an unmatched
			 * trail surrogate that is alone in the last buffer of the text stream
			 */
			sourceIndex2=(int)(sourceIndex-args.sourceBegin);
			if(sourceIndex2>0) {
				--sourceIndex2;
				if( UConverterUTF16.U16_IS_TRAIL(args.sourceArray[sourceIndex2]) &&
						(sourceIndex2==0 || UConverterUTF16.U16_IS_LEAD(args.sourceArray[sourceIndex + sourceIndex2-1]))
					) {
					--sourceIndex2;
					}
			} else {
				sourceIndex2=-1;
			}
	
			{
				final int[] targetIndexLocal = { targetIndex };
				final int[] offsetsIndexLocal = { offsetsIndex };
				UConverterUtility.ucnv_fromUWriteBytes(
						args.converter,
						SHIFT_IN_STR,
						0,
						1,
						targetArray,
						targetIndexLocal,
						targetLimit,
						offsetsArray,
						offsetsIndexLocal,
						sourceIndex2,
						err);
				targetIndex = targetIndexLocal[0];
				offsetsIndex = offsetsIndexLocal[0];
			}
			}
	
		/*save the state and return */
		args.sourceBegin = sourceIndex;
		args.targetBegin = targetIndex;
		args.converter.fromUnicodeStatus = isTargetByteDBCS ? 1 : 0;
	}

	/************************ To Unicode ***************************************/
	
	/**
	 * Clone references. The actual array/object contents are not duplicated.
	 */
	private static UConverterToUnicodeArgs cloneReferences(final UConverterToUnicodeArgs src)
	{
		final UConverterToUnicodeArgs dst = new UConverterToUnicodeArgs();
		
		dst.converter		=	src.converter;
		dst.flush			=	src.flush;
		dst.sourceArray		=	src.sourceArray;
		dst.sourceBegin		=	src.sourceBegin;
		dst.sourceLimit		=	src.sourceLimit;
		dst.targetArray		=	src.targetArray;
		dst.targetBegin		=	src.targetBegin;
		dst.targetLimit		=	src.targetLimit;
		dst.offsetsArray	=	src.offsetsArray;
		dst.offsetsBegin	=	src.offsetsBegin;
		
		return dst;
	}

	private static void UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC_IBM(final UConverterToUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
		int sourceStart;
		final UConverterDataISO2022 myData=(UConverterDataISO2022)(args.converter.extraInfo);
	
		final UConverterToUnicodeArgs subArgs = cloneReferences(args);
	
		/* remember the original start of the input for offsets */
		sourceStart = args.sourceBegin;
	
		if(myData.key != 0) {
			/* continue with a partial escape sequence */
			//goto escape;
			// expanded due to goto escape
			final int[] sourceBeginLocal = { args.sourceBegin };
			changeState_2022(args.converter,
					args.sourceArray,
					sourceBeginLocal,
					args.sourceLimit,
					ISO_2022_KR,
					err);
			args.sourceBegin = sourceBeginLocal[0];
		}
	
		while(ErrorCode.isSuccess(err[0]) && args.sourceBegin < args.sourceLimit) {
			/*Find the end of the buffer e.g : Next Escape Seq | end of Buffer*/
			subArgs.sourceArray = args.sourceArray;
			subArgs.sourceBegin = args.sourceBegin;
			subArgs.sourceLimit = getEndOfBuffer_2022(args.sourceArray, args.sourceBegin, args.sourceLimit, args.flush);
			if(subArgs.sourceBegin != subArgs.sourceLimit) {
				/*
				 * get the current partial byte sequence
				 *
				 * it needs to be moved between the public and the subconverter
				 * so that the conversion framework, which only sees the public
				 * converter, can handle truncated and illegal input etc.
				 */
				if(args.converter.toULength > 0) {
					System.arraycopy(
							args.converter.toUBytesArray,
							args.converter.toUBytesBegin,
							subArgs.converter.toUBytesArray,
							subArgs.converter.toUBytesBegin,
							args.converter.toULength);
				}
				subArgs.converter.toULength = args.converter.toULength;
	
				/*
				 * Convert up to the end of the input, or to before the next escape character.
				 * Does not handle conversion extensions because the preToU[] state etc.
				 * is not copied.
				 */
				((UConverterSharedData_MBCS)subArgs.converter.sharedData).ucnv_MBCSToUnicodeWithOffsets(subArgs, err);
	
				if(args.offsetsArray != null && sourceStart != args.sourceBegin) {
					/* update offsets to base them on the actual start of the input */
					final int[]	offsetsArray	= args.offsetsArray;
					int				offsetsIndex	= args.offsetsBegin;
					final char[]	targetArray		= args.targetArray;
					int				targetIndex		= args.targetBegin;
					final int		delta = args.sourceBegin - sourceStart;
					while(targetIndex < subArgs.targetBegin) {
						if(offsetsArray[offsetsIndex] >= 0) {
							offsetsIndex += delta;
						}
						++offsetsIndex;
						++targetIndex;
					}
				}
				args.sourceBegin = subArgs.sourceBegin;
				args.targetBegin = subArgs.targetBegin;
				args.offsetsBegin = subArgs.offsetsBegin;
	
				/* copy input/error/overflow buffers */
				if(subArgs.converter.toULength > 0) {
					System.arraycopy(
							subArgs.converter.toUBytesArray,
							subArgs.converter.toUBytesBegin,
							args.converter.toUBytesArray,
							args.converter.toUBytesBegin,
							subArgs.converter.toULength);
				}
				args.converter.toULength = subArgs.converter.toULength;
	
				if(err[0] == ErrorCode.U_BUFFER_OVERFLOW_ERROR) {
					if(subArgs.converter.UCharErrorBufferLength > 0) {
						System.arraycopy(
								subArgs.converter.UCharErrorBufferArray,
								subArgs.converter.UCharErrorBufferBegin,
								args.converter.UCharErrorBufferArray,
								args.converter.UCharErrorBufferBegin,
								subArgs.converter.UCharErrorBufferLength);
					}
					args.converter.UCharErrorBufferLength=subArgs.converter.UCharErrorBufferLength;
					subArgs.converter.UCharErrorBufferLength = 0;
				}
			}
	
			if (ErrorCode.isFailure(err[0]) || (args.sourceBegin == args.sourceLimit)) {
				return;
			}
	
	escape:
			{
				final int[] sourceBeginLocal = { args.sourceBegin };
				changeState_2022(args.converter,
						args.sourceArray,
						sourceBeginLocal,
						args.sourceLimit,
						ISO_2022_KR,
						err);
				args.sourceBegin = sourceBeginLocal[0];
			}
		}
	}
	
	private static void UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC(final UConverterToUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
		final byte[]	tempBuf = new byte [2];
		final byte[]	mySourceArray = args.sourceArray;
		int				mySourceIndex = args.sourceBegin;
		final char[]	myTargetArray = args.targetArray;
		int				myTargetIndex = args.targetBegin;
		final int		mySourceLimit = args.sourceLimit;
		int		targetUniChar	= 0x0000;
		char	mySourceChar	= 0x0000;
		UConverterDataISO2022 myData;
		UConverterSharedData sharedData ;
		boolean useFallback;
	
		myData=(UConverterDataISO2022)(args.converter.extraInfo);
		if(myData.version==1){
			UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC_IBM(args,err);
			return;
		}
	
		/* initialize state */
		sharedData = myData.currentConverter.sharedData;
		useFallback = args.converter.useFallback;
	
		if(myData.key != 0) {
			/* continue with a partial escape sequence */
			//goto escape;
			// expanded due to goto escape
			{
				{
					final int[] mySourceIndexLocal = { mySourceIndex };
					changeState_2022(args.converter,mySourceArray, mySourceIndexLocal,
							mySourceLimit, ISO_2022_KR, err);
					mySourceIndex = mySourceIndexLocal[0];
				}
				if(ErrorCode.isFailure(err[0])){
					args.targetBegin = myTargetIndex;
					args.sourceBegin = mySourceIndex;
					return;
				}
				//continue;
			}	// end of goto expansion
		} else if(args.converter.toULength == 1 && mySourceIndex < mySourceLimit && myTargetIndex < args.targetLimit) {
			/* continue with a partial double-byte character */
			mySourceChar = (char)(args.converter.toUBytesArray[0] & 0xFF);
			args.converter.toULength = 0;
			//goto getTrailByte;
			// expanded due to goto getTrailByte
			{
				{
					final byte trailByte = mySourceArray[mySourceIndex++];
					tempBuf[0] = (byte)(mySourceChar + 0x80);
					tempBuf[1] = (byte)(trailByte + 0x80);
					mySourceChar = (char)((mySourceChar << 8) | (trailByte & 0xFF));
					if((mySourceChar & 0x8080) == 0) {
						targetUniChar = ((UConverterSharedData_MBCS)sharedData).ucnv_MBCSSimpleGetNextUChar(sharedData, tempBuf, 0, 2, useFallback);
					} else {
						/* illegal bytes > 0x7f */
						targetUniChar = missingCharMarker;
					}
				}
				if(targetUniChar < 0xfffe){
					if(args.offsetsArray != null) {
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else {
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					//break;
				}
			}	// end of goto expansion
		}
	
		while(mySourceIndex< mySourceLimit){
	
			if(myTargetIndex < args.targetLimit){
	
				mySourceChar= (char)(mySourceArray[mySourceIndex++] & 0xFF);
	
				if(mySourceChar==UConverter.UCNV_SI){
					myData.toU2022State.g = 0;
					/*consume the source */
					continue;
				}else if(mySourceChar==UConverter.UCNV_SO){
					myData.toU2022State.g = 1;
					/*consume the source */
					continue;
				}else if(mySourceChar==ESC_2022){
					mySourceIndex--;
	escape:
					{
						final int[] mySourceIndexLocal = { mySourceIndex };
						changeState_2022(args.converter,mySourceArray, mySourceIndexLocal,
								mySourceLimit, ISO_2022_KR, err);
						mySourceIndex = mySourceIndexLocal[0];
					}
					if(ErrorCode.isFailure(err[0])){
						args.targetBegin = myTargetIndex;
						args.sourceBegin = mySourceIndex;
						return;
					}
					continue;
				}   
	
				if(myData.toU2022State.g == 1) {
					if(mySourceIndex < mySourceLimit) {
						byte trailByte;
	getTrailByte:
						trailByte = mySourceArray[mySourceIndex++];
						tempBuf[0] = (byte)(mySourceChar + 0x80);
						tempBuf[1] = (byte)(trailByte + 0x80);
						mySourceChar = (char)((mySourceChar << 8) | (trailByte & 0xFF));
						if((mySourceChar & 0x8080) == 0) {
							targetUniChar = ((UConverterSharedData_MBCS)sharedData).ucnv_MBCSSimpleGetNextUChar(sharedData, tempBuf, 0, 2, useFallback);
						} else {
							/* illegal bytes > 0x7f */
							targetUniChar = missingCharMarker;
						}
					} else {
						args.converter.toUBytesArray[0] = (byte)(mySourceChar & 0xFF);
						args.converter.toULength = 1;
						break;
					}
				}
				else{
					targetUniChar = ((UConverterSharedData_MBCS)sharedData).ucnv_MBCSSimpleGetNextUChar(sharedData, mySourceArray, mySourceIndex - 1, 1, useFallback);
				}
				if(targetUniChar < 0xfffe){
					if(args.offsetsArray != null) {
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else {
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					break;
				}
			}
			else{
				err[0] =ErrorCode.U_BUFFER_OVERFLOW_ERROR;
				break;
			}
		}
		args.targetBegin = myTargetIndex;
		args.sourceBegin = mySourceIndex;
	}

	/*************************** END ISO2022-KR *********************************/

	/*************************** ISO-2022-CN *********************************
	*
	* Rules for ISO-2022-CN Encoding:
	* i)   The designator sequence must appear once on a line before any instance
	*      of character set it designates.
	* ii)  If two lines contain characters from the same character set, both lines
	*      must include the designator sequence.
	* iii) Once the designator sequence is known, a shifting sequence has to be found
	*      to invoke the  shifting
	* iv)  All lines start in ASCII and end in ASCII.
	* v)   Four shifting sequences are employed for this purpose:
	*
	*      Sequcence   ASCII Eq    Charsets
	*      ----------  -------    ---------
	*      SI           <SI>        US-ASCII
	*      SO           <SO>        CNS-11643-1992 Plane 1, GB2312, ISO-IR-165
	*      SS2          <ESC>N      CNS-11643-1992 Plane 2
	*      SS3          <ESC>O      CNS-11643-1992 Planes 3-7
	*
	* vi)
	*      SOdesignator  : ESC "$" ")" finalchar_for_SO
	*      SS2designator : ESC "$" "*" finalchar_for_SS2
	*      SS3designator : ESC "$" "+" finalchar_for_SS3
	*
	*      ESC $ ) A       Indicates the bytes following SO are Chinese
	*       characters as defined in GB 2312-80, until
	*       another SOdesignation appears
	*
	*
	*      ESC $ ) E       Indicates the bytes following SO are as defined
	*       in ISO-IR-165 (for details, see section 2.1),
	*       until another SOdesignation appears
	*
	*      ESC $ ) G       Indicates the bytes following SO are as defined
	*       in CNS 11643-plane-1, until another
	*       SOdesignation appears
	*
	*      ESC $ * H       Indicates the two bytes immediately following
	*       SS2 is a Chinese character as defined in CNS
	*       11643-plane-2, until another SS2designation
	*       appears
	*       (Meaning <ESC>N must preceed every 2 byte 
	*        sequence.)
	*
	*      ESC $ + I       Indicates the immediate two bytes following SS3
	*       is a Chinese character as defined in CNS
	*       11643-plane-3, until another SS3designation
	*       appears
	*       (Meaning <ESC>O must preceed every 2 byte 
	*        sequence.)
	*
	*      ESC $ + J       Indicates the immediate two bytes following SS3
	*       is a Chinese character as defined in CNS
	*       11643-plane-4, until another SS3designation
	*       appears
	*       (In English: <ESC>O must preceed every 2 byte 
	*        sequence.)
	*
	*      ESC $ + K       Indicates the immediate two bytes following SS3
	*       is a Chinese character as defined in CNS
	*       11643-plane-5, until another SS3designation
	*       appears
	*
	*      ESC $ + L       Indicates the immediate two bytes following SS3
	*       is a Chinese character as defined in CNS
	*       11643-plane-6, until another SS3designation
	*       appears
	*
	*      ESC $ + M       Indicates the immediate two bytes following SS3
	*       is a Chinese character as defined in CNS
	*       11643-plane-7, until another SS3designation
	*       appears
	*
	*       As in ISO-2022-CN, each line starts in ASCII, and ends in ASCII, and
	*       has its own designation information before any Chinese characters
	*       appear
	*
	*/

	/* The following are defined this way to make the strings truely readonly */
	private static final byte[] GB_2312_80_STR = { 0x1B, 0x24, 0x29, 0x41 };
	private static final byte[] ISO_IR_165_STR = { 0x1B, 0x24, 0x29, 0x45 };
	private static final byte[] CNS_11643_1992_Plane_1_STR = { 0x1B, 0x24, 0x29, 0x47 };
	private static final byte[] CNS_11643_1992_Plane_2_STR = { 0x1B, 0x24, 0x2A, 0x48 };
	private static final byte[] CNS_11643_1992_Plane_3_STR = { 0x1B, 0x24, 0x2B, 0x49 };
	private static final byte[] CNS_11643_1992_Plane_4_STR = { 0x1B, 0x24, 0x2B, 0x4A };
	private static final byte[] CNS_11643_1992_Plane_5_STR = { 0x1B, 0x24, 0x2B, 0x4B };
	private static final byte[] CNS_11643_1992_Plane_6_STR = { 0x1B, 0x24, 0x2B, 0x4C };
	private static final byte[] CNS_11643_1992_Plane_7_STR = { 0x1B, 0x24, 0x2B, 0x4D };

	/********************** ISO2022-CN Data **************************/
	private static final byte[/*10*/][] escSeqCharsCN = {
	        SHIFT_IN_STR,           /* ASCII */
	        GB_2312_80_STR,
	        ISO_IR_165_STR,
	        CNS_11643_1992_Plane_1_STR,
	        CNS_11643_1992_Plane_2_STR,
	        CNS_11643_1992_Plane_3_STR,
	        CNS_11643_1992_Plane_4_STR,
	        CNS_11643_1992_Plane_5_STR,
	        CNS_11643_1992_Plane_6_STR,
	        CNS_11643_1992_Plane_7_STR
	};

	private static void UConverter_fromUnicode_ISO_2022_CN_OFFSETS_LOGIC(final UConverterFromUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
	
		UConverterDataISO2022	converterData;
		ISO2022State			pFromU2022State;
		final byte[]	targetArray 	=	args.targetArray;
		int				targetIndex 	=	args.targetBegin;
		final int		targetLimit 	=	args.targetLimit;
		final char[]	sourceArray 	=	args.sourceArray;
		int				sourceIndex		=	args.sourceBegin;
		final int		sourceLimit 	=	args.sourceLimit;
		final int[]	offsetsArray	=	args.offsetsArray;
		int				offsetsIndex	=	args.offsetsBegin;
		int				sourceChar;
		final byte[]	buffer = new byte [8];
		int				len;
		final byte[]	choices = new byte [3];
		int 			choiceCount;
		int				targetValue = 0;
		boolean			useFallback;
		boolean			goto_getTrail = false;
	
		/* set up the state */
		converterData     = (UConverterDataISO2022)args.converter.extraInfo;
		pFromU2022State   = converterData.fromU2022State;
		useFallback       = args.converter.useFallback;
	
		choiceCount = 0;
	
		/* check if the last codepoint of previous buffer was a lead surrogate*/
		if((sourceChar = args.converter.fromUChar32)!=0 && targetIndex< targetLimit) {
			goto_getTrail = true;
		}
	
		while( goto_getTrail || (sourceIndex < sourceLimit)){
			if(goto_getTrail || (targetIndex < targetLimit)){
	
				if (!goto_getTrail)
				{
					sourceChar  = sourceArray[sourceIndex++];
				}
				/*check if the byte is a First surrogate*/
				if(goto_getTrail || UConverterUTF.U_IS_SURROGATE(sourceChar)) {
					if(goto_getTrail || UConverterUTF.U_IS_SURROGATE_LEAD(sourceChar)) {
						//getTrail:
						goto_getTrail = false;
						/*look ahead to find the trail surrogate*/
						if(sourceIndex < sourceLimit) {
							/* test the following code unit */
							char trail=sourceArray[sourceIndex];
							if(UConverterUTF16.U16_IS_TRAIL(trail)) {
								sourceIndex++;
								sourceChar=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)sourceChar, trail);
								args.converter.fromUChar32=0x00;
								/* convert this supplementary code point */
								/* exit this condition tree */
							} else {
								/* this is an unmatched lead code unit (1st surrogate) */
								/* callback(illegal) */
								err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
								args.converter.fromUChar32=sourceChar;
								break;
							}
						} else {
							/* no more input */
							args.converter.fromUChar32=sourceChar;
							break;
						}
					} else {
						/* this is an unmatched trail code unit (2nd surrogate) */
						/* callback(illegal) */
						err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
						args.converter.fromUChar32=sourceChar;
						break;
					}
				}
	
				/* do the conversion */
				if(sourceChar <= 0x007f ){
					/* do not convert SO/SI/ESC */
	                if(IS_2022_CONTROL(sourceChar)) {
	                    /* callback(illegal) */
	                    err[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                    args.converter.fromUChar32=sourceChar;
	                    break;
	                }
	                
					/* US-ASCII */
					if(pFromU2022State.g == 0) {
						buffer[0] = (byte)sourceChar;
						len = 1;
					} else {
						buffer[0] = UConverter.UCNV_SI;
						buffer[1] = (byte)sourceChar;
						len = 2;
						pFromU2022State.g = 0;
						choiceCount = 0;
					}
					if(sourceChar == CR || sourceChar == LF) {
						/* reset the state at the end of a line */
						pFromU2022State.reset();
						choiceCount = 0;
					}
				}
				else{
					/* convert U+0080..U+10ffff */
					UConverterSharedData cnv;
					int i;
					byte cs, g;
	
					if(choiceCount == 0) {
						/* try the current SO/G1 converter first */
						choices[0] = pFromU2022State.cs[1];
	
						/* default to GB2312_1 if none is designated yet */
						if(choices[0] == 0) {
							choices[0] = GB2312_1;
						}
	
						if(converterData.version == 0) {
							/* ISO-2022-CN */
	
							/* try the other SO/G1 converter; a CNS_11643_1 lookup may result in any plane */
							if(choices[0] == GB2312_1) {
								choices[1] = (byte)CNS_11643_1;
							} else {
								choices[1] = (byte)GB2312_1;
							}
	
							choiceCount = 2;
						} else {
							/* ISO-2022-CN-EXT */
	
							/* try one of the other converters */
							switch(choices[0]) {
								case GB2312_1:
									choices[1] = (byte)CNS_11643_1;
									choices[2] = (byte)ISO_IR_165;
									break;
								case ISO_IR_165:
									choices[1] = (byte)GB2312_1;
									choices[2] = (byte)CNS_11643_1;
									break;
								default: /* CNS_11643_x */
									choices[1] = (byte)GB2312_1;
									choices[2] = (byte)ISO_IR_165;
									break;
							}
	
							choiceCount = 3;
						}
					}
	
					cs = g = 0;
					len = 0;
	
					for(i = 0; i < choiceCount && len == 0; ++i) {
						cs = choices[i];
						if(cs > 0) {
							if(cs > CNS_11643_0) {
								cnv = converterData.myConverterArray[CNS_11643];
								{
									final long[] targetValueLocal = { targetValue };
									final int[] lenLocal = { len };
									MBCS_FROM_UCHAR32_ISO2022(cnv,sourceChar,targetValueLocal,useFallback,lenLocal,UConverterSharedData_MBCS.MBCS_OUTPUT_3);
									targetValue = (int)targetValueLocal[0];
									len = lenLocal[0];
								}
								if(len==3) {
									cs = (byte)(CNS_11643_0 + (targetValue >> 16) - 0x80);
									len = 2;
									if(cs == CNS_11643_1) {
										g = 1;
									} else if(cs == CNS_11643_2) {
										g = 2;
									} else /* plane 3..7 */ if(converterData.version == 1) {
										g = 3;
									} else {
										/* ISO-2022-CN (without -EXT) does not support plane 3..7 */
										len = 0;
									}
								}
							} else {
								/* GB2312_1 or ISO-IR-165 */
								cnv = converterData.myConverterArray[cs];
								{
									final long[] targetValueLocal = { targetValue };
									final int[] lenLocal = { len };
									MBCS_FROM_UCHAR32_ISO2022(cnv,sourceChar,targetValueLocal,useFallback,lenLocal,UConverterSharedData_MBCS.MBCS_OUTPUT_2);
									targetValue = (int)targetValueLocal[0];
									len = lenLocal[0];
								}
								g = 1; /* used if len == 2 */
							}
						}
					}
	
					if(len > 0) {
						len = 0; /* count output bytes; it must have been len == 2 */
	
						/* write the designation sequence if necessary */
						if(cs != pFromU2022State.cs[g]) {
							if(cs < CNS_11643) {
								System.arraycopy(
										escSeqCharsCN[cs],
										0,
										buffer,
										0,
										4);
							} else {
								System.arraycopy(
										escSeqCharsCN[CNS_11643 + (cs - CNS_11643_1)],
										0,
										buffer,
										0,
										4);
							}
							len = 4;
							pFromU2022State.cs[g] = cs;
							if(g == 1) {
								/* changing the SO/G1 charset invalidates the choices[] */
								choiceCount = 0;
							}
						}
	
						/* write the shift sequence if necessary */
						if(g != pFromU2022State.g) {
							switch(g) {
								case 1:
									buffer[len++] = UConverter.UCNV_SO;
	
									/* set the new state only if it is the locking shift SO/G1, not for SS2 or SS3 */
									pFromU2022State.g = 1;
									break;
								case 2:
									buffer[len++] = 0x1b;
									buffer[len++] = 0x4e;
									break;
								default: /* case 3 */
									buffer[len++] = 0x1b;
									buffer[len++] = 0x4f;
									break;
							}
						}
	
						/* write the two output bytes */
						buffer[len++] = (byte)(targetValue >> 8);
						buffer[len++] = (byte)targetValue;
					} else {
						/* if we cannot find the character after checking all codepages 
						 * then this is an error
						 */
						err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
						args.converter.fromUChar32=sourceChar;
						break;
					}
				}
	
				/* output len>0 bytes in buffer[] */
				if(len == 1) {
					targetArray[targetIndex++] = buffer[0];
					if(offsetsArray != null) {
						offsetsArray[offsetsIndex++] = sourceIndex - args.sourceBegin - 1; /* -1: known to be ASCII */
					}
				} else if(len == 2 && (targetIndex + 2) <= targetLimit) {
					targetArray[targetIndex++] = buffer[0];
					targetArray[targetIndex++] = buffer[1];
					if(offsetsArray != null) {
						final int sourceIndex2 = sourceIndex - args.sourceBegin - UConverterUTF16.U16_LENGTH(sourceChar);
						offsetsArray[offsetsIndex++] = sourceIndex2;
						offsetsArray[offsetsIndex++] = sourceIndex2;
					}
				} else {
					{
						final int[] targetIndexLocal = { targetIndex };
						final int[] offsetsIndexLocal = { offsetsIndex };
						UConverterUtility.ucnv_fromUWriteBytes(
								args.converter,
								buffer,
								0,
								len,
								targetArray,
								targetIndexLocal,
								targetLimit,
								offsetsArray,
								offsetsIndexLocal,
								sourceIndex - args.sourceBegin -UConverterUTF16. U16_LENGTH(sourceChar),
								err);
						targetIndex = targetIndexLocal[0];
						offsetsIndex = offsetsIndexLocal[0];
					}
					if(ErrorCode.isFailure(err[0])) {
						break;
					}
				}
			} /* end if(myTargetIndex<myTargetLength) */
			else{
				err[0] =ErrorCode.U_BUFFER_OVERFLOW_ERROR;
				break;
			}
	
		}/* end while(mySourceIndex<mySourceLength) */
	
		/*
		 * the end of the input stream and detection of truncated input
		 * are handled by the framework, but for ISO-2022-CN conversion
		 * we need to be in ASCII mode at the very end
		 *
		 * conditions:
		 *   successful
		 *   not in ASCII mode
		 *   end of input and no truncated input
		 */
		if( ErrorCode.isSuccess(err[0]) &&
				pFromU2022State.g!=0 &&
				args.flush && sourceIndex>=sourceLimit && args.converter.fromUChar32==0
			) {
			int sourceIndex2;
	
			/* we are switching to ASCII */
			pFromU2022State.g=0;
	
			/* get the source index of the last input character */
			/*
			 * TODO this would be simpler and more reliable if we used a pair
			 * of sourceIndex/prevSourceIndex like in ucnvmbcs.c
			 * so that we could simply use the prevSourceIndex here;
			 * this code gives an incorrect result for the rare case of an unmatched
			 * trail surrogate that is alone in the last buffer of the text stream
			 */
			sourceIndex2=sourceIndex-args.sourceBegin;
			if(sourceIndex2>0) {
				--sourceIndex2;
				if( UConverterUTF16.U16_IS_TRAIL(args.sourceArray[args.sourceBegin + sourceIndex2]) &&
						(sourceIndex2==0 || UConverterUTF16.U16_IS_LEAD(args.sourceArray[args.sourceBegin + sourceIndex2-1]))
					) {
					--sourceIndex2;
					}
			} else {
				sourceIndex2=-1;
			}
	
			{
				final int[] targetIndexLocal = { targetIndex };
				final int[] offsetsIndexLocal = { offsetsIndex };
				UConverterUtility.ucnv_fromUWriteBytes(
						args.converter,
						SHIFT_IN_STR,
						0,
						1,
						targetArray,
						targetIndexLocal,
						targetLimit,
						offsetsArray,
						offsetsIndexLocal,
						sourceIndex2,
						err);
				targetIndex = targetIndexLocal[0];
				offsetsIndex = offsetsIndexLocal[0];
			}
			}
	
		/*save the state and return */
		args.sourceBegin = sourceIndex;
		args.targetBegin = targetIndex;
	}
	
	
	private static void UConverter_toUnicode_ISO_2022_CN_OFFSETS_LOGIC(final UConverterToUnicodeArgs args, final /*UErrorCode*/ int[] err)
	{
		final byte[]	tempBuf = new byte [3];
		final byte[]	mySourceArray	=	args.sourceArray;
		int				mySourceIndex	=	args.sourceBegin;
		final char[]	myTargetArray	=	args.targetArray;
		int				myTargetIndex	=	args.targetBegin;
		final int		mySourceLimit	=	args.sourceLimit;
		int				targetUniChar = 0x0000;
		int				mySourceChar = 0x0000;
		UConverterDataISO2022	myData;
		ISO2022State			pToU2022State;
	
		myData=(UConverterDataISO2022)args.converter.extraInfo;
		pToU2022State = myData.toU2022State;
	
		if(myData.key != 0) {
			/* continue with a partial escape sequence */
			//goto escape;
			// expanded due to goto escape
			{
				{
					final int[] mySourceIndexLocal = { mySourceIndex };
					changeState_2022(args.converter,mySourceArray,mySourceIndexLocal, 
							mySourceLimit, ISO_2022_CN,err);
					mySourceIndex = mySourceIndexLocal[0];
				}
	
				/* invalid or illegal escape sequence */
				if(ErrorCode.isFailure(err[0])){
					args.targetBegin = myTargetIndex;
					args.sourceBegin = mySourceIndex;
					return;
				}
				// continue;
			}	// end of goto expansion
		} else if(args.converter.toULength == 1 && mySourceIndex < mySourceLimit && myTargetIndex < args.targetLimit) {
			/* continue with a partial double-byte character */
			mySourceChar = args.converter.toUBytesArray[0];
			args.converter.toULength = 0;
			// goto getTrailByte;
			// expanded due to goto getTrailByte
			{
				{
					UConverterSharedData	cnv;
					final byte	tempState = pToU2022State.cs[pToU2022State.g];
					int			tempBufLen;
					final byte	trailByte = mySourceArray[mySourceIndex++];
	
					if(tempState > CNS_11643_0) {
						cnv = myData.myConverterArray[CNS_11643];
						tempBuf[0] = (byte) (0x80+(tempState-CNS_11643_0));
						tempBuf[1] = (byte) (mySourceChar);
						tempBuf[2] = trailByte;
						tempBufLen = 3;
	
					}else{
						cnv = myData.myConverterArray[tempState];
						tempBuf[0] = (byte) (mySourceChar);
						tempBuf[1] = trailByte;
						tempBufLen = 2;
					}
					mySourceChar = (mySourceChar << 8) | (trailByte & 0xFF);
					if(pToU2022State.g>=2) {
						/* return from a single-shift state to the previous one */
						pToU2022State.g=pToU2022State.prevG;
					}
					targetUniChar = ((UConverterSharedData_MBCS)cnv).ucnv_MBCSSimpleGetNextUChar(cnv, tempBuf, 0, tempBufLen, false);
				}
	
				if(targetUniChar < (missingCharMarker-1/*0xfffe*/)){
					if(args.offsetsArray != null){
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else if(targetUniChar > missingCharMarker){
					/* disassemble the surrogate pair and write to output*/
					targetUniChar-=0x0010000;
					myTargetArray[myTargetIndex] = (char)(0xd800+(char)(targetUniChar>>10));
					if(args.offsetsArray != null){
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					++myTargetIndex;
					if(myTargetIndex< args.targetLimit){ 
						myTargetArray[myTargetIndex] = (char)(0xdc00+(char)(targetUniChar&0x3ff));
						if(args.offsetsArray != null){
							args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
						}
						++myTargetIndex;
					}else{
						args.converter.UCharErrorBufferArray[args.converter.UCharErrorBufferLength++]=
							(char)(0xdc00+(char)(targetUniChar&0x3ff));
					}
	
				}
				else{
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					//break;
				}
			}	// end of goto expansion
		}
	
	endloop:
		while(mySourceIndex < mySourceLimit){
	
			targetUniChar =missingCharMarker;
	
			if(myTargetIndex < args.targetLimit){
	
				mySourceChar= (/*unsigned*/ byte) mySourceArray[mySourceIndex++];
	
				switch(mySourceChar){
					case UConverter.UCNV_SI:
						pToU2022State.g=0;
						continue;
	
					case UConverter.UCNV_SO:
						if(pToU2022State.cs[1] != 0) {
							pToU2022State.g=1;
							continue;
						} else {
							/* illegal to have SO before a matching designator */
							break;
						}
	
					case ESC_2022:
						mySourceIndex--;
	escape:
						{
							final int[] mySourceIndexLocal = { mySourceIndex };
							changeState_2022(args.converter,mySourceArray,mySourceIndexLocal, 
									mySourceLimit, ISO_2022_CN,err);
							mySourceIndex = mySourceIndexLocal[0];
						}
	
						/* invalid or illegal escape sequence */
						if(ErrorCode.isFailure(err[0])){
							args.targetBegin = myTargetIndex;
							args.sourceBegin = mySourceIndex;
							return;
						}
						continue;
	
						/* ISO-2022-CN does not use single-byte (C1) SS2 and SS3 */
	
					case CR:
						/*falls through*/
					case LF:
						pToU2022State.reset();
						/* falls through */
					default:
						/* convert one or two bytes */
						if(pToU2022State.g != 0) {
							if(mySourceIndex < mySourceLimit) {
								UConverterSharedData cnv;
								/*StateEnum*/ byte tempState;
								int tempBufLen;
								byte trailByte;
	getTrailByte:
								trailByte = mySourceArray[mySourceIndex++];
								tempState = pToU2022State.cs[pToU2022State.g];
								if(tempState > CNS_11643_0) {
									cnv = myData.myConverterArray[CNS_11643];
									tempBuf[0] = (byte) (0x80+(tempState-CNS_11643_0));
									tempBuf[1] = (byte) (mySourceChar);
									tempBuf[2] = trailByte;
									tempBufLen = 3;
	
								}else{
									cnv = myData.myConverterArray[tempState];
									tempBuf[0] = (byte) (mySourceChar);
									tempBuf[1] = trailByte;
									tempBufLen = 2;
								}
								mySourceChar = (mySourceChar << 8) | (trailByte & 0xFF);
								if(pToU2022State.g>=2) {
									/* return from a single-shift state to the previous one */
									pToU2022State.g=pToU2022State.prevG;
								}
								targetUniChar = ((UConverterSharedData_MBCS)cnv).ucnv_MBCSSimpleGetNextUChar(cnv, tempBuf, 0, tempBufLen, false);
							} else {
								args.converter.toUBytesArray[0] = (byte)(mySourceChar & 0xFF);
								args.converter.toULength = 1;
								break endloop;
							}
						}
						else{
							if(mySourceChar <= 0x7f) {
								targetUniChar = (char) mySourceChar;
							}
						}
						break;
				}
				if(targetUniChar < (missingCharMarker-1/*0xfffe*/)){
					if(args.offsetsArray != null){
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					myTargetArray[myTargetIndex++]=(char)targetUniChar;
				}
				else if(targetUniChar > missingCharMarker){
					/* disassemble the surrogate pair and write to output*/
					targetUniChar-=0x0010000;
					myTargetArray[myTargetIndex] = (char)(0xd800+(char)(targetUniChar>>10));
					if(args.offsetsArray != null){
						args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
					}
					++myTargetIndex;
					if(myTargetIndex< args.targetLimit){ 
						myTargetArray[myTargetIndex] = (char)(0xdc00+(char)(targetUniChar&0x3ff));
						if(args.offsetsArray != null){
							args.offsetsArray[args.offsetsBegin + myTargetIndex - args.targetBegin]= mySourceIndex - args.sourceBegin - (mySourceChar <= 0xff ? 1 : 2);
						}
						++myTargetIndex;
					}else{
						args.converter.UCharErrorBufferArray[args.converter.UCharErrorBufferLength++]=
							(char)(0xdc00+(char)(targetUniChar&0x3ff));
					}
	
				}
				else{
					/* Call the callback function*/
					toUnicodeCallback(args.converter,mySourceChar,targetUniChar,err);
					break;
				}
			}
			else{
				err[0] =ErrorCode.U_BUFFER_OVERFLOW_ERROR;
				break;
			}
		}
		args.targetBegin = myTargetIndex;
		args.sourceBegin = mySourceIndex;
	}
	/*************************** END ISO2022-CN *********************************/

	/*************Shared****************/
	private UConverterSharedData_ISO2022 actualConverter = null;
	public static UConverterStaticData			_ISO2022StaticData;
	public static UConverterSharedData_ISO2022	_ISO2022Data;
	static
	{
		_ISO2022StaticData = new UConverterStaticData(
				UConverterStaticData.sizeofUConverterStaticData,
				"ISO_2022",
				2022,
				(byte)UConverterPlatform.UCNV_IBM,
				(byte)UConverterType.UCNV_ISO_2022,
				(byte)1,
				(byte)3, /* max 3 bytes per UChar from UTF-8 (4 bytes from surrogate _pair_) */
				new byte [] { 0x1a, 0, 0, 0 },
				(byte)1,
				(byte)0 /*false*/,
				(byte)0 /*false*/,
				(short)0,
				(byte)0,
				new byte [] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
			);
		
		_ISO2022Data = new UConverterSharedData_ISO2022(
				sizeofUConverterSharedData,
				~0,
				//null,
				//null,
				_ISO2022StaticData,
				false,
				//_ISO2022Impl,
				0
			);
	}

	/*************JP****************/
	//static final UConverterImpl _ISO2022JPImpl={
	//    UCNV_ISO_2022,
	//
	//    null,
	//    null,
	//
	//    _ISO2022Open,
	//    _ISO2022Close,
	//    _ISO2022Reset,
	//
	//    UConverter_toUnicode_ISO_2022_JP_OFFSETS_LOGIC,
	//    UConverter_toUnicode_ISO_2022_JP_OFFSETS_LOGIC,
	//    UConverter_fromUnicode_ISO_2022_JP_OFFSETS_LOGIC,
	//    UConverter_fromUnicode_ISO_2022_JP_OFFSETS_LOGIC,
	//    null,
	//
	//    null,
	//    _ISO2022getName,
	//    _ISO_2022_WriteSub,
	//    _ISO_2022_SafeClone,
	//    _ISO_2022_GetUnicodeSet
	//};
	public static UConverterStaticData			_ISO2022JPStaticData;
	public static UConverterSharedData_ISO2022	_ISO2022JPData;
	static
	{
		_ISO2022JPStaticData = new UConverterStaticData(
				UConverterStaticData.sizeofUConverterStaticData,
				"ISO_2022_JP",
				0,
				(byte)UConverterPlatform.UCNV_IBM,
				(byte)UConverterType.UCNV_ISO_2022,
				(byte)1,
				(byte)6, /* max 6 bytes per UChar: 4-byte escape sequence + DBCS */
				new byte [] { 0x1a, 0, 0, 0 },
				(byte)1,
				(byte)0 /*false*/,
				(byte)0 /*false*/,
				(short)0,
				(byte)0,
				new byte [] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
			);
		
		_ISO2022JPData = new UConverterSharedData_ISO2022(
				sizeofUConverterSharedData,
				~0,
				//null,
				//null,
				_ISO2022JPStaticData,
				false,
				//_ISO2022JPImpl,
				0
			);
	}

	/************* KR ***************/
	//static final UConverterImpl _ISO2022KRImpl={
	//	UCNV_ISO_2022,
	//
	//	NULL,
	//	NULL,
	//
	//	_ISO2022Open,
	//	_ISO2022Close,
	//	_ISO2022Reset,
	//
	//	UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC,
	//	UConverter_toUnicode_ISO_2022_KR_OFFSETS_LOGIC,
	//	UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC,
	//	UConverter_fromUnicode_ISO_2022_KR_OFFSETS_LOGIC,
	//	NULL,
	//
	//	NULL,
	//	_ISO2022getName,
	//	_ISO_2022_WriteSub,
	//	_ISO_2022_SafeClone,
	//	_ISO_2022_GetUnicodeSet
	//};
	public static UConverterStaticData			_ISO2022KRStaticData;
	public static UConverterSharedData_ISO2022	_ISO2022KRData;
	static
	{
		_ISO2022KRStaticData = new UConverterStaticData(
				UConverterStaticData.sizeofUConverterStaticData,
				"ISO_2022_KR",
				0,
				(byte)UConverterPlatform.UCNV_IBM,
				(byte)UConverterType.UCNV_ISO_2022,
				(byte)1,
				(byte)3, /* max 3 bytes per UChar: SO+DBCS */
				new byte [] { 0x1a, 0, 0, 0 },
				(byte)1,
				(byte)0 /*false*/,
				(byte)0 /*false*/,
				(short)0,
				(byte)0,
				new byte [] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
			);
		
		_ISO2022KRData = new UConverterSharedData_ISO2022(
				sizeofUConverterSharedData,
				~0,
				//null,
				//null,
				_ISO2022KRStaticData,
				false,
				//_ISO2022KRImpl,
				0
			);
	}

	/*************** CN ***************/
	//static final UConverterImpl _ISO2022CNImpl={
	//	UCNV_ISO_2022,
	//
	//	NULL,
	//	NULL,
	//
	//	_ISO2022Open,
	//	_ISO2022Close,
	//	_ISO2022Reset,
	//
	//	UConverter_toUnicode_ISO_2022_CN_OFFSETS_LOGIC,
	//	UConverter_toUnicode_ISO_2022_CN_OFFSETS_LOGIC,
	//	UConverter_fromUnicode_ISO_2022_CN_OFFSETS_LOGIC,
	//	UConverter_fromUnicode_ISO_2022_CN_OFFSETS_LOGIC,
	//	NULL,
	//
	//	NULL,
	//	_ISO2022getName,
	//	_ISO_2022_WriteSub,
	//	_ISO_2022_SafeClone,
	//	_ISO_2022_GetUnicodeSet
	//};
	public static UConverterStaticData			_ISO2022CNStaticData;
	public static UConverterSharedData_ISO2022	_ISO2022CNData;
	static
	{
		_ISO2022CNStaticData = new UConverterStaticData(
				UConverterStaticData.sizeofUConverterStaticData,
				"ISO_2022_CN",
				0,
				(byte)UConverterPlatform.UCNV_IBM,
				(byte)UConverterType.UCNV_ISO_2022,
				(byte)2,
				(byte)8, /* max 8 bytes per UChar: 4-byte CNS designator + 2 bytes for SS2/SS3 + DBCS */
				new byte [] { 0x1a, 0, 0, 0 },
				(byte)1,
				(byte)0 /*false*/,
				(byte)0 /*false*/,
				(short)0,
				(byte)0,
				new byte [] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
			);
		
		_ISO2022CNData = new UConverterSharedData_ISO2022(
				sizeofUConverterSharedData,
				~0,
				//null,
				//null,
				_ISO2022CNStaticData,
				false,
				//_ISO2022CNImpl,
				0
		);
	}
}
