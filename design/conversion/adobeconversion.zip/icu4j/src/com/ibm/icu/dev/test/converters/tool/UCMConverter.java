/*
 * Created on Jun 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.icu.dev.test.converters.tool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.HashSet;
import java.util.Vector;

/**
 * Convert UCM files from the specified input path (either file or directory) 
 * to XML files conforming to XML input format used by TestClass in the specified output path 
 * (default as <input directory>/xml if not specified)
 * 
 * Currently support only round trip between Unicode and code page (code 0 under CHARMAP)
 * 
 * @see TestClass
 * @author Niti Hantaweepant
 */
public class UCMConverter {

	// Header section
	public static final String CODE_SET_NAME 	= "<code_set_name>";
	public static final String ICU_BASE			= "<icu:base>";
	
	// Mapping table section
	public static final String CHARMAP			= "CHARMAP";
	public static final String END_CHARMAP		= "END CHARMAP";	
	public static final String PRECISION_ROUNDTRIP = "0";
	public static final String PRECISION_FALLBACK = "1";
	public static final String PRECISION_REVERSE_FALLBACK = "3";
	
	private URI inputUCMURI = null;
	private URI outputXMLURI = null;
	private BufferedWriter out = null;
	private HashSet baseHash = new HashSet();
	private Vector toUFromU = new Vector();
	
	/**
	 * Convert UCM files from the specified input path (either file or directory) 
	 * to XML files conforming to XML input format in the specified output path 
	 * (default as <input directory>/xml if not specified)
	 * 
	 * Support round trip, fallback and reverse fallback between Unicode and code page
	 * (precision 0, 1, and 3 respectively)
	 * 
	 * XML format: Roundtrip and fallback mappings are converted to TestDataFromUToU, 
	 * while reverse fallback mapping is converted to TestDataToUFromU.
	 * 
	 * @param inputPath Absolute URI of Input path  - can be either file or directory
	 * @param outputPath Absolute URI of Output path - If null or not exist, <input directory>/xml will be used
	 * @throws	IllegalArgumentException If inputPath is not an absolute URI
	 * @throws	FileNotFoundException If outputPath does not exist or is not a directory
	 * @throws	URISyntaxException If inputPath or outputPath URI is syntax error
	 */
	public void convert(String inputPath, String outputPath) throws IllegalArgumentException, FileNotFoundException, URISyntaxException{
		
		inputUCMURI = new URI(inputPath);
		File inputUCMFile = new File(inputUCMURI);		
		File[] inputUCMFiles = null;
		
		// Verify the input path
		if (!inputUCMFile.exists()){
			throw new FileNotFoundException("The specified input UCM path does not exist");
		}
		if (inputUCMFile.isFile()){
			if (!inputUCMFile.getName().endsWith(".ucm")){
				// Not ucm file
				throw new IllegalArgumentException("The input file is not UCM file");
			}
			else{
				inputUCMFiles = new File[]{inputUCMFile};
			}
		}
		else{
			FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File dir, String name) {
		            return name.toLowerCase().endsWith(".ucm");
		        }
		    };

			inputUCMFiles = inputUCMFile.listFiles(filter);
		}
		
		// Verify the output path
		outputXMLURI = null;
		if (outputPath!=null){
			outputXMLURI = new URI(outputPath);
			File outputXMLFile = new File(outputXMLURI);
			if (!outputXMLFile.exists() || !outputXMLFile.isDirectory()){
				// Default output path as <input directory>/xml
				outputXMLURI = inputUCMURI.resolve("xml/");
				System.out.println("Specified output path directory: "+outputPath+" doesn't exist");
				
			}
		}
		else{
			// Default output path as <input directory>/xml
			outputXMLURI = inputUCMURI.resolve("xml/");			
		}
		System.out.println("Output path: "+outputXMLURI.getPath()+" is used");
		new File(outputXMLURI).mkdir();
		for (int i=0; i<inputUCMFiles.length; i++){
			convertUCMFile(inputUCMFiles[i]);
		}
	}
	
	/**
	 * Process each UCM file
	 * @param file UCM file
	 * @param outputURI output URI
	 */
	private void convertUCMFile(File file){
	
		try{			
			BufferedReader in = new BufferedReader(new FileReader(file));
			System.out.println("File: "+file.getName());
			BufferedWriter out = null;
			String line = null;
			String encoding = null;
			
			// Process header section
			while ((line=in.readLine())!=null){
            	
				// Remove comment
				if (line.indexOf('#')!=-1){
					line = line.substring(0, line.indexOf('#'));
				}
				// Remove empty line
				if ((line=line.trim()).equals("")){
					continue;
				}
				
				String[] tokens = line.split("\\s+");
				// Code set name				
				if (tokens[0].equals(CODE_SET_NAME)){
					encoding = tokens[1].substring(1,tokens[1].length()-1);
					out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(outputXMLURI.resolve(encoding+".xml"))),"UTF-8"));
					out.write("<?xml version='1.0' encoding='UTF-8'?>"); out.newLine();
					out.write("<testcase id='"+encoding+"' encoding='"+encoding+"'>"); out.newLine();
					out.write("\t<fromutou>"); out.newLine();
				}
				else if (tokens[0].equals(ICU_BASE)){
					URI baseFileURI = inputUCMURI.resolve(tokens[1].substring(1,tokens[1].length()-1)+".ucm");
					convertUCMBaseFile(baseFileURI, out);
				}
				else if (tokens[0].equals(CHARMAP)){
					break;
				}            
            }
			
			// Process mapping table section
			while ((line=in.readLine())!=null){
				// Remove comment
				if (line.indexOf('#')!=-1){
					line = line.substring(0, line.indexOf('#'));
				}
				// Remove empty line, CHARMAP headers/footers
				if ((line=line.trim()).equals("") || line.equals(CHARMAP) || line.equals(END_CHARMAP)){
					continue;
				}
				
				String[] tokens = line.split("\\s+", 3);
				
				// Precision Indicator
				String precision = PRECISION_ROUNDTRIP;
				if (2<tokens.length && tokens[2].indexOf("|")!=-1){
					precision = tokens[2].substring(tokens[2].indexOf('|')+1, tokens[2].length());
				}
				// UIn: Split string into Unicode tokens '<UXXXX'
				String[] uTokens = tokens[0].split(">\\+*<??");
				String u = "";
				for (int i=0; i<uTokens.length; i++){
					u += "\\u"+uTokens[i].substring(2,6);
				}					
				// CP: Split string into code page tokens 'XX'
				uTokens = tokens[1].split("\\+*\\\\x");
				String cp = "";
				for (int i=1; i<uTokens.length; i++){
					cp += uTokens[i];
				}
				
				if (!baseHash.contains(u+cp+precision)){				
					// 0 - A "normal", roundtrip mapping from a Unicode code point and back.
					if (precision.equals(PRECISION_ROUNDTRIP)){
						out.write("\t\t<testdata>"); out.newLine();
						out.write("\t\t\t<uin>"+u+"</uin>"); out.newLine();
						out.write("\t\t\t<cp>"+cp+"</cp>"); out.newLine();
						// UOut: the same value as UIn
						out.write("\t\t\t<uout>"+u+"</uout>"); out.newLine();
						out.write("\t\t</testdata>"); out.newLine();
					}	
					// 1 - for the best fallback codepage byte sequence.
					else if (precision.equals(PRECISION_FALLBACK)){
						out.write("\t\t<testdata>"); out.newLine();
						out.write("\t\t\t<uin>"+u+"</uin>"); out.newLine();
						out.write("\t\t\t<cp>"+cp+"</cp>"); out.newLine();
						out.write("\t\t</testdata>"); out.newLine();					
					}
					// 3 - for the best reverse fallback Unicode scaler value
					else if (precision.equals(PRECISION_REVERSE_FALLBACK)){
						toUFromU.add(new Mapping(u, cp));			
					}
				}
			}
			out.write("\t</fromutou>"); out.newLine();
			
			if(toUFromU.size()>0){
				out.write("\t<toufromu>"); out.newLine();
				for (int i=0; i<toUFromU.size(); i++){
					Mapping m = (Mapping)toUFromU.elementAt(i);
					out.write("\t\t<testdata>"); out.newLine();
					out.write("\t\t\t<cpin>"+m.getCP()+"</cpin>"); out.newLine();
					out.write("\t\t\t<u>"+m.getU()+"</u>"); out.newLine();
					out.write("\t\t</testdata>"); out.newLine();		
				}
				out.write("\t</toufromu>"); out.newLine();
			}
			
			in.close();			
			out.write("</testcase>"); out.newLine();
            out.close();
            // Clear mappings
            baseHash.clear();
            toUFromU.clear();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Process UCM base file
	 * @param baseURI base UCM file URI
	 * @param out file writer instance
	 */
	private void convertUCMBaseFile(URI baseURI, BufferedWriter out){
		try{			
			baseHash = new HashSet();
			BufferedReader in = new BufferedReader(new FileReader(new File(baseURI)));
			String line = null;
			
			// Process header section
			while ((line=in.readLine())!=null){
            	
				// Remove comment
				if (line.indexOf('#')!=-1){
					line = line.substring(0, line.indexOf('#'));
				}
				// Remove empty line
				if ((line=line.trim()).equals("")){
					continue;
				}
				
				String[] tokens = line.split("\\s+");
				if (tokens[0].equals(CHARMAP)){
					break;
				}            
            }
			
			// Process base mapping table section
			while ((line=in.readLine())!=null){
				// Remove comment
				if (line.indexOf('#')!=-1){
					line = line.substring(0, line.indexOf('#'));
				}
				// Remove empty line, CHARMAP headers/footers
				if ((line=line.trim()).equals("")){
					continue;
				}
				if (line.equals(END_CHARMAP)){
					break;
				}		
				String[] tokens = line.split("\\s+", 3);
				// End of first CHARMAP section
						
				// Precision Indicator
				String precision = PRECISION_ROUNDTRIP;
				if (2<tokens.length && tokens[2].indexOf("|")!=-1){
					precision = tokens[2].substring(tokens[2].indexOf('|')+1, tokens[2].length());
				}
				// UIn: Split string into Unicode tokens '<UXXXX'
				String[] uTokens = tokens[0].split(">\\+*<??");
				String u = "";
				for (int i=0; i<uTokens.length; i++){
					u += "\\u"+uTokens[i].substring(2,6);
				}					
				// CP: Split string into code page tokens 'XX'
				uTokens = tokens[1].split("\\+*\\\\x");
				String cp = "";
				for (int i=1; i<uTokens.length; i++){
					cp += uTokens[i];
				}
				
				// 0 - A "normal", roundtrip mapping from a Unicode code point and back.
				if (precision.equals(PRECISION_ROUNDTRIP)){
					out.write("\t\t<testdata>"); out.newLine();					
					out.write("\t\t\t<uin>"+u+"</uin>"); out.newLine();
					out.write("\t\t\t<cp>"+cp+"</cp>"); out.newLine();
					// UOut: the same value as UIn
					out.write("\t\t\t<uout>"+u+"</uout>"); out.newLine();
					out.write("\t\t</testdata>"); out.newLine();				
				}			
				// 1 - for the best fallback codepage byte sequence.
				else if (precision.equals(PRECISION_FALLBACK)){
					out.write("\t\t<testdata>"); out.newLine();
					out.write("\t\t\t<uin>"+u+"</uin>"); out.newLine();
					out.write("\t\t\t<cp>"+cp+"</cp>"); out.newLine();
					out.write("\t\t</testdata>"); out.newLine();					
				}
				// 3 - for the best reverse fallback Unicode scaler value
				else if (precision.equals(PRECISION_REVERSE_FALLBACK)){
					toUFromU.add(new Mapping(u, cp));			
				}
				// Keep in HashSet to prevent duplicates in the extension UCM file
				baseHash.add(u+cp+precision);
			}
			
			in.close();			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private class Mapping{
		private String u;
		private String cp;
		
		Mapping(String u, String cp){
			this.u = u;
			this.cp = cp;
		}
		
		String getU(){
			return u;
		}
		
		String getCP(){
			return cp;
		}
	}
	
	public static void main(String[] args) {
		
		String inputPath = null;
		String outputPath = null;
		
		for (int i=0; i<args.length; i++){
			if (args[i].equals("-i")){
				if (i+1<args.length){
					inputPath = args[i+1];
					i += 1;
				}
			}
			else if (args[i].equals("-o")){
				if (i+1<args.length){
					outputPath = args[i+1];
					i += 1;
				}
			}
		}
		
		if (inputPath==null){
			System.out.println("UCMConverter - A tool to convert UCM files to XML input for AGL conversion testing");
			System.out.println(" -i <input absolute URI - file or directory>");
			System.out.println(" -o <output absolute URI directory>");
			System.out.println("Without specifying output, <input directory>/xml will be used");
			return;
		}
		try{
			System.out.println("Start converting...");
			UCMConverter conv = new UCMConverter();
			conv.convert(inputPath, outputPath);
			System.out.println("End converting");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
