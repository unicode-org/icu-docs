package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_UTF32 extends UConverterSharedData {

	public UConverterSharedData_UTF32(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_UTF32()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		_UTF32Open(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doReset(UConverter cnv, int choice)
	{
		_UTF32Reset(cnv, choice);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		_UTF32ToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		T_UConverter_fromUnicode_UTF32_BE(args, pErrorCode);
	}
	
	final static int UCNV_NEED_TO_WRITE_BOM = 1;
	
	/* UTF-32BE ----------------------------------------------------------------- */
	
	//static void T_UConverter_toUnicode_UTF32_BE(UConverterToUnicodeArgs * args, UErrorCode * err)
	public final void T_UConverter_toUnicode_UTF32_BE(UConverterToUnicodeArgs args, int[] err)
	{
	    byte[] mySourceArray = args.sourceArray;
	    int mySourceArrayIndex = args.sourceBegin;
	    char[] myTargetArray = args.targetArray;
	    int myTargetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    byte[] toUBytesArray = args.converter.toUBytesArray;
	    int ch, i;
	
	donefornow:
			{
	    /* UTF-8 returns here for only non-offset, this needs to change.*/
	    if (args.converter.toUnicodeStatus != 0 && myTargetArrayIndex < targetLimit) {
	        i = args.converter.toULength;       /* restore # of bytes consumed */
	
	        ch = (int)(args.converter.toUnicodeStatus - 1);/*Stores the previously calculated ch from a previous call*/
	        args.converter.toUnicodeStatus = 0;
					//agljport:comment copied morebytes block here from inside loop below
	//morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch = (ch << 8) | ((byte)(mySourceArray[mySourceArrayIndex]) & UConverterUtility.UNSIGNED_BYTE_MASK);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break donefornow;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break donefornow;
	        }
	    }
	
	    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit) {
	        i = 0;
	        ch = 0;
	//agljport:delete morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch = (ch << 8) | ((byte)(mySourceArray[mySourceArrayIndex]) & UConverterUtility.UNSIGNED_BYTE_MASK);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break;
	        }
	    }
					}
	
	//agljport:delete donefornow:
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0])) {
	        /* End of target buffer */
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
	    args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
	    args.sourceBegin = mySourceArrayIndex;
	}
	
	//static void T_UConverter_fromUnicode_UTF32_BE(UConverterFromUnicodeArgs * args, UErrorCode * err)
	public final void T_UConverter_fromUnicode_UTF32_BE(UConverterFromUnicodeArgs args, int[] err)
	{
	    char[] mySourceArray = args.sourceArray;
		int mySourceArrayIndex = args.sourceBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    long ch, ch2;
	    int indexToWrite;
	    byte temp[/*sizeof(uint32_t)*/] = new byte[4];
	
	    if(mySourceArrayIndex >= sourceLimit) {
	        /* no input, nothing to do */
	        return;
	    }

	    /* write the BOM if necessary */
	    if(args.converter.fromUnicodeStatus==UCNV_NEED_TO_WRITE_BOM) {
	        byte[] bom={ 0, 0, (byte)0xfe, (byte)0xff };
	        int[] targetBegin = {args.targetBegin};
			int[] offsetsBegin = {args.offsetsBegin};
			UConverterUtility.ucnv_fromUWriteBytes(args.converter,
	                             bom, 0, 4,
	                             args.targetArray, targetBegin, args.targetLimit,
	                             args.offsetsArray, offsetsBegin, -1,
	                             err);
	        args.targetBegin = targetBegin[0];
	        args.offsetsBegin = offsetsBegin[0];	        
	        args.converter.fromUnicodeStatus=0;
	    }
	    
	    byte[] myTargetArray = args.targetArray;
		int myTargetArrayIndex = args.targetBegin;
	    temp[0] = 0;
	
		boolean doloop = true;
	    if (args.converter.fromUChar32 != 0) {
	        ch = args.converter.fromUChar32;
	        args.converter.fromUChar32 = 0;
	        //lowsurogate:
            if (mySourceArrayIndex < sourceLimit) {
                ch2 = mySourceArray[mySourceArrayIndex];
                if (UConverterUTF.U_IS_TRAIL((int)ch2)) {
                    ch = ((ch - SURROGATE_HIGH_START) << HALF_SHIFT) + ch2 + SURROGATE_LOW_BASE;
                    mySourceArrayIndex++;
                }
                else {
                    /* this is an unmatched trail code unit (2nd surrogate) */
                    /* callback(illegal) */
                    args.converter.fromUChar32 = (int)ch;
                    err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
											doloop = false;
                }
            }
            else {
                /* ran out of source */
                args.converter.fromUChar32 = (int)ch;
                if (args.flush) {
                    /* this is an unmatched trail code unit (2nd surrogate) */
                    /* callback(illegal) */
                    err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
                }
									doloop = false;
            }
			/*agljport:delete
	            }
	            else {
	                args->converter->fromUChar32 = ch;
	                *err = U_ILLEGAL_CHAR_FOUND;
	                break;
	            }
	        }
					*/
	
	        /* We cannot get any larger than 10FFFF because we are coming from UTF-16 */
	        temp[1] = (byte) (ch >>> 16 & 0x1F);
	        temp[2] = (byte) (ch >>> 8);  /* unsigned cast implicitly does (ch & FF) */
	        temp[3] = (byte) (ch);       /* unsigned cast implicitly does (ch & FF) */
	
	        for (indexToWrite = 0; indexToWrite <= 3; indexToWrite++) {
	            if (myTargetArrayIndex < targetLimit) {
	                myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
	            }
	            else {
	                args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = temp[indexToWrite];
	                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            }
	        }
	    }
	
		if(doloop) {
		    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit) {
		        ch = mySourceArray[mySourceArrayIndex++];
		
		        if (UConverterUTF.U_IS_SURROGATE((int)ch)) {
		            if (UConverterUTF.U_IS_LEAD((int)ch)) {
	            		//lowsurogate:
		                if (mySourceArrayIndex < sourceLimit) {
		                    ch2 = mySourceArray[mySourceArrayIndex];
		                    if (UConverterUTF.U_IS_TRAIL((int)ch2)) {
		                        ch = ((ch - SURROGATE_HIGH_START) << HALF_SHIFT) + ch2 + SURROGATE_LOW_BASE;
		                        mySourceArrayIndex++;
		                    }
		                    else {
		                        /* this is an unmatched trail code unit (2nd surrogate) */
		                        /* callback(illegal) */
		                        args.converter.fromUChar32 = (int)ch;
		                        err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                        break;
		                    }
		                }
		                else {
		                    /* ran out of source */
		                    args.converter.fromUChar32 = (int)ch;
		                    if (args.flush) {
		                        /* this is an unmatched trail code unit (2nd surrogate) */
		                        /* callback(illegal) */
		                        err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                    }
		                    break;
		                }
		            }
		            else {
		                args.converter.fromUChar32 = (int)ch;
		                err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
		                break;
		            }
		        }
		
		        /* We cannot get any larger than 10FFFF because we are coming from UTF-16 */
		        temp[1] = (byte) (ch >>> 16 & 0x1F);
		        temp[2] = (byte) (ch >>> 8);  /* unsigned cast implicitly does (ch & FF) */
		        temp[3] = (byte) (ch);       /* unsigned cast implicitly does (ch & FF) */
		
		        for (indexToWrite = 0; indexToWrite <= 3; indexToWrite++) {
		            if (myTargetArrayIndex < targetLimit) {
		                myTargetArray[myTargetArrayIndex++] = temp[indexToWrite];
		            }
		            else {
		                args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] = temp[indexToWrite];
		                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
		            }
		        }
		    }
		}
	
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0])) {
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
		args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
		args.sourceBegin = mySourceArrayIndex;
	}
	
	/* UTF-32LE ----------------------------------------------------------------- */
	
	//static void T_UConverter_toUnicode_UTF32_LE(UConverterToUnicodeArgs * args, UErrorCode * err)
	public final void T_UConverter_toUnicode_UTF32_LE(UConverterToUnicodeArgs args, int[] err)
	{
	    byte[] mySourceArray = args.sourceArray;
	    int mySourceArrayIndex = args.sourceBegin;
	    char[] myTargetArray = args.targetArray;
	    int myTargetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    byte[] toUBytesArray = args.converter.toUBytesArray;
	    int ch, i;
	
	donefornow:
			{
	    /* UTF-8 returns here for only non-offset, this needs to change.*/
	    if (args.converter.toUnicodeStatus != 0 && myTargetArrayIndex < targetLimit) {
	        i = args.converter.toULength;       /* restore # of bytes consumed */
	
	        ch = (int)(args.converter.toUnicodeStatus - 1);/*Stores the previously calculated ch from a previous call*/
	        args.converter.toUnicodeStatus = 0;
					//agljport:comment copied morebytes block here from inside loop below
	//morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch |= (mySourceArray[mySourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK) << (i * 8);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break donefornow;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break donefornow;
	        }
	    }
	
	    while (mySourceArrayIndex < sourceLimit && myTargetArrayIndex < targetLimit) {
	        i = 0;
	        ch = 0;
	//agljport:delete morebytes:
	        while (i < 4) {
	            if (mySourceArrayIndex < sourceLimit) {
	                ch |= (mySourceArray[mySourceArrayIndex] & UConverterUtility.UNSIGNED_BYTE_MASK) << (i * 8);
	                toUBytesArray[i++] = (byte) mySourceArray[mySourceArrayIndex++];
	            }
	            else {
	                /* stores a partially calculated target*/
	                /* + 1 to make 0 a valid character */
	                args.converter.toUnicodeStatus = ch + 1;
	                args.converter.toULength = (byte) i;
	                break donefornow;
	            }
	        }
	
	        if (ch <= MAXIMUM_UTF && !UConverterUTF.U_IS_SURROGATE(ch)) {
	            /* Normal valid byte when the loop has not prematurely terminated (i < inBytes) */
	            if (ch <= MAXIMUM_UCS2) 
	            {
	                /* fits in 16 bits */
	                myTargetArray[myTargetArrayIndex++] = (char) ch;
	            }
	            else {
	                /* write out the surrogates */
	                myTargetArray[myTargetArrayIndex++] = UConverterUTF16.U16_LEAD(ch);
	                ch = UConverterUTF16.U16_TRAIL(ch);
	                if (myTargetArrayIndex < targetLimit) {
	                    myTargetArray[myTargetArrayIndex++] = (char)ch;
	                }
	                else {
	                    /* Put in overflow buffer (not handled here) */
	                    args.converter.UCharErrorBufferArray[0] = (char) ch;
	                    args.converter.UCharErrorBufferLength = 1;
	                    err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    break;
	                }
	            }
	        }
	        else {
	            args.converter.toULength = (byte)i;
	            err[0] = ErrorCode.U_ILLEGAL_CHAR_FOUND;
	            break;
	        }
	    }
					}
	
	//agljport:delete donefornow:
	    if (mySourceArrayIndex < sourceLimit && myTargetArrayIndex >= targetLimit && ErrorCode.isSuccess(err[0])) {
	        /* End of target buffer */
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    args.targetArray = myTargetArray;
	    args.targetBegin = myTargetArrayIndex;
	    args.sourceArray = mySourceArray;
	    args.sourceBegin = mySourceArrayIndex;
	}
	/* UTF-32 (Detect BOM) ------------------------------------------------------ */
	
	/*
	 * Detect a BOM at the beginning of the stream and select UTF-32BE or UTF-32LE
	 * accordingly.
	 *
	 * State values:
	 * 0    initial state
	 * 1    saw 00
	 * 2    saw 00 00
	 * 3    saw 00 00 FE
	 * 4    -
	 * 5    saw FF
	 * 6    saw FF FE
	 * 7    saw FF FE 00
	 * 8    UTF-32BE mode
	 * 9    UTF-32LE mode
	 *
	 * During detection: state&3==number of matching bytes so far.
	 *
	 * On output, emit U+FEFF as the first code point.
	 */
	
	//static void _UTF32Reset(UConverter *cnv, UConverterResetChoice choice)
	protected void _UTF32Reset(UConverter cnv, int choice)
	{
	    if(choice<=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        /* reset toUnicode: state=0 */
	        cnv.mode=0;
	    }
	
	    if(choice!=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        /* reset fromUnicode: prepare to output the UTF-32PE BOM */
	    	cnv.fromUnicodeStatus=UCNV_NEED_TO_WRITE_BOM;
	    }
	}
	
	//static void _UTF32Open(UConverter *cnv, const char *name, const char *locale, uint32_t options, UErrorCode *pErrorCode)
	protected void _UTF32Open(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
	    _UTF32Reset(cnv, UConverterConstants.UConverterResetChoice.UCNV_RESET_BOTH);
	}
	
	protected static final byte utf32BOM[/*8*/]={ 0, 0, (byte)0xfe, (byte)0xff,    (byte)0xff, (byte)0xfe, 0, 0 };
	
	//static void _UTF32ToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	protected void _UTF32ToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv=pArgs.converter;
	    byte[] sourceArray=pArgs.sourceArray;
			int sourceArrayIndex = pArgs.sourceBegin;
	    int sourceLimit=pArgs.sourceLimit;
	    int[] offsetsArray=pArgs.offsetsArray;
	    int offsetsArrayIndex=pArgs.offsetsBegin;
	
	    int state, offsetDelta;
	    byte b;
	
	    state=cnv.mode;
	
	    /*
	     * If we detect a BOM in this buffer, then we must add the BOM size to the
	     * offsets because the actual converter function will not see and count the BOM.
	     * offsetDelta will have the number of the BOM bytes that are in the current buffer.
	     */
	    offsetDelta=0;
	
	    while(sourceArrayIndex<sourceLimit && ErrorCode.isSuccess(pErrorCode[0])) {
	        switch(state) {
	        case 0:
	            b=sourceArray[sourceArrayIndex];
	            if(b==0) {
	                state=1; /* could be 00 00 FE FF */
	            } else if(b==(byte)0xff) {
	                state=5; /* could be FF FE 00 00 */
	            } else {
	                state=8; /* default to UTF-32BE */
	                continue;
	            }
	            ++sourceArrayIndex;
	            break;
	        case 1:
	        case 2:
	        case 3:
	        case 5:
	        case 6:
	        case 7:
	            if(sourceArray[sourceArrayIndex]==utf32BOM[state]) {
	                ++state;
	                ++sourceArrayIndex;
	                if(state==4) {
	                    state=8; /* detect UTF-32BE */
	                    offsetDelta=sourceArrayIndex-pArgs.sourceBegin;
	                } else if(state==8) {
	                    state=9; /* detect UTF-32LE */
	                    offsetDelta=sourceArrayIndex-pArgs.sourceBegin;
	                }
	            } else {
	                /* switch to UTF-32BE and pass the previous bytes */
	                int count=sourceArrayIndex-pArgs.sourceBegin; /* number of bytes from this buffer */
	
	                /* reset the source */
	                sourceArrayIndex=pArgs.sourceBegin;
	
	                if(count==(state&3)) {
	                    /* simple: all in the same buffer, just reset source */
	                } else {
	                    boolean oldFlush=pArgs.flush;
	
	                    /* some of the bytes are from a previous buffer, replay those first */
	                    pArgs.sourceArray=utf32BOM; /* select the correct BOM */
	                    pArgs.sourceBegin=(state&4); /* select the correct BOM */
	                    pArgs.sourceLimit=pArgs.sourceBegin+((state&3)-count); /* replay previous bytes */
	                    pArgs.flush=false; /* this sourceLimit is not the real source stream limit */
	
	                    /* no offsets: bytes from previous buffer, and not enough for output */
	                    T_UConverter_toUnicode_UTF32_BE(pArgs, pErrorCode);
	
	                    /* restore real pointers; pArgs->source will be set in case 8/9 */
	                    pArgs.sourceLimit=sourceLimit;
	                    pArgs.flush=oldFlush;
	                }
	                state=8;
	                continue;
	            }
	            break;
	        case 8:
	            /* call UTF-32BE */
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
	            if(offsetsArray==null) {
	                T_UConverter_toUnicode_UTF32_BE(pArgs, pErrorCode);
	            } else {
	                //agljport:fix T_UConverter_toUnicode_UTF32_BE_OFFSET_LOGIC(pArgs, pErrorCode);
	            }
	            sourceArray=pArgs.sourceArray;
	            sourceArrayIndex=pArgs.sourceBegin;
	            break;
	        case 9:
	            /* call UTF-32LE */
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
	            if(offsetsArray==null) {
	                T_UConverter_toUnicode_UTF32_LE(pArgs, pErrorCode);
	            } else {
	                //agljport:fix T_UConverter_toUnicode_UTF32_LE_OFFSET_LOGIC(pArgs, pErrorCode);
	            }
	            sourceArray=pArgs.sourceArray;
	            sourceArrayIndex=pArgs.sourceBegin;
	            break;
	        default:
	            break; /* does not occur */
	        }
	    }
	
	    /* add BOM size to offsets - see comment at offsetDelta declaration */
	    if(offsetsArray!=null && offsetDelta!=0) {
	        int offsetsLimit=pArgs.offsetsBegin;
	        while(offsetsArrayIndex<offsetsLimit) {
	            offsetsArray[offsetsArrayIndex++] += offsetDelta;
	        }
	    }
	
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	
	    if(sourceArrayIndex==sourceLimit && pArgs.flush) {
	        /* handle truncated input */
	        switch(state) {
	        case 0:
	            break; /* no input at all, nothing to do */
	        case 8:
	            T_UConverter_toUnicode_UTF32_BE(pArgs, pErrorCode);
	            break;
	        case 9:
	            T_UConverter_toUnicode_UTF32_LE(pArgs, pErrorCode);
	            break;
	        default:
	            /* handle 0<state<8: call UTF-32BE with too-short input */
	            pArgs.sourceArray=utf32BOM; /* select the correct BOM */
	            pArgs.sourceBegin=(state&4); /* select the correct BOM */
	            pArgs.sourceLimit=pArgs.sourceBegin+(state&3); /* replay bytes */
	
	            /* no offsets: not enough for output */
	            T_UConverter_toUnicode_UTF32_BE(pArgs, pErrorCode);
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
	            pArgs.sourceLimit=sourceLimit;
	            state=8;
	            break;
	        }
	    }
	
	    cnv.mode=state;
	}
	
	/*
	static const UConverterImpl _UTF32Impl = {
	    UCNV_UTF32,
	
	    NULL,
	    NULL,
	
	    _UTF32Open,
	    NULL,
	    _UTF32Reset,
	
	    _UTF32ToUnicodeWithOffsets,
	    _UTF32ToUnicodeWithOffsets,
	#if U_IS_BIG_ENDIAN
	    T_UConverter_fromUnicode_UTF32_BE,
	    T_UConverter_fromUnicode_UTF32_BE_OFFSET_LOGIC,
	#else
	    T_UConverter_fromUnicode_UTF32_LE,
	    T_UConverter_fromUnicode_UTF32_LE_OFFSET_LOGIC,
	#endif
	    _UTF32GetNextUChar,
	
	    NULL, // ### TODO implement getStarters for all Unicode encodings?!
	    NULL,
	    NULL,
	    NULL,
	    ucnv_getNonSurrogateUnicodeSet
	};
	
	// The 1236 CCSID refers to any version of Unicode with a BOM sensitive endianess of UTF-32
	static const UConverterStaticData _UTF32StaticData = {
	    sizeof(UConverterStaticData),
	    "UTF-32",
	    1236,
	    UCNV_IBM, UCNV_UTF32, 4, 4,
	#if U_IS_BIG_ENDIAN
	    { 0, 0, 0xff, 0xfd }, 4,
	#else
	    { 0xfd, 0xff, 0, 0 }, 4,
	#endif
	    FALSE, FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	
	const UConverterSharedData _UTF32Data = {
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_UTF32StaticData, FALSE, &_UTF32Impl, 
	    0
	};
	*/
	
	public static UConverterStaticData _UTF32StaticData;
	public static UConverterSharedData_UTF32 _UTF32Data;
	static 
	{
	
		_UTF32StaticData = new UConverterStaticData(
		    UConverterStaticData.sizeofUConverterStaticData,
		    "UTF-32",
		    1236,
		    (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_UTF32, (byte)4, (byte)4,
		    new byte[]{ 0, 0, (byte)0xff, (byte)0xfd }, (byte)4, (byte)0, (byte)0,
		    (short)0,
		    (byte)0,
		    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
		);
		
		_UTF32Data = new UConverterSharedData_UTF32(
		    sizeofUConverterSharedData, ~0,
		    /*NULL, NULL,*/ _UTF32StaticData, false, /*&_UTF32Impl,*/
		    0
		);
	}

}
