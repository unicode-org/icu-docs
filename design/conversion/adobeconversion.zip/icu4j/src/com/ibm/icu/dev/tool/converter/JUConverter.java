package com.ibm.icu.dev.tool.converter;

import java.util.Vector;

import com.ibm.icu.converters.UConverter;
import com.ibm.icu.impl.UConverterAlias;
import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.impl.UConverterAliasesEnumeration;

/** 
 * A tool to provide information of available character set conversion in AGL-Java 
 * 
 * @author Niti Hantaweepant
 */

public class JUConverter {

	// Command Argument
	private static final String COMMAND_HELP 		= "-h";
	private static final String COMMAND_HELP2 		= "-?";
	private static final String COMMAND_HELP3 		= "--help";
	private static final String COMMAND_VERSION		= "-V";
	private static final String COMMAND_VERSION2	= "--version";
	private static final String COMMAND_LIST 		= "-l";
	private static final String COMMAND_LIST2 		= "--list";
	private static final String COMMAND_LIST_CODE	= "--list-code";
	private static final String COMMAND_CANON		= "--canon";
	
	// Version
	private static final String VERSION = "JUConverter v1.0 ICU 3.2";
	
	/**
	 * Display help for AGLJUConverter tool
	 *
	 */
	private void displayHelp(){
		System.out.println("Usage: JUConverter [ "+COMMAND_HELP+", "+COMMAND_HELP2+", "+COMMAND_HELP3+" ] [ "+
				COMMAND_VERSION+", "+COMMAND_VERSION2+" ] [ "+
				COMMAND_LIST+", "+COMMAND_LIST2+" | "+COMMAND_LIST_CODE+" code ] [ "+
				COMMAND_CANON+" ] \n\n"+
				"Option:\t"+COMMAND_HELP+", "+COMMAND_HELP2+", "+COMMAND_HELP3+"\t\t\tprint this message\n"+
				"\t"+COMMAND_VERSION+", "+COMMAND_VERSION2+"\t\t\tprint the program version\n"+
				"\t"+COMMAND_LIST+", "+COMMAND_LIST2+"\t\t\tlist all available encodings\n"+
				"\t"+COMMAND_LIST_CODE+" code\t\tlist only the given encoding\n"+
				"\t"+COMMAND_CANON+"\t\t\t\tprint list in cnvrtrs.txt(5) format"
		);
	}
	
	/**
	 * Display version of AGLJUConverter tool
	 *
	 */
	private void displayVersion(){
		System.out.println(VERSION);
	}
	
	/**
	 * Display list of available encodings in AGLJ
	 *
	 */
	private void displayEncodings(String canon){
		StringBuffer line;
		int[] errCode = new int[] {ErrorCode.U_ZERO_ERROR};
		if (canon==null){
			for (int i=0; i<UConverter.ucnv_countAvailable(); i++){			
				String encoding = UConverter.ucnv_getAvailableName(i);
				line = new StringBuffer();				
				for (int j=0; j<UConverterAlias.ucnv_countAliases(encoding, errCode); j++){
					line.append(UConverterAlias.ucnv_getAlias(encoding, j, errCode)+" ");
				}
				System.out.println(line.toString());
			}		
		}
		else if (canon.equals(COMMAND_CANON)){
			
			int standardCount = UConverterAlias.ucnv_countStandards();
			Vector stdVector = new Vector();
			
			// print available standards
			line = new StringBuffer("{");
			for(int i=0; i<standardCount; i++){
				String stdName = UConverter.ucnv_getStandard(i, errCode);
				if (stdName.equals(""))
					continue;
				stdVector.add(new Standard(stdName));
				line.append(" "+stdName);
			}
			line.append(" }");
			System.out.println(line.toString());
			
			for (int i=0; i<UConverter.ucnv_countAvailable(); i++){			
				String encoding = UConverter.ucnv_getAvailableName(i);
				// Initialize all aliases of each standards
				for (int j=0; j<stdVector.size(); j++){
					Standard standard = (Standard)stdVector.elementAt(j);
					UConverterAliasesEnumeration enum = UConverter.ucnv_openStandardNames(encoding, standard.name, errCode);
					for (int k=0; k<enum.count(errCode); k++){
						standard.aliases.add(enum.uNext(errCode));
					}
				}
				
				for (int j=0; j<UConverterAlias.ucnv_countAliases(encoding, errCode); j++){
					line = new StringBuffer();
					String alias = UConverterAlias.ucnv_getAlias(encoding, j, errCode);
					if (j!=0)
						line.append("\t");
					
					line.append(alias);
					StringBuffer stdStr = new StringBuffer();
					for (int k=0; k<stdVector.size(); k++){
						Standard standard = (Standard)stdVector.elementAt(k);
						if (standard.aliases.contains(alias)){
							stdStr.append(standard.name);
							if (alias.equals(UConverter.ucnv_getStandardName(alias, standard.name, errCode)))
								stdStr.append("*");
							stdStr.append(" ");
						}
					}
					if (!stdStr.toString().equals(""))
						line.append(" { "+stdStr.toString()+"}");
					System.out.println(line.toString());
				}				
			}
			System.out.println();
		}
	}
	
	/**
	 * Display default encoding
	 *
	 */
	private void listCode(String encoding){
		boolean exist = false;
		String enc = null;
		for (int i=0; i<UConverter.ucnv_countAvailable(); i++){			
			enc = UConverter.ucnv_getAvailableName(i);
			if (enc.equals(encoding)){
				exist = true;
				break;
			}
			
			int[] errCode = new int[] {ErrorCode.U_ZERO_ERROR};
			for (int j=0; j<UConverterAlias.ucnv_countAliases(encoding, errCode); j++){
				if (encoding.equals(UConverterAlias.ucnv_getAlias(enc, j, errCode))){
					exist = true;
					break;
				}
			}
			
			if (exist) 
				break;
		}
		
		if(exist){
			System.out.println(enc);
		}
		else{
			System.out.println("Couldn't find encoding: "+encoding);
		}		
	}
	
	/**
	 * Class to keep Standard information - name and applicable aliases
	 */
	private static class Standard{
		String name;
		Vector aliases;
		
		Standard(String name){
			this.name = name;
			aliases = new Vector();
		}		
	}
	
	/**
	 * Main method to be called for the tool usage
	 * @param args
	 */
	public void processArgs(String[] args){
		String command = COMMAND_HELP;
		
		if (args.length>0){
			command = args[0];
		}
		
		if (command.equals(COMMAND_VERSION) || command.equals(COMMAND_VERSION2)){
			// Display the version of AGLJConverter
			displayVersion();
		}
		else if (command.equals(COMMAND_LIST) || command.equals(COMMAND_LIST2)){
			String optCmd = null;
			if (args.length>1)
				optCmd = args[1];
			displayEncodings(optCmd);
		}
		else if (command.equals(COMMAND_LIST_CODE)){
			if (args.length>1)
				listCode(args[1]);
			else
				displayHelp();
		}
		else {
			// Display the usage
			displayHelp();			
		}
	}
	
	public static void main(String[] args){
		
		JUConverter cnv = new JUConverter();
		cnv.processArgs(args);
	}
}
