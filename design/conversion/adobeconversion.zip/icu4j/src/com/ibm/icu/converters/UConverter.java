package com.ibm.icu.converters;

import java.nio.ByteBuffer;
import java.lang.reflect.Method;
import java.lang.Class;

import com.ibm.icu.common.ErrorCode;

import com.ibm.icu.impl.UConverterAlias;
import com.ibm.icu.impl.UConverterAliasesEnumeration;
import com.ibm.icu.impl.UConverterCallback;
import com.ibm.icu.impl.UConverterConstants;
import com.ibm.icu.impl.UConverterExt;
import com.ibm.icu.impl.UConverterFromUnicodeArgs;
import com.ibm.icu.impl.UConverterLoadArgs;
import com.ibm.icu.impl.UConverterSharedData;
import com.ibm.icu.impl.UConverterToUnicodeArgs;
import com.ibm.icu.impl.UConverterUTF16;
import com.ibm.icu.impl.UConverterUtility;
import com.ibm.icu.impl.UMachine;

import com.ibm.icu.impl.UDataMemory;

public class UConverter implements UConverterConstants{

	// class	UConverter_
    /*
     * Error function pointer called when conversion issues
     * occur during a ucnv_fromUnicode call
     */
    // void (U_EXPORT2 *fromUCharErrorBehaviour) (const void *context, UConverterFromUnicodeArgs *args, const UChar *codeUnits, int32_t length, UChar32 codePoint, UConverterCallbackReason reason, UErrorCode *);
	public UConverterCallback.UConverterFromUCallback fromUCharErrorBehaviour;
		
    /*
     * Error function pointer called when conversion issues
     * occur during a ucnv_toUnicode call
     */
    // void (U_EXPORT2 *fromCharErrorBehaviour) (const void *context, UConverterToUnicodeArgs *args, const char *codeUnits, int32_t length, UConverterCallbackReason reason, UErrorCode *);
	public UConverterCallback.UConverterToUCallback fromCharErrorBehaviour;

    /*
     * Pointer to additional data that depends on the converter type.
     * Used by ISO 2022, SCSU, GB 18030 converters, possibly more.
     */
    //void *extraInfo;
	public Object extraInfo;

    //const void *fromUContext;
	public byte[] fromUContextArray;
    //const void *toUContext;
	public byte[] toUContextArray;

    //UConverterSharedData *sharedData;   /* Pointer to the shared immutable part of the converter object */
    public UConverterSharedData sharedData;   /* Pointer to the shared immutable part of the converter object */

    //uint32_t options; /* options flags from UConverterOpen, may contain additional bits */
    public long options; /* options flags from UConverterOpen, may contain additional bits */

    //UBool sharedDataIsCached;  /* TRUE:  shared data is in cache, don't destroy on ucnv_close() if 0 ref.  FALSE: shared data isn't in the cache, do attempt to clean it up if the ref is 0 */
    public boolean sharedDataIsCached;  /* TRUE:  shared data is in cache, don't destroy on ucnv_close() if 0 ref.  FALSE: shared data isn't in the cache, do attempt to clean it up if the ref is 0 */
    //UBool isCopyLocal;  /* TRUE if UConverter is not owned and not released in ucnv_close() (stack-allocated, safeClone(), etc.) */
    public boolean isCopyLocal;  /* TRUE if UConverter is not owned and not released in ucnv_close() (stack-allocated, safeClone(), etc.) */
    //UBool isExtraLocal; /* TRUE if extraInfo is not owned and not released in ucnv_close() (stack-allocated, safeClone(), etc.) */
    public boolean isExtraLocal; /* TRUE if extraInfo is not owned and not released in ucnv_close() (stack-allocated, safeClone(), etc.) */

    //UBool  useFallback;
    public boolean  useFallback;
    //int8_t toULength;                   /* number of bytes in toUBytes */
    public byte toULength;                   /* number of bytes in toUBytes */
    //uint8_t toUBytes[UCNV_MAX_CHAR_LEN-1];/* more "toU status"; keeps the bytes of the current character */
    public byte[] toUBytesArray;/* more "toU status"; keeps the bytes of the current character */
	public int toUBytesBegin;
    //uint32_t toUnicodeStatus;           /* Used to internalize stream status information */
    public long toUnicodeStatus;           /* Used to internalize stream status information */
    //int32_t mode;
    public int mode;
    //uint32_t fromUnicodeStatus;
    public long fromUnicodeStatus;

    /*
     * More fromUnicode() status. Serves 3 purposes:
     * - keeps a lead surrogate between buffers (similar to toUBytes[])
     * - keeps a lead surrogate at the end of the stream,
     *   which the framework handles as truncated input
     * - if the fromUnicode() implementation returns to the framework
     *   (ucnv.c ucnv_fromUnicode()), then the framework calls the callback
     *   for this code point
     */
    //UChar32 fromUChar32;
    public int fromUChar32;

    /*
     * value for ucnv_getMaxCharSize()
     *
     * usually simply copied from the static data, but ucnvmbcs.c modifies
     * the value depending on the converter type and options
     */
    //int8_t maxBytesPerUChar;
    public byte maxBytesPerUChar;

    //int8_t subCharLen;                  /* length of the codepage specific character sequence */
    public byte subCharLen;                  /* length of the codepage specific character sequence */
    //int8_t invalidCharLength;
    public byte invalidCharLength;
    //int8_t charErrorBufferLength;       /* number of valid bytes in charErrorBuffer */
    public byte charErrorBufferLength;       /* number of valid bytes in charErrorBuffer */

    //int8_t invalidUCharLength;
    public byte invalidUCharLength;
    //int8_t UCharErrorBufferLength;      /* number of valid UChars in charErrorBuffer */
    public byte UCharErrorBufferLength;      /* number of valid UChars in charErrorBuffer */

    //uint8_t subChar1;                                   /* single-byte substitution character if different from subChar */
    public byte subChar1;                                   /* single-byte substitution character if different from subChar */
    //UBool useSubChar1;
    public boolean useSubChar1;
    //uint8_t subChar[UCNV_MAX_SUBCHAR_LEN];              /* codepage specific character sequence */
    public byte[] subCharArray;              /* codepage specific character sequence */
	public int subCharBegin;
    //char invalidCharBuffer[UCNV_MAX_CHAR_LEN];          /* bytes from last error/callback situation */
    public byte[] invalidCharBufferArray;          /* bytes from last error/callback situation */
	public int invalidCharBufferBegin;
    //uint8_t charErrorBuffer[UCNV_ERROR_BUFFER_LENGTH];  /* codepage output from Error functions */
	//agljport:note ucnv_fromUnicode has char* overflow pointer to this array so made it byte[] instead of widening to short[]
    public byte[] charErrorBufferArray;  /* codepage output from Error functions */
	public int charErrorBufferBegin;

    //UChar invalidUCharBuffer[U16_MAX_LENGTH];           /* UChars from last error/callback situation */
    public char[] invalidUCharBufferArray;           /* UChars from last error/callback situation */
	public int invalidUCharBufferBegin;
    //UChar UCharErrorBuffer[UCNV_ERROR_BUFFER_LENGTH];   /* unicode output from Error functions */
    public char[] UCharErrorBufferArray;   /* unicode output from Error functions */
	public int UCharErrorBufferBegin;

    /* fields for conversion extension */

    /* store previous UChars/chars to continue partial matches */
    //UChar32 preFromUFirstCP;                /* >=0: partial match */
    public int preFromUFirstCP;                /* >=0: partial match */
    //UChar preFromU[UCNV_EXT_MAX_UCHARS];
    public char[] preFromUArray;
	public int preFromUBegin;
    //char preToU[UCNV_EXT_MAX_BYTES];
    public byte[] preToUArray;
	public int preToUBegin;
    //int8_t preFromULength, preToULength;    /* negative: replay */
    public byte preFromULength, preToULength;    /* negative: replay */
    //int8_t preToUFirstLength;               /* length of first character */
    public byte preToUFirstLength;               /* length of first character */
    // struct UConverter

	public UConverter()
	{
		toUBytesArray = new byte[UCNV_MAX_CHAR_LEN-1];/* more "toU status"; keeps the bytes of the current character */
		subCharArray = new byte[UCNV_MAX_SUBCHAR_LEN];              /* codepage specific character sequence */
		invalidCharBufferArray = new byte[UCNV_MAX_CHAR_LEN];          /* bytes from last error/callback situation */
		charErrorBufferArray = new byte[UCNV_ERROR_BUFFER_LENGTH];  /* codepage output from Error functions */
		invalidUCharBufferArray = new char[U16_MAX_LENGTH];           /* UChars from last error/callback situation */
		UCharErrorBufferArray = new char[UCNV_ERROR_BUFFER_LENGTH];   /* unicode output from Error functions */
		preFromUArray = new char[UConverterExt.UCNV_EXT_MAX_UCHARS];
		preToUArray = new byte[UConverterExt.UCNV_EXT_MAX_BYTES];

	}

	static class UConverterLookupData {
		//char cnvName[UCNV_MAX_CONVERTER_NAME_LENGTH], locale[ULOC_FULLNAME_CAPACITY];
		StringBuffer cnvName;
		StringBuffer locale;
		//const char *realName;
		String realName;
		//uint32_t options;
		long options;
		UConverterLookupData()
		{
			cnvName = new StringBuffer(UCNV_MAX_CONVERTER_NAME_LENGTH);
			locale = new StringBuffer(ULOC_FULLNAME_CAPACITY);
		}
	}

	/**
	 * Creates a UConverter object with the names specified as a C string.
	 * The actual name will be resolved with the alias file
	 * using a case-insensitive string comparison that ignores
	 * the delimiters '-', '_', and ' ' (dash, underscore, and space).
	 * E.g., the names "UTF8", "utf-8", and "Utf 8" are all equivalent.
	 * If <code>NULL</code> is passed for the converter name, it will create one with the
	 * getDefaultName return value.
	 * 
	 * @param name Name of the uconv table, may have options appended
	 * @param err outgoing error status <TT>U_MEMORY_ALLOCATION_ERROR, U_FILE_ACCESS_ERROR</TT>
	 * @return the created Unicode converter object, or <TT>NULL</TT> if an error occured
	 * @stable ICU 2.0
	 */
	// U_CAPI UConverter* U_EXPORT2 ucnv_open (const char *name, UErrorCode * err)
	public static final UConverter ucnv_open(String name, int[]  err)
	{
	    UConverter r;
	
	    if (err == null || ErrorCode.isFailure(err[0])) {
	        return null;
	    }
	
	    r = ucnv_createConverter(null, name, err);
	    return r;
	}
	
	// UConverter * ucnv_createConverter(UConverter *myUConverter, const char *converterName, UErrorCode * err)
	static UConverter ucnv_createConverter(UConverter myUConverter, String converterName, int[] err)
	{
	    UConverterLookupData stackLookup = new UConverterLookupData();
	    UConverterSharedData mySharedConverterData;
	
	    //agljport:todo UTRACE_ENTRY_OC(UTRACE_UCNV_OPEN);
	
	    if(ErrorCode.isSuccess(err[0])) {
	        //agljport:todo UTRACE_DATA1(UTRACE_OPEN_CLOSE, "open converter %s", converterName);
	
	        mySharedConverterData = ucnv_loadSharedData(converterName, stackLookup, err);
	
	        if(ErrorCode.isSuccess(err[0])) {
	            myUConverter = ucnv_createConverterFromSharedData(myUConverter, mySharedConverterData, stackLookup.realName, stackLookup.locale.toString(), stackLookup.options, err);
	
	            if(ErrorCode.isSuccess(err[0])) {
	                //agljport:todo UTRACE_EXIT_PTR_STATUS(myUConverter, *err);
	                return myUConverter;
	            } else {
	                ucnv_unloadSharedDataIfReady(mySharedConverterData);
	            }
	        }
	    }
	
	    /* exit with error */
	    //agljport:todo UTRACE_EXIT_STATUS(*err);
	    return null;
	}

	/*Logic determines if the converter is Algorithmic AND/OR cached
	 *depending on that:
	 * -we either go to get data from disk and cache it (Data=TRUE, Cached=False)
	 * -Get it from a Hashtable (Data=X, Cached=TRUE)
	 * -Call dataConverter initializer (Data=TRUE, Cached=TRUE)
	 * -Call AlgorithmicConverter initializer (Data=FALSE, Cached=TRUE)
	 */
	
	//UConverterSharedData * ucnv_loadSharedData(const char *converterName, UConverterLookupData *lookup, UErrorCode * err)
	public static final UConverterSharedData ucnv_loadSharedData(String converterName, UConverterLookupData lookup, int[] err)
	{
	    UConverterLookupData stackLookup = new UConverterLookupData();
	    UConverterSharedData mySharedConverterData = null;
	    int[] internalErrorCode = new int[1]; internalErrorCode[0] = ErrorCode.U_ZERO_ERROR;
			long[] pFlags = new long[1];
	
	    if (ErrorCode.isFailure(err[0])) {
	        return null;
	    }
	
	    if(lookup == null) {
	        lookup = stackLookup;
	    }
	
	    lookup.locale.delete(0, lookup.locale.length());
	    lookup.options = 0;
	
	    /* In case "name" is NULL we want to open the default converter. */
	    if (converterName == null) {
	        lookup.realName = UConverterAlias.ucnv_getDefaultName();
	        if (lookup.realName == null) {
	            err[0] = ErrorCode.U_MISSING_RESOURCE_ERROR;
	            return null;
	        }
	        /* the default converter name is already canonical */
	    } else {
	        /* separate the converter name from the options */
				pFlags[0] = lookup.options;
	        parseConverterOptions(converterName, lookup.cnvName, lookup.locale, pFlags, err);
					lookup.options = pFlags[0];
	        if (ErrorCode.isFailure(err[0])) {
	            /* Very bad name used. */
	            return null;
	        }
	
	        /* get the canonical converter name */
	        lookup.realName = UConverterAlias.ucnv_io_getConverterName(lookup.cnvName.toString(), internalErrorCode);
	        if (ErrorCode.isFailure(internalErrorCode[0]) || lookup.realName == null) {
	            /*
	            * set the input name in case the converter was added
	            * without updating the alias table, or when there is no alias table
	            */
	            lookup.realName = lookup.cnvName.toString();
	        }
	    }
	
	    /* separate the converter name from the options */
	    if(!lookup.realName.contentEquals(lookup.cnvName)) {
				pFlags[0] = lookup.options;
	        parseConverterOptions(lookup.realName, lookup.cnvName, lookup.locale, pFlags, err);
					lookup.options = pFlags[0];
	        lookup.realName = new String(lookup.cnvName);
	    }
	
	    /* get the shared data for an algorithmic converter, if it is one */
	    mySharedConverterData = UConverterSharedData.getAlgorithmicTypeFromName(lookup.realName);
	    if (mySharedConverterData == null)
	    {
	        /* it is a data-based converter, get its shared data.               */
	        /* Hold the cnvCacheMutex through the whole process of checking the */
	        /*   converter data cache, and adding new entries to the cache      */
	        /*   to prevent other threads from modifying the cache during the   */
	        /*   process.                                                       */
	        //UConverterLoadArgs args={ 0 };
					UConverterLoadArgs args = new UConverterLoadArgs();
	
	        //args.size=sizeof(UConverterLoadArgs);
	        args.nestedLoads=1;
	        args.options=lookup.options;
	        args.pkg=null;
	        args.name=lookup.realName;
	
	        //agljport:todo umtx_lock(&cnvCacheMutex);
	        mySharedConverterData = UConverterSharedData.ucnv_load(args, err);
	        //agljport:todo umtx_unlock(&cnvCacheMutex);
	        if (ErrorCode.isFailure(err[0]) || (mySharedConverterData == null))
	        {
	            return null;
	        }
	    }
	
	    return mySharedConverterData;
	}

	//UConverter* ucnv_createConverterFromSharedData(UConverter *myUConverter, UConverterSharedData *mySharedConverterData, const char *realName, const char *locale, uint32_t options, UErrorCode *err)
	public static final UConverter ucnv_createConverterFromSharedData(UConverter myUConverter, UConverterSharedData mySharedConverterData, String realName, String locale, long options, int[] err)
	{
	    boolean isCopyLocal;
	
	    if(myUConverter == null)
	    {
	        //myUConverter = (UConverter *) uprv_malloc (sizeof (UConverter));
	        myUConverter = new UConverter();
	        if(myUConverter == null)
	        {
	            err[0] = ErrorCode.U_MEMORY_ALLOCATION_ERROR;
	            return null;
	        }
	        isCopyLocal = false;
	    } else {
	        isCopyLocal = true;
	    }
	
	    /* initialize the converter */
	    //uprv_memset(myUConverter, 0, sizeof(UConverter));
	    myUConverter.isCopyLocal = isCopyLocal;
	    myUConverter.isExtraLocal = false;
	    myUConverter.sharedData = mySharedConverterData;
	    myUConverter.options = options;
	    myUConverter.fromCharErrorBehaviour = new UConverterCallback.UCNV_TO_U_CALLBACK_SUBSTITUTE();
	    myUConverter.fromUCharErrorBehaviour = new UConverterCallback.UCNV_FROM_U_CALLBACK_SUBSTITUTE();
	    myUConverter.toUnicodeStatus = myUConverter.sharedData.toUnicodeStatus;
	    myUConverter.maxBytesPerUChar = myUConverter.sharedData.staticData.maxBytesPerChar;
	    myUConverter.subChar1 = myUConverter.sharedData.staticData.subChar1;
	    myUConverter.subCharLen = myUConverter.sharedData.staticData.subCharLen;
	    UConverterUtility.uprv_memcpy (myUConverter.subCharArray, myUConverter.subCharBegin, myUConverter.sharedData.staticData.subChar, 0, myUConverter.subCharLen);
	    myUConverter.preFromUFirstCP = U_SENTINEL;
	
	    //agljport:todo if(myUConverter != null && myUConverter.sharedData.impl.open != null)
	    if(myUConverter != null) {
	        myUConverter.sharedData.open(myUConverter, realName, locale, options, err);
	        if(ErrorCode.isFailure(err[0])) {
	            myUConverter.ucnv_close();
	            return null;
	        }
	    }
	
	    return myUConverter;
	}

	//U_CAPI const char*   U_EXPORT2 ucnv_getName (const UConverter * converter, UErrorCode * err)
	public static final String ucnv_getName(UConverter converter, int[] err)
	{
	    if (ErrorCode.isFailure(err[0]))
	        return null;
	    //agljport:todo if(converter.sharedData.impl.getName){
	        String temp= converter.sharedData.getName(converter);
	        if(temp != null)
	            return temp;
	    //agljport:todo }
	    return converter.sharedData.staticData.name;
	}

	// static void parseConverterOptions(const char *inName, char *cnvName, char *locale, uint32_t *pFlags, UErrorCode *err)
	static void parseConverterOptions(String inName, StringBuffer cnvName, StringBuffer locale, long[] pFlags, int[] err)
	{
	    char c;
	    long len = 0;
			int inNameIndex = 0, cnvNameIndex = 0;
			inName = inName.concat("\000");
			//byte[] localeArray = locale.getBytes();
			//int localeIndex = 0;
	
			cnvName.delete(0, cnvName.length());
			locale.delete(0, locale.length());
	    /* copy the converter name itself to cnvName */
	    while((c=inName.charAt(inNameIndex))!=0 && c!=UCNV_OPTION_SEP_CHAR) {
	        if (++len>=UCNV_MAX_CONVERTER_NAME_LENGTH) {
	            err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;    /* bad name */
	            return;
	        }
	        //cnvName.charAt(cnvNameIndex++)=c;
	        cnvName.append(c);
	        inNameIndex++;
	    }
	
	    /* parse options. No more name copying should occur. */
	    while((c=inName.charAt(inNameIndex))!=0) {
	        if(c==UCNV_OPTION_SEP_CHAR) {
	            ++inNameIndex;
	        }
	
	        /* inName is behind an option separator */
	        if(UConverterUtility.uprv_strncmp(inName.getBytes(), inNameIndex, "locale=", 7)==0) {
	            /* do not modify locale itself in case we have multiple locale options */
	            StringBuffer dest=locale;
	
	            /* copy the locale option value */
	            inNameIndex+=7;
	            len=0;
	            while((c=inName.charAt(inNameIndex))!=0 && c!=UCNV_OPTION_SEP_CHAR) {
	                ++inNameIndex;
	
	                if(++len>=ULOC_FULLNAME_CAPACITY) {
	                    err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;    /* bad name */
											locale.delete(0, locale.length());
	                    return;
	                }
	
									dest.append(c);
	            }
	            //agljport:delete *dest=0;
	        } else if(UConverterUtility.uprv_strncmp(inName.getBytes(), inNameIndex, "version=", 8)==0) {
	            /* copy the version option value into bits 3..0 of *pFlags */
	            inNameIndex+=8;
	            c=inName.charAt(inNameIndex);
	            if(c==0) {
	                pFlags[0]&=~UCNV_OPTION_VERSION;
	                return;
	            } else if(((char)c-'0')<10 && ((char)c-'0') >= 0) {
	                pFlags[0]=(pFlags[0]&~UCNV_OPTION_VERSION)|(int)((char)c-'0');
	                ++inNameIndex;
	            }
	        } else if(UConverterUtility.uprv_strncmp(inName.getBytes(), inNameIndex, "swaplfnl", 8)==0) {
	            inNameIndex+=8;
	            pFlags[0]|=UCNV_OPTION_SWAP_LFNL;
	        } else if(UConverterUtility.uprv_strncmp(inName.getBytes(), inNameIndex, "mac", 3)==0) {
	            inNameIndex+=3;
	            pFlags[0]|=UCNV_OPTION_MAC;
	        /* add processing for new options here with another else if(uprv_strncmp(inName, "option-name=", XX)==0) */
	        } else {
	            /* ignore any other options until we define some */
	            while(((c = inName.charAt(inNameIndex++)) != 0) && (c != UCNV_OPTION_SEP_CHAR)) {
	            }
	            if(c==0) {
	                return;
	            }
	        }
	    }
	}

	// void ucnv_unloadSharedDataIfReady(UConverterSharedData *sharedData)
	public static final void ucnv_unloadSharedDataIfReady(UConverterSharedData sharedData)
	{
	    /*
	    Checking whether it's an algorithic converter is okay
	    in multithreaded applications because the value never changes.
	    Don't check referenceCounter for any other value.
	    */
	    if(sharedData != null && sharedData.referenceCounter != ~0) {
	        //agljport:todo umtx_lock(&cnvCacheMutex);
	        ucnv_unload(sharedData);
	        //agljport:todo umtx_unlock(&cnvCacheMutex);
	    }
	}

	/**
	 * Unload a non-algorithmic converter.
	 * It must be sharedData->referenceCounter != ~0
	 * and this function must be called inside umtx_lock(&cnvCacheMutex).
	 */
	// void ucnv_unload(UConverterSharedData *sharedData)
	static final void ucnv_unload(UConverterSharedData sharedData)
	{
	    if(sharedData != null) {
	        if (sharedData.referenceCounter > 0) {
	            sharedData.referenceCounter--;
	        }
	
	        if((sharedData.referenceCounter <= 0)&&(sharedData.sharedDataCached == false)) {
	            //agljport:fix ucnv_deleteSharedConverterData(sharedData);
	        }
	    }
	}

	/*Decreases the reference counter in the shared immutable section of the object
	 *and frees the mutable part*/

	//U_CAPI void  U_EXPORT2 ucnv_close (UConverter * converter)
	public final void  ucnv_close ()
	{
	    /* first, notify the callback functions that the converter is closed */
	    UConverterToUnicodeArgs toUArgs = new UConverterToUnicodeArgs(
	        //agljport:delete sizeof(UConverterToUnicodeArgs),
	            true,
	            null,
	            null, 0, 0,
	            null, 0, 0,
	            null, 0
	    );
	    UConverterFromUnicodeArgs fromUArgs = new UConverterFromUnicodeArgs(
	        //agljport:delete sizeof(UConverterFromUnicodeArgs),
	            true,
	            null,
	            null, 0, 0,
	            null, 0, 0,
	            null, 0
	    );
	    int[] errorCode = new int[1]; errorCode[0] = ErrorCode.U_ZERO_ERROR;
	
	    //agljport:todo UTRACE_ENTRY_OC(UTRACE_UCNV_CLOSE);
	
			/*agljport:delete
	    if (converter == null)
	    {
	        UTRACE_EXIT();
	        return;
	    }
			*/
	
	    //agljport:todo UTRACE_DATA3(UTRACE_OPEN_CLOSE, "close converter %s at %p, isCopyLocal=%b", ucnv_getName(converter, &errorCode), converter, converter->isCopyLocal);
	
	    toUArgs.converter = fromUArgs.converter = this;
	
	    fromCharErrorBehaviour.call(toUContextArray, toUArgs, null, 0, 0, UConverterCallbackReason.UCNV_CLOSE, errorCode);
	    errorCode[0] = ErrorCode.U_ZERO_ERROR;
	    fromUCharErrorBehaviour.call(fromUContextArray, fromUArgs, null, 0, 0, 0, UConverterCallbackReason.UCNV_CLOSE, errorCode);
	
	    //agljport:delete if (converter.sharedData.impl.close != NULL) {
	        sharedData.close(this);
	    //agljport:delete }
	
	    /*
	    Checking whether it's an algorithic converter is okay
	    in multithreaded applications because the value never changes.
	    Don't check referenceCounter for any other value.
	    */
	    if (sharedData.referenceCounter != ~0) {
	        ucnv_unloadSharedDataIfReady(sharedData);
	    }
	
	    //agljport:delete if(!converter.isCopyLocal){ uprv_free (converter); }
	
	    //agljport:todo UTRACE_EXIT();
	}

	/**
	 * Callback function for udata_openChoice().
	 * @param context parameter passed into <code>udata_openChoice()</code>.
	 * @param type The type of the data as passed into <code>udata_openChoice()</code>.
	 *             It may be <code>NULL</code>.
	 * @param name The name of the data as passed into <code>udata_openChoice()</code>.
	 * @param pInfo A pointer to the <code>UDataInfo</code> structure
	 *              of data that has been loaded and will be returned
	 *              by <code>udata_openChoice()</code> if this function
	 *              returns <code>TRUE</code>.
	 * @return TRUE if the current data memory is acceptable
	 * @stable ICU 2.0
	 */
	//typedef UBool U_CALLCONV UDataMemoryIsAcceptable(void *context, const char *type, const char *name, const UDataInfo *pInfo);
	interface UDataMemoryIsAcceptable {
		boolean call(byte[] context, byte[] type, byte[] name, UDataInfo pInfo);
	}

	/**
	 * Selectors for Unicode sets that can be returned by ucnv_getUnicodeSet().
	 * @see ucnv_getUnicodeSet
	 * @stable ICU 2.6
	 */
	class UConverterUnicodeSet {
	    /** Select the set of roundtrippable Unicode code points. @stable ICU 2.6 */
	    public static final int UCNV_ROUNDTRIP_SET = 0;
	    /** Number of UConverterUnicodeSet selectors. @stable ICU 2.6 */
	    public static final int UCNV_SET_COUNT = UCNV_ROUNDTRIP_SET + 1;
	}

	//typedef void U_CALLCONV USetAdd(USet *set, UChar32 c);
	interface USetAdd {
		//void call(USet *set, UChar32 c);
	}
	
	//typedef void U_CALLCONV USetAddRange(USet *set, UChar32 start, UChar32 end);
	interface USetAddRange {
		//void call(USet *set, UChar32 start, UChar32 end);
	}
	
	//typedef void U_CALLCONV USetAddString(USet *set, const UChar *str, int32_t length);
	interface USetAddString {
	}

	/**
	 * Interface for adding items to a USet, to keep low-level code from
	 * statically depending on the USet implementation.
	 * Calls will look like sa->add(sa->set, c);
	 */
	class USetAdder {
	    //USet set;
	    USetAdd add;
	    USetAddRange addRange;
	    USetAddString addString;
	}

	//ucnv_cb.c

	// begin ucnv.c
	//U_CAPI void    U_EXPORT2 ucnv_setToUCallBack (UConverter * converter, UConverterToUCallback newAction, const void* newContext, UConverterToUCallback *oldAction, const void** oldContext, UErrorCode * err)
	public void ucnv_setToUCallBack (UConverterCallback.UConverterToUCallback newAction, byte[] newContext, UConverterCallback.UConverterToUCallback[] oldAction, byte[][] oldContext, int[] err)
	{
	    if(ErrorCode.isFailure(err[0]))
	        return;
	    if (oldAction != null) oldAction[0] = fromCharErrorBehaviour;
	    fromCharErrorBehaviour = newAction;
	    if (oldContext != null) oldContext[0] = toUContextArray;
	    toUContextArray = newContext;
	}

	//U_CAPI void  U_EXPORT2 ucnv_setFromUCallBack (UConverter * converter, UConverterFromUCallback newAction, const void* newContext, UConverterFromUCallback *oldAction, const void** oldContext, UErrorCode * err)
	public void ucnv_setFromUCallBack (UConverterCallback.UConverterFromUCallback newAction, byte[] newContext, UConverterCallback.UConverterFromUCallback[] oldAction, byte[][] oldContext, int[] err)
	{
	    if (ErrorCode.isFailure(err[0]))
	        return;
	    if (oldAction != null) oldAction[0] = fromUCharErrorBehaviour;
	    fromUCharErrorBehaviour = newAction;
	    if (oldContext != null) oldContext[0] = fromUContextArray;
	    fromUContextArray = newContext;
	}	
	
	// end ucnv.c

	//ucnv_cnv.c

	/* ucnv_fromUnicode --------------------------------------------------------- */
	
	/*
	 * Implementation note for m:n conversions
	 *
	 * While collecting source units to find the longest match for m:n conversion,
	 * some source units may need to be stored for a partial match.
	 * When a second buffer does not yield a match on all of the previously stored
	 * source units, then they must be "replayed", i.e., fed back into the converter.
	 *
	 * The code relies on the fact that replaying will not nest -
	 * converting a replay buffer will not result in a replay.
	 * This is because a replay is necessary only after the _continuation_ of a
	 * partial match failed, but a replay buffer is converted as a whole.
	 * It may result in some of its units being stored again for a partial match,
	 * but there will not be a continuation _during_ the replay which could fail.
	 *
	 * It is conceivable that a callback function could call the converter
	 * recursively in a way that causes another replay to be stored, but that
	 * would be an error in the callback function.
	 * Such violations will cause assertion failures in a debug build,
	 * and wrong output, but they will not cause a crash.
	 */
	
	//static void _fromUnicodeWithCallback(UConverterFromUnicodeArgs *pArgs, UErrorCode *err)
	final void _fromUnicodeWithCallback(UConverterFromUnicodeArgs pArgs, int[] err)
	{
	    //agljport:delete UConverterFromUnicode fromUnicode;
	    //agljport:delete UConverter cnv;
	    char[] sArray;
		int sArrayIndex;
		byte[] tArray;
		int tArrayIndex;
		int[] offsetsArray;
	    int offsetsArrayIndex;
	    int sourceIndex;
	    int errorInputLength;
	    boolean converterSawEndOfInput, calledCallback;

	    /* variables for m:n conversion */
	    char[] replayArray = new char[UConverterExt.UCNV_EXT_MAX_UCHARS];
		int replayArrayIndex = 0;
	    char[] realSourceArray; int realSourceArrayIndex = 0; int realSourceLimit;
	    boolean realFlush;
		int realSourceIndex;

	    //agljport:delete cnv=pArgs->converter;
			sArray=pArgs.sourceArray;
	    sArrayIndex=pArgs.sourceBegin;
	    tArray=pArgs.targetArray;
	    tArrayIndex=pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	
	    /* get the converter implementation function */
	    sourceIndex=0;
	    if(offsetsArray==null) {
	        //agljport:todo fromUnicode=cnv->sharedData->impl->fromUnicode;
	    } else {
	        //agljport:todo fromUnicode=cnv->sharedData->impl->fromUnicodeWithOffsets;
	        //agljport:todo if(fromUnicode==NULL) {
	            /* there is no WithOffsets implementation */
	            //agljport:todo fromUnicode=cnv->sharedData->impl->fromUnicode;
	            /* we will write -1 for each offset */
	            //agljport:todo sourceIndex=-1;
	        //agljport:todo }
	    }

	    if(preFromULength>=0) {
	        /* normal mode */
	        realSourceArray=null;
	
	        /* avoid compiler warnings - not otherwise necessary, and the values do not matter */
	        realSourceLimit=0;
	        realFlush=false;
	        realSourceIndex=0;
	    } else {
	        /*
	         * Previous m:n conversion stored source units from a partial match
	         * and failed to consume all of them.
	         * We need to "replay" them from a temporary buffer and convert them first.
	         */
	        realSourceArray=pArgs.sourceArray;
			realSourceArrayIndex = pArgs.sourceBegin;
	        realSourceLimit=pArgs.sourceLimit;
	        realFlush=pArgs.flush;
	        realSourceIndex=sourceIndex;
	
	        UConverterUtility.uprv_memcpy(replayArray, replayArrayIndex, preFromUArray, 0, -preFromULength*UMachine.U_SIZEOF_UCHAR);
	        pArgs.sourceArray=replayArray;
			pArgs.sourceBegin=replayArrayIndex;
	        pArgs.sourceLimit=replayArrayIndex-preFromULength; //preFromULength is negative, see declaration
	        pArgs.flush=false;
	        sourceIndex=-1;
	
	        preFromULength=0;
	    }

	    /*
	     * loop for conversion and error handling
	     *
	     * loop {
	     *   convert
	     *   loop {
	     *     update offsets
	     *     handle end of input
	     *     handle errors/call callback
	     *   }
	     * }
	     */
	    for(;;) {
	        /* convert */
				sharedData.fromUnicode(pArgs, err);
	        /*
	         * set a flag for whether the converter
	         * successfully processed the end of the input
	         *
	         * need not check cnv.preFromULength==0 because a replay (<0) will cause
	         * s<sourceLimit before converterSawEndOfInput is checked
	         */
	        converterSawEndOfInput= (boolean)(ErrorCode.isSuccess(err[0]) && pArgs.flush && pArgs.sourceBegin==pArgs.sourceLimit && fromUChar32==0);
	
	        /* no callback called yet for this iteration */
	        calledCallback=false;
	
	        /* no sourceIndex adjustment for conversion, only for callback output */
	        errorInputLength=0;

	        /*
	         * loop for offsets and error handling
	         *
	         * iterates at most 3 times:
	         * 1. to clean up after the conversion function
	         * 2. after the callback
	         * 3. after the callback again if there was truncated input
	         */
        	for(;;) {
	            /* update offsets if we write any */
	            if(offsetsArray!=null) {
	                int length=(int)(pArgs.targetBegin-tArrayIndex);
	                if(length>0) {
	                    //agljport:todo _updateOffsets(offsetsArray, offsetsArrayIndex, length, sourceIndex, errorInputLength);
	
	                    /*
	                     * if a converter handles offsets and updates the offsets
	                     * pointer at the end, then pArgs->offset should not change
	                     * here;
	                     * however, some converters do not handle offsets at all
	                     * (sourceIndex<0) or may not update the offsets pointer
	                     */
	                    pArgs.offsetsBegin=offsetsArrayIndex+=length;
	                }
	
	                if(sourceIndex>=0) {
	                    sourceIndex+=(int)(pArgs.sourceBegin-sArrayIndex);
	                }
	            }

	            if(preFromULength<0) {
	                /*
	                 * switch the source to new replay units (cannot occur while replaying)
	                 * after offset handling and before end-of-input and callback handling
	                 */
	                if(realSourceArray==null) {
	                    realSourceArray=pArgs.sourceArray;
											realSourceArrayIndex=pArgs.sourceBegin;
	                    realSourceLimit=pArgs.sourceLimit;
	                    realFlush=pArgs.flush;
	                    realSourceIndex=sourceIndex;
	
	                    UConverterUtility.uprv_memcpy(replayArray, replayArrayIndex, preFromUArray, 0, -preFromULength*UMachine.U_SIZEOF_UCHAR);
	                    pArgs.sourceArray=replayArray;
						pArgs.sourceBegin=replayArrayIndex;
	                    pArgs.sourceLimit=replayArrayIndex-preFromULength;
	                    pArgs.flush=false;
	                    if((sourceIndex+=preFromULength)<0) {
	                        sourceIndex=-1;
	                    }
	
	                    preFromULength=0;
	                } else {
	                    /* see implementation note before _fromUnicodeWithCallback() */
	                    //agljport:todo U_ASSERT(realSource==NULL);
	                    err[0]=ErrorCode.U_INTERNAL_PROGRAM_ERROR;
	                }
	            }

	            /* update pointers */
	            sArray=pArgs.sourceArray; // agljport:note needed?
	            sArrayIndex=pArgs.sourceBegin;
	            tArray=pArgs.targetArray; // agljport:note needed?
	            tArrayIndex=pArgs.targetBegin;
	
	            if(ErrorCode.isSuccess(err[0])) {
	                if(sArrayIndex<pArgs.sourceLimit) {
	                    /*
	                     * continue with the conversion loop while there is still input left
	                     * (continue converting by breaking out of only the inner loop)
	                     */
	                    break;
	                } else if(realSourceArray!=null) {
	                    /* switch back from replaying to the real source and continue */
	                    pArgs.sourceArray=realSourceArray;
	                    pArgs.sourceBegin=realSourceArrayIndex;
	                    pArgs.sourceLimit=realSourceLimit;
	                    pArgs.flush=realFlush;
	                    sourceIndex=realSourceIndex;
	
	                    realSourceArray=null;
	                    break;
	                } else if(pArgs.flush && fromUChar32!=0) {
	                    /*
	                     * the entire input stream is consumed
	                     * and there is a partial, truncated input sequence left
	                     */
	
	                    /* inject an error and continue with callback handling */
	                    err[0]=ErrorCode.U_TRUNCATED_CHAR_FOUND;
	                    calledCallback=false; /* new error condition */
	                } else {
	                    /* input consumed */
	                    if(pArgs.flush) {
	                        /*
	                         * return to the conversion loop once more if the flush
	                         * flag is set and the conversion function has not
	                         * successfully processed the end of the input yet
	                         *
	                         * (continue converting by breaking out of only the inner loop)
	                         */
	                        if(!converterSawEndOfInput) {
	                            break;
	                        }
	
	                        /* reset the converter without calling the callback function */
	                        _reset(UConverterResetChoice.UCNV_RESET_FROM_UNICODE, false);
	                    }
	
	                    /* done successfully */
	                    return;
	                }
	            }

	            /* U_FAILURE(*err) */
	            {
	                int e;
	
	                if( calledCallback ||
	                    (e=err[0])==ErrorCode.U_BUFFER_OVERFLOW_ERROR ||
	                    (e!=ErrorCode.U_INVALID_CHAR_FOUND &&
	                     e!=ErrorCode.U_ILLEGAL_CHAR_FOUND &&
	                     e!=ErrorCode.U_TRUNCATED_CHAR_FOUND)
	                ){
	                    /*
	                     * the callback did not or cannot resolve the error:
	                     * set output pointers and return
	                     *
	                     * the check for buffer overflow is redundant but it is
	                     * a high-runner case and hopefully documents the intent
	                     * well
	                     *
	                     * if we were replaying, then the replay buffer must be
	                     * copied back into the UConverter
	                     * and the real arguments must be restored
	                     */
	                    if(realSourceArray!=null) {
	                        int length;
	
	                        //agljport:todo U_ASSERT(cnv.preFromULength==0);
	
	                        length=(int)(pArgs.sourceLimit-pArgs.sourceBegin);
	                        if(length>0) {
	                            UConverterUtility.uprv_memcpy(preFromUArray, 0, pArgs.sourceArray, pArgs.sourceBegin, length*UMachine.U_SIZEOF_UCHAR);
	                            preFromULength=(byte)-length;
	                        }
	
	                        pArgs.sourceArray=realSourceArray;
							pArgs.sourceBegin=realSourceArrayIndex;
	                        pArgs.sourceLimit=realSourceLimit;
	                        pArgs.flush=realFlush;
	                    }
	
	                    return;
	                }
	            }

	            /* callback handling */
	            {
	                int codePoint;
	
	                /* get and write the code point */
	                codePoint=fromUChar32;
	                errorInputLength=0;
									int I[] = new int[]{errorInputLength};
	                UConverterUTF16.U16_APPEND_UNSAFE(invalidUCharBufferArray, I, codePoint);
									errorInputLength = I[0];
	                invalidUCharLength=(byte)errorInputLength;
	
	                /* set the converter state to deal with the next character */
	                fromUChar32=0;
	
	                /* call the callback function */
	                fromUCharErrorBehaviour.call(fromUContextArray, pArgs, invalidUCharBufferArray, invalidUCharBufferBegin, errorInputLength, codePoint, err[0]==ErrorCode.U_INVALID_CHAR_FOUND ? UConverterCallbackReason.UCNV_UNASSIGNED : UConverterCallbackReason.UCNV_ILLEGAL, err);
	            }
	
	            /*
	             * loop back to the offset handling
	             *
	             * this flag will indicate after offset handling
	             * that a callback was called;
	             * if the callback did not resolve the error, then we return
	             */
	            calledCallback=true;
        	}
		}
	}

	//U_CAPI void U_EXPORT2 ucnv_fromUnicode(UConverter *cnv, char **target, const char *targetLimit, const UChar **source, const UChar *sourceLimit, int32_t *offsets, UBool flush, UErrorCode *err)
	public final void ucnv_fromUnicode(byte[] targetArray, int[] targetBegin, int targetLimit, char[] sourceArray, int[] sourceBegin, int sourceLimit, /*int32_t *offsets,*/ boolean flush, int[] err) 
	{
		// offsets array parameter is not supported in ICU4JNI
		int[] offsetsArray = null;
		int offsetsArrayIndex = 0;
	    UConverterFromUnicodeArgs args = new UConverterFromUnicodeArgs();
	    char[] sArray;
	    int sArrayIndex;
	    byte[] tArray;
	    int tArrayIndex;
	
	    /* check parameters */
	    if(err==null || ErrorCode.isFailure(err[0])) {
	        return;
	    }
	
	    if(targetArray==null || sourceArray==null) {
	        err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	
		sArray=sourceArray;
	    sArrayIndex=sourceBegin[0];
		tArray=targetArray;
	    tArrayIndex=targetBegin[0];
	    if(sourceLimit<sArrayIndex || targetLimit<tArrayIndex) {
	        err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	
	    /*
	     * Make sure that the buffer sizes do not exceed the number range for
	     * int32_t because some functions use the size (in units or bytes)
	     * rather than comparing pointers, and because offsets are int32_t values.
	     *
	     * size_t is guaranteed to be unsigned and large enough for the job.
	     *
	     * Return with an error instead of adjusting the limits because we would
	     * not be able to maintain the semantics that either the source must be
	     * consumed or the target filled (unless an error occurs).
	     * An adjustment would be targetLimit=t+0x7fffffff; for example.
	     */
	    if( ((long)(sourceLimit-sArrayIndex)>(long)0x3fffffff && sourceLimit>sArrayIndex) || ((long)(targetLimit-tArrayIndex)>(long)0x7fffffff && targetLimit>tArrayIndex)) {
	        err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    
	    /* flush the target overflow buffer */
	    if(charErrorBufferLength>0) {
	        byte[] overflowArray;
					int overflowArrayIndex;
	        int i, length;
	
	        overflowArray=charErrorBufferArray;
					overflowArrayIndex=charErrorBufferBegin;
	        length=charErrorBufferLength;
	        i=0;
	        do {
	            if(tArrayIndex==targetLimit) {
	                /* the overflow buffer contains too much, keep the rest */
	                int j=0;
	
	                do {
	                    overflowArray[j++]=overflowArray[i++];
	                } while(i<length);
	
	                charErrorBufferLength=(byte)j;
	                targetBegin[0]=tArrayIndex;
	                err[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                return;
	            }
	
	            /* copy the overflow contents to the target */
	            tArray[tArrayIndex++]=overflowArray[i++];
	            if(offsetsArray!=null) {
	                offsetsArray[offsetsArrayIndex++]=-1; /* no source index available for old output */
	            }
	        } while(i<length);
	
	        /* the overflow buffer is completely copied to the target */
	        charErrorBufferLength=0;
	    }
	
	    if(!flush && sArrayIndex==sourceLimit && preFromULength>=0) {
	        /* the overflow buffer is emptied and there is no new input: we are done */
	        targetBegin[0]=tArrayIndex;
	        return;
	    }
	
	    /*
	     * Do not simply return with a buffer overflow error if
	     * !flush && t==targetLimit
	     * because it is possible that the source will not generate any output.
	     * For example, the skip callback may be called;
	     * it does not output anything.
	     */
	
	    /* prepare the converter arguments */
		args.converter=this;
	    args.flush=flush;
	    args.offsetsArray=offsetsArray;
		args.offsetsBegin=offsetsArrayIndex;
	    args.sourceArray=sArray;
		args.sourceBegin = sArrayIndex;
	    args.sourceLimit=sourceLimit;
	    args.targetArray=tArray;
	    args.targetBegin=tArrayIndex;
	    args.targetLimit=targetLimit;
	    //agljport:delete args.size=sizeof(args);
	
	    _fromUnicodeWithCallback(args, err);
	
	    sourceBegin[0]=args.sourceBegin;
	    targetBegin[0]=args.targetBegin;
	}

	//U_CFUNC void ucnv_toUWriteCodePoint(UConverter *cnv, UChar32 c, UChar **target, UChar *targetLimit, int32_t **offsets, int32_t sourceIndex, UErrorCode *pErrorCode)
	public final void ucnv_toUWriteCodePoint(int c, char[] targetArray, int[] targetBegin, int targetLimit, int[] offsetsArray, int[]offsetsBegin, int sourceIndex, int[] pErrorCode) 
	{
	    char[] tArray;
		int tIndex;
	    int[] oArray;
		int oIndex;
	
	    tArray=targetArray;
		tIndex = targetBegin[0];
	
	    if(tIndex<targetLimit) {
	        if(c<=0xffff) {
	            tArray[tIndex++]=(char)c;
	            c=U_SENTINEL;
	        } else /* c is a supplementary code point */ {
	            tArray[tIndex++]=UConverterUTF16.U16_LEAD(c);
	            c=UConverterUTF16.U16_TRAIL(c);
	            if(tIndex<targetLimit) {
	                tArray[tIndex++]=(char)c;
	                c=U_SENTINEL;
	            }
	        }
	
	        /* write offsets */
					oIndex = offsetsBegin[0];
	        if((oArray=offsetsArray)!=null) {
	            oArray[oIndex++]=sourceIndex;
	            if((targetBegin[0]+1)<tIndex) {
	                oArray[oIndex++]=sourceIndex;
	            }
	            offsetsBegin[0]=oIndex;
	        }
	    }
	
	    targetBegin[0]=tIndex;
	
	    /* write overflow from c */
	    if(c>=0) {
	        //agljport:delete if(cnv!=null) {
	        int i=0;
			//int[] I = new int[]{i};
			int[] I = {i};
	        UConverterUTF16.U16_APPEND_UNSAFE(UCharErrorBufferArray, I, c);
			i = I[0];
	        UCharErrorBufferLength=(byte)i;
	        //agljport:delete }
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	}
	
	//U_CAPI int8_t   U_EXPORT2 ucnv_getMaxCharSize (const UConverter * converter)
	public int ucnv_getMaxCharSize()
	{
	    return maxBytesPerUChar;
	}
	
	public int ucnv_getMinCharSize()
	{
	    return sharedData.staticData.minBytesPerChar;
	}
	
	//U_CAPI void  U_EXPORT2 ucnv_resetToUnicode(UConverter *converter)
	public void ucnv_resetToUnicode()
	{
	    _reset(UConverterResetChoice.UCNV_RESET_TO_UNICODE, true);
	}
	
	//U_CAPI void  U_EXPORT2 ucnv_resetFromUnicode(UConverter *converter)
	public void ucnv_resetFromUnicode()
	{
	    _reset(UConverterResetChoice.UCNV_RESET_FROM_UNICODE, true);
	}
	
	/*resets the internal states of a converter
	 *goal : have the same behaviour than a freshly created converter
	 */
	//static void _reset(UConverter *converter, UConverterResetChoice choice, UBool callCallback)
	void _reset(int choice, boolean callCallback)
	{
	    /*agljport:delete
			if(converter == NULL) {
	        return;
	    }
			*/
	
	    if(callCallback) {
	        /* first, notify the callback functions that the converter is reset */
	        UConverterToUnicodeArgs toUArgs = new UConverterToUnicodeArgs( 
	            //agljport:delete sizeof(UConverterToUnicodeArgs),
	                true,
	                null,
	                null, 0, 0,
	                null, 0, 0,
	                null, 0
	        );
	        UConverterFromUnicodeArgs fromUArgs = new UConverterFromUnicodeArgs( 
	            //agljport:delete sizeof(UConverterFromUnicodeArgs),
	                true,
	                null,
	                null, 0, 0,
	                null, 0, 0,
	                null, 0
	        );
					int[] errorCode = new int[1]; errorCode[0] = ErrorCode.U_ZERO_ERROR;
	
	
	        toUArgs.converter = fromUArgs.converter = this;
	        if(choice<=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	            errorCode[0] = ErrorCode.U_ZERO_ERROR;
	            fromCharErrorBehaviour.call(toUContextArray, toUArgs, null, 0, 0, UConverterCallbackReason.UCNV_RESET, errorCode);
	        }
	        if(choice!=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	            errorCode[0] = ErrorCode.U_ZERO_ERROR;
	            fromUCharErrorBehaviour.call(fromUContextArray, fromUArgs, null, 0, 0, 0, UConverterCallbackReason.UCNV_RESET, errorCode);
	        }
	    }
	
	    /* now reset the converter itself */
			/*agljport:change
	    if(choice<=UCNV_RESET_TO_UNICODE) {
	        converter->toUnicodeStatus = converter->sharedData->toUnicodeStatus;
	        converter->mode = 0;
	        converter->toULength = 0;
	        converter->invalidCharLength = converter->UCharErrorBufferLength = 0;
	        converter->preToULength = 0;
	    }
	    if(choice!=UCNV_RESET_TO_UNICODE) {
	        converter->fromUnicodeStatus = 0;
	        converter->fromUChar32 = 0;
	        converter->invalidUCharLength = converter->charErrorBufferLength = 0;
	        converter->preFromUFirstCP = U_SENTINEL;
	        converter->preFromULength = 0;
	    }
	
	    if (converter->sharedData->impl->reset != NULL) {
	        converter->sharedData->impl->reset(converter, choice);
	    }
			*/
	    if(choice<=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        toUnicodeStatus = sharedData.toUnicodeStatus;
	        mode = 0;
	        toULength = 0;
	        invalidCharLength = UCharErrorBufferLength = 0;
	        preToULength = 0;
	    }
	    if(choice!=UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        fromUnicodeStatus = 0;
	        fromUChar32 = 0;
	        invalidUCharLength = charErrorBufferLength = 0;
	        preFromUFirstCP = U_SENTINEL;
	        preFromULength = 0;
	    }
	
	        /* call the custom reset function */
	        sharedData.reset(this, choice);
	}

	/* ucnv_toUnicode() --------------------------------------------------------- */

	//static void _toUnicodeWithCallback(UConverterToUnicodeArgs *pArgs, UErrorCode *err)
	void _toUnicodeWithCallback(UConverterToUnicodeArgs pArgs, int[] err)
	{
	    //agljport:delete UConverterToUnicode toUnicode;
	    //agljport:delete UConverter cnv;
	    int s;
	    int t;
	    int[] offsets;
	    int sourceIndex;
	    int errorInputLength;
	    boolean converterSawEndOfInput, calledCallback;
	
	    /* variables for m:n conversion */
	    byte replayArray[] = new byte[UConverterExt.UCNV_EXT_MAX_BYTES];
			int replayBegin = 0;
			
	    byte[] realSourceArray;
	    int realSourceBegin = 0, realSourceLimit;
	    int realSourceIndex;
	    boolean realFlush;
	
	    //agljport:delete cnv=pArgs->converter;
	    s=pArgs.sourceBegin;
	    t=pArgs.targetBegin;
	    offsets=pArgs.offsetsArray;
	
	    /* get the converter implementation function */
	    sourceIndex=0;
	    if(offsets==null) {
	        //agljport:todo toUnicode=cnv->sharedData->impl->toUnicode;
	    } else {
	        //agljport:todo toUnicode=cnv->sharedData->impl->toUnicodeWithOffsets;
	        //agljport:todo if(toUnicode==NULL) {
	            /* there is no WithOffsets implementation */
	            //agljport:todo toUnicode=cnv->sharedData->impl->toUnicode;
	            /* we will write -1 for each offset */
	            //agljport:todo sourceIndex=-1;
	        //agljport:todo }
	    }
	
	    if(preToULength>=0) {
	        /* normal mode */
	        realSourceArray=null;
	
	        /* avoid compiler warnings - not otherwise necessary, and the values do not matter */
	        realSourceLimit=0;
	        realFlush=false;
	        realSourceIndex=0;
	    } else {
	        /*
	         * Previous m:n conversion stored source units from a partial match
	         * and failed to consume all of them.
	         * We need to "replay" them from a temporary buffer and convert them first.
	         */
	        realSourceArray=pArgs.sourceArray;
					realSourceBegin = pArgs.sourceBegin;
	        realSourceLimit=pArgs.sourceLimit;
	        realFlush=pArgs.flush;
	        realSourceIndex=sourceIndex;
	
	        UConverterUtility.uprv_memcpy(replayArray, replayBegin, preToUArray, preToUBegin, -preToULength);
	        pArgs.sourceArray=replayArray;
					pArgs.sourceBegin = replayBegin;
	        pArgs.sourceLimit=replayBegin-preToULength;
	        pArgs.flush=false;
	        sourceIndex=-1;
	
	        preToULength=0;
	    }
	
	    /*
	     * loop for conversion and error handling
	     *
	     * loop {
	     *   convert
	     *   loop {
	     *     update offsets
	     *     handle end of input
	     *     handle errors/call callback
	     *   }
	     * }
	     */
	    for(;;) {
	        if(ErrorCode.isSuccess(err[0])) {
	            /* convert */
							sharedData.toUnicode(pArgs, err);
	
	            /*
	             * set a flag for whether the converter
	             * successfully processed the end of the input
	             *
	             * need not check cnv->preToULength==0 because a replay (<0) will cause
	             * s<sourceLimit before converterSawEndOfInput is checked
	             */
	            converterSawEndOfInput= (ErrorCode.isSuccess(err[0]) && pArgs.flush && pArgs.sourceBegin==pArgs.sourceLimit && toULength==0);
	        } else {
	            /* handle error from getNextUChar() */
	            converterSawEndOfInput=false;
	        }
	
	        /* no callback called yet for this iteration */
	        calledCallback=false;
	
	        /* no sourceIndex adjustment for conversion, only for callback output */
	        errorInputLength=0;
	
	        /*
	         * loop for offsets and error handling
	         *
	         * iterates at most 3 times:
	         * 1. to clean up after the conversion function
	         * 2. after the callback
	         * 3. after the callback again if there was truncated input
	         */
	        for(;;) {
	            /* update offsets if we write any */
	            if(offsets!=null) {
								/*agljport:todo
	                int32_t length=(int32_t)(pArgs->target-t);
	                if(length>0) {
	                    _updateOffsets(offsets, length, sourceIndex, errorInputLength);
	
											*/
	                    /*
	                     * if a converter handles offsets and updates the offsets
	                     * pointer at the end, then pArgs->offset should not change
	                     * here;
	                     * however, some converters do not handle offsets at all
	                     * (sourceIndex<0) or may not update the offsets pointer
	                     */
	                    /*agljport:todo 
											pArgs->offsets=offsets+=length;
	                }
	
	                if(sourceIndex>=0) {
	                    sourceIndex+=(int32_t)(pArgs->source-s);
	                }
									*/
	            }
	
	            if(preToULength<0) {
	                /*
	                 * switch the source to new replay units (cannot occur while replaying)
	                 * after offset handling and before end-of-input and callback handling
	                 */
	                if(realSourceArray==null)
									{
	                    realSourceArray=pArgs.sourceArray;
	                    realSourceBegin=pArgs.sourceBegin;
	                    realSourceLimit=pArgs.sourceLimit;
	                    realFlush=pArgs.flush;
	                    realSourceIndex=sourceIndex;
	
	                    UConverterUtility.uprv_memcpy(replayArray, replayBegin, preToUArray, preToUBegin, -preToULength);
	                    pArgs.sourceArray=replayArray;
	                    pArgs.sourceLimit=replayBegin-preToULength;
	                    pArgs.flush=false;
	                    if((sourceIndex+=preToULength)<0) {
	                        sourceIndex=-1;
	                    }
	
	                    preToULength=0;
	                } else {
	                    /* see implementation note before _fromUnicodeWithCallback() */
	                    //agljport:todo U_ASSERT(realSource==NULL);
	                    err[0]=ErrorCode.U_INTERNAL_PROGRAM_ERROR;
	                }
	            }
	
	            /* update pointers */
	            s=pArgs.sourceBegin;
	            t=pArgs.targetBegin;
	
	            if(ErrorCode.isSuccess(err[0])) {
	                if(s<pArgs.sourceLimit)
									{
	                    /*
	                     * continue with the conversion loop while there is still input left
	                     * (continue converting by breaking out of only the inner loop)
	                     */
	                    break;
	                } else if(realSourceArray!=null) {
	                    /* switch back from replaying to the real source and continue */
	                    pArgs.sourceBegin=realSourceBegin;
	                    pArgs.sourceLimit=realSourceLimit;
	                    pArgs.flush=realFlush;
	                    sourceIndex=realSourceIndex;
	
	                    realSourceArray=null;
	                    break;
	                } else if(pArgs.flush && toULength>0) {
	                    /*
	                     * the entire input stream is consumed
	                     * and there is a partial, truncated input sequence left
	                     */
	
	                    /* inject an error and continue with callback handling */
	                    err[0]=ErrorCode.U_TRUNCATED_CHAR_FOUND;
	                    calledCallback=false; /* new error condition */
	                } else {
	                    /* input consumed */
	                    if(pArgs.flush) {
	                        /*
	                         * return to the conversion loop once more if the flush
	                         * flag is set and the conversion function has not
	                         * successfully processed the end of the input yet
	                         *
	                         * (continue converting by breaking out of only the inner loop)
	                         */
	                        if(!converterSawEndOfInput) {
	                            break;
	                        }
	
	                        /* reset the converter without calling the callback function */
	                        _reset(UConverterResetChoice.UCNV_RESET_TO_UNICODE, false);
	                    }
	
	                    /* done successfully */
	                    return;
	                }
	            }
	
	            /* U_FAILURE(*err) */
	            {
	                int e;
	
	                if( calledCallback ||
	                    (e=err[0])==ErrorCode.U_BUFFER_OVERFLOW_ERROR ||
	                    (e!=ErrorCode.U_INVALID_CHAR_FOUND &&
	                     e!=ErrorCode.U_ILLEGAL_CHAR_FOUND &&
	                     e!=ErrorCode.U_TRUNCATED_CHAR_FOUND &&
	                     e!=ErrorCode.U_ILLEGAL_ESCAPE_SEQUENCE &&
	                     e!=ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE)
	                ) {
	                    /*
	                     * the callback did not or cannot resolve the error:
	                     * set output pointers and return
	                     *
	                     * the check for buffer overflow is redundant but it is
	                     * a high-runner case and hopefully documents the intent
	                     * well
	                     *
	                     * if we were replaying, then the replay buffer must be
	                     * copied back into the UConverter
	                     * and the real arguments must be restored
	                     */
	                    if(realSourceArray!=null) {
	                        int length;
	
	                        //agljport:todo U_ASSERT(cnv->preToULength==0);
	
	                        length=(int)(pArgs.sourceLimit-pArgs.sourceBegin);
	                        if(length>0) {
	                            UConverterUtility.uprv_memcpy(preToUArray, preToUBegin, pArgs.sourceArray, pArgs.sourceBegin, length);
	                            preToULength=(byte)-length;
	                        }
	
	                        pArgs.sourceArray=realSourceArray;
	                        pArgs.sourceBegin=realSourceBegin;
	                        pArgs.sourceLimit=realSourceLimit;
	                        pArgs.flush=realFlush;
	                    }
	
	                    return;
	                }
	            }
	
	            /* copy toUBytes[] to invalidCharBuffer[] */
	            errorInputLength=invalidCharLength=toULength;
	            if(errorInputLength>0) {
	                UConverterUtility.uprv_memcpy(invalidCharBufferArray, invalidCharBufferBegin, toUBytesArray, toUBytesBegin, errorInputLength);
	            }
	
	            /* set the converter state to deal with the next character */
	            toULength=0;
	
	            /* call the callback function */
	            fromCharErrorBehaviour.call(toUContextArray, pArgs, invalidCharBufferArray, invalidCharBufferBegin, errorInputLength, (err[0]==ErrorCode.U_INVALID_CHAR_FOUND || err[0]==ErrorCode.U_UNSUPPORTED_ESCAPE_SEQUENCE) ?  UConverterCallbackReason.UCNV_UNASSIGNED : UConverterCallbackReason.UCNV_ILLEGAL, err);
	
	            /*
	             * loop back to the offset handling
	             *
	             * this flag will indicate after offset handling
	             * that a callback was called;
	             * if the callback did not resolve the error, then we return
	             */
	            calledCallback=true;
	        }
	    }
	}

	//U_CAPI void U_EXPORT2 ucnv_toUnicode(UConverter *cnv, UChar **target, const UChar *targetLimit, const char **source, const char *sourceLimit, int32_t *offsets, UBool flush, UErrorCode *err)
	final void ucnv_toUnicode(char[] target, int[]targetBegin, int targetLimit, byte[] source, int[] sourceBegin, int sourceLimit, /*int[] offsets,*/ boolean flush, int[] err)
	{
		// offsets array parameter is not supported in ICU4JNI
		int[] offsets = null;
	    UConverterToUnicodeArgs args = new UConverterToUnicodeArgs();
	    int s;
	    int t;
	
	    /* check parameters */
	    if(err==null || ErrorCode.isFailure(err[0])) {
	        return;
	    }
	
	    if(target==null || source==null) {
	        err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	
	    s=sourceBegin[0];
	    t=targetBegin[0];
	    if(sourceLimit<s || targetLimit<t) {
	        err[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	
	    /*
	     * Make sure that the buffer sizes do not exceed the number range for
	     * int32_t because some functions use the size (in units or bytes)
	     * rather than comparing pointers, and because offsets are int32_t values.
	     *
	     * size_t is guaranteed to be unsigned and large enough for the job.
	     *
	     * Return with an error instead of adjusting the limits because we would
	     * not be able to maintain the semantics that either the source must be
	     * consumed or the target filled (unless an error occurs).
	     * An adjustment would be sourceLimit=t+0x7fffffff; for example.
	     */
			/*agljport:fix
	    if(
	        ((size_t)(sourceLimit-s)>(size_t)0x7fffffff && sourceLimit>s) ||
	        ((size_t)(targetLimit-t)>(size_t)0x3fffffff && targetLimit>t)
	    ) {
	        *err=U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
			*/
	    
	    /* flush the target overflow buffer */
	    if(UCharErrorBufferLength>0) {
	        char[] overflow = null;
	        int i, length;
	
	        overflow=UCharErrorBufferArray;
	        length=UCharErrorBufferLength;
	        i=0;
	        do {
	            if(t==targetLimit) {
	                /* the overflow buffer contains too much, keep the rest */
	                int j=0;
	
	                do {
	                    overflow[j++]=overflow[i++];
	                } while(i<length);
	
	                UCharErrorBufferLength=(byte)j;
	                targetBegin[0]=t;
	                err[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                return;
	            }
	
	            /* copy the overflow contents to the target */
	            target[t++]=overflow[i++];
	            if(offsets!=null) {
	                //agljport:todo *offsets++=-1; /* no source index available for old output */
	            }
	        } while(i<length);
	
	        /* the overflow buffer is completely copied to the target */
	        UCharErrorBufferLength=0;
	    }
	
	    if(!flush && s==sourceLimit && preToULength>=0) {
	        /* the overflow buffer is emptied and there is no new input: we are done */
	        targetBegin[0]=t;
	        return;
	    }
	
	    /*
	     * Do not simply return with a buffer overflow error if
	     * !flush && t==targetLimit
	     * because it is possible that the source will not generate any output.
	     * For example, the skip callback may be called;
	     * it does not output anything.
	     */
	
	    /* prepare the converter arguments */
	    args.converter=this;
	    args.flush=flush;
	    args.offsetsArray=offsets;
		args.sourceArray = source;
	    args.sourceBegin=s;
	    args.sourceLimit=sourceLimit;
	    args.targetArray=target;
	    args.targetBegin=t;
	    args.targetLimit=targetLimit;
	    //args.size=sizeof(args);
	
	    _toUnicodeWithCallback(args, err);
	
	    sourceBegin[0]=args.sourceBegin;
	    targetBegin[0]=args.targetBegin;
	}

	public void ucnv_isValidSubstChars (byte[] mySubChar, int[] err)
	{
		int len = mySubChar.length;
	    if (ErrorCode.isFailure(err[0]))
	        return;
	    
	    /*Makes sure that the subChar is within the codepages char length boundaries */
	    if ((len > sharedData.staticData.maxBytesPerChar) || (len < sharedData.staticData.minBytesPerChar))
	    {
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    
	    return;
	}
	
	//U_CAPI void    U_EXPORT2 ucnv_setSubstChars (UConverter * converter, const char *mySubChar, int8_t len, UErrorCode * err)
	public void ucnv_setSubstChars (byte[] mySubChar, byte len, int[] err)
	{
	    if (ErrorCode.isFailure(err[0]))
	        return;
	    
	    /*Makes sure that the subChar is within the codepages char length boundaries */
	    if ((len > sharedData.staticData.maxBytesPerChar) || (len < sharedData.staticData.minBytesPerChar))
	    {
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    
	    UConverterUtility.uprv_memcpy (subCharArray,0, mySubChar, 0,len); /*copies the subchars */
			subCharBegin = 0;
	    subCharLen = len;  /*sets the new len */
	
	    /*
	    * There is currently (2001Feb) no separate API to set/get subChar1.
	    * In order to always have subChar written after it is explicitly set,
	    * we set subChar1 to 0.
	    */
	    subChar1 = 0;
	    
	    return;
	}
	
	//U_CAPI void    U_EXPORT2 ucnv_getSubstChars (const UConverter * converter, char *mySubChar, int8_t * len, UErrorCode * err)
	public void ucnv_getSubstChars (byte[] mySubChar, byte[] len, int[] err)
	{
	    if (ErrorCode.isFailure(err[0]))
	        return;
	
	    if (len[0] < subCharLen) /*not enough space in subChars */
	    {
	        err[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	        return;
	    }
	
	  UConverterUtility.uprv_memcpy (mySubChar, 0, subCharArray, subCharBegin, subCharLen);   /*fills in the subchars */
	  len[0] = subCharLen; /*store # of bytes copied to buffer */
	}
	
	//U_CAPI void  U_EXPORT2 ucnv_getInvalidChars (const UConverter * converter, char *errBytes, int8_t * len, UErrorCode * err)
	public final void ucnv_getInvalidChars (byte[] errBytes, int[] len, int[] err)
	{
	    if (err == null || ErrorCode.isFailure(err[0]))
	    {
	        return;
	    }
	    if (len == null || errBytes == null)
	    {
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    if (len[0] < invalidCharLength)
	    {
	        err[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	        return;
	    }
	    if ((len[0] = invalidCharLength) > 0)
	    {
	        UConverterUtility.uprv_memcpy (errBytes,0, invalidCharBufferArray,invalidCharBufferBegin, len[0]);
	    }
	}

	//U_CAPI void  U_EXPORT2 ucnv_getInvalidUChars (const UConverter * converter, UChar *errChars, int8_t * len, UErrorCode * err)
	public void ucnv_getInvalidUChars (char[] errChars, int[] len, int[] err)
	{
	    if (err == null || ErrorCode.isFailure(err[0]))
	    {
	        return;
	    }
	    if (len == null || errChars == null)
	    {
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    if (len[0] < invalidUCharLength)
	    {
	        err[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	        return;
	    }
	    if ((len[0] = invalidUCharLength) > 0)
	    {
					System.arraycopy(invalidUCharBufferArray, 0, errChars, 0, len[0]);
	    }
	}
		
	//U_CAPI int32_t   U_EXPORT2 ucnv_countAvailable ()
	public static int ucnv_countAvailable ()
	{
	    int[] err = new int[] {ErrorCode.U_ZERO_ERROR};
	    return UConverterAlias.ucnv_bld_countAvailableConverters(err);
	}
		
	/*returns a single Name from the list, will return NULL if out of bounds
	 */
	public static String ucnv_getAvailableName (int n)
	{
	  if (0 <= n && n <= 0xffff) {
	    int[] err = new int[] {ErrorCode.U_ZERO_ERROR};
	    String name = UConverterAlias.ucnv_bld_getAvailableConverter(n, err);
	    if (ErrorCode.isSuccess(err[0])) {
	      return name;
	    }
	  }
	  return null;
	}

	//U_CAPI const char * U_EXPORT2ucnv_getStandard(uint16_t n, UErrorCode *pErrorCode)
	public static String ucnv_getStandard(int n, int[] pErrorCode)
	{
		return UConverterAlias.ucnv_getStandard(n, pErrorCode);
	}
	
	public static String ucnv_getStandardName(String alias, String standard, int[] pErrorCode)
	{
		return UConverterAlias.ucnv_getStandardName(alias, standard, pErrorCode);
	}
	
	public static UConverterAliasesEnumeration ucnv_openStandardNames(String alias, String standard, int[] pErrorCode)
	{
		return UConverterAlias.ucnv_openStandardNames(alias, standard, pErrorCode);
	}

	/**
	 * Returns the number of UChars held in the converter's internal state 
	 * because more input is needed for completing the conversion. This function is 
	 * useful for mapping semantics of ICU's converter interface to those of iconv,
	 * and this information is not needed for normal conversion.
	 * @param cnv       The converter in which the input is held
	 * @param status    ICU error code in/out parameter.
	 *                  Must fulfill U_SUCCESS before the function call.
	 * @return The number of UChars in the state. -1 if an error is encountered.
	 * @draft ICU 3.4
	 */
	//U_DRAFT int32_t U_EXPORT2 ucnv_fromUCountPending(const UConverter* cnv, UErrorCode* status){
	public static int ucnv_fromUCountPending(UConverter cnv, int[] status)
	{    
	    if(status == null || ErrorCode.isFailure(status[0])){
	        return -1;
	    }
	    if(cnv == null){
	        status[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return -1;
	    }

	    if(cnv.preFromULength > 0){
	        return UConverterUTF16.U16_LENGTH(cnv.preFromUFirstCP)+cnv.preFromULength ;
	    }else if(cnv.preFromULength < 0){
	        return -cnv.preFromULength ;
	    }else if(cnv.fromUChar32 > 0){
	        return 1;
	    }else if(cnv.preFromUFirstCP >0){
	        return UConverterUTF16.U16_LENGTH(cnv.preFromUFirstCP);
	    }
	    return 0; 

	 }

	/**
	 * Returns the number of chars held in the converter's internal state
	 * because more input is needed for completing the conversion. This function is 
	 * useful for mapping semantics of ICU's converter interface to those of iconv,
	 * and this information is not needed for normal conversion.
	 * @param cnv       The converter in which the input is held as internal state
	 * @param status    ICU error code in/out parameter.
	 *                  Must fulfill U_SUCCESS before the function call.
	 * @return The number of chars in the state. -1 if an error is encountered.
	 * @draft ICU 3.4
	 */
	//U_DRAFT int32_t U_EXPORT2 ucnv_toUCountPending(const UConverter* cnv, UErrorCode* status);		
	public static int ucnv_toUCountPending(UConverter cnv, int[] status)
	{
	    if(status == null || ErrorCode.isFailure(status[0])){
	        return -1;
	    }
	    if(cnv == null){
	        status[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return -1;
	    }

	    if(cnv.preToULength > 0){
	        return cnv.preToULength ;
	    }else if(cnv.preToULength < 0){
	        return -cnv.preToULength;
	    }else if(cnv.toULength > 0){
	        return cnv.toULength;
	    }
	    return 0;
	}

	// ucmndata.h
	
	//U_CFUNC uint16_t udata_getHeaderSize(const DataHeader *udh)
	static final int udata_getHeaderSize(DataHeader udh)
	{
	    if(udh==null) {
	        return 0;
	    } else if(udh.info.isBigEndian==U_IS_BIG_ENDIAN) {
	        /* same endianness */
	        return udh.dataHeader.headerSize;
	    } else {
	        /* opposite endianness */
	        int x=udh.dataHeader.headerSize;
	        return (int)((x<<8)|(x>>8));
	    }
	}

	//U_CAPI const void * U_EXPORT2 udata_getMemory(UDataMemory *pData)
	static final ByteBuffer udata_getMemory(UDataMemory pData) 
	{
	    if(pData!=null && pData.pHeaderArray!=null) {
	        return pData.pHeaderArray;
	    } else {
					return null;
	    }
	}	
	
	class MappedData {
	    int    headerSize;
	    short     magic1;
	    short     magic2;
	} 		
	
	class DataHeader {
	    MappedData  dataHeader;
	    UDataInfo   info;
	}
	
	class UDataOffsetTOCEntry {
	    long nameOffset;
	    long dataOffset;
	}
	
	class UDataOffsetTOC {
	    long count;
	    UDataOffsetTOCEntry[] entry;    /* Actual size of array is from count. */
		UDataOffsetTOC()
		{
			entry = new UDataOffsetTOCEntry[2];
		}
	}
	
	// udata.h
	
	//U_CAPI UDataMemory * U_EXPORT2 udata_openChoice(const char *path, const char *type, const char *name, UDataMemoryIsAcceptable *isAcceptable, void *context, UErrorCode *pErrorCode) {
	static final UDataMemory udata_openChoice(byte[] path, byte[] type, byte[] nameArray, long nameArrayIndex, UDataMemoryIsAcceptable isAcceptable, byte[] context, int[] pErrorCode)
	{
	//agljport:delete #ifdef UDATA_DEBUG
	  //agljport:delete fprintf(stderr, "udata_openChoice(): Opening: %s : %s . %s\n", (path?path:"NULL"), name, type);
	//agljport:delete #endif
	
	    if(pErrorCode==null || ErrorCode.isFailure(pErrorCode[0])) {
	        return null;
	    } else if(nameArray==null || nameArray[(int)nameArrayIndex]==0 || isAcceptable==null) {
	        pErrorCode[0]=ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return null;
	    } else {
	        //agljport:fix return doOpenChoice(path, type, nameArray, isAcceptable, context, pErrorCode);
					return null;
	    }
	}
	
	/**
	 * UDataInfo contains the properties about the requested data.
	 * This is meta data.
	 *
	 * <p>This structure may grow in the future, indicated by the
	 * <code>size</code> field.</p>
	 *
	 * <p>The platform data property fields help determine if a data
	 * file can be efficiently used on a given machine.
	 * The particular fields are of importance only if the data
	 * is affected by the properties - if there is integer data
	 * with word sizes > 1 byte, char* text, or UChar* text.</p>
	 *
	 * <p>The implementation for the <code>udata_open[Choice]()</code>
	 * functions may reject data based on the value in <code>isBigEndian</code>.
	 * No other field is used by the <code>udata</code> API implementation.</p>
	 *
	 * <p>The <code>dataFormat</code> may be used to identify
	 * the kind of data, e.g. a converter table.</p>
	 *
	 * <p>The <code>formatVersion</code> field should be used to
	 * make sure that the format can be interpreted.
	 * I may be a good idea to check only for the one or two highest
	 * of the version elements to allow the data memory to
	 * get more or somewhat rearranged contents, for as long
	 * as the using code can still interpret the older contents.</p>
	 *
	 * <p>The <code>dataVersion</code> field is intended to be a
	 * common place to store the source version of the data;
	 * for data from the Unicode character database, this could
	 * reflect the Unicode version.</p>
	 * @stable ICU 2.0
	 */
	class UDataInfo {
	    /** sizeof(UDataInfo)
	     *  @stable ICU 2.0 */
	    int size;
	
	    /** unused, set to 0 
	     *  @stable ICU 2.0*/
	    int reservedWord;
	
	    /* platform data properties */
	    /** 0 for little-endian machine, 1 for big-endian
	     *  @stable ICU 2.0 */
	    short isBigEndian;
	
	    /** see U_CHARSET_FAMILY values in utypes.h 
	     *  @stable ICU 2.0*/
	    short charsetFamily;
	
	    /** sizeof(UChar), one of { 1, 2, 4 } 
	     *  @stable ICU 2.0*/
	    short sizeofUChar;
	
	    /** unused, set to 0 
	     *  @stable ICU 2.0*/
	    short reservedByte;
	
	    /** data format identifier 
	     *  @stable ICU 2.0*/
	    short dataFormat[/*4*/];
	
	    /** versions: [0] major [1] minor [2] milli [3] micro 
	     *  @stable ICU 2.0*/
	    short formatVersion[/*4*/];
	
	    /** versions: [0] major [1] minor [2] milli [3] micro 
	     *  @stable ICU 2.0*/
	    short dataVersion[/*4*/];
	
		UDataInfo()
		{
			dataFormat = new short[4];
			formatVersion = new short[4];
			dataVersion = new short[4];
		}
	}

} // UConverter
