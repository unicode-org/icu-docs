package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_ASCII extends UConverterSharedData {

	public UConverterSharedData_ASCII(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_ASCII()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		_ASCIIToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		_Latin1FromUnicodeWithOffsets(args, pErrorCode);
	}
	/* US-ASCII ----------------------------------------------------------------- */
	
	/* This is a table-less version of ucnv_MBCSSingleToBMPWithOffsets(). */
	//static void _ASCIIToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode) 
	final void _ASCIIToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode) 
	{
	    byte[] sourceArray;
			int sourceArrayIndex, sourceLimit;
	    char[] targetArray;
			int targetArrayIndex, oldTarget;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    int sourceIndex;
	
	    char c;
	
	    /* set up the local pointers */
			sourceArray = pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
			targetArray = pArgs.targetArray;
	    targetArrayIndex=oldTarget=pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
			offsetsArrayIndex=pArgs.offsetsBegin;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex=0;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=sourceLimit-sourceArrayIndex;
	    if(length<targetCapacity) {
	        targetCapacity=length;
	    }
	
	//agljport:delete #if ASCII_UNROLL_TO_UNICODE
			//agljport:delete unrolled loop
	//agljport:delete #endif
	
	    /* conversion loop */
	    c=0;
	    while(targetCapacity>0 && (c=(char)(sourceArray[sourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK))<=0x7f) {
	        targetArray[targetArrayIndex++]=c;
	        --targetCapacity;
	    }
	
	    if(c>0x7f) {
	        /* callback(illegal); copy the current bytes to toUBytes[] */
	        UConverter cnv=pArgs.converter;
	        cnv.toUBytesArray[0]=(byte)c;
	        cnv.toULength=1;
	        pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	    } else if(sourceArrayIndex<sourceLimit && targetArrayIndex>=pArgs.targetLimit) {
	        /* target is full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* set offsets since the start */
	    if(offsetsArray!=null) {
	        int count=targetArrayIndex-oldTarget;
	        while(count>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --count;
	        }
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
			pArgs.targetArray = targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
			pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/* This is a table-less version of ucnv_MBCSSingleFromBMPWithOffsets(). */
	//static void _Latin1FromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	final void _Latin1FromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    char[] sourceArray;
			int sourceArrayIndex, sourceLimit;
	    byte[] targetArray;
			int targetArrayIndex, oldTarget;
	    int targetCapacity, length;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    int cp;
	    char c, max;
	
	    int sourceIndex;
	
	
	    /* set up the local pointers */
	    cnv=pArgs.converter;
			sourceArray = pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    sourceLimit=pArgs.sourceLimit;
			targetArray = pArgs.targetArray;
	    targetArrayIndex=oldTarget=pArgs.targetBegin;
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
			offsetsArrayIndex=pArgs.offsetsBegin;
	
	
	    //agljport:delete if(cnv->sharedData==&_Latin1Data) {
	        //agljport:delete max=0xff; /* Latin-1 */
	    //agljport:delete } else {
	        max=0x7f; /* US-ASCII */
	    //agljport:delete }
	
	    /* get the converter state from UConverter */
	    cp=cnv.fromUChar32;
	
	    /* sourceIndex=-1 if the current character began in the previous buffer */
	    sourceIndex= cp==0 ? 0 : -1;
	
	    /*
	     * since the conversion here is 1:1 UChar:uint8_t, we need only one counter
	     * for the minimum of the sourceLength and targetCapacity
	     */
	    length=sourceLimit-sourceArrayIndex;
	    if(length<targetCapacity) {
	        targetCapacity=length;
	    }
	
	    /* conversion loop */
			boolean goto_getTrail = false;
			boolean goto_noMoreInput = false;
	    if(cp!=0 && targetCapacity>0) {
					goto_getTrail = true;
					//agljport:comment inserted getTrail block below
	            if(sourceArrayIndex<sourceLimit) {
	                /* test the following code unit */
	                char trail=sourceArray[sourceArrayIndex];
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    ++sourceArrayIndex;
	                    cp=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)cp, trail);
	                    /* this codepage does not map supplementary code points */
	                    /* callback(unassigned) */
	                } else {
	                    /* this is an unmatched lead code unit (1st surrogate) */
	                    /* callback(illegal) */
	                }
	            } else {
	                /* no more input */
	                cnv.fromUChar32=cp;
									goto_noMoreInput = true;
	            }
							if(!goto_noMoreInput) {
								pErrorCode[0]= UConverterUTF.U_IS_SURROGATE(cp) ? ErrorCode.U_ILLEGAL_CHAR_FOUND : ErrorCode.U_INVALID_CHAR_FOUND;
								cnv.fromUChar32=cp;
							}
	    }
	
	//agljport:delete #if LATIN1_UNROLL_FROM_UNICODE
	//agljport:delete unrolled loop code
	//agljport:delete #endif
	
	    /* conversion loop */
			if(!goto_noMoreInput) {
	    c=0;
	    while(targetCapacity>0 && (c=sourceArray[sourceArrayIndex++])<=max) {
	        /* convert the Unicode code point */
	        targetArray[targetArrayIndex++]=(byte)c;
	        --targetCapacity;
	    }
	
	    if(c>max) {
	        cp=c;
	        if(!UConverterUTF.U_IS_SURROGATE(cp)) {
	            /* callback(unassigned) */
	        } else if(UConverterUTF.U_IS_SURROGATE_LEAD(cp)) {
	getTrail:
	            if(sourceArrayIndex<sourceLimit) {
	                /* test the following code unit */
	                char trail=sourceArray[sourceArrayIndex];
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    ++sourceArrayIndex;
	                    cp=UConverterUTF16.U16_GET_SUPPLEMENTARY((char)cp, trail);
	                    /* this codepage does not map supplementary code points */
	                    /* callback(unassigned) */
	                } else {
	                    /* this is an unmatched lead code unit (1st surrogate) */
	                    /* callback(illegal) */
	                }
	            } else {
	                /* no more input */
	                cnv.fromUChar32=cp;
									goto_noMoreInput = true;
	            }
	        } else {
	            /* this is an unmatched trail code unit (2nd surrogate) */
	            /* callback(illegal) */
	        }
	
					if(!goto_noMoreInput) {
	        pErrorCode[0]= UConverterUTF.U_IS_SURROGATE(cp) ? ErrorCode.U_ILLEGAL_CHAR_FOUND : ErrorCode.U_INVALID_CHAR_FOUND;
	        cnv.fromUChar32=cp;
					}
	    }
			}
	noMoreInput:
	
	    /* set offsets since the start */
	    if(offsetsArray!=null) {
	        int count=targetArrayIndex-oldTarget;
	        while(count>0) {
	            offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	            --count;
	        }
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0]) && sourceArrayIndex<sourceLimit && targetArrayIndex>=pArgs.targetLimit) {
	        /* target is full */
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
			pArgs.targetArray = targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
			pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/*agljport:delete
	static const UConverterImpl _ASCIIImpl={
	    UCNV_US_ASCII,
	
	    NULL,
	    NULL,
	
	    NULL,
	    NULL,
	    NULL,
	
	    _ASCIIToUnicodeWithOffsets,
	    _ASCIIToUnicodeWithOffsets,
	    _Latin1FromUnicodeWithOffsets,
	    _Latin1FromUnicodeWithOffsets,
	    _ASCIIGetNextUChar,
	
	    NULL,
	    NULL,
	    NULL,
	    NULL,
	    _ASCIIGetUnicodeSet
	};
	*/
	
	/*agljport:change 
	static const UConverterStaticData _ASCIIStaticData={
	    sizeof(UConverterStaticData),
	    "US-ASCII",
	    367, UCNV_IBM, UCNV_US_ASCII, 1, 1,
	    { 0x1a, 0, 0, 0 }, 1, FALSE, FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	const UConverterSharedData _ASCIIData={
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_ASCIIStaticData, FALSE, &_ASCIIImpl, 
	    0
	};
	*/
	public static UConverterStaticData _ASCIIStaticData;
	public static UConverterSharedData_ASCII _ASCIIData;
	static 
	{
	_ASCIIStaticData = new UConverterStaticData(
	    UConverterStaticData.sizeofUConverterStaticData,
	    "US-ASCII",
	    367, (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_US_ASCII, (byte)1, (byte)1,
	    new byte[]{ 0x1a, 0, 0, 0 }, (byte)1, (byte)0, (byte)0,
	    (short)0,
	    (byte)0,
	    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
	);
	
	_ASCIIData = new UConverterSharedData_ASCII(
	    sizeofUConverterSharedData, ~0,
	    /*NULL, NULL,*/ _ASCIIStaticData, false, /*&_ASCIIImpl,*/
	    0
			);
	}
}
