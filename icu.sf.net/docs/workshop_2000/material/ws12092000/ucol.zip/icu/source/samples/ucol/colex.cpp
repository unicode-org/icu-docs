/**************************************************************************
*
*   Copyright (C) 2000, International Business Machines
*   Corporation and others.  All Rights Reserved.
*
***************************************************************************
*   file name:  colex.cpp
*
*   created on: 2000Sep02
*   created by: Helena Shih
*
*   Sample code for the ICU Collator C++ routines.  This sample code file
*   contains the parallel examples of the colex1.c file.
*
*   collateWithLocaleInCPP(): 
*   1. Opens a collator with a locale. 
*   2. Compares two strings with the collator. 
*   3. Sets the strength to tertiary and compare the strings again. 
*   4. Gets the keys for the strings and compare them. 
* 
*   collateWithRulesInCPP():
*   1. Open a Collator with customized rules and attributes. 
*   2. Compare two strings with the collator. 
*   3. Open a CollationElementIterator. 
*   4. Walk through the text with the element iterator. 
*
*/
#include <stdio.h>
#include "unicode/unistr.h"
#include "unicode/utypes.h"
#include "unicode/locid.h"
#include "unicode/coll.h"
#include "unicode/tblcoll.h"
#include "unicode/coleitr.h"
#include "unicode/sortkey.h"

extern "C" UBool collateWithLocaleInC(const char* locale, UErrorCode *status);
extern "C" UBool collateWithRulesInC(UErrorCode* status);

/* show the primary elements for 'Zero' and 'Pie' with both enUSCollator and new Collator. */
UBool walkThroughElements(Collator* col, const UnicodeString& source, const UnicodeString target, int32_t len, UErrorCode& status)
{
    CollationElementIterator *elems = 0;
    Collator::ECollationStrength strength = col->getStrength();
    int32_t order = 0, orderSegment;
    int i = 0;

    /* Print out primary orders of the first few specified characters of both source and target strings*/
    col->setDecomposition(Normalizer::DECOMP);
    elems = ((RuleBasedCollator*)col)->createCollationElementIterator(source);
    if (U_FAILURE(status))
    {
        fprintf(stderr,
        "Failed to create the collation element iterator.\n");  
        return FALSE;
    }
    fprintf(stdout, "Processing source string now...\n");
    while ((order = elems->next(status)) != CollationElementIterator::NULLORDER && i < len) {
        if (U_FAILURE(status))
        {
            fprintf(stderr, "Getting the next source collation element failed.\n");
            return FALSE;
        }
        orderSegment = CollationElementIterator::primaryOrder(order);
        fprintf(stdout, "Source character = '%c' : primary order = 0x%04x.\n", source[i++], orderSegment);        
    }
    elems->setText(target, status);
    i = 0;
    fprintf(stdout, "Processing target string now...\n");
    while ((order = elems->next(status)) != CollationElementIterator::NULLORDER && i < len) {
        if (U_FAILURE(status))
        {
            fprintf(stderr, "Getting the next target collation element failed.\n");
            return FALSE;
        }
        orderSegment = CollationElementIterator::primaryOrder(order);
        fprintf(stdout, "Target character = '%c' : primary order = 0x%04x.\n", target[i++], orderSegment);        
    }
    delete elems;
    return TRUE;
}
UBool collateWithLocaleInCPP(const Locale& locale, UErrorCode& status)
{
    UnicodeString	dispName; 
    UnicodeString source("This is a test.");
    UnicodeString target("THISISATEST.");
    Collator::EComparisonResult result	= Collator::EQUAL;
    CollationKey sourceKey;
    CollationKey targetKey; 
    Collator	*myCollator	= 0;

    if (U_FAILURE(status))
    {
        return FALSE;
    }
    myCollator = Collator::createInstance(locale, status);
    if (U_FAILURE(status)){
        locale.getDisplayName(dispName);
        /*Report the error with display name... */
        fprintf(stderr,
        "%s: Failed to create the collator for : \"%s\"\n", dispName);
        return FALSE;
    }
    result = myCollator->compare(source, target);
    /* result is 1, secondary differences only for ignorable space characters*/
    if (result != 1)
    {
        fprintf(stderr,
        "Comparing two strings with only secondary differences in C failed.\n");
        return FALSE;
    }
    /* To compare them with just primary differences */
    myCollator->setStrength(Collator::PRIMARY);
    result = myCollator->compare(source, target);
    /* result is 0 */
    if (result != 0)
    {
        fprintf(stderr,
        "Comparing two strings with no differences in C failed.\n");
        return FALSE;
    }
    /* Now, do the same comparison with keys */
    myCollator->getCollationKey(source, sourceKey, status);
    myCollator->getCollationKey(target, targetKey, status);
    result = Collator::EQUAL;
    result = sourceKey.compareTo(targetKey);
    if (result != 0)
    {
        fprintf(stderr,
        "%s: Comparing two strings with sort keys in C failed.\n");
        return FALSE;
    }
    delete myCollator;
    return TRUE;
}

UBool collateWithRulesInCPP(UErrorCode& status)
{    /* Open a new collator with additional rules \"& Z < p, P\" */
    UnicodeString	ruleSet;
    UnicodeString   newRules("& Z < p, P");
    int32_t 	ruleLen 	= 0, newRuleLen = 0;
    UnicodeString 	source("Zero in with the pie"), target("Pie as the target");
    RuleBasedCollator 	*col 		= 0;
    Collator	*enUSCollator	= 0;
    Collator::EComparisonResult result 	= Collator::EQUAL;

    enUSCollator = Collator::createInstance(Locale("en", "US"), status);
    if (U_FAILURE(status)){
        fprintf(stderr,
        "Failed to create the collator for en_US.\n");        
        return FALSE;
    }

    const UnicodeString& baseRules = 
        ((RuleBasedCollator*)enUSCollator)->getRules();
    ruleSet.append(baseRules);
    ruleSet.append(newRules);
    status = U_ZERO_ERROR;
    col = new RuleBasedCollator(ruleSet, Collator::TERTIARY, Normalizer::NO_OP, status);
    if (U_FAILURE(status)) {
        /* Report the error */
        fprintf(stderr,
        "Failed to create the collator for with rules.\n");
        return FALSE;
    }
    result = enUSCollator->compare(source, target);
    if (result != Collator::GREATER)
    {
        fprintf(stderr, "'Pie' should sort before 'Zero' with the en_US rules.\n");
        return FALSE;
    }
    result = col->compare(source, target);
    /* Get attributes from the collator */
    if (result != Collator::LESS)
    {
        fprintf(stderr, "'Zero' should sort before 'Pie' with the new rules.\n");
        return FALSE;
    }

    /* Go through the elements until the first occurance of ' ' character in the strings */
   fprintf(stdout, "\nWalk through strings with en_US collator first...\n");
   if (walkThroughElements(enUSCollator, source, target, 4, status) == FALSE)
    {
        return FALSE;
    }
   fprintf(stdout, "\n\nWalk through strings with the custom collator now...\n");
    if (walkThroughElements(col, source, target, 4, status) == FALSE)
    {
        return FALSE;
    }

    delete enUSCollator;
    delete col; 
    return TRUE;
}

int main()
{
   UErrorCode status = U_ZERO_ERROR;
   fprintf(stdout, "\n");
   if (collateWithLocaleInCPP(Locale("en", "US"), status) != TRUE)
   {
        fprintf(stderr,
        "Collate with locale in C++ failed.\n");
   } else 
   {
       fprintf(stdout, "Collate with Locale C++ example worked!!\n");
   }
   status = U_ZERO_ERROR;
   if (collateWithRulesInCPP(status) != TRUE)
   {
        fprintf(stderr,
        "%s: Collate with rules in C failed.\n");
   } else 
   {
       fprintf(stdout, "Collate with rules C++ example worked!!\n");
   }
   fprintf(stdout, "\n");
   if (collateWithLocaleInC("en_US", &status) != TRUE)
   {
        fprintf(stderr,
        "%s: Collate with locale in C failed.\n");
   } else 
   {
       fprintf(stdout, "Collate with Locale C example worked!!\n");
   }
   status = U_ZERO_ERROR;
   if (collateWithRulesInC(&status) != TRUE)
   {
        fprintf(stderr,
        "%s: Collate with rules in C failed.\n");
   } else 
   {
       fprintf(stdout, "Collate with rules C example worked!!\n");
   }
   return 0;
}