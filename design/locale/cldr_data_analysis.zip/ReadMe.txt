﻿After CLDR 1.1 was put to bed, I ran into some oddities that lead me to write some additional tests, which reveal problems that we will want to address in CLDR 1.2.

A. display_name_collisions.txt shows cases where display names collide. Here are my recommendations:

Zones: fix as a part of the change to zone localizations (see other bug).

The bm vs bam collisions are an artifact of the test.

Others

am_ET: Display Names collide for Currencies (0) USD & ETB =>$
am_ET: Display Names collide for Currencies (1) USD & ETB =>$
om_ET: Display Names collide for Currencies (0) USD & ETB =>$
om_ET: Display Names collide for Currencies (1) USD & ETB =>$
so_DJ: Display Names collide for Currencies (0) USD & DJF =>$
so_DJ: Display Names collide for Currencies (1) USD & DJF =>$
so_ET: Display Names collide for Currencies (0) USD & ETB =>$
so_ET: Display Names collide for Currencies (1) USD & ETB =>$
so_SO: Display Names collide for Currencies (0) USD & SOS =>$
so_SO: Display Names collide for Currencies (1) USD & SOS =>$
ti_ER: Display Names collide for Currencies (0) USD & ERN =>$
ti_ER: Display Names collide for Currencies (1) USD & ERN =>$
ti_ET: Display Names collide for Currencies (0) USD & ETB =>$
ti_ET: Display Names collide for Currencies (1) USD & ETB =>$

Make $ be US$ in am_ET, om_ET, so_*, ti_*

ga_IE: Display Names collide for Currencies (0) IEP & GBP =>\u00A3
ga_IE: Display Names collide for Currencies (1) IEP & GBP =>\u00A3
ga_IE_PREEURO: Display Names collide for Currencies (0) IEP & GBP =>\u00A3
ga_IE_PREEURO: Display Names collide for Currencies (1) IEP & GBP =>\u00A3

Change ga_IE to drop conversion for IEP.

ja: Display Names collide for Language ie & ia =>\u56FD\u969B\u8A9E
ja_JP: Display Names collide for Language ie & ia =>\u56FD\u969B\u8A9E
ru: Display Names collide for Language ie & ia =>\u0421\u043C\u0435\u0448\u0430\u043D\u043D\u044B\u0439 \u044F\u0437\u044B\u043A
ru_RU: Display Names collide for Language ie & ia =>\u0421\u043C\u0435\u0448\u0430\u043D\u043D\u044B\u0439 \u044F\u0437\u044B\u043A
ru_UA: Display Names collide for Language ie & ia =>\u0421\u043C\u0435\u0448\u0430\u043D\u043D\u044B\u0439 \u044F\u0437\u044B\u043A
ta: Display Names collide for Language ie & ia =>\u0B87\u0BA9\u0BCD\u0B9F\u0BB0\u0BCD\u0BB2\u0BBF\u0B99\u0BCD\u0B95\u0BC1\u0BB5\u0BBE
ta_IN: Display Names collide for Language ie & ia =>\u0B87\u0BA9\u0BCD\u0B9F\u0BB0\u0BCD\u0BB2\u0BBF\u0B99\u0BCD\u0B95\u0BC1\u0BB5\u0BBE
uk: Display Names collide for Language ie & ia 
=>\u0406\u043D\u0442\u0435\u0440\u043B\u0456\u043D\u0433\u0432\u0430
uk_UA: Display Names collide for Language ie & ia =>\u0406\u043D\u0442\u0435\u0440\u043B\u0456\u043D\u0433\u0432\u0430
zh: Display Names collide for Language ie & ia =>\u62C9\u4E01\u56FD\u9645\u6587
zh_CN: Display Names collide for Language ie & ia =>\u62C9\u4E01\u56FD\u9645\u6587
zh_HK: Display Names collide for Language ie & ia =>\u62C9\u4E01\u570B\u969B\u6587
zh_MO: Display Names collide for Language ie & ia =>\u62C9\u4E01\u570B\u969B\u6587
zh_SG: Display Names collide for Language ie & ia =>\u62C9\u4E01\u56FD\u9645\u6587
zh_TW: Display Names collide for Language ie & ia =>\u62C9\u4E01\u570B\u969B\u6587

For each of the "ia" localizations, add "(IALA)" to the end of the word.

Currencies	(1):	de_AT [German (Austria)]	AFN [Afghani]	& AFA [Afghani (1927-2002)]	=> Afghani
...

For all cases where there is a year difference, add the year to the translation.

Currencies	(1):	zh_HK [Chinese (Hong Kong S.A.R., China)]	BRR [Brazilian Cruzeiro]	& BRC [Brazilian Cruzado]	=> 巴西克鲁塞罗	

Currencies	(1):	zh_HK [Chinese (Hong Kong S.A.R., China)]	BRR [Brazilian Cruzeiro]	& BRC [Brazilian Cruzado]	=> 巴西克鲁塞罗	

For other cases of collisions, retract the non-modern currency if there is one. Notify country contacts to supply alternative.

B. Redundancies
Note: for uniformity, the test does not use include the zh_<country> aliases, instead uses zh_Han(t|s)_<country>

Remove the obvious redundancies.

Add to LDML that if an ISO code (language, script, country, currency) does not have an explicit display name in the root (for currency, this also includes the <symbol>, that the display name is assumed to be the code itself. Then remove the ISO codes that this would cover from the root.

C. Sideways view

This is a view of the CLDR data "from the side". That is, it groups field data first by elements, then by value. This provides a way to compare data across different locales. I'd recommend that we forward this to our country contacts for verification, because it allows people to pick up discrepancies. I formatted the data so that there is a middle-dot before each locale ID, which allows searching through the document for items like ·ar· (for Arabic alone) or ·ar_ (for Arabic country locale IDs), or ·ar (for any Arabic locale).

Some items that I noticed are:

1. There is a bogus trailing space in the following cases. Unfortunately, since
they are in Root, they get picked up by lots of locales.

<ldml><dates><calendars><calendar
type="gregorian"><dateFormats><dateFormatLength
type="medium"><dateFormat><pattern>

"yyyy MMM d ": aa, af, am, az, bn, byn, cy, dv, eu, ga, gez, gl, gu, gv, haw,
hi, id, iu, ka, kl, kn, kok, kw, ky, mn, mr, ms, om, pa, root, sa, sid, sw, syr,
ta, te, ti, tig, tt, ur, uz, wal, zh

<ldml><dates><calendars><calendar
type="gregorian"><dateFormats><dateFormatLength
type="full"><dateFormat><pattern>
"EEEE, yyyy MMMM dd ": aa, af, am, az, bn, byn, cy, dv, eu, ga, gez, gl, gu, gv,
haw, hi, id, iu, ka, kl, kn, kok, kw, ky, mn, mr, ms, om, pa, root, sa, sid, sw,
syr, ta, te, ti, tig, tt, ur, uz, wal, zh

<ldml><dates><calendars><calendar
type="gregorian"><dateFormats><dateFormatLength
type="long"><dateFormat><pattern>

"yyyy MMMM d ": aa, af, am, az, bn, byn, cy, dv, eu, ga, gez, gl, gu, gv, haw,
hi, id, iu, ka, kl, kn, kok, kw, ky, mn, mr, ms, om, pa, root, sa, sid, sw, syr,
ta, te, ti, tig, tt, ur, uz, wal, zh

<ldml><dates><calendars><calendar
type="gregorian"><timeFormats><timeFormatLength
type="medium"><timeFormat><pattern>
"HH:mm:ss ": aa, af, am, az, bn, byn, cy, dv, eu, ga, gez, gl, gu, gv, haw, hi,
id, iu, ka, kl, kn, kok, kw, ky, mn, mr, ms, om, pa, root, sa, sid, sw, syr, ta,
te, ti, tig, tt, ur, uz, wal, zh

2. The following are not errors, but we could flag. Multiple leading # are
equivalent to singles, so should be removed for uniformity

"##,##,##0%": sa
"#,##,##0%": dv

Ditto for:

"¤ ##,##,##0.00;-¤ ##,##,##0.00": ar_IN, bn_IN, en_IN, gu_IN, hi_IN, kn_IN,
kok_IN, mr_IN, pa, ta_IN, te_IN
"¤##,##,##0.00;-¤##,##,##0.00": pa_IN

3. Plus these should be moved up into the language. Right now, they all get the
wrong default value:

"¤ #,##0.00;-¤ #,##0.00": aa, af, am, az, be, bg, bn, byn, ca, cs, cy, da, de,
dv, el, eo, et, eu, fa, fi, fo, ga, gez, gl, gu, gv, haw, he, hi, hr, hu, is,
it, iu, iw, ja, ka, kk, kl, kn, ko, kok, kw, ky, lt, lv, mk, mn, mr, ms, mt, nb,
nl, nn, no, om, pl, ps, pt, ro, root, ru, sa, sh, sid, sk, sl, so, sq, sr, sv,
sw, syr, te, th, ti, tig, tr, tt, uk, ur, uz, wal, zh

[We need to scrub a lot of languages in the area of number formats, where the most common default for the language needs to be moved up from the country locales.]

4. Missing Narrow Month/Days for English
Although we got the Narrow formats for many other languages, we are missing English!