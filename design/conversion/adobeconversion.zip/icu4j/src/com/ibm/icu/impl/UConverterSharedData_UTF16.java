/*  
**********************************************************************
*   Copyright (C) 2002-2004, International Business Machines
*   Corporation and others.  All Rights Reserved.
**********************************************************************
*   file name:  ucnv_u16.c
*   encoding:   US-ASCII
*   tab size:   8 (not used)
*   indentation:4
*
*   created on: 2002jul01
*   created by: Markus W. Scherer
*
*   UTF-16 converter implementation. Used to be in ucnv_utf.c.
*/

package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;

class UConverterSharedData_UTF16 extends UConverterSharedData {

	public UConverterSharedData_UTF16(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_,/* UConverterImpl impl_,*/ long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_UTF16()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		_UTF16Open(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doReset(UConverter cnv, int choice)
	{
		_UTF16Reset(cnv, choice);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		_UTF16ToUnicodeWithOffsets(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		_UTF16BEFromUnicodeWithOffsets(args, pErrorCode);
	}
	
	final static int UCNV_NEED_TO_WRITE_BOM = 1;
	
	/* UTF-16BE ----------------------------------------------------------------- */
	
	//static void _UTF16BEFromUnicodeWithOffsets(UConverterFromUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	public final void _UTF16BEFromUnicodeWithOffsets(UConverterFromUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    char[] sourceArray;
		int sourceArrayIndex;
	    byte[] targetArray;
		int targetArrayIndex;
	    int[] offsetsArray;
		int offsetsArrayIndex;
	
	    int targetCapacity, length, sourceIndex;
	    char c, trail;
	    byte overflow[/*4*/] = new byte[4];
	
	    sourceArray=pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    length=pArgs.sourceLimit-sourceArrayIndex;
	    if(length<=0) {
	        /* no input, nothing to do */
	        return;
	    }
	
	    cnv=pArgs.converter;

	    /* write the BOM if necessary */
	    if(cnv.fromUnicodeStatus==UCNV_NEED_TO_WRITE_BOM) {
	        byte bom[]={ (byte)0xfe, (byte)0xff };
	        int[] targetBegin = {pArgs.targetBegin};
			int[] offsetsBegin = {pArgs.offsetsBegin};
			UConverterUtility.ucnv_fromUWriteBytes(cnv,
	                             bom, 0, 2,
	                             pArgs.targetArray, targetBegin, pArgs.targetLimit,
	                             pArgs.offsetsArray, offsetsBegin, -1,
	                             pErrorCode);
	        pArgs.targetBegin = targetBegin[0];
	        pArgs.offsetsBegin = offsetsBegin[0];
	        cnv.fromUnicodeStatus=0;
	    }
	    
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    if(targetCapacity<=0) {
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	        return;
	    }
	
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	    sourceIndex=0;
	
	    /* c!=0 indicates in several places outside the main loops that a surrogate was found */
	
	    if((c=(char)cnv.fromUChar32)!=0 && UConverterUTF16.U16_IS_TRAIL(trail=sourceArray[sourceArrayIndex]) && targetCapacity>=4) {
	        /* the last buffer ended with a lead surrogate, output the surrogate pair */
	        ++sourceArrayIndex;
	        --length;
	        targetArray[targetArrayIndex + 0]=(byte)(c>>>8);
	        targetArray[targetArrayIndex + 1]=(byte)c;
	        targetArray[targetArrayIndex + 2]=(byte)(trail>>>8);
	        targetArray[targetArrayIndex + 3]=(byte)trail;
	        targetArrayIndex+=4;
	        targetCapacity-=4;
	        if(offsetsArray!=null) {
						/*agljport:change 
	            *offsets++=-1;
	            *offsets++=-1;
	            *offsets++=-1;
	            *offsets++=-1;
							*/
	            offsetsArray[offsetsArrayIndex++]=-1;
	            offsetsArray[offsetsArrayIndex++]=-1;
	            offsetsArray[offsetsArrayIndex++]=-1;
	            offsetsArray[offsetsArrayIndex++]=-1;
	        }
	        sourceIndex=1;
	        cnv.fromUChar32=c=0;
	    }
		    
	    if(c==0) {
	    	/* copy an even number of bytes for complete UChars */
		    int count=2*length;
		    if(count>targetCapacity) {
		        count=targetCapacity&~1;
		    }	    	
	    	/* count is even */
	        targetCapacity-=count;
	        count>>=1;
	        length-=count;
	
	        if(offsetsArray==null) {
	            while(count>0) {
	                c=sourceArray[sourceArrayIndex++];
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex+0]=(byte)(c>>>8);
	                    targetArray[targetArrayIndex+1]=(byte)c;
	                    targetArrayIndex+=2;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 && UConverterUTF16.U16_IS_TRAIL(trail=sourceArray[sourceArrayIndex])) {
	                    ++sourceArrayIndex;
	                    --count;
	                    targetArray[targetArrayIndex+0]=(byte)(c>>>8);
	                    targetArray[targetArrayIndex+1]=(byte)c;
	                    targetArray[targetArrayIndex+2]=(byte)(trail>>>8);
	                    targetArray[targetArrayIndex+3]=(byte)trail;
	                    targetArrayIndex+=4;
	                } else {
	                    break;
	                }
	                --count;
	            }
	        } else {
	            while(count>0) {
	                c=sourceArray[sourceArrayIndex++];
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex+0]=(byte)(c>>>8);
	                    targetArray[targetArrayIndex+1]=(byte)c;
	                    targetArrayIndex+=2;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex++;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 && UConverterUTF16.U16_IS_TRAIL(trail=sourceArray[sourceArrayIndex])) {
	                    ++sourceArrayIndex;
	                    --count;
	                    targetArray[targetArrayIndex+0]=(byte)(c>>>8);
	                    targetArray[targetArrayIndex+1]=(byte)c;
	                    targetArray[targetArrayIndex+2]=(byte)(trail>>>8);
	                    targetArray[targetArrayIndex+3]=(byte)trail;
	                    targetArrayIndex+=4;
											/*agljport:change 
	                    *offsets++=sourceIndex;
	                    *offsets++=sourceIndex;
	                    *offsets++=sourceIndex;
	                    *offsets++=sourceIndex;
											*/
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    sourceIndex+=2;
	                } else {
	                    break;
	                }
	                --count;
	            }
	        }
	
	        if(count==0) {
	            /* done with the loop for complete UChars */
	            if(length>0 && targetCapacity>0) {
	                /*
	                 * there is more input and some target capacity -
	                 * it must be targetCapacity==1 because otherwise
	                 * the above would have copied more;
	                 * prepare for overflow output
	                 */
	                if(UConverterUTF16.U16_IS_SINGLE(c=sourceArray[sourceArrayIndex++])) {
	                    overflow[0]=(byte)(c>>>8);
	                    overflow[1]=(byte)c;
	                    length=2; /* 2 bytes to output */
	                    c=0;
	                /* } else { keep c for surrogate handling, length will be set there */
	                }
	            } else {
	                length=0;
	                c=0;
	            }
	        } else {
	            /* keep c for surrogate handling, length will be set there */
	            targetCapacity+=2*count;
	        }
	    } else {
	        length=0; /* from here on, length counts the bytes in overflow[] */
	    }
	    
	    if(c!=0) {
	        /*
	         * c is a surrogate, and
	         * - source or target too short
	         * - or the surrogate is unmatched
	         */
	        length=0;
	        if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c)) {
	            if(sourceArrayIndex<pArgs.sourceLimit) {
	                if(UConverterUTF16.U16_IS_TRAIL(trail=sourceArray[sourceArrayIndex])) {
	                    /* output the surrogate pair, will overflow (see conditions comment above) */
	                    ++sourceArrayIndex;
	                    overflow[0]=(byte)(c>>>8);
	                    overflow[1]=(byte)c;
	                    overflow[2]=(byte)(trail>>>8);
	                    overflow[3]=(byte)trail;
	                    length=4; /* 4 bytes to output */
	                    c=0;
	                } else {
	                    /* unmatched lead surrogate */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                }
	            } else {
	                /* see if the trail surrogate is in the next buffer */
	            }
	        } else {
	            /* unmatched trail surrogate */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        }
	        cnv.fromUChar32=c;
	    }
	
	    if(length>0) {
	        /* output length bytes with overflow (length>targetCapacity>0) */
					int[] targetBegin = {targetArrayIndex};
					int[] offsetsBegin = {offsetsArrayIndex};
					UConverterUtility.ucnv_fromUWriteBytes(cnv, overflow, 0, length, targetArray, targetBegin, pArgs.targetLimit, offsetsArray, offsetsBegin, sourceIndex, pErrorCode);
					targetArrayIndex = targetBegin[0];
					offsetsArrayIndex = offsetsBegin[0];
	        targetCapacity=pArgs.targetLimit-targetArrayIndex;
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0]) && sourceArrayIndex<pArgs.sourceLimit && targetCapacity==0) {
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	//static void _UTF16BEToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	public final void _UTF16BEToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    byte[] sourceArray;
		int sourceArrayIndex;
	    char[] targetArray;
		int targetArrayIndex;
	    int[] offsetsArray;
		int offsetsArrayIndex;
	
	    int targetCapacity, length, count, sourceIndex;
	    char c, trail;
	
	    cnv=pArgs.converter;
	    sourceArray=pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    length=pArgs.sourceLimit-sourceArrayIndex;
	    if(length<=0 && cnv.toUnicodeStatus==0) {
	        /* no input, nothing to do */
	        return;
	    }
	
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    if(targetCapacity<=0) {
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	        return;
	    }
	
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	    sourceIndex=0;
	    c=0;
	
	    /* complete a partial UChar or pair from the last call */
	    if(cnv.toUnicodeStatus!=0) {
	        /*
	         * special case: single byte from a previous buffer,
	         * where the byte turned out not to belong to a trail surrogate
	         * and the preceding, unmatched lead surrogate was put into toUBytes[]
	         * for error handling
	         */
	        cnv.toUBytesArray[cnv.toUBytesBegin+0]=(byte)cnv.toUnicodeStatus;
	        cnv.toULength=1;
	        cnv.toUnicodeStatus=0;
	    }
	    if((count=cnv.toULength)!=0) {
	        byte[] pArray=cnv.toUBytesArray;
					int pArrayIndex = cnv.toUBytesBegin;
	        do {
	            pArray[count++]=sourceArray[sourceArrayIndex++];
	            ++sourceIndex;
	            --length;
	            if(count==2) {
	                c=(char)(((pArray[pArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    /* output the BMP code point */
	                    targetArray[targetArrayIndex++]=c;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=-1;
	                    }
	                    --targetCapacity;
	                    count=0;
	                    c=0;
	                    break;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c)) {
	                    /* continue collecting bytes for the trail surrogate */
	                    c=0; /* avoid unnecessary surrogate handling below */
	                } else {
	                    /* fall through to error handling for an unmatched trail surrogate */
	                    break;
	                }
	            } else if(count==4) {
	                c=(char)(((pArray[pArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                trail=(char)(((pArray[pArrayIndex+2]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+3]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    /* output the surrogate pair */
	                    targetArray[targetArrayIndex++]=c;
	                    if(targetCapacity>=2) {
	                        targetArray[targetArrayIndex++]=trail;
	                        if(offsetsArray!=null) {
	                            offsetsArray[offsetsArrayIndex++]=-1;
	                            offsetsArray[offsetsArrayIndex++]=-1;
	                        }
	                        targetCapacity-=2;
	                    } else /* targetCapacity==1 */ {
	                        targetCapacity=0;
	                        cnv.UCharErrorBufferArray[cnv.UCharErrorBufferBegin+0]=trail;
	                        cnv.UCharErrorBufferLength=1;
	                        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    }
	                    count=0;
	                    c=0;
	                    break;
	                } else {
	                    /* unmatched lead surrogate, handle here for consistent toUBytes[] */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	
	                    /* back out reading the code unit after it */
	                    if((pArgs.sourceBegin-sourceArrayIndex)>=2) {
	                        sourceArrayIndex-=2;
	                    } else {
	                        /*
	                         * if the trail unit's first byte was in a previous buffer, then
	                         * we need to put it into a special place because toUBytes[] will be
	                         * used for the lead unit's bytes
	                         */
	                        cnv.toUnicodeStatus=0x100|pArray[pArrayIndex+2];
	                        --sourceArrayIndex;
	                    }
	                    cnv.toULength=2;
	
	                    /* write back the updated pointers */
	                    pArgs.sourceArray=sourceArray;
	                    pArgs.sourceBegin=sourceArrayIndex;
	                    pArgs.targetArray=targetArray;
	                    pArgs.targetBegin=targetArrayIndex;
	                    pArgs.offsetsArray=offsetsArray;
	                    pArgs.offsetsBegin=offsetsArrayIndex;
	                    return;
	                }
	            }
	        } while(length>0);
	        cnv.toULength=(byte)count;
	    }
	
	    /* copy an even number of bytes for complete UChars */
	    count=2*targetCapacity;
	    if(count>length) {
	        count=length&~1;
	    }
	    if(c==0 && count>0) {
	        length-=count;
	        count>>=1;
	        targetCapacity-=count;
	        if(offsetsArray==null) {
	            do {
	                c=(char)(((sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                sourceArrayIndex+=2;
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex++]=c;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 &&
	                          UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)))
	                ) {
	                    sourceArrayIndex+=2;
	                    --count;
	                    targetArray[targetArrayIndex++]=c;
	                    targetArray[targetArrayIndex++]=trail;
	                } else {
	                    break;
	                }
	            } while(--count>0);
	        } else {
	            do {
	                c=(char)(((sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                sourceArrayIndex+=2;
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex++]=c;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    sourceIndex+=2;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 &&
	                          UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)))
	                ) {
	                    sourceArrayIndex+=2;
	                    --count;
	                    targetArray[targetArrayIndex++]=c;
	                    targetArray[targetArrayIndex++]=trail;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    sourceIndex+=4;
	                } else {
	                    break;
	                }
	            } while(--count>0);
	        }
	
	        if(count==0) {
	            /* done with the loop for complete UChars */
	            c=0;
	        } else {
	            /* keep c for surrogate handling, trail will be set there */
	            length+=2*(count-1); /* one more byte pair was consumed than count decremented */
	            targetCapacity+=count;
	        }
	    }
	
	    if(c!=0) {
	        /*
	         * c is a surrogate, and
	         * - source or target too short
	         * - or the surrogate is unmatched
	         */
	        cnv.toUBytesArray[cnv.toUBytesBegin+0]=(byte)(c>>>8);
	        cnv.toUBytesArray[cnv.toUBytesBegin+1]=(byte)c;
	        cnv.toULength=2;
	
	        if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c)) {
	            if(length>=2) {
	                if(UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)))) {
	                    /* output the surrogate pair, will overflow (see conditions comment above) */
	                    sourceArrayIndex+=2;
	                    length-=2;
	                    targetArray[targetArrayIndex++]=c;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                    cnv.UCharErrorBufferArray[cnv.UCharErrorBufferBegin+0]=trail;
	                    cnv.UCharErrorBufferLength=1;
	                    cnv.toULength=0;
	                    pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                } else {
	                    /* unmatched lead surrogate */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                }
	            } else {
	                /* see if the trail surrogate is in the next buffer */
	            }
	        } else {
	            /* unmatched trail surrogate */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        }
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0])) {
	        /* check for a remaining source byte */
	        if(length>0) {
	            if(targetCapacity==0) {
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            } else {
	                /* it must be length==1 because otherwise the above would have copied more */
	                cnv.toUBytesArray[cnv.toULength++]=sourceArray[sourceArrayIndex++];
	            }
	        }
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	// UTF-16LE
	//static void _UTF16LEToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	public final void _UTF16LEToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv;
	    byte[] sourceArray;
			int sourceArrayIndex;
	    char[] targetArray;
			int targetArrayIndex;
	    int[] offsetsArray;
			int offsetsArrayIndex;
	
	    int targetCapacity, length, count, sourceIndex;
	    char c, trail;
	
	    cnv=pArgs.converter;
	    sourceArray=pArgs.sourceArray;
	    sourceArrayIndex=pArgs.sourceBegin;
	    length=pArgs.sourceLimit-sourceArrayIndex;
	    if(length<=0 && cnv.toUnicodeStatus==0) {
	        /* no input, nothing to do */
	        return;
	    }
	
	    targetCapacity=pArgs.targetLimit-pArgs.targetBegin;
	    if(targetCapacity<=0) {
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	        return;
	    }
	
	    targetArray=pArgs.targetArray;
	    targetArrayIndex=pArgs.targetBegin;
	    offsetsArray=pArgs.offsetsArray;
	    offsetsArrayIndex=pArgs.offsetsBegin;
	    sourceIndex=0;
	    c=0;
	
	    /* complete a partial UChar or pair from the last call */
	    if(cnv.toUnicodeStatus!=0) {
	        /*
	         * special case: single byte from a previous buffer,
	         * where the byte turned out not to belong to a trail surrogate
	         * and the preceding, unmatched lead surrogate was put into toUBytes[]
	         * for error handling
	         */
	        cnv.toUBytesArray[cnv.toUBytesBegin+0]=(byte)cnv.toUnicodeStatus;
	        cnv.toULength=1;
	        cnv.toUnicodeStatus=0;
	    }
	    if((count=cnv.toULength)!=0) {
	        byte[] pArray=cnv.toUBytesArray;
					int pArrayIndex = cnv.toUBytesBegin;
	        do {
	            pArray[count++]=sourceArray[sourceArrayIndex++];
	            ++sourceIndex;
	            --length;
	            if(count==2) {
	                c=(char)(((pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    /* output the BMP code point */
	                    targetArray[targetArrayIndex++]=c;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=-1;
	                    }
	                    --targetCapacity;
	                    count=0;
	                    c=0;
	                    break;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c)) {
	                    /* continue collecting bytes for the trail surrogate */
	                    c=0; /* avoid unnecessary surrogate handling below */
	                } else {
	                    /* fall through to error handling for an unmatched trail surrogate */
	                    break;
	                }
	            } else if(count==4) {
	                c=(char)(((pArray[pArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                trail=(char)(((pArray[pArrayIndex+3]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(pArray[pArrayIndex+2]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                if(UConverterUTF16.U16_IS_TRAIL(trail)) {
	                    /* output the surrogate pair */
	                    targetArray[targetArrayIndex++]=c;
	                    if(targetCapacity>=2) {
	                        targetArray[targetArrayIndex++]=trail;
	                        if(offsetsArray!=null) {
	                            offsetsArray[offsetsArrayIndex++]=-1;
	                            offsetsArray[offsetsArrayIndex++]=-1;
	                        }
	                        targetCapacity-=2;
	                    } else /* targetCapacity==1 */ {
	                        targetCapacity=0;
	                        cnv.UCharErrorBufferArray[cnv.UCharErrorBufferBegin+0]=trail;
	                        cnv.UCharErrorBufferLength=1;
	                        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                    }
	                    count=0;
	                    c=0;
	                    break;
	                } else {
	                    /* unmatched lead surrogate, handle here for consistent toUBytes[] */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	
	                    /* back out reading the code unit after it */
	                    if((pArgs.sourceBegin-sourceArrayIndex)>=2) {
	                        sourceArrayIndex-=2;
	                    } else {
	                        /*
	                         * if the trail unit's first byte was in a previous buffer, then
	                         * we need to put it into a special place because toUBytes[] will be
	                         * used for the lead unit's bytes
	                         */
	                        cnv.toUnicodeStatus=0x100|pArray[pArrayIndex+2];
	                        --sourceArrayIndex;
	                    }
	                    cnv.toULength=2;
	
	                    /* write back the updated pointers */
	                    pArgs.sourceArray=sourceArray;
	                    pArgs.sourceBegin=sourceArrayIndex;
	                    pArgs.targetArray=targetArray;
	                    pArgs.targetBegin=targetArrayIndex;
	                    pArgs.offsetsArray=offsetsArray;
	                    pArgs.offsetsBegin=offsetsArrayIndex;
	                    return;
	                }
	            }
	        } while(length>0);
	        cnv.toULength=(byte)count;
	    }
	
	    /* copy an even number of bytes for complete UChars */
	    count=2*targetCapacity;
	    if(count>length) {
	        count=length&~1;
	    }
	    if(c==0 && count>0) {
	        length-=count;
	        count>>=1;
	        targetCapacity-=count;
	        if(offsetsArray==null) {
	            do {
	                c=(char)(((sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                sourceArrayIndex+=2;
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex++]=c;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 &&
	                          UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)))
	                ) {
	                    sourceArrayIndex+=2;
	                    --count;
	                    targetArray[targetArrayIndex++]=c;
	                    targetArray[targetArrayIndex++]=trail;
	                } else {
	                    break;
	                }
	            } while(--count>0);
	        } else {
	            do {
	                c=(char)(((sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK));
	                sourceArrayIndex+=2;
	                if(UConverterUTF16.U16_IS_SINGLE(c)) {
	                    targetArray[targetArrayIndex++]=c;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    sourceIndex+=2;
	                } else if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c) && count>=2 &&
	                          UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)))
	                ) {
	                    sourceArrayIndex+=2;
	                    --count;
	                    targetArray[targetArrayIndex++]=c;
	                    targetArray[targetArrayIndex++]=trail;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    sourceIndex+=4;
	                } else {
	                    break;
	                }
	            } while(--count>0);
	        }
	
	        if(count==0) {
	            /* done with the loop for complete UChars */
	            c=0;
	        } else {
	            /* keep c for surrogate handling, trail will be set there */
	            length+=2*(count-1); /* one more byte pair was consumed than count decremented */
	            targetCapacity+=count;
	        }
	    }
	
	    if(c!=0) {
	        /*
	         * c is a surrogate, and
	         * - source or target too short
	         * - or the surrogate is unmatched
	         */
	        cnv.toUBytesArray[cnv.toUBytesBegin+0]=(byte)c;
	        cnv.toUBytesArray[cnv.toUBytesBegin+1]=(byte)(c>>>8);
	        cnv.toULength=2;
	
	        if(UConverterUTF16.U16_IS_SURROGATE_LEAD(c)) {
	            if(length>=2) {
	                if(UConverterUTF16.U16_IS_TRAIL(trail=(char)(((sourceArray[sourceArrayIndex+1]&UConverterUtility.UNSIGNED_BYTE_MASK)<<8)|(sourceArray[sourceArrayIndex+0]&UConverterUtility.UNSIGNED_BYTE_MASK)))) {
	                    /* output the surrogate pair, will overflow (see conditions comment above) */
	                    sourceArrayIndex+=2;
	                    length-=2;
	                    targetArray[targetArrayIndex++]=c;
	                    if(offsetsArray!=null) {
	                        offsetsArray[offsetsArrayIndex++]=sourceIndex;
	                    }
	                    cnv.UCharErrorBufferArray[cnv.UCharErrorBufferBegin+0]=trail;
	                    cnv.UCharErrorBufferLength=1;
	                    cnv.toULength=0;
	                    pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	                } else {
	                    /* unmatched lead surrogate */
	                    pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	                }
	            } else {
	                /* see if the trail surrogate is in the next buffer */
	            }
	        } else {
	            /* unmatched trail surrogate */
	            pErrorCode[0]=ErrorCode.U_ILLEGAL_CHAR_FOUND;
	        }
	    }
	
	    if(ErrorCode.isSuccess(pErrorCode[0])) {
	        /* check for a remaining source byte */
	        if(length>0) {
	            if(targetCapacity==0) {
	                pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            } else {
	                /* it must be length==1 because otherwise the above would have copied more */
	                cnv.toUBytesArray[cnv.toULength++]=sourceArray[sourceArrayIndex++];
	            }
	        }
	    }
	
	    /* write back the updated pointers */
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	    pArgs.targetArray=targetArray;
	    pArgs.targetBegin=targetArrayIndex;
	    pArgs.offsetsArray=offsetsArray;
	    pArgs.offsetsBegin=offsetsArrayIndex;
	}
	
	/* UTF-16 (Detect BOM) ------------------------------------------------------ */
	
	/*
	 * Detect a BOM at the beginning of the stream and select UTF-16BE or UTF-16LE
	 * accordingly.
	 * This is a simpler version of the UTF-32 converter below, with
	 * fewer states for shorter BOMs.
	 *
	 * State values:
	 * 0    initial state
	 * 1    saw FE
	 * 2..4 -
	 * 5    saw FF
	 * 6..7 -
	 * 8    UTF-16BE mode
	 * 9    UTF-16LE mode
	 *
	 * During detection: state&3==number of matching bytes so far.
	 *
	 * On output, emit U+FEFF as the first code point.
	 */
	
	//static void _UTF16Reset(UConverter *cnv, UConverterResetChoice choice) {
	protected void _UTF16Reset(UConverter cnv, int choice)
	{
	    if(choice<=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        /* reset toUnicode: state=0 */
	        cnv.mode=0;
	    }
	    if(choice!=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        /* reset fromUnicode: prepare to output the UTF-16PE BOM */
	    	cnv.fromUnicodeStatus=UCNV_NEED_TO_WRITE_BOM;
	    }
	}
	
	//static void _UTF16Open(UConverter *cnv, const char *name, const char *locale, uint32_t options, UErrorCode *pErrorCode)
	protected void _UTF16Open(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
	    _UTF16Reset(cnv, UConverterConstants.UConverterResetChoice.UCNV_RESET_BOTH);
	}
	
	protected static final byte utf16BOM[/*8*/]={ (byte)0xfe, (byte)0xff, 0, 0,    (byte)0xff, (byte)0xfe, 0, 0 };
	
	//static void _UTF16ToUnicodeWithOffsets(UConverterToUnicodeArgs *pArgs, UErrorCode *pErrorCode)
	protected void _UTF16ToUnicodeWithOffsets(UConverterToUnicodeArgs pArgs, int[] pErrorCode)
	{
	    UConverter cnv=pArgs.converter;
	    byte[] sourceArray=pArgs.sourceArray;
			int sourceArrayIndex = pArgs.sourceBegin;
	    int sourceLimit=pArgs.sourceLimit;
	    int[] offsetsArray=pArgs.offsetsArray;
			int offsetsArrayIndex = pArgs.offsetsBegin;
	
	    int state, offsetDelta;
	    byte b;
	
	    state=cnv.mode;
	
	    /*
	     * If we detect a BOM in this buffer, then we must add the BOM size to the
	     * offsets because the actual converter function will not see and count the BOM.
	     * offsetDelta will have the number of the BOM bytes that are in the current buffer.
	     */
	    offsetDelta=0;
	
	    while(sourceArrayIndex<sourceLimit && ErrorCode.isSuccess(pErrorCode[0])) {
	        switch(state) {
	        case 0:
	            b=sourceArray[sourceArrayIndex];
	            if(b==(byte)0xfe) {
	                state=1; /* could be FE FF */
	            } else if(b==(byte)0xff) {
	                state=5; /* could be FF FE */
	            } else {
	                state=8; /* default to UTF-16BE */
	                continue;
	            }
	            ++sourceArrayIndex;
	            break;
	        case 1:
	        case 5:
	            if(sourceArray[sourceArrayIndex]==utf16BOM[state]) {
	                ++sourceArrayIndex;
	                if(state==1) {
	                    state=8; /* detect UTF-16BE */
	                    offsetDelta=sourceArrayIndex-pArgs.sourceBegin;
	                } else if(state==5) {
	                    state=9; /* detect UTF-16LE */
	                    offsetDelta=sourceArrayIndex-pArgs.sourceBegin;
	                }
	            } else {
	                /* switch to UTF-16BE and pass the previous bytes */
	                if(sourceArrayIndex!=pArgs.sourceBegin) {
	                    /* just reset the source */
	                    sourceArrayIndex=pArgs.sourceBegin;
	                } else {
	                    boolean oldFlush=pArgs.flush;
	
	                    /* the first byte is from a previous buffer, replay it first */
	                    pArgs.sourceArray=utf16BOM; /* select the correct BOM */
	                    pArgs.sourceBegin=state&4; /* select the correct BOM */
	                    pArgs.sourceLimit=pArgs.sourceBegin+1; /* replay previous byte */
	                    pArgs.flush=false; /* this sourceLimit is not the real source stream limit */
	
	                    _UTF16BEToUnicodeWithOffsets(pArgs, pErrorCode);
	
	                    /* restore real pointers; pArgs->source will be set in case 8/9 */
	                    pArgs.sourceLimit=sourceLimit;
	                    pArgs.flush=oldFlush;
	                }
	                state=8;
	                continue;
	            }
	            break;
	        case 8:
	            /* call UTF-16BE */
	            pArgs.sourceArray=sourceArray;
							pArgs.sourceBegin=sourceArrayIndex;
	            _UTF16BEToUnicodeWithOffsets(pArgs, pErrorCode);
	            sourceArray=pArgs.sourceArray;
							sourceArrayIndex=pArgs.sourceBegin;
	            break;
	        case 9:
	            /* call UTF-16LE */
	            pArgs.sourceArray=sourceArray;
							pArgs.sourceBegin=sourceArrayIndex;
	            _UTF16LEToUnicodeWithOffsets(pArgs, pErrorCode);
	            sourceArray=pArgs.sourceArray;
							sourceArrayIndex=pArgs.sourceBegin;
	            break;
	        default:
	            break; /* does not occur */
	        }
	    }
	
	    /* add BOM size to offsets - see comment at offsetDelta declaration */
	    if(offsetsArray!=null && offsetDelta!=0) {
	        int offsetsLimit=pArgs.offsetsBegin;
	        while(offsetsArrayIndex<offsetsLimit) {
	            offsetsArray[offsetsArrayIndex++] += offsetDelta;
	        }
	    }
	
	    pArgs.sourceArray=sourceArray;
	    pArgs.sourceBegin=sourceArrayIndex;
	
	    if(sourceArrayIndex==sourceLimit && pArgs.flush) {
	        /* handle truncated input */
	        switch(state) {
	        case 0:
	            break; /* no input at all, nothing to do */
	        case 8:
	            _UTF16BEToUnicodeWithOffsets(pArgs, pErrorCode);
	            break;
	        case 9:
	            _UTF16LEToUnicodeWithOffsets(pArgs, pErrorCode);
	            break;
	        default:
	            /* handle 0<state<8: call UTF-16BE with too-short input */
	            pArgs.sourceArray=utf16BOM; /* select the correct BOM */
	            pArgs.sourceBegin=state&4; /* select the correct BOM */
	            pArgs.sourceLimit=state&3; /* replay bytes */
	
	            /* no offsets: not enough for output */
	            _UTF16BEToUnicodeWithOffsets(pArgs, pErrorCode);
	            pArgs.sourceArray=sourceArray;
	            pArgs.sourceBegin=sourceArrayIndex;
	            pArgs.sourceLimit=sourceLimit;
	            state=8;
	            break;
	        }
	    }
	
	    cnv.mode=state;
	}
	/*
	static const UConverterImpl _UTF16BEImpl={
	    UCNV_UTF16_BigEndian,
	
	    NULL,
	    NULL,
	
	    NULL,
	    NULL,
	    NULL,
	
	    _UTF16ToUnicodeWithOffsets,
	    _UTF16ToUnicodeWithOffsets,
	    _UTF16BEFromUnicodeWithOffsets,
	    _UTF16BEFromUnicodeWithOffsets,
	    _UTF16BEGetNextUChar,
	
	    NULL,
	    NULL,
	    NULL,
	    NULL,
	    ucnv_getNonSurrogateUnicodeSet
	};
	
	static const UConverterStaticData _UTF16StaticData = {
	    sizeof(UConverterStaticData),
	    "UTF-16",
	    1204, // CCSID for BOM sensitive UTF-16 
	    UCNV_IBM, UCNV_UTF16, 2, 2,
	#if U_IS_BIG_ENDIAN
	    { 0xff, 0xfd, 0, 0 }, 2,
	#else
	    { 0xfd, 0xff, 0, 0 }, 2,
	#endif
	    FALSE, FALSE,
	    0,
	    0,
	    { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
	};
	
	const UConverterSharedData _UTF16Data = {
	    sizeof(UConverterSharedData), ~((uint32_t) 0),
	    NULL, NULL, &_UTF16StaticData, FALSE, &_UTF16Impl, 
	    0
	};
	*/
	
	public static UConverterStaticData _UTF16StaticData;
	public static UConverterSharedData_UTF16 _UTF16Data;
	
	static
	{
	
		_UTF16StaticData= new UConverterStaticData (
		    UConverterStaticData.sizeofUConverterStaticData,
		    "UTF-16",
		    1204, /* CCSID for BOM sensitive UTF-16 */
		    (byte)UConverterPlatform.UCNV_IBM, (byte)UConverterType.UCNV_UTF16, (byte)2, (byte)2,
		    new byte[]{ (byte)0xff, (byte)0xfd, 0, 0 },(byte)2,(byte)0,(byte)0,
		    (short)0,
		    (byte)0,
		    new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
		);
		
		
		_UTF16Data= new UConverterSharedData_UTF16(
		    sizeofUConverterSharedData, ~0,
		    /*NULL, NULL,*/ _UTF16StaticData, false, /*&_UTF16BEImpl,*/
		    0
		);
	
	}

}
