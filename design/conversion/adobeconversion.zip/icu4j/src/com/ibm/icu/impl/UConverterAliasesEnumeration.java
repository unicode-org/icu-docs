package com.ibm.icu.impl;

import com.ibm.icu.common.ErrorCode;

/**
 * Enumeration for Converter Aliases
 */

public class UConverterAliasesEnumeration implements UEnumeration {

	private UAliasContext context;
	
	/* Set alias context
	 */	
	public void setContext(UAliasContext context){
		this.context = context;		
	}
	
	//static int32_t U_CALLCONV ucnv_io_countStandardAliases(UEnumeration *enumerator, UErrorCode *pErrorCode) 
	public int count(int[] status) {
		int value = 0;
	    
	    if (context.listOffset!=0) {
	        value = UConverterAlias.gTaggedAliasListsArray[(int)context.listOffset];
	    }
	    return value;
	}

	//U_CAPI const UChar* U_EXPORT2 uenum_unextDefault(UEnumeration* en, int32_t* resultLength, UErrorCode* status)
	public String uNext(int[] status) {
	
		if (context.listOffset!=0) {
	        long listCount = UConverterAlias.gTaggedAliasListsArray[(int)context.listOffset];
	        int[] currListArray = UConverterAlias.gTaggedAliasListsArray;
	        long currListArrayIndex = context.getListOffset() + 1; 

	        if (context.getListIdx() < listCount) {
	            String str = UConverterAlias.GET_STRING(currListArray[(int)(context.listIdx+currListArrayIndex)]);
	            context.listIdx++;
	            return str;
	        }
	    }
	    /* Either we accessed a zero length list, or we enumerated too far. */
	    status[0] = ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR;
	    return null;
	}

	//static void U_CALLCONV ucnv_io_resetStandardAliases(UEnumeration *enumerator, UErrorCode *pErrorCode)
	public void reset(int[] status) {
		context.listIdx = 0;
	}

	/**
	 * Class to store context for alias
	 */
	public static class UAliasContext{
		private long listOffset;
		private long listIdx;
		
		public UAliasContext(long listOffset, long listIdx){
			this.listOffset = listOffset;
			this.listIdx = listIdx;
		}
		
		public long getListOffset(){
			return listOffset;
		}
		
		public long getListIdx(){
			return listIdx;
		}
	}
}
