package com.ibm.icu.impl;

import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;

import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;
import com.ibm.icu.impl.UConverterConstants;

public final class UConverterUtility {

	public static final short UNSIGNED_BYTE_MASK = 0xff;
	public static final int UNSIGNED_SHORT_MASK = 0xffff;
	public static final long UNSIGNED_INT_MASK = 0xffffffffL;
	
	//string.h
	public static final int uprv_memcpy(byte[] destArray, int destBegin, byte[] srcArray, int srcBegin, int len)
	{
		return uprv_memmove(destArray, destBegin, srcArray, srcBegin, len);
	}
	
	public static final int uprv_memcpy(char[] destArray, int destBegin, char[] srcArray, int srcBegin, int len)
	{
		System.arraycopy(srcArray, srcBegin, destArray, destBegin, len);
		return destBegin;
	}
	
	public static final int uprv_memmove(char[] destArray, int destBegin, char[] srcArray, int srcBegin, int len)
	{
		System.arraycopy(srcArray, srcBegin, destArray, destBegin, len);
		return destBegin;
	}
	
	public static final int uprv_memmove(byte[] destArray, int destBegin, byte[] srcArray, int srcBegin, int len)
	{
		System.arraycopy(srcArray, srcBegin, destArray, destBegin, len);
		return destBegin;
	}
	
	public static final int uprv_strcmp(byte[] s1Array, int s1Begin, byte[] s2Array, int s2Begin)
	{
		String s1 = new String(s1Array, s1Begin, uprv_strlen(s1Array, s1Begin));
		String s2 = new String(s2Array, s2Begin, uprv_strlen(s2Array, s2Begin));
		return s1.compareTo(s2);
	}
	
	public static final int uprv_strcmp(byte[] s1Array, int s1Begin, String s2)
	{
		String s1 = new String(s1Array, s1Begin, uprv_strlen(s1Array, s1Begin));
		return s1.compareTo(s2);
	}
	
	public static final int uprv_strncmp(String s1, String s2, int n)
	{
		int s1Len = s1.length();
		int s2Len = s2.length();
		int n1 = n < s1Len? n : s1Len;
		int n2 = n < s2Len? n : s2Len;
		return s1.substring(0, n1).compareTo(s2.substring(0,n2));
	}
	
	public static final int uprv_strncmp(byte[] s1Array, int s1Begin, String s2, int n)
	{
		String s1 = new String(s1Array, s1Begin, uprv_strlen(s1Array, s1Begin));
		return uprv_strncmp(s1, s2, n);
	}
	
	public static final int uprv_strncmp(byte[] s1Array, int s1Begin, byte[] s2Array, int s2Begin, int n)
	{
		String s1 = new String(s1Array, s1Begin, uprv_strlen(s1Array, s1Begin));
		String s2 = new String(s2Array, s2Begin, uprv_strlen(s2Array, s2Begin));
		return uprv_strncmp(s1, s2, n);
	}
	
	// since array indexes are int, it does not make sense to take long or return long
	public static final int uprv_strlen(byte[] sArray, int sBegin)
	{
		int i = sBegin;
		while(i < sArray.length && sArray[i++] != 0) {}
		return i - sBegin - 1;
	}
	
	//#if U_CHARSET_FAMILY==U_ASCII_FAMILY
	//#   define uprv_tolower uprv_asciitolower
	public static final char uprv_tolower(char c)
	{
		return uprv_asciitolower(c);
	}
	//#elif U_CHARSET_FAMILY==U_EBCDIC_FAMILY
	//#   define uprv_tolower uprv_ebcdictolower
	//#else
	//#   error U_CHARSET_FAMILY is not valid
	//#endif
	
	public static final char uprv_asciitolower(char c) {
	    if(0x41<=c && c<=0x5a) {
	        c=(char)(c+0x20);
	    }
	    return c;
	}
	
	private static String defaultEncoding;
	
	//U_CAPI const char*  U_EXPORT2 uprv_getDefaultCodepage()
	public static final String uprv_getDefaultCodepage()
	{
	    //agljport:todo umtx_lock(NULL);
	    if (defaultEncoding == null) {
				String defaultEncoding = new InputStreamReader(new ByteArrayInputStream(new byte[0])).getEncoding();
	    }
	    //agljport:todo umtx_unlock(NULL);
	    return defaultEncoding;
	}
	
	//end ucnv_cnv.h
	
	/** Always use fallbacks from codepage to Unicode */
	public static final boolean TO_U_USE_FALLBACK(boolean useFallback) {return true;}
	public static final boolean UCNV_TO_U_USE_FALLBACK(UConverter cnv) {return true;}
	
	/** Use fallbacks from Unicode to codepage when cnv->useFallback or for private-use code points */
	public static final boolean IS_PRIVATE_USE(int c) {return (((c)-0xe000)<0x1900 || ((c)-0xf0000)<0x20000);}
	public static final boolean FROM_U_USE_FALLBACK(boolean useFallback, int c) {return ((useFallback) || IS_PRIVATE_USE(c));}
	public static final boolean UCNV_FROM_U_USE_FALLBACK(UConverter cnv, int c) {return FROM_U_USE_FALLBACK(cnv.useFallback, c);}
	
	//ucnv_cnv.c

	//U_CFUNC void ucnv_fromUWriteBytes(UConverter *cnv, char *bytes, int32_t length, char **target, char *targetLimit, int32_t **offsets, int32_t sourceIndex, UErrorCode *pErrorCode)
	public static final void ucnv_fromUWriteBytes(UConverter cnv, byte[] bytesArray, int bytesBegin, int length, byte[] targetArray, int[] targetBegin, int targetLimit, int[] offsetsArray, int[] offsetsBegin, int sourceIndex, int[] pErrorCode)
	{
		byte[] tArray = targetArray;
		int tIndex = targetBegin[0];
		int[] oArray;
		int oIndex;
	
	    /* write bytes */
		oIndex = offsetsBegin[0];
	    if((oArray=offsetsArray)==null) {
	        while(length>0 && tIndex<targetLimit) {
	            tArray[tIndex++]=bytesArray[bytesBegin++];
	            --length;
	        }
	    } else {
	        /* output with offsets */
	        while(length>0 && tIndex<targetLimit) {
	            tArray[tIndex++]=bytesArray[bytesBegin++];
	            oArray[oIndex++]=sourceIndex;
	            --length;
	        }
	        offsetsBegin[0]=oIndex;
	    }
	    targetBegin[0]=tIndex;
	
	    /* write overflow */
	    if(length>0) {
	        if(cnv!=null) {
	            tArray=cnv.charErrorBufferArray;
	            cnv.charErrorBufferLength=(byte)length;
	            do {
	                tArray[tIndex++]=bytesArray[bytesBegin++];
	            } while(--length>0);
	        }
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	}

	//U_CFUNC void ucnv_toUWriteUChars(UConverter *cnv, UChar *uchars, int32_t length, UChar **target, UChar *targetLimit, int32_t **offsets, int32_t sourceIndex, UErrorCode *pErrorCode)
	public static final void ucnv_toUWriteUChars(UConverter cnv, char[] ucharsArray, int ucharsBegin, int length, char[] targetArray, int[] targetBegin, int targetLimit, int[] offsetsArray, int[] offsetsBegin, int sourceIndex, int[] pErrorCode) 
	{
		char[] tArray = targetArray;
		int tIndex = targetBegin[0];

		int[] oArray;
		int oIndex;
	
	    /* write UChars */
		oIndex = offsetsBegin[0];
	    if((oArray=offsetsArray)==null) {
	        while(length>0 && tIndex<targetLimit) {
	            tArray[tIndex++]=ucharsArray[ucharsBegin++];
	            --length;
	        }
	    } else {
	        /* output with offsets */
	        while(length>0 && tIndex<targetLimit) {
	            tArray[tIndex++]=ucharsArray[ucharsBegin++];
	            oArray[oIndex++]=sourceIndex;
	            --length;
	        }
	        offsetsBegin[0]=oIndex;
	    }
	    targetBegin[0]=tIndex;
	
	    /* write overflow */
	    if(length>0) {
	        if(cnv!=null) {
	            tArray=cnv.UCharErrorBufferArray;
	            cnv.UCharErrorBufferLength=(byte)length;
	            do {
	                tArray[tIndex++]=ucharsArray[ucharsBegin++];
	            } while(--length>0);
	        }
	        pErrorCode[0]=ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	    }
	}
	
	//	 ucnv_cb.c
	
	/* need to update the offsets when the target moves. */
	/* Note: Recursion may occur in the cb functions, be sure to update the offsets correctly
	if you don't use ucnv_cbXXX functions.  Make sure you don't use the same callback within
	the same call stack if the complexity arises. */
	//U_CAPI void  U_EXPORT2 ucnv_cbFromUWriteBytes (UConverterFromUnicodeArgs *args, const char* source, int32_t length, int32_t offsetIndex, UErrorCode * err)
	public static final void ucnv_cbFromUWriteBytes (UConverterFromUnicodeArgs args, byte[] sourceArray, int sourceBegin, int length, int offsetIndex, int[] err)
	{
	    if(ErrorCode.isFailure(err[0])) {
	        return;
	    }
	
		int[] targetBegin_param = new int[] {args.targetBegin};
		int[] offsetsBegin_param = new int[] {args.offsetsBegin};
	    UConverterUtility.ucnv_fromUWriteBytes(args.converter, sourceArray, sourceBegin, length, args.targetArray, targetBegin_param, args.targetLimit, args.offsetsArray, offsetsBegin_param, offsetIndex, err);
		args.targetBegin = targetBegin_param[0];
		args.offsetsBegin = offsetsBegin_param[0];
	}

	//U_CAPI void  U_EXPORT2 ucnv_cbFromUWriteUChars(UConverterFromUnicodeArgs *args, const UChar** source, const UChar*  sourceLimit, int32_t offsetIndex, UErrorCode * err)
	public static final void ucnv_cbFromUWriteUChars(UConverterFromUnicodeArgs args, char[] sourceArray, int[] sourceBegin, int sourceLimit, int offsetIndex, int[] err)
	{
	    /*
	    This is a fun one.  Recursion can occur - we're basically going to
	    just retry shoving data through the same converter. Note, if you got
	    here through some kind of invalid sequence, you maybe should emit a
	    reset sequence of some kind and/or call ucnv_reset().  Since this
	    IS an actual conversion, take care that you've changed the callback
	    or the data, or you'll get an infinite loop.
	
	    Please set the err value to something reasonable before calling
	    into this.
	    */
	
		byte[] oldTargetArray;
	    int oldTargetIndex;
	
	    if(ErrorCode.isFailure(err[0]))
	    {
	        return;
	    }
	
			oldTargetArray = args.targetArray;
	    oldTargetIndex = args.targetBegin;
	
		int[] targetBegin = new int[] {args.targetBegin};
	    args.converter.ucnv_fromUnicode(args.targetArray, targetBegin, args.targetLimit, sourceArray, sourceBegin, sourceLimit, false, /* no flush */ err);
		args.targetBegin = targetBegin[0];
	
	    if(args.offsetsArray != null)
	    {
	        while (args.targetBegin != oldTargetIndex)  /* if it moved at all.. */
	        {
	            args.offsetsArray[args.offsetsBegin++] = offsetIndex;
	            oldTargetIndex++;
	        }
	    }
	
	    /*
	    Note, if you did something like used a Stop subcallback, things would get interesting.
	    In fact, here's where we want to return the partially consumed in-source!
	    */
	    if(err[0] == ErrorCode.U_BUFFER_OVERFLOW_ERROR)
	    /* && (*source < sourceLimit && args->target >= args->targetLimit)
	    -- S. Hrcek */
	    {
	    /* Overflowed the target.  Now, we'll write into the charErrorBuffer.
	        It's a fixed size. If we overflow it... Hmm */
				byte[] newTargetArray = null;
	        int newTargetIndex;
	        int newTargetLimit;
	        int[] err2 = new int[] {ErrorCode.U_ZERO_ERROR};
	
	        byte errBuffLen;
	
	        errBuffLen  = args.converter.charErrorBufferLength;
	
	        /* start the new target at the first free slot in the errbuff.. */
	        newTargetIndex = errBuffLen;
	
	        newTargetLimit = args.converter.charErrorBufferArray.length;
	
	        if(newTargetIndex >= newTargetLimit)
	        {
	            err[0] = ErrorCode.U_INTERNAL_PROGRAM_ERROR;
	            return;
	        }
	
	       /* We're going to tell the converter that the errbuff len is empty.
	       This prevents the existing errbuff from being 'flushed' out onto
	       itself.  If the errbuff is needed by the converter this time,
	       we're hosed - we're out of space! */
	
	       args.converter.charErrorBufferLength = 0;
	
				 int[] newTarget_param = new int[] {newTargetIndex};
	       args.converter.ucnv_fromUnicode(newTargetArray, newTarget_param, newTargetLimit, sourceArray, sourceBegin, sourceLimit, false, err2);
				 newTargetIndex = newTarget_param[0];
	
	       /* We can go ahead and overwrite the  length here. We know just how
	       to recalculate it. */
	
	       args.converter.charErrorBufferLength = (byte)(newTargetIndex - args.converter.charErrorBufferBegin);
	
	       if((newTargetIndex >= newTargetLimit) || (err2[0] == ErrorCode.U_BUFFER_OVERFLOW_ERROR))
	       {
	           /* now we're REALLY in trouble.
	           Internal program error - callback shouldn't have written this much
	           data!
	           */
	           err[0] = ErrorCode.U_INTERNAL_PROGRAM_ERROR;
	           return;
	       }
	       else
	       {
			   /* sub errs could be invalid/truncated/illegal chars or w/e.
			   These might want to be passed on up.. But the problem is, we already
			   need to pass U_BUFFER_OVERFLOW_ERROR. That has to override these
			   other errs.. */
			
			   /*
			   if(U_FAILURE(err2))
			   ??
			   */
	       }
	    }
	}

	//U_CAPI void  U_EXPORT2 ucnv_cbFromUWriteSub (UConverterFromUnicodeArgs *args, int32_t offsetIndex, UErrorCode * err)
	public static final void  ucnv_cbFromUWriteSub (UConverterFromUnicodeArgs args, int offsetIndex, int[] err)
	{
	    if(ErrorCode.isFailure(err[0])) {
	        return;
	    }
	
	    //agljport:delete if(args.converter.sharedData.impl.writeSub!=null) {
	    if(false) {
	        args.converter.sharedData.writeSub(args, offsetIndex, err);
	    } else if(args.converter.subChar1!=0 && args.converter.invalidUCharBufferArray[0]<=0xff) {
					byte[] args_converter_subChar1_param = new byte[] {args.converter.subChar1};
	        ucnv_cbFromUWriteBytes(args, new byte[] {args.converter.subChar1}, 0, 1, offsetIndex, err);
	    } else {
	        ucnv_cbFromUWriteBytes(args, args.converter.subCharArray, args.converter.subCharBegin, args.converter.subCharLen, offsetIndex, err);
	    }
	}

	//U_CAPI void  U_EXPORT2 ucnv_cbToUWriteUChars (UConverterToUnicodeArgs *args, const UChar* source, int32_t length, int32_t offsetIndex, UErrorCode * err)
	public static final void  ucnv_cbToUWriteUChars (UConverterToUnicodeArgs args, char[] sourceArray, int sourceBegin, int length, int offsetIndex, int[] err)
	{
	    if(ErrorCode.isFailure(err[0])) {
	        return;
	    }
	
		int[] targetBegin_param = new int[] {args.targetBegin};
		int[] offsetsBegin_param = new int[] {args.offsetsBegin};
		UConverterUtility.ucnv_toUWriteUChars(args.converter, sourceArray, sourceBegin, length, args.targetArray, targetBegin_param, args.targetLimit, args.offsetsArray, offsetsBegin_param, offsetIndex, err);
		args.targetBegin = targetBegin_param[0];
		args.offsetsBegin = offsetsBegin_param[0];
	}

	//U_CAPI void  U_EXPORT2 ucnv_cbToUWriteSub (UConverterToUnicodeArgs *args, int32_t offsetIndex, UErrorCode * err)
	public static final void ucnv_cbToUWriteSub (UConverterToUnicodeArgs args, int offsetIndex, int[] err)
	{
	    char kSubstituteChar1 = 0x1A, kSubstituteChar = 0xFFFD;
	
	    /* could optimize this case, just one uchar */
	    if(args.converter.invalidCharLength == 1 && args.converter.subChar1 != 0) {
	        ucnv_cbToUWriteUChars(args, new char[] {kSubstituteChar1}, 0, 1, offsetIndex, err);
	    } else {
	        ucnv_cbToUWriteUChars(args, new char[] {kSubstituteChar}, 0, 1, offsetIndex, err);
	    }
	}
}
