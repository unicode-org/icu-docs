/*  
**********************************************************************
*   Copyright (C) 2000-2004, International Business Machines
*   Corporation and others.  All Rights Reserved.
**********************************************************************
*   file name:  ucnvisci.c
*   encoding:   US-ASCII
*   tab size:   8 (not used)
*   indentation:4
*
*   created on: 2001JUN26
*   created by: Ram Viswanadha
*   
*   Date        Name        Description
*   24/7/2001   Ram         Added support for EXT character handling
*/

package com.ibm.icu.impl;

import java.text.Bidi;
import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.converters.UConverter;;

class UConverterSharedData_MacArabic extends UConverterSharedData {

	public UConverterSharedData_MacArabic(int structSize_, int referenceCounter_, UConverterStaticData staticData_, boolean sharedDataCached_, long toUnicodeStatus_)
	{
		super(structSize_, referenceCounter_, staticData_, sharedDataCached_, toUnicodeStatus_);
	}
	
	public UConverterSharedData_MacArabic()
	{
		super(sizeofUConverterSharedData, 1, null, false, 0);
	}
	
	protected void doOpen(UConverter cnv, String name, String locale, long options, int[] pErrorCode)
	{
		_MacArabicOpen(cnv, name, locale, options, pErrorCode);
	}
	
	protected void doReset(UConverter cnv, int choice)
	{
		_MacArabicReset(cnv, choice);
	}
	
	protected void doToUnicode(UConverterToUnicodeArgs args, int[] pErrorCode)
	{
		UConverter_toUnicode_MacArabic(args, pErrorCode);
	}
	
	protected void doFromUnicode(UConverterFromUnicodeArgs args, int[] pErrorCode)
	{
		UConverter_fromUnicode_MacArabic(args, pErrorCode);
	}
	
	// Unicode directional formatting codes
	protected static final char LRE = 0x202A;
	protected static final char RLE = 0x202B;
	protected static final char PDF = 0x202C;
	protected static final char LRO = 0x202D;
	protected static final char RLO = 0x202E;
	
	protected static final char[] NLF = System.getProperty("line.separator").toCharArray();
	protected static final char LS  = 0x2028;
	protected static final char PS  = 0x2029;
	
	protected static final int INVALID_CHAR        = 0xffff;
	protected static final int ASCII_END           = 0x7F;
	protected static final int NO_CHAR_MARKER      = 0xFFFE;
	protected static final int BYTE_MASK		   = 0x00FF;
	
	// Arabic digit
	protected static final byte ARABIC_DIGIT_MIN = (byte)0xB0;
	protected static final byte ARABIC_DIGIT_MAX = (byte)0xB9;	

	protected static final class UConverterDataMacArabic {
		public char contextDirectionToUnicode;   /* previous Unicode direction for contextual analysis */
	    public boolean isFirstBuffer;      	/* boolean for fromUnicode to see if we need to announce the first script */
	    public String name;
	    public int realSourceArrayIndex = -1;
	    // Paragraph string for from Unicode conversion
		public StringBuffer fromUPara = new StringBuffer();
		public int paraIndex = 0;
		public boolean isInParagraph = false;
	}

	protected void _MacArabicOpen(UConverter cnv, String name, String locale,long options, int[] errorCode)
	{
	    cnv.extraInfo = new UConverterDataMacArabic();
	
	    if(cnv.extraInfo != null) {
	        int len=0;
	        UConverterDataMacArabic converterData=(UConverterDataMacArabic) cnv.extraInfo;
	        
	        /* initialize state variables */
	        converterData.contextDirectionToUnicode = NO_CHAR_MARKER;
	        cnv.toUnicodeStatus = UConverter.missingCharMarker;
	        converterData.name = "MacArabic";
	        len = converterData.name.length();            
			
	    }else{
	        errorCode[0] =ErrorCode.U_MEMORY_ALLOCATION_ERROR;
	    }
	}

	protected void _MacArabicClose(UConverter cnv)
	{
	    if(cnv.extraInfo!=null) {
	        if(!cnv.isExtraLocal) {
	            //agljport:delete uprv_free(cnv->extraInfo);
	        }
	        cnv.extraInfo=null;
	    }
	}

	protected String _MacArabicgetName(UConverter cnv)
	{
	    if(cnv.extraInfo != null){
	        UConverterDataMacArabic myData = (UConverterDataMacArabic)cnv.extraInfo;
	        return myData.name;
	    }
	    return null;
	}
	
	protected void _MacArabicReset(UConverter cnv, int choice)
	{
	    UConverterDataMacArabic data =(UConverterDataMacArabic ) (cnv.extraInfo);
	    if(choice<=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        cnv.toUnicodeStatus = UConverter.missingCharMarker;
	        cnv.mode=0;
	        data.contextDirectionToUnicode=NO_CHAR_MARKER;
	    }
	    if(choice!=UConverterConstants.UConverterResetChoice.UCNV_RESET_TO_UNICODE) {
	        data.realSourceArrayIndex = -1;
	    	data.fromUPara = new StringBuffer();
	        data.paraIndex = 0;
	        data.isFirstBuffer = true;
	        data.isInParagraph = false;
	    }
	}

	// Conversion mapping from Unicode, excluding ASCII(all LR) and some few code points
	protected static final char fromUnicodeTable[/*256*/]={
	    0xFFFF,/* 0x00 */
	    0xFFFF,/* 0x01 */
	    0xFFFF,/* 0x02 */
	    0xFFFF,/* 0x03 */
	    0xFFFF,/* 0x04 */
	    0xFFFF,/* 0x05 */
	    0xFFFF,/* 0x06 */
	    0xFFFF,/* 0x07 */
	    0xFFFF,/* 0x08 */
	    0xFFFF,/* 0x09 */
	    0xFFFF,/* 0x0a */
	    0xFFFF,/* 0x0b */
	    0x00ac,/* 0x060c */
	    0xFFFF,/* 0x0d */
	    0xFFFF,/* 0x0e */
	    0xFFFF,/* 0x0f */
	    0xFFFF,/* 0x10 */
	    0xFFFF,/* 0x11 */
	    0xFFFF,/* 0x12 */
	    0xFFFF,/* 0x13 */
	    0xFFFF,/* 0x14 */
	    0xFFFF,/* 0x15 */
	    0xFFFF,/* 0x16 */
	    0xFFFF,/* 0x17 */
	    0xFFFF,/* 0x18 */
	    0xFFFF,/* 0x19 */
	    0xFFFF,/* 0x1a */
	    0x00bb,/* 0x061b */
	    0xFFFF,/* 0x1c */
	    0xFFFF,/* 0x1d */
	    0xFFFF,/* 0x1e */
	    0x00bf,/* 0x061f */
	    0xFFFF,/* 0x20 */
	    0x00c1,/* 0x0621 */
	    0x00c2,/* 0x0622 */
	    0x00c3,/* 0x0623 */
	    0x00c4,/* 0x0624 */
	    0x00c5,/* 0x0625 */
	    0x00c6,/* 0x0626 */
	    0x00c7,/* 0x0627 */
	    0x00c8,/* 0x0628 */
	    0x00c9,/* 0x0629 */
	    0x00ca,/* 0x062a */
	    0x00cb,/* 0x062b */
	    0x00cc,/* 0x062c */
	    0x00cd,/* 0x062d */
	    0x00ce,/* 0x062e */
	    0x00cf,/* 0x062f */
	    0x00d0,/* 0x0630 */
	    0x00d1,/* 0x0631 */
	    0x00d2,/* 0x0632 */
	    0x00d3,/* 0x0633 */
	    0x00d4,/* 0x0634 */
	    0x00d5,/* 0x0635 */
	    0x00d6,/* 0x0636 */
	    0x00d7,/* 0x0637 */
	    0x00d8,/* 0x0638 */
	    0x00d9,/* 0x0639 */
	    0x00dA,/* 0x063A */
	    0xFFFF,/* 0x3B */
	    0x00bc,/* 0x003c */
	    0x00bd,/* 0x003d */
	    0x00be,/* 0x003e */
	    0xFFFF,/* 0x3f */
	    0x00e0,/* 0x0640 */
	    0x00e1,/* 0x0641 */
	    0x00e2,/* 0x0642 */
	    0x00e3,/* 0x0643 */
	    0x00e4,/* 0x0644 */
	    0x00e5,/* 0x0645 */
	    0x00e6,/* 0x0646 */
	    0x00e7,/* 0x0647 */
	    0x00e8,/* 0x0648 */
	    0x00e9,/* 0x0649 */
	    0x00ea,/* 0x064a */
	    0x00eb,/* 0x064b */
	    0x00ec,/* 0x064c */
	    0x00ed,/* 0x064d */
	    0x00ee,/* 0x064e */
	    0x00ef,/* 0x064f */
	    0x00f0,/* 0x0650 */
	    0x00f1,/* 0x0651 */
	    0x00f2,/* 0x0652 */
	    0xFFFF,/* 0x53 */
	    0xFFFF,/* 0x54 */
	    0xFFFF,/* 0x55 */
	    0xFFFF,/* 0x56 */
	    0xFFFF,/* 0x57 */
	    0xFFFF,/* 0x58 */
	    0xFFFF,/* 0x59 */
	    0xFFFF,/* 0x5a */
	    0x00db,/* 0x005b */
	    0x00dc,/* 0x005c */
	    0x00dd,/* 0x005d */
	    0x00de,/* 0x005e */
	    0x00df,/* 0x005f */
	    0x00b0,/* 0x0660 */
	    0x00b1,/* 0x0661 */
	    0x00b2,/* 0x0662 */
	    0x00b3,/* 0x0663 */
	    0x00b4,/* 0x0664 */
	    0x00b5,/* 0x0665 */
	    0x00b6,/* 0x0666 */
	    0x00b7,/* 0x0667 */
	    0x00b8,/* 0x0668 */
	    0x00b9,/* 0x0669 */
	    0x00a5,/* 0x066a */
	    0xFFFF,/* 0x6b */
	    0xFFFF,/* 0x6c */
	    0xFFFF,/* 0x6d */
	    0xFFFF,/* 0x6e */
	    0xFFFF,/* 0x6f */
	    0xFFFF,/* 0x70 */
	    0xFFFF,/* 0x71 */
	    0xFFFF,/* 0x72 */
	    0xFFFF,/* 0x73 */
	    0xFFFF,/* 0x74 */
	    0xFFFF,/* 0x75 */
	    0xFFFF,/* 0x76 */
	    0xFFFF,/* 0x77 */
	    0xFFFF,/* 0x78 */
	    0x00f4,/* 0x0679 */
	    0xFFFF,/* 0x7a */
	    0x00fb,/* 0x007b */
	    0x00fc,/* 0x007c */
	    0x00fd,/* 0x007d */
	    0x00f3,/* 0x067e */
	    0xFFFF,/* 0x7f */
	    0xFFFF,/* 0x80 */
	    0xFFFF,/* 0x81 */
	    0xFFFF,/* 0x82 */
	    0xFFFF,/* 0x83 */
	    0xFFFF,/* 0x84 */
	    0xFFFF,/* 0x85 */
	    0x00f5,/* 0x0686 */
	    0xFFFF,/* 0x87 */
	    0x00f9,/* 0x0688 */
	    0xFFFF,/* 0x89 */
	    0xFFFF,/* 0x8a */
	    0xFFFF,/* 0x8b */
	    0xFFFF,/* 0x8c */
	    0xFFFF,/* 0x8d */
	    0xFFFF,/* 0x8e */
	    0xFFFF,/* 0x8f */
	    0xFFFF,/* 0x90 */
	    0x00fa,/* 0x0691 */
	    0xFFFF,/* 0x92 */
	    0xFFFF,/* 0x93 */
	    0xFFFF,/* 0x94 */
	    0xFFFF,/* 0x95 */
	    0xFFFF,/* 0x96 */
	    0xFFFF,/* 0x97 */
	    0x00fe,/* 0x0698 */
	    0xFFFF,/* 0x99 */
	    0xFFFF,/* 0x9a */
	    0xFFFF,/* 0x9b */
	    0xFFFF,/* 0x9c */
	    0xFFFF,/* 0x9d */
	    0xFFFF,/* 0x9e */
	    0xFFFF,/* 0x9f */
	    0x0081,/* 0x00a0 */
	    0xFFFF,/* 0xa1 */
	    0xFFFF,/* 0xa2 */
	    0xFFFF,/* 0xa3 */
	    0x00f7,/* 0x06a4 */
	    0xFFFF,/* 0xa5 */
	    0xFFFF,/* 0xa6 */
	    0xFFFF,/* 0xa7 */
	    0xFFFF,/* 0xa8 */
	    0xFFFF,/* 0xa9 */
	    0xFFFF,/* 0xaa */
	    0x008c,/* 0x00ab */
	    0xFFFF,/* 0xac */
	    0xFFFF,/* 0xad */
	    0xFFFF,/* 0xae */
	    0x00f8,/* 0x06af */
	    0xFFFF,/* 0xb0 */
	    0xFFFF,/* 0xb1 */
	    0xFFFF,/* 0xb2 */
	    0xFFFF,/* 0xb3 */
	    0xFFFF,/* 0xb4 */
	    0xFFFF,/* 0xb5 */
	    0xFFFF,/* 0xb6 */
	    0xFFFF,/* 0xb7 */
	    0xFFFF,/* 0xb8 */
	    0xFFFF,/* 0xb9 */
	    0x008b,/* 0x06ba */
	    0x0098,/* 0x00bb */
	    0xFFFF,/* 0xbc */
	    0xFFFF,/* 0xbd */
	    0xFFFF,/* 0xbe */
	    0xFFFF,/* 0xbf */
	    0xFFFF,/* 0xc0 */
	    0xFFFF,/* 0xc1 */
	    0xFFFF,/* 0xc2 */
	    0xFFFF,/* 0xc3 */
	    0x0080,/* 0x00c4 */
	    0xFFFF,/* 0xc5 */
	    0xFFFF,/* 0xc6 */
	    0x0082,/* 0x00c7 */
	    0xFFFF,/* 0xc8 */
	    0x0083,/* 0x00c9 */
	    0xFFFF,/* 0xca */
	    0xFFFF,/* 0xcb */
	    0xFFFF,/* 0xcc */
	    0xFFFF,/* 0xcd */
	    0xFFFF,/* 0xce */
	    0xFFFF,/* 0xcf */
	    0xFFFF,/* 0xd0 */
	    0x0084,/* 0x00d1 */
	    0x00ff,/* 0x06d2 */
	    0xFFFF,/* 0xd3 */
	    0xFFFF,/* 0xd4 */
	    0x00f6,/* 0x06d5 */
	    0x0085,/* 0x00d6 */
	    0xFFFF,/* 0xd7 */
	    0xFFFF,/* 0xd8 */
	    0xFFFF,/* 0xd9 */
	    0xFFFF,/* 0xda */
	    0xFFFF,/* 0xdb */
	    0x0086,/* 0x00dc */
	    0xFFFF,/* 0xdd */
	    0xFFFF,/* 0xde */
	    0xFFFF,/* 0xdf */
	    0x0088,/* 0x00e0 */
	    0x0087,/* 0x00e1 */
	    0x0089,/* 0x00e2 */
	    0xFFFF,/* 0xe3 */
	    0x008a,/* 0x00e4 */
	    0xFFFF,/* 0xe5 */
	    0xFFFF,/* 0xe6 */
	    0x008d,/* 0x00e7 */
	    0x008f,/* 0x00e8 */
	    0x008e,/* 0x00e9 */
	    0x0090,/* 0x00ea */
	    0x0091,/* 0x00eb */
	    0xFFFF,/* 0xec */
	    0x0092,/* 0x00ed */
	    0x0094,/* 0x00ee */
	    0x0095,/* 0x00ef */
	    0xFFFF,/* 0xf0 */
	    0x0096,/* 0x00f1 */
	    0xFFFF,/* 0xf2 */
	    0x0097,/* 0x00f3 */
	    0x0099,/* 0x00f4 */
	    0xFFFF,/* 0xf5 */
	    0x009a,/* 0x00f6 */
	    0x009b,/* 0x00f7 */
	    0xFFFF,/* 0xf8 */
	    0x009d,/* 0x00f9 */
	    0x009c,/* 0x00fa */
	    0x009e,/* 0x00fb */
	    0x009f,/* 0x00fc */
	    0xFFFF,/* 0xfd */
	    0xFFFF,/* 0xfe */
	    0xFFFF /* 0xff */
	};

	protected static final char toUnicodeTable[/*256*/][/*1*/]={
	    { 0x0000, 0 },	/* 0x00 */
	    { 0x0001, 0 }, 	/* 0x01 */
	    { 0x0002, 0 }, 	/* 0x02 */
	    { 0x0003, 0 }, 	/* 0x03 */
	    { 0x0004, 0 }, 	/* 0x04 */
	    { 0x0005, 0 }, 	/* 0x05 */
	    { 0x0006, 0 }, 	/* 0x06 */
	    { 0x0007, 0 }, 	/* 0x07 */
	    { 0x0008, 0 }, 	/* 0x08 */
	    { 0x0009, 0 }, 	/* 0x09 */
	    { 0x000a, 0 }, 	/* 0x0a */
	    { 0x000b, 0 }, 	/* 0x0b */
	    { 0x000c, 0 }, 	/* 0x0c */
	    { 0x000d, 0 }, 	/* 0x0d */
	    { 0x000e, 0 }, 	/* 0x0e */
	    { 0x000f, 0 }, 	/* 0x0f */
	    { 0x0010, 0 }, 	/* 0x10 */
	    { 0x0011, 0 }, 	/* 0x11 */
	    { 0x0012, 0 }, 	/* 0x12 */
	    { 0x0013, 0 }, 	/* 0x13 */
	    { 0x0014, 0 }, 	/* 0x14 */
	    { 0x0015, 0 }, 	/* 0x15 */
	    { 0x0016, 0 }, 	/* 0x16 */
	    { 0x0017, 0 }, 	/* 0x17 */
	    { 0x0018, 0 }, 	/* 0x18 */
	    { 0x0019, 0 }, 	/* 0x19 */
	    { 0x001a, 0 }, 	/* 0x1a */
	    { 0x001b, 0 }, 	/* 0x1b */
	    { 0x001c, 0 }, 	/* 0x1c */
	    { 0x001d, 0 }, 	/* 0x1d */
	    { 0x001e, 0 }, 	/* 0x1e */
	    { 0x001f, 0 }, 	/* 0x1f */
	    { 0x0020, LRO }, 	/* 0x20 */
	    { 0x0021, LRO },	/* 0x21 */
	    { 0x0022, LRO }, 	/* 0x22 */
	    { 0x0023, LRO }, 	/* 0x23 */
	    { 0x0024, LRO }, 	/* 0x24 */
	    { 0x0025, LRO }, 	/* 0x25 */
	    { 0x0026, LRO }, 	/* 0x26 */
	    { 0x0027, LRO }, 	/* 0x27 */
	    { 0x0028, LRO }, 	/* 0x28 */
	    { 0x0029, LRO }, 	/* 0x29 */
	    { 0x002a, LRO }, 	/* 0x2a */
	    { 0x002b, LRO }, 	/* 0x2b */
	    { 0x002c, LRO }, 	/* 0x2c */
	    { 0x002d, LRO }, 	/* 0x2d */
	    { 0x002e, LRO }, 	/* 0x2e */
	    { 0x002f, LRO }, 	/* 0x2f */
	    { 0x0030, 0 }, 	/* 0x30 */
	    { 0x0031, 0 }, 	/* 0x31 */
	    { 0x0032, 0 }, 	/* 0x32 */
	    { 0x0033, 0 }, 	/* 0x33 */
	    { 0x0034, 0 }, 	/* 0x34 */
	    { 0x0035, 0 }, 	/* 0x35 */
	    { 0x0036, 0 }, 	/* 0x36 */
	    { 0x0037, 0 }, 	/* 0x37 */
	    { 0x0038, 0 }, 	/* 0x38 */
	    { 0x0039, 0 }, 	/* 0x39 */
	    { 0x003a, LRO }, 	/* 0x3A */
	    { 0x003b, LRO }, 	/* 0x3B */
	    { 0x003c, LRO }, 	/* 0x3c */
	    { 0x003d, LRO }, 	/* 0x3d */
	    { 0x003e, LRO }, 	/* 0x3e */
	    { 0x003f, LRO }, 	/* 0x3f */
	    { 0x0040, 0 }, 	/* 0x40 */
	    { 0x0041, 0 }, 	/* 0x41 */
	    { 0x0042, 0 }, 	/* 0x42 */
	    { 0x0043, 0 }, 	/* 0x43 */
	    { 0x0044, 0 }, 	/* 0x44 */
	    { 0x0045, 0 }, 	/* 0x45 */
	    { 0x0046, 0 }, 	/* 0x46 */
	    { 0x0047, 0 }, 	/* 0x47 */
	    { 0x0048, 0 }, 	/* 0x48 */
	    { 0x0049, 0 }, 	/* 0x49 */
	    { 0x004a, 0 }, 	/* 0x4a */
	    { 0x004b, 0 }, 	/* 0x4b */
	    { 0x004c, 0 }, 	/* 0x4c */
	    { 0x004d, 0 }, 	/* 0x4d */
	    { 0x004e, 0 }, 	/* 0x4e */
	    { 0x004f, 0 }, 	/* 0x4f */
	    { 0x0050, 0 }, 	/* 0x50 */
	    { 0x0051, 0 }, 	/* 0x51 */
	    { 0x0052, 0 }, 	/* 0x52 */
	    { 0x0053, 0 }, 	/* 0x53 */
	    { 0x0054, 0 }, 	/* 0x54 */
	    { 0x0055, 0 }, 	/* 0x55 */
	    { 0x0056, 0 }, 	/* 0x56 */
	    { 0x0057, 0 }, 	/* 0x57 */
	    { 0x0058, 0 }, 	/* 0x58 */
	    { 0x0059, 0 }, 	/* 0x59 */
	    { 0x005a, 0 }, 	/* 0x5a */
	    { 0x005b, LRO }, 	/* 0x5b */
	    { 0x005c, LRO }, 	/* 0x5c */
	    { 0x005d, LRO }, 	/* 0x5d */
	    { 0x005e, LRO }, 	/* 0x5e */
	    { 0x005f, LRO }, 	/* 0x5f */
	    { 0x0060, 0 }, 	/* 0x60 */
	    { 0x0061, 0 }, 	/* 0x61 */
	    { 0x0062, 0 }, 	/* 0x62 */
	    { 0x0063, 0 }, 	/* 0x63 */
	    { 0x0064, 0 }, 	/* 0x64 */
	    { 0x0065, 0 }, 	/* 0x65 */
	    { 0x0066, 0 }, 	/* 0x66 */
	    { 0x0067, 0 }, 	/* 0x67 */
	    { 0x0068, 0 }, 	/* 0x68 */
	    { 0x0069, 0 }, 	/* 0x69 */
	    { 0x006a, 0 }, 	/* 0x6a */
	    { 0x006b, 0 }, 	/* 0x6b */
	    { 0x006c, 0 }, 	/* 0x6c */
	    { 0x006d, 0 }, 	/* 0x6d */
	    { 0x006e, 0 }, 	/* 0x6e */
	    { 0x006f, 0 }, 	/* 0x6f */
	    { 0x0070, 0 }, 	/* 0x70 */
	    { 0x0071, 0 }, 	/* 0x71 */
	    { 0x0072, 0 }, 	/* 0x72 */
	    { 0x0073, 0 }, 	/* 0x73 */
	    { 0x0074, 0 }, 	/* 0x74 */
	    { 0x0075, 0 }, 	/* 0x75 */
	    { 0x0076, 0 }, 	/* 0x76 */
	    { 0x0077, 0 }, 	/* 0x77 */
	    { 0x0078, 0 }, 	/* 0x78 */
	    { 0x0079, 0 }, 	/* 0x79 */
	    { 0x007a, 0 }, 	/* 0x7a */
	    { 0x007b, LRO }, 	/* 0x7b */
	    { 0x007c, LRO }, 	/* 0x7c */
	    { 0x007d, LRO }, 	/* 0x7d */
	    { 0x007e, 0 }, 	/* 0x7e */
	    { 0x007f, 0 }, 	/* 0x7f */
	    { 0x00c4, 0 }, 	/* 0x80 */
	    { 0x00a0, RLO }, 	/* 0x81 */
	    { 0x00c7, 0 }, 	/* 0x82 */
	    { 0x00c9, 0 }, 	/* 0x83 */
	    { 0x00d1, 0 }, 	/* 0x84 */
	    { 0x00d6, 0 }, 	/* 0x85 */
	    { 0x00dc, 0 }, 	/* 0x86 */
	    { 0x00e1, 0 }, 	/* 0x87 */
	    { 0x00e0, 0 }, 	/* 0x88 */
	    { 0x00e2, 0 }, 	/* 0x89 */
	    { 0x00e4, 0 }, 	/* 0x8a */
	    { 0x06ba, 0 }, 	/* 0x8b */
	    { 0x00ab, RLO }, 	/* 0x8c */
	    { 0x00e7, 0 }, 	/* 0x8d */
	    { 0x00e9, 0 }, 	/* 0x8e */
	    { 0x00e8, 0 }, 	/* 0x8f */
	    { 0x00ea, 0 }, 	/* 0x90 */
	    { 0x00eb, 0 }, 	/* 0x91 */
	    { 0x00ed, 0 }, 	/* 0x92 */
	    { 0x2026, RLO }, 	/* 0x93 */
	    { 0x00ee, 0 }, 	/* 0x94 */
	    { 0x00ef, 0 }, 	/* 0x95 */
	    { 0x00f1, 0 }, 	/* 0x96 */
	    { 0x00f3, 0 }, 	/* 0x97 */
	    { 0x00bb, RLO }, 	/* 0x98 */
	    { 0x00f4, 0 }, 	/* 0x99 */
	    { 0x00f6, 0 }, 	/* 0x9a */
	    { 0x00f7, RLO }, 	/* 0x9b */
	    { 0x00fa, 0 }, 	/* 0x9c */
	    { 0x00f9, 0 }, 	/* 0x9d */
	    { 0x00fb, 0 }, 	/* 0x9e */
	    { 0x00fc, 0 }, 	/* 0x9f */
	    { 0x0020, RLO }, 	/* 0xa0 */
	    { 0x0021, RLO }, 	/* 0xa1 */
	    { 0x0022, RLO }, 	/* 0xa2 */
	    { 0x0023, RLO }, 	/* 0xa3 */
	    { 0x0024, RLO }, 	/* 0xa4 */
	    { 0x066a, 0 }, 	/* 0xa5 */
	    { 0x0026, RLO }, 	/* 0xa6 */
	    { 0x0027, RLO }, 	/* 0xa7 */
	    { 0x0028, RLO }, 	/* 0xa8 */
	    { 0x0029, RLO }, 	/* 0xa9 */
	    { 0x002a, RLO }, 	/* 0xaa */
	    { 0x002b, RLO }, 	/* 0xab */
	    { 0x060c, 0 }, 	/* 0xac */
	    { 0x002d, RLO }, 	/* 0xad */
	    { 0x002e, RLO }, 	/* 0xae */
	    { 0x002f, RLO }, 	/* 0xaf */
	    { 0x0660, RLO }, 	/* 0xb0 */
	    { 0x0661, RLO }, 	/* 0xb1 */
	    { 0x0662, RLO }, 	/* 0xb2 */
	    { 0x0663, RLO }, 	/* 0xb3 */
	    { 0x0664, RLO }, 	/* 0xb4 */
	    { 0x0665, RLO }, 	/* 0xb5 */
	    { 0x0666, RLO }, 	/* 0xb6 */
	    { 0x0667, RLO }, 	/* 0xb7 */
	    { 0x0668, RLO }, 	/* 0xb8 */
	    { 0x0669, RLO }, 	/* 0xb9 */
	    { 0x003a, RLO }, 	/* 0xba */
	    { 0x061b, 0 }, 	/* 0xbb */
	    { 0x003c, RLO }, 	/* 0xbc */
	    { 0x003d, RLO }, 	/* 0xbd */
	    { 0x003e, RLO }, 	/* 0xbe */
	    { 0x061f, 0 }, 	/* 0xbf */
	    { 0x274a, RLO }, 	/* 0xc0 */
	    { 0x0621, 0 }, 	/* 0xc1 */
	    { 0x0622, 0 }, 	/* 0xc2 */
	    { 0x0623, 0 }, 	/* 0xc3 */
	    { 0x0624, 0 }, 	/* 0xc4 */
	    { 0x0625, 0 }, 	/* 0xc5 */
	    { 0x0626, 0 }, 	/* 0xc6 */
	    { 0x0627, 0 }, 	/* 0xc7 */
	    { 0x0628, 0 }, 	/* 0xc8 */
	    { 0x0629, 0 }, 	/* 0xc9 */
	    { 0x062a, 0 }, 	/* 0xca */
	    { 0x062b, 0 }, 	/* 0xcb */
	    { 0x062c, 0 }, 	/* 0xcc */
	    { 0x062d, 0 }, 	/* 0xcd */
	    { 0x062e, 0 }, 	/* 0xce */
	    { 0x062f, 0 }, 	/* 0xcf */
	    { 0x0630, 0 }, 	/* 0xd0 */
	    { 0x0631, 0 }, 	/* 0xd1 */
	    { 0x0632, 0 }, 	/* 0xd2 */
	    { 0x0633, 0 }, 	/* 0xd3 */
	    { 0x0634, 0 }, 	/* 0xd4 */
	    { 0x0635, 0 }, 	/* 0xd5 */
	    { 0x0636, 0 }, 	/* 0xd6 */
	    { 0x0637, 0 }, 	/* 0xd7 */
	    { 0x0638, 0 }, 	/* 0xd8 */
	    { 0x0639, 0 }, 	/* 0xd9 */
	    { 0x063a, 0 }, 	/* 0xda */
	    { 0x005b, RLO }, 	/* 0xdb */
	    { 0x005c, RLO }, 	/* 0xdc */
	    { 0x005d, RLO }, 	/* 0xdd */
	    { 0x005e, RLO }, 	/* 0xde */
	    { 0x005f, RLO }, 	/* 0xdf */
	    { 0x0640, 0 }, 	/* 0xe0 */
	    { 0x0641, 0 }, 	/* 0xe1 */
	    { 0x0642, 0 }, 	/* 0xe2 */
	    { 0x0643, 0 }, 	/* 0xe3 */
	    { 0x0644, 0 }, 	/* 0xe4 */
	    { 0x0645, 0 }, 	/* 0xe5 */
	    { 0x0646, 0 }, 	/* 0xe6 */
	    { 0x0647, 0 }, 	/* 0xe7 */
	    { 0x0648, 0 }, 	/* 0xe8 */
	    { 0x0649, 0 }, 	/* 0xe9 */
	    { 0x064a, 0 }, 	/* 0xea */
	    { 0x064b, 0 }, 	/* 0xeb */
	    { 0x064c, 0 }, 	/* 0xec */
	    { 0x064d, 0 }, 	/* 0xed */
	    { 0x064e, 0 }, 	/* 0xee */
	    { 0x064f, 0 }, 	/* 0xef */
	    { 0x0650, 0 }, 	/* 0xf0 */
	    { 0x0651, 0 }, 	/* 0xf1 */
	    { 0x0652, 0 }, 	/* 0xf2 */
	    { 0x067e, 0 }, 	/* 0xf3 */
	    { 0x0679, 0 }, 	/* 0xf4 */
	    { 0x0686, 0 }, 	/* 0xf5 */
	    { 0x06d5, 0 }, 	/* 0xf6 */
	    { 0x06a4, 0 }, 	/* 0xf7 */
	    { 0x06af, 0 }, 	/* 0xf8 */
	    { 0x0688, 0 }, 	/* 0xf9 */
	    { 0x0691, 0 }, 	/* 0xfa */
	    { 0x007b, RLO }, 	/* 0xfb */
	    { 0x007c, RLO }, 	/* 0xfc */
	    { 0x007d, RLO }, 	/* 0xfd */
	    { 0x0698, 0 }, 	/* 0xfe */
	    { 0x06d2, 0 }   /* 0xff */
	};

	private static final void WRITE_TO_TARGET_FROM_U(UConverterFromUnicodeArgs args,int[] offsetsArray, int[] offsetsArrayIndex,int sourceArrayIndex,byte[] targetArray, int[] targetArrayIndex, int targetLimit,int targetByteUnit,int[] err)
	{
	      /* write the targetUniChar  to target */                                                  
	    if(targetArrayIndex[0] <targetLimit){                                                                    
	        if((targetByteUnit & UConverterUtility.UNSIGNED_SHORT_MASK) <= 0xFF){                                                             
	            targetArray[targetArrayIndex[0]++] = (byte)(targetByteUnit);                                            
	            if(offsetsArray != null){                                                                        
	                offsetsArray[offsetsArrayIndex[0]++] = (int)(sourceArrayIndex - args.sourceBegin-1);                              
	            }                                                                                   
	        }else{                                                                                  
	            targetArray[targetArrayIndex[0]++] = (byte)(targetByteUnit>>>8);                                         
	            if(offsetsArray != null){                                                                        
	                offsetsArray[offsetsArrayIndex[0]++] = (int)(sourceArrayIndex - args.sourceBegin-1);                              
	            }                                                                                   
	            if(targetArrayIndex[0] < targetLimit){                                                           
	                targetArray[targetArrayIndex[0]++] = (byte)  targetByteUnit;                                        
	                if(offsetsArray != null){                                                                    
	                    offsetsArray[offsetsArrayIndex[0]++] = (int)(sourceArrayIndex - args.sourceBegin-1);                          
	                }                                                                               
	            }else{                                                                              
	                args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] =    
	                            (byte) (targetByteUnit);                                         
	                err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;                                                 
	            }                                                                                   
	        }                                                                                       
	    }else{                                                                                      
	        if((targetByteUnit & 0xFF00) != 0){                                                            
	            args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] =        
	                        (byte) (targetByteUnit >>>8);                                         
	        }                                                                                       
	        args.converter.charErrorBufferArray[args.converter.charErrorBufferLength++] =            
	                        (byte) (targetByteUnit);                                             
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;                                                         
	    }                                                                                           
	}       
	
	// Check if this is NLF according to platform convention
	protected boolean isNLF(StringBuffer fromUPara, int paraIndex){
		
		for (int i=1; i<NLF.length; i++){
			if (fromUPara.charAt(paraIndex++)!=NLF[i]){
				return false;
			}
		}
		return true;
	}
	
	// Preliminary validation for Unicode mapping of MacArabic
	protected static boolean isValidMacArabicUnicode(int uVal){
		return (uVal<0xff || (uVal<=0x06d5 && uVal>=0x060c) || uVal==0x2026 || uVal==0x274a || 
				(uVal<=RLO && uVal>=LRE) || uVal==LS || uVal==PS);
	}
	
	/* Note: 
	 * 	- sourceArrayIndex doesn't work for offsetArray since this is paragraph processing.
	 * 	- NLF is treated as other characters. We might want to convert all of NLF to NLF platform convention later.
	 * */
	protected void UConverter_fromUnicode_MacArabic (UConverterFromUnicodeArgs args, int[] err)
	{
	    char[] sourceArray = args.sourceArray;
		int sourceArrayIndex = args.sourceBegin;
		int realSourceArrayIndex = args.sourceBegin;
	    int sourceLimit = args.sourceLimit;
	    byte[] targetArray = args.targetArray;
		int targetArrayIndex = args.targetBegin;
	    int targetLimit = args.targetLimit;
	    int[] offsetsArray = args.offsetsArray;
		int offsetsArrayIndex = args.offsetsBegin;
	    int targetByteUnit = 0x0000;
	    int sourceChar = 0x0000;
	    UConverterDataMacArabic converterData;
	    int curParaIndex = 0;
	    
	    if ((args.converter == null) || (args.targetLimit < args.targetBegin) || (args.sourceLimit < args.sourceBegin)){
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    /* initialize data */
	    converterData=(UConverterDataMacArabic)args.converter.extraInfo;
	    if (!args.flush){
		    /*writing the char to the output stream */
		    while(sourceArrayIndex < sourceLimit){    
		    	
		    	// Normal run through 
		    	if (!converterData.isInParagraph){
		    		
		    		if (realSourceArrayIndex < sourceLimit){
				    	sourceChar = sourceArray[realSourceArrayIndex++];
				    	// Append to current paragraph
				        converterData.fromUPara.append((char)sourceChar);
				        
				    	// Found end of paragraph
				        if(sourceChar==PS){		        	
				        	converterData.isInParagraph = true;
				        	converterData.realSourceArrayIndex = realSourceArrayIndex;
				        }
		    		}
		    		// End of source
		    		else{
		    			sourceArrayIndex = sourceLimit;
		    			break;
		    		}
			    }
		    	// Convert paragraph
		    	else{
		        	// Create Bidi paragraph for determining direction
		        	Bidi bidiPara = new Bidi(converterData.fromUPara.toString(), Bidi.DIRECTION_DEFAULT_RIGHT_TO_LEFT);
		        	
		        	while (converterData.paraIndex<converterData.fromUPara.length()){
		        		curParaIndex = converterData.paraIndex;
	//	        		sourceArrayIndex++;
		        		sourceChar = converterData.fromUPara.charAt(converterData.paraIndex++);
		        		targetByteUnit = UConverter.missingCharMarker;
		        		//boolean isNLFChar = false;
		        		
		        		// Preliminary screening
		                if (isValidMacArabicUnicode(sourceChar)){
		                	 
			                // If input is direction formatting code
			                if (sourceChar<=RLO && sourceChar>=LRE){
			                	continue;
			                }
			                // If sourceChar is Newline function 
			                /*else if (sourceChar==NLF[0] && (isNLFChar=isNLF(converterData.fromUPara, converterData.paraIndex))){
			                	converterData.paraIndex += NLF.length-1;
	//		                	sourceArrayIndex += NLF.length-1;
			                	targetByteUnit = NLF[0];
			                }*/
			                // If sourceChar is Paragraph Separator or Line Separator
			                else if (sourceChar==PS || sourceChar==LS){
			                	targetByteUnit = (byte)NLF[0];
	                		}
			        		// If input is in ASCII and C0 control codes range
			                else if (sourceChar <= ASCII_END){
			                	
			                	// R-L
			                	if (bidiPara.getLevelAt(curParaIndex)%2==1){
			                		if (sourceChar>=0x20 && sourceChar<=0x2F && sourceChar!=0x25 && sourceChar!=0x2C){
			                			targetByteUnit = (0x000F & sourceChar) + 0xA0;
			                		}
			                		else if (sourceChar==0x3A){
			                			targetByteUnit = 0xBA;
			                		}
			                		else if ((sourceChar>=0x3C && sourceChar<=0x3E) || 
			                				 (sourceChar>=0x5B && sourceChar<=0x5f) ||
			                				 (sourceChar>=0x7b && sourceChar<=0x7D)){
			                			targetByteUnit = fromUnicodeTable[sourceChar&BYTE_MASK];
			                		}
			                		else {
			                			targetByteUnit = sourceChar;
			                		}
			                	}
			                	// L-R
			                	else {
			                		targetByteUnit = sourceChar;
			                	}
			                }
			                else {
			                	switch(sourceChar){
			                		case 0x2026:
			                			targetByteUnit = 0x93;
			                			break;
			                		case 0x274A:
			                			targetByteUnit = 0xC0;
			                			break;		                		
			                		default:
			                			targetByteUnit = fromUnicodeTable[sourceChar&BYTE_MASK];
			                	}
			                }
		                }
		        		
		        		if(targetByteUnit != UConverter.missingCharMarker) {
		        			// For Paragraph Separator/Line Separator - convert to platform newline convention
		        			if (sourceChar==LS || sourceChar==PS /*|| isNLFChar*/){
		        				for (int i=0; i<NLF.length; i++){
	            	        		int[] offsetsBegin = {offsetsArrayIndex};
	                    			int[] targetBegin = {targetArrayIndex};
	                    			targetByteUnit = (byte)NLF[i];
	                    			WRITE_TO_TARGET_FROM_U(args,offsetsArray, offsetsBegin,0/*sourceArrayIndex*/,targetArray, targetBegin,targetLimit,targetByteUnit,err);
	                    			offsetsArrayIndex = offsetsBegin[0];
	                    			targetArrayIndex = targetBegin[0];
	                    			if(ErrorCode.isFailure(err[0])){
	                    				break;
	                    			}
	            	        	}
		        			}
		        			// Other characters
		        			else{
			        			int[] offsetsBegin = {offsetsArrayIndex};
			        			int[] targetBegin = {targetArrayIndex};
			        			WRITE_TO_TARGET_FROM_U(args,offsetsArray, offsetsBegin,0/*sourceArrayIndex*/,targetArray, targetBegin,targetLimit,targetByteUnit,err);
			        			offsetsArrayIndex = offsetsBegin[0];
			        			targetArrayIndex = targetBegin[0];
			        			if(ErrorCode.isFailure(err[0])){
			        				break;
			        			}
		        			}
		        		}
		        		else{
		        			err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
		        			break;
		        		}
		        	}
		        	if (ErrorCode.isFailure(err[0])){
			        	break;
					}
		        	
		        	// Reset the paragraph
		        	converterData.fromUPara = new StringBuffer();
		        	converterData.paraIndex = 0;
		        	converterData.isInParagraph = false;
		        	realSourceArrayIndex = converterData.realSourceArrayIndex;
		        }	 
		    }
	    }
		// End of input - process the last paragraph
		else if (converterData.fromUPara.length()>0){
	    	
	    	sourceArrayIndex = -1;
	    	// Create Bidi paragraph for determining direction
        	Bidi bidiPara = new Bidi(converterData.fromUPara.toString(), Bidi.DIRECTION_DEFAULT_RIGHT_TO_LEFT);
        	
        	while (converterData.paraIndex<converterData.fromUPara.length()){
        		curParaIndex = converterData.paraIndex;
//        		sourceArrayIndex++;
        		sourceChar = converterData.fromUPara.charAt(converterData.paraIndex++);
        		targetByteUnit = UConverter.missingCharMarker;
        		//boolean isNLFChar = false;
        		
        		// Preliminary screening
                if (isValidMacArabicUnicode(sourceChar)){
                	 
	                // If input is direction formatting code
	                if (sourceChar<=RLO && sourceChar>=LRE){
	                	continue;
	                }
	                // If sourceChar is Newline function
	                /*else if (sourceChar==NLF[0] && (isNLFChar=isNLF(converterData.fromUPara, converterData.paraIndex))){
	                	converterData.paraIndex += NLF.length-1;
//	                	sourceArrayIndex += NLF.length-1;
	                	targetByteUnit = NLF[0];
	                }*/
	                // If sourceChar is Paragraph Separator or Line Separator
	                else if (sourceChar==PS || sourceChar==LS){
	                	targetByteUnit = (byte)NLF[0];
            		}
	        		// If input is in ASCII and C0 control codes range
	                else if (sourceChar <= ASCII_END){
	                	
	                	// R-L
	                	if (bidiPara.getLevelAt(curParaIndex)%2==1){
	                		if (sourceChar>=0x20 && sourceChar<=0x2F && sourceChar!=0x25 && sourceChar!=0x2C){
	                			targetByteUnit = (0x000F & sourceChar) + 0xA0;
	                		}
	                		else if (sourceChar==0x3A){
	                			targetByteUnit = 0xBA;
	                		}
	                		else if ((sourceChar>=0x3C && sourceChar<=0x3E) || 
	                				 (sourceChar>=0x5B && sourceChar<=0x5f) ||
	                				 (sourceChar>=0x7b && sourceChar<=0x7D)){
	                			targetByteUnit = fromUnicodeTable[sourceChar&BYTE_MASK];
	                		}
	                		else {
	                			targetByteUnit = sourceChar;
	                		}
	                	}
	                	// L-R
	                	else {
	                		targetByteUnit = sourceChar;
	                	}
	                }
	                else {
	                	switch(sourceChar){
	                		case 0x2026:
	                			targetByteUnit = 0x93;
	                			break;
	                		case 0x274A:
	                			targetByteUnit = 0xC0;
	                			break;		                		
	                		default:
	                			targetByteUnit = fromUnicodeTable[sourceChar&BYTE_MASK];
	                	}
	                }
                }
        		
        		if(targetByteUnit != UConverter.missingCharMarker) {
        			// For Paragraph Separator/Line Separator - convert to platform newline convention
        			if (sourceChar==LS || sourceChar==PS /*|| isNLFChar*/){
        				for (int i=0; i<NLF.length; i++){
        	        		int[] offsetsBegin = {offsetsArrayIndex};
                			int[] targetBegin = {targetArrayIndex};
                			targetByteUnit = (byte)NLF[i];
                			WRITE_TO_TARGET_FROM_U(args,offsetsArray, offsetsBegin,0/*sourceArrayIndex*/,targetArray, targetBegin,targetLimit,targetByteUnit,err);
                			offsetsArrayIndex = offsetsBegin[0];
                			targetArrayIndex = targetBegin[0];
                			if(ErrorCode.isFailure(err[0])){
                				break;
                			}
        	        	}
        			}
        			// Other characters
        			else{
	        			int[] offsetsBegin = {offsetsArrayIndex};
	        			int[] targetBegin = {targetArrayIndex};
	        			WRITE_TO_TARGET_FROM_U(args,offsetsArray, offsetsBegin,0/*sourceArrayIndex*/,targetArray, targetBegin,targetLimit,targetByteUnit,err);
	        			offsetsArrayIndex = offsetsBegin[0];
	        			targetArrayIndex = targetBegin[0];
	        			if(ErrorCode.isFailure(err[0])){
	        				break;
	        			}
        			}
        		}
        		else{
        			err[0] = ErrorCode.U_INVALID_CHAR_FOUND;
        			break;
        		}
        	}
        	
        	if (!ErrorCode.isFailure(err[0])){
        		// Reset the paragraph
            	converterData.fromUPara = new StringBuffer();
            	converterData.paraIndex = 0;
            	sourceArrayIndex = 0;
			}        	
	    }
	
	    /*save the state and return */
	    args.sourceBegin = sourceArrayIndex;
	    args.targetBegin = targetArrayIndex;
	}

	private static final void WRITE_TO_TARGET_TO_U(UConverterToUnicodeArgs args,char[] targetArray, int[] targetBegin,int[] offsetsArray, int[] offsetsBegin,int offset,char targetUniChar, int[] err)
	{
	    /* now write the targetUniChar */                                                    
	    if(targetBegin[0]<args.targetLimit){                                                        
	        targetArray[targetBegin[0]++] = targetUniChar;                                              
	        if(offsetsArray != null){                                                                     
	            offsetsArray[offsetsBegin[0]++] = (int)(offset);                                            
	        }                                                                                
	    }else{                                                                               
	        args.converter.UCharErrorBufferArray[args.converter.UCharErrorBufferLength++] = targetUniChar;                                                        
	        err[0] = ErrorCode.U_BUFFER_OVERFLOW_ERROR;                                                  
	    }                                                                                    
	}                                                                                        
	                                                                                         
	protected void UConverter_toUnicode_MacArabic(UConverterToUnicodeArgs args, int[] err)
	{
	    byte[] sourceArray = args.sourceArray;
		int sourceArrayIndex = args.sourceBegin;
	    char[] targetArray = args.targetArray;
	    int targetArrayIndex = args.targetBegin;
	    int sourceLimit = args.sourceLimit;
	    int targetLimit = args.targetLimit;
	    char targetUniChar = 0x0000;
	    short sourceChar = 0x0000;
	    UConverterDataMacArabic data;
	    int[] targetBegin = new int[1];
	    int[] offsetsBegin = new int[1];

	    if ((args.converter == null) || (targetArrayIndex < args.targetBegin) || (sourceArrayIndex < args.sourceBegin)){
	        err[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        return;
	    }
	    
	    data = (UConverterDataMacArabic)(args.converter.extraInfo);
	
	    while(sourceArrayIndex<sourceLimit){
	
	        if(targetArrayIndex < targetLimit){
	        	
	            sourceChar = (short)(sourceArray[sourceArrayIndex++] & UConverterUtility.UNSIGNED_BYTE_MASK);
	            targetUniChar = toUnicodeTable[sourceChar][0];
	            
	            switch(toUnicodeTable[sourceChar][1]){
	            	// No direction formatting required	
	            	case 0:
	            		byte targetDirection = Character.getDirectionality(targetUniChar);
	            		
	            		// A remain character in buffer 
	            		if (args.converter.toUnicodeStatus!=UConverter.missingCharMarker){
	    	            	// Same direction
	            			if (data.contextDirectionToUnicode==targetDirection){
	    	            		// Write remaining character in buffer
	    	            		targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	    	            	}	    	     
	            			// Opposite direction
	    	            	else{
	    	            		char directionTmp;
	    	            		if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_LEFT_TO_RIGHT){
	    	            			directionTmp = LRO;
	    	            		}
	    	            		else{
	    	            			directionTmp = RLO;
	    	            		}
	    	            		// Write direction
	    	            		targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), directionTmp, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		
	    	            		// Write remaining character in buffer
	    	    				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	    	            		
	    	            		// Write PDF
	    	            		targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	 
	    	            	}	            			
	    	            }
	            		// There's previous direction
	            		else if (data.contextDirectionToUnicode==LRO || data.contextDirectionToUnicode==RLO){	            			
	            			// Write PDF
	            			targetBegin[0] = targetArrayIndex;
    	    				offsetsBegin[0] = args.offsetsBegin;
    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
    	    				targetArrayIndex = targetBegin[0];
    	    				args.offsetsBegin = offsetsBegin[0];	
	            		}
	            		
	            		// Write current targetUniChar
	            		targetBegin[0] = targetArrayIndex;
	    				offsetsBegin[0] = args.offsetsBegin;
	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
	    				targetArrayIndex = targetBegin[0];
	    				args.offsetsBegin = offsetsBegin[0];	
	            		
	    				// Set context direction
	            		if (targetDirection==Character.DIRECTIONALITY_LEFT_TO_RIGHT || 
	            			targetDirection==Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC)
	            			data.contextDirectionToUnicode = (char)targetDirection;
	            		else 
	            			data.contextDirectionToUnicode = NO_CHAR_MARKER;
	            		
	            		break;
	            	case LRO:
	            		// A remaining character in buffer
	            		if (args.converter.toUnicodeStatus!=UConverter.missingCharMarker){
	            			// Same direction
	            			if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_LEFT_TO_RIGHT){
	            				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), LRO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		
	    	            		// Write remaining character in buffer
	    	    				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	            			}
	            			// Opposite direction
	            			else{
	            				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), RLO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		
	    	            		// Write remaining character in buffer
	    	    				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	    	            		
	    	            		// Write PDF
		            			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	    				
	    	    				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), LRO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	            			}
	            			// Write current targetUniChar
	            			targetBegin[0] = targetArrayIndex;
		    				offsetsBegin[0] = args.offsetsBegin;
		    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
		    				targetArrayIndex = targetBegin[0];
		    				args.offsetsBegin = offsetsBegin[0];	
		    				
		    				// Set direction
		            		data.contextDirectionToUnicode = LRO;
	            		}
	            		else{
	            			// The same strong direction
	            			if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_LEFT_TO_RIGHT){
	            				args.converter.toUnicodeStatus = targetUniChar;
	            			}
	            			// The same direction
	            			else if (data.contextDirectionToUnicode==LRO){
	            				// Write current targetUniChar
	                			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	            			}
	            			// The opposite direction or No previous direction or opposite strong direction
	            			else{
	            				// The opposite direction
	            				if (data.contextDirectionToUnicode==RLO){	            		
		            				// Write PDF
			            			targetBegin[0] = targetArrayIndex;
		    	    				offsetsBegin[0] = args.offsetsBegin;
		    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
		    	    				targetArrayIndex = targetBegin[0];
		    	    				args.offsetsBegin = offsetsBegin[0];
	            				}
	    	    				
	    	    				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), LRO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	    				
	    	    				// Write current targetUniChar
	                			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	            		
	    	            		// Set direction
	    	            		data.contextDirectionToUnicode = LRO;
	            			}
	            		}
	            		
	            		break;
	            	case RLO:
	            		// A remaining character in buffer
	            		if (args.converter.toUnicodeStatus!=UConverter.missingCharMarker){
	            			// Same direction
	            			if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC){
	            				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), RLO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		
	    	            		// Write remaining character in buffer
	    	    				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	            			}
	            			// Opposite direction
	            			else{
	            				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), LRO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		
	    	            		// Write remaining character in buffer
	    	    				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), (char)args.converter.toUnicodeStatus, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	    	            		
	    	            		args.converter.toUnicodeStatus = UConverter.missingCharMarker;
	    	            		
	    	            		// Write PDF
		            			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	    				
	    	    				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), RLO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	            			}
	            			// Write current targetUniChar
	            			targetBegin[0] = targetArrayIndex;
		    				offsetsBegin[0] = args.offsetsBegin;
		    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
		    				targetArrayIndex = targetBegin[0];
		    				args.offsetsBegin = offsetsBegin[0];	
		    				
		    				// Set direction
		            		data.contextDirectionToUnicode = RLO;
	            		}
	            		else{
	            			// The same strong direction
	            			if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC){
	            				if (sourceChar<ARABIC_DIGIT_MIN || sourceChar>ARABIC_DIGIT_MAX){
	            					args.converter.toUnicodeStatus = targetUniChar;
	            				}
	            				// Arabic digit, need override
	            				else{
	            					// Write direction
		            				targetBegin[0] = targetArrayIndex;
		    	    				offsetsBegin[0] = args.offsetsBegin;
		    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), RLO, err);
		    	    				targetArrayIndex = targetBegin[0];
		    	    				args.offsetsBegin = offsetsBegin[0];	
		    	    				
		    	    				// Write current targetUniChar
		                			targetBegin[0] = targetArrayIndex;
		    	    				offsetsBegin[0] = args.offsetsBegin;
		    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
		    	    				targetArrayIndex = targetBegin[0];
		    	    				args.offsetsBegin = offsetsBegin[0];	
		    	            		
		    	            		// Set direction
		    	            		data.contextDirectionToUnicode = RLO;
	            				}
	            			}
	            			// The same direction
	            			else if (data.contextDirectionToUnicode==RLO){
	            				// Write current targetUniChar
	                			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	            			}
	            			// The opposite direction or No previous direction or opposite strong direction
	            			else{
	            				// The opposite direction
	            				if (data.contextDirectionToUnicode==LRO){	            		
		            				// Write PDF
			            			targetBegin[0] = targetArrayIndex;
		    	    				offsetsBegin[0] = args.offsetsBegin;
		    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), PDF, err);
		    	    				targetArrayIndex = targetBegin[0];
		    	    				args.offsetsBegin = offsetsBegin[0];
	            				}
	    	    				
	    	    				// Write direction
	            				targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), RLO, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	    				
	    	    				// Write current targetUniChar
	                			targetBegin[0] = targetArrayIndex;
	    	    				offsetsBegin[0] = args.offsetsBegin;
	    	    				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-2), targetUniChar, err);
	    	    				targetArrayIndex = targetBegin[0];
	    	    				args.offsetsBegin = offsetsBegin[0];	
	    	            		
	    	            		// Set direction
	    	            		data.contextDirectionToUnicode = RLO;
	            			}
	            		}
	            }
	        }
	        else{
	            err[0] =ErrorCode.U_BUFFER_OVERFLOW_ERROR;
	            break;
	        }
	    }
	
	    /* end of the input stream */
	    if(ErrorCode.isSuccess(err[0]) &&  args.flush && sourceArrayIndex == sourceLimit) {
	        
        	/* output direction override and code point if there's one in the buffer */
        	if (args.converter.toUnicodeStatus!=UConverter.missingCharMarker){
        		
        		char directionTmp;
        		if (data.contextDirectionToUnicode==Character.DIRECTIONALITY_LEFT_TO_RIGHT){
        			directionTmp = LRO;
        		}
        		else{
        			directionTmp = RLO;
        		}
        		
        		// Write direction
        		targetBegin[0] = targetArrayIndex;
				offsetsBegin[0] = args.offsetsBegin;
				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-1),directionTmp,err);
				targetArrayIndex = targetBegin[0];
				args.offsetsBegin = offsetsBegin[0];
				
				// The remain code point
				targetBegin[0] = targetArrayIndex;
				offsetsBegin[0] = args.offsetsBegin;
				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-1),(char)args.converter.toUnicodeStatus,err);
				targetArrayIndex = targetBegin[0];
				args.offsetsBegin = offsetsBegin[0];						        		
				args.converter.toUnicodeStatus = UConverter.missingCharMarker;
				
				// Write PDF
	        	targetBegin[0] = targetArrayIndex;
				offsetsBegin[0] = args.offsetsBegin;
				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-1),PDF,err);
				targetArrayIndex = targetBegin[0];
				args.offsetsBegin = offsetsBegin[0];
        	}
        	else if (data.contextDirectionToUnicode==LRO || data.contextDirectionToUnicode==RLO){
	        	// Write PDF
	        	targetBegin[0] = targetArrayIndex;
				offsetsBegin[0] = args.offsetsBegin;
				WRITE_TO_TARGET_TO_U(args,targetArray, targetBegin,args.offsetsArray, offsetsBegin,(sourceArrayIndex-args.sourceBegin-1),PDF,err);
				targetArrayIndex = targetBegin[0];
				args.offsetsBegin = offsetsBegin[0];
        	}
	    }
	
	    args.targetBegin = targetArrayIndex;
	    args.sourceBegin = sourceArrayIndex;
	}

	public static UConverterStaticData _MacArabicStaticData;
	public static UConverterSharedData_MacArabic _MacArabicData;
	static
	{
		_MacArabicStaticData= new UConverterStaticData(
						UConverterStaticData.sizeofUConverterStaticData,
		        "MacArabic",
		         0, 
		         (byte)UConverterPlatform.UCNV_IBM, 
		         (byte)UConverterType.UCNV_MAC_ARABIC, 
		         (byte)1, 
		         (byte)4,
		        new byte[]{ 0x1a, 0, 0, 0 },
		        (byte)0x1,
		        (byte)0 /*FALSE*/, 
		        (byte)0 /*FALSE*/,
		        (short)0x0,
		        (byte)0x0,
		        new byte[]{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 } /* reserved */
		
		);
   
		_MacArabicData= new UConverterSharedData_MacArabic(
						sizeofUConverterSharedData,
		        ~0,
		        //agljport:delete NULL, 
		        //agljport:delete NULL, 
		        _MacArabicStaticData, 
		        false, 
		        //agljport:delete &_ISCIIImpl, 
		        0
		);
	}
}
