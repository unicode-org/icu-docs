/**************************************************************************
*
*   Copyright (C) 2000, International Business Machines
*   Corporation and others.  All Rights Reserved.
*
***************************************************************************
*   file name:  colex1.c
*
*   created on: 2000Aug31
*   created by: Helena Shih
*
*   Sample code for the ICU Collator C routines.  This sample code file
*   contains the parallel examples of the colex.cpp file.
*
*   collateWithLocaleInC(): 
*   1. Opens a collator with a locale. 
*   2. Compares two strings with the collator. 
*   3. Sets the strength to tertiary and compare the strings again. 
*   4. Gets the keys for the strings and compare them. 
* 
*   collateWithRulesInC():
*   1. Open a Collator with customized rules and attributes. 
*   2. Compare two strings with the collator. 
*   3. Open a CollationElementIterator. 
*   4. Walk through the text with the element iterator. 
*
*/
#include <stdio.h>
#include <memory.h>
#include "unicode/ustring.h"
#include "unicode/utypes.h"
#include "unicode/uloc.h"
#include "unicode/ucol.h"

#define MAXBUFFERSIZE 100
#define BIGBUFFERSIZE 5000

UChar* 
prv_strncpy(UChar     *dst, 
     const UChar     *src, 
     int32_t     n) 
{
  UChar *anchor = dst;     /* save the start of result string */
  
  if (!n) return dst;
  while(n--)
      *dst++ = *src++;
  *dst = 0x0000;
  return anchor;
}

UChar* 
prv_strcat(UChar     *dst, 
     const UChar     *src,
     int32_t n)
{
  UChar *anchor = dst;       /* save a pointer to start of dst */
  
  if (!n) return dst;

  dst += n;
  while (*src != 0x0000) 
      *dst++ = *src++;
  *dst = 0x0000;
  
  return anchor;
}

/* show the primary elements for 'Zero' and 'Pie' with both enUSCollator and new Collator. */
UBool walkThroughElements(UCollator* col, const UChar* source, const UChar* target, int32_t len, UErrorCode *status)
{
    UCollationElements *elems = 0;
    UCollationStrength strength = ucol_getStrength(col);
    int32_t order = 0, orderSegment;
    int i = 0;

    /* Print out primary orders of the first few specified characters of both source and target strings*/
    ucol_setNormalization(col, UCOL_DECOMP_CAN);
    elems = ucol_openElements(col, source, MAXBUFFERSIZE, status);
    if (U_FAILURE(*status))
    {
        fprintf(stderr,
        "Failed to create the collation element iterator.\n");  
        return FALSE;
    }
    fprintf(stdout, "Processing source string now...\n");
    while ((order = ucol_next(elems, status)) != UCOL_NULLORDER && i < len) {
        if (U_FAILURE(*status))
        {
            fprintf(stderr, "Getting the next source collation element failed.\n");
            return FALSE;
        }
        orderSegment = order & UCOL_PRIMARYMASK;
        fprintf(stdout, "Source character = '%c' : primary order = 0x%04x.\n", source[i++], orderSegment);        
    }
    ucol_setText(elems, target, len, status);
    i = 0;
    fprintf(stdout, "Processing target string now...\n");
    while ((order = ucol_next(elems, status)) != UCOL_NULLORDER && i < len) {
        if (U_FAILURE(*status))
        {
            fprintf(stderr, "Getting the next target collation element failed.\n");
            return FALSE;
        }
        orderSegment = order & UCOL_PRIMARYMASK;
        fprintf(stdout, "Target character = '%c' : primary order = 0x%04x.\n", target[i++], orderSegment);        
    }
    ucol_closeElements(elems);
    return TRUE;
}

UBool collateWithLocaleInC(const char* locale, UErrorCode *status)
{
    UChar 		dispName	[MAXBUFFERSIZE]; 
    int32_t 	bufferLen 	= 0;
    UChar 		source		[MAXBUFFERSIZE];
    UChar 		target		[MAXBUFFERSIZE];
    UCollationResult result 	= UCOL_EQUAL;
    uint8_t 		sourceKeyArray	[MAXBUFFERSIZE];
    uint8_t 		targetKeyArray	[MAXBUFFERSIZE]; 
    int32_t 	sourceKeyOut 	= 0, 
		    targetKeyOut 	= 0;
    UCollator	*myCollator	= 0;

    if (U_FAILURE(*status))
    {
        return FALSE;
    }
    u_uastrcpy(source, "This is a test.");
    u_uastrcpy(target, "THISISATEST.");

    myCollator = ucol_open(locale, status);
    if (U_FAILURE(*status)){
        bufferLen = uloc_getDisplayName(locale, 0, dispName, MAXBUFFERSIZE, status);
        /*Report the error with display name... */
        fprintf(stderr,
        "Failed to create the collator for : \"%s\"\n", dispName);
        return FALSE;
    }
    result = ucol_strcoll(myCollator, source, u_strlen(source), target, u_strlen(target));
    /* result is 1, secondary differences only for ignorable space characters*/
    if (result != 1)
    {
        fprintf(stderr,
        "Comparing two strings with only secondary differences in C failed.\n");
        return FALSE;
    }
    /* To compare them with just primary differences */
    ucol_setStrength(myCollator, UCOL_PRIMARY);
    result = ucol_strcoll(myCollator, source, u_strlen(source), target, u_strlen(target));
    /* result is 0 */
    if (result != 0)
    {
        fprintf(stderr,
        "Comparing two strings with no differences in C failed.\n");
        return FALSE;
    }
    /* Now, do the same comparison with keys */
    sourceKeyOut = ucol_getSortKey(myCollator, source, u_strlen(source), sourceKeyArray, MAXBUFFERSIZE);
    targetKeyOut = ucol_getSortKey(myCollator, target, u_strlen(target), targetKeyArray, MAXBUFFERSIZE);
    result = 0;
    bufferLen = ((targetKeyOut > MAXBUFFERSIZE) ? MAXBUFFERSIZE : targetKeyOut);
    result = memcmp(sourceKeyArray, targetKeyArray, bufferLen);
    if (result != 0)
    {
        fprintf(stderr,
        "Comparing two strings with sort keys in C failed.\n");
        return FALSE;
    }
    ucol_close(myCollator);
    return TRUE;
}

UBool collateWithRulesInC(UErrorCode* status)
{    /* Open a new collator with additional rules \"& Z < p, P\" */
    UChar 		newRules	[MAXBUFFERSIZE];
    UChar 		ruleSet		[BIGBUFFERSIZE];
    int32_t 	ruleLen 	= 0, newRuleLen = 0;
    UChar 		source		[MAXBUFFERSIZE];
    UChar 		target		[MAXBUFFERSIZE];
    const UChar *baseRules 	= 0;
    UCollator 	*col 		= 0;
    UCollator	*enUSCollator	= 0;
    UCollationResult result 	= UCOL_EQUAL;

    enUSCollator = ucol_open("en_US", status);
    if (U_FAILURE(*status)){
        fprintf(stderr,
        "Failed to create the collator for en_US.\n");        
        return FALSE;
    }

    baseRules = ucol_getRules(enUSCollator, &ruleLen);
    u_uastrcpy(newRules, " & Z < p, P");
    newRuleLen = u_strlen(newRules);
    prv_strncpy(ruleSet, baseRules, ruleLen);
    prv_strcat(ruleSet, newRules, ruleLen);  /* Hard to make insertion easily */
    *status = U_ZERO_ERROR;
    col = ucol_openRules(ruleSet, ruleLen + newRuleLen, UCOL_NO_NORMALIZATION, UCOL_DEFAULT_STRENGTH, status);
    if (U_FAILURE(*status)) {
        /* Report the error */
        fprintf(stderr,
        "Failed to create the collator for with rules.\n");
        return FALSE;
    }
    u_uastrcpy(source, "Zero in with the pie");
    u_uastrcpy(target, "Pie as the target");
    result = ucol_strcoll(enUSCollator, source, u_strlen(source), target, u_strlen(target));
    if (result != 1)
    {
        fprintf(stderr, "'Pie' should sort before 'Zero' with the en_US rules.\n");
        return FALSE;
    }
    result = ucol_strcoll(col, source, u_strlen(source), target, u_strlen(target));
    /* Get attributes from the collator */
    if (result != -1)
    {
        fprintf(stderr, "'Zero' should sort before 'Pie' with the new rules.\n");
        return FALSE;
    }
    /* Go through the elements until the first occurance of ' ' character in the strings */
   fprintf(stdout, "\nWalk through strings with en_US collator first...\n");
   if (walkThroughElements(enUSCollator, source, target, 4, status) == FALSE)
    {
        return FALSE;
    }
   fprintf(stdout, "\n\nWalk through strings with the custom collator now...\n");
    if (walkThroughElements(col, source, target, 4, status) == FALSE)
    {
        return FALSE;
    }
    ucol_close(enUSCollator);
    ucol_close(col); 
    return TRUE;
}

