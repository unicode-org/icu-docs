package com.ibm.icu.impl;

public final class UConverterUTF16 {
/* single-code point definitions -------------------------------------------- */

/**
 * Does this code unit alone encode a code point (BMP, not a surrogate)?
 * @param c 16-bit code unit
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U16_IS_SINGLE(char c) {return !UConverterUTF.U_IS_SURROGATE(c);}

/**
 * Is this code unit a lead surrogate (U+d800..U+dbff)?
 * @param c 16-bit code unit
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U16_IS_LEAD(char c) {return (((c & UConverterUtility.UNSIGNED_SHORT_MASK)&0xfffffc00)==0xd800);}

/**
 * Is this code unit a trail surrogate (U+dc00..U+dfff)?
 * @param c 16-bit code unit
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U16_IS_TRAIL(char c) {return (((c & UConverterUtility.UNSIGNED_SHORT_MASK)&0xfffffc00)==0xdc00);}

/**
 * Is this code unit a surrogate (U+d800..U+dfff)?
 * @param c 16-bit code unit
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U16_IS_SURROGATE(char c) {return UConverterUTF.U_IS_SURROGATE(c);}

/**
 * Assuming c is a surrogate code point (U16_IS_SURROGATE(c)),
 * is it a lead surrogate?
 * @param c 16-bit code unit
 * @return TRUE or FALSE
 * @stable ICU 2.4
 */
public static boolean U16_IS_SURROGATE_LEAD(char c) {return (((c)&0x400)==0);}

/**
 * Helper constant for U16_GET_SUPPLEMENTARY.
 * @internal
 */
public static final int U16_SURROGATE_OFFSET = ((0xd800<<10)+0xdc00-0x10000);


/**
 * Get a supplementary code point value (U+10000..U+10ffff)
 * from its lead and trail surrogates.
 * The result is undefined if the input values are not
 * lead and trail surrogates.
 *
 * @param lead lead surrogate (U+d800..U+dbff)
 * @param trail trail surrogate (U+dc00..U+dfff)
 * @return supplementary code point (U+10000..U+10ffff)
 * @stable ICU 2.4
 */
/*agljport:change 
#define U16_GET_SUPPLEMENTARY(lead, trail) \
    (((UChar32)(lead)<<10UL)+(UChar32)(trail)-U16_SURROGATE_OFFSET)
		*/
public static int U16_GET_SUPPLEMENTARY(char lead, char trail)
{
    return (((lead & UConverterUtility.UNSIGNED_SHORT_MASK)<<10)+(trail & UConverterUtility.UNSIGNED_SHORT_MASK)-U16_SURROGATE_OFFSET);
}

/**
 * Get the lead surrogate (0xd800..0xdbff) for a
 * supplementary code point (0x10000..0x10ffff).
 * @param supplementary 32-bit code point (U+10000..U+10ffff)
 * @return lead surrogate (U+d800..U+dbff) for supplementary
 * @stable ICU 2.4
 */
public static char U16_LEAD(int supplementary) {return (char)(((supplementary)>>10)+0xd7c0);}

/**
 * Get the trail surrogate (0xdc00..0xdfff) for a
 * supplementary code point (0x10000..0x10ffff).
 * @param supplementary 32-bit code point (U+10000..U+10ffff)
 * @return trail surrogate (U+dc00..U+dfff) for supplementary
 * @stable ICU 2.4
 */
public static char U16_TRAIL(int supplementary) {return (char)(((supplementary)&0x3ff)|0xdc00);}

/**
 * How many 16-bit code units are used to encode this Unicode code point? (1 or 2)
 * The result is not defined if c is not a Unicode code point (U+0000..U+10ffff).
 * @param c 32-bit code point
 * @return 1 or 2
 * @stable ICU 2.4
 */
public static int U16_LENGTH(int c) {return ((c & UConverterUtility.UNSIGNED_INT_MASK)<=0xffff ? 1 : 2);}

/**
 * The maximum number of 16-bit code units per Unicode code point (U+0000..U+10ffff).
 * @return 2
 * @stable ICU 2.4
 */
public static final int U16_MAX_LENGTH = 2;

/**
 * Append a code point to a string, overwriting 1 or 2 code units.
 * The offset points to the current end of the string contents
 * and is advanced (post-increment).
 * "Unsafe" macro, assumes a valid code point and sufficient space in the string.
 * Otherwise, the result is undefined.
 *
 * @param s const UChar * string buffer
 * @param i string offset
 * @param c code point to append
 * @see U16_APPEND
 * @stable ICU 2.4
 */
/*agljport:change
#define U16_APPEND_UNSAFE(s, i, c) { \
    if((uint32_t)(c)<=0xffff) { \
        (s)[(i)++]=(uint16_t)(c); \
    } else { \
        (s)[(i)++]=(uint16_t)(((c)>>10)+0xd7c0); \
        (s)[(i)++]=(uint16_t)(((c)&0x3ff)|0xdc00); \
    } \
}
*/
public static final void U16_APPEND_UNSAFE(char[] s, int[] i, int c)
{
    if((c & UConverterUtility.UNSIGNED_INT_MASK)<=0xffff) { 
        s[i[0]++]=(char)(c); 
    } else { 
        s[i[0]++]=(char)((c>>>10)+0xd7c0); 
        s[i[0]++]=(char)((c&0x3ff)|0xdc00); 
    } 
}

/**
 * Append a code point to a string, overwriting 1 or 2 code units.
 * The offset points to the current end of the string contents
 * and is advanced (post-increment).
 * "Safe" macro, checks for a valid code point.
 * If a surrogate pair is written, checks for sufficient space in the string.
 * If the code point is not valid or a trail surrogate does not fit,
 * then isError is set to TRUE.
 *
 * @param s const UChar * string buffer
 * @param i string offset, i<length
 * @param capacity size of the string buffer
 * @param c code point to append
 * @param isError output UBool set to TRUE if an error occurs, otherwise not modified
 * @see U16_APPEND_UNSAFE
 * @stable ICU 2.4
 */
/*agljport:change
#define U16_APPEND(s, i, capacity, c, isError) { \
    if((uint32_t)(c)<=0xffff) { \
        (s)[(i)++]=(uint16_t)(c); \
    } else if((uint32_t)(c)<=0x10ffff && (i)+1<(capacity)) { \
        (s)[(i)++]=(uint16_t)(((c)>>10)+0xd7c0); \
        (s)[(i)++]=(uint16_t)(((c)&0x3ff)|0xdc00); \
    } else { \
        (isError)=TRUE; \
    } \
}
*/
public static final void U16_APPEND(char[] s, int[] i, int capacity, int c, boolean[] isError)
{
    if((c & UConverterUtility.UNSIGNED_INT_MASK)<=0xffff) { 
        s[i[0]++]=(char)c; 
    } else if((c & UConverterUtility.UNSIGNED_INT_MASK)<=0x10ffff && i[0]+1<capacity) { 
        s[i[0]++]=(char)((c>>>10)+0xd7c0); 
        s[i[0]++]=(char)((c&0x3ff)|0xdc00); 
    } else /* c>0x10ffff or not enough space */ { 
        if(isError != null)
					isError[0]=true; 
    } 
}


}

