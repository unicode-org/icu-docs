package com.ibm.icu.impl;

/* struct with arguments for UConverterLoad and ucnv_load() */
public final class UConverterLoadArgs {
    //agljport:todo int32_t size;               /* sizeof(UConverterLoadArgs) */
    //int32_t nestedLoads;        /* count nested ucnv_load() calls */
    public int nestedLoads;        /* count nested ucnv_load() calls */
    //int32_t reserved;           /* reserved - for good alignment of the pointers */
    public int reserved;           /* reserved - for good alignment of the pointers */
    //uint32_t options;
    public long options;
    //const char *pkg, *name;
    public String pkg;
		public String name;
}


