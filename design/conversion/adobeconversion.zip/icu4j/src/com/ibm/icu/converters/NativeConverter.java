/**
*******************************************************************************
* Copyright (C) 1996-2005, International Business Machines Corporation and    *
* others. All Rights Reserved.                                                *
*******************************************************************************
*
*******************************************************************************
*/ 

package com.ibm.icu.converters;

import java.util.Arrays;

import com.ibm.icu.impl.UConverterUTF16;
import com.ibm.icu.text.UnicodeSet;
import com.ibm.icu.common.ErrorCode;
import com.ibm.icu.impl.UConverterCallback;
import com.ibm.icu.impl.UConverterAlias;

/**
 * Class for accessing the underlying JNI methods
 * @internal ICU 2.4
 */
public final class NativeConverter{
  
    // library loading ----------------------------------------------
    static {
        //agljport:delete ICU4JNILoader.loadLibrary();
    }
      
    //Native methods
    
    /**
     * Converts an array of bytes containing characters in an external
     * encoding into an array of Unicode characters.  This  method allows
     * a buffer by buffer conversion of a data stream.  The state of the
     * conversion is saved between calls to convert.  Among other things,
     * this means multibyte input sequences can be split between calls.
     * If a call to convert results in an Error, the conversion may be
     * continued by calling convert again with suitably modified parameters.
     * All conversions should be finished with a call to the flush method.
     *
     * @param converterHandle Address of converter object created by C code
     * @param input byte array containing text to be converted.
     * @param inEnd stop conversion at this offset in input array (exclusive).
     * @param output character array to receive conversion result.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */
     
    public static final int convertByteToChar( /*long*/UConverter converterHandle,
                                   byte[] input, int inEnd,
		                           char[] output, int outEnd,
		                           int[] data,
		                           boolean flush)
	{
		int[] errorCode = new int[] {ErrorCode.U_ZERO_ERROR};
		int[] inputBegin = new int[] {data[0]};
		int[] outputBegin = new int[] {data[1]};
		converterHandle.ucnv_toUnicode(output, outputBegin, outEnd, input, inputBegin, inEnd, flush, errorCode);
		data[0] = inputBegin[0] - data[0];
		data[1] = outputBegin[0] - data[1];
		return errorCode[0];
	}

    /**
     * Converts an array of bytes containing characters in an external
     * encoding into an array of Unicode characters.  This  method allows
     * a buffer by buffer conversion of a data stream.  The state of the
     * conversion is saved between calls to convert.  Among other things,
     * this means multibyte input sequences can be split between calls.
     * If a call to convert results in an Error, the conversion may be
     * continued by calling convert again with suitably modified parameters.
     * All conversions should be finished with a call to the flush method.
     *
     * @param converterHandle Address of converter object created by C code
     * @param input byte array containing text to be converted.
     * @param inEnd stop conversion at this offset in input array (exclusive).
     * @param output character array to receive conversion result.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */
	public static final int decode( /*long*/UConverter converterHandle,
                                   byte[] input, int inEnd,
		                           char[] output, int outEnd,
		                           int[] data,
		                           boolean flush)
	{
		int[] ec = new int[1];
		ec[0] = convertByteToChar(converterHandle, input, inEnd, output, outEnd, data, flush);
		
		int[] myData = data;
		
		if (myData!=null && converterHandle!=null){
			int err[] = {ErrorCode.U_ZERO_ERROR};
			myData[3] = UConverter.ucnv_toUCountPending(converterHandle, err);
			
			if(ec[0] == ErrorCode.U_ILLEGAL_CHAR_FOUND || ec[0] == ErrorCode.U_INVALID_CHAR_FOUND){
				char invalidUChars[] = new char[32];
				int[] len = {invalidUChars.length};
				converterHandle.ucnv_getInvalidUChars(invalidUChars,len,err);
				
				if(ErrorCode.isSuccess(err[0])){
					myData[2] = len[0];
				}
			}
		}
	    return ec[0];		
	}
	
	/**
     * Converts an array of Unicode chars containing characters in an 
     * external encoding into an array of bytes.  This  method allows
     * a buffer by buffer conversion of a data stream.  The state of the
     * conversion is saved between calls to convert.  Among other things,
     * this means multibyte input sequences can be split between calls.
     * If a call to convert results in an Error, the conversion may be
     * continued by calling convert again with suitably modified parameters.
     * All conversions should be finished with a call to the flush method.
     *
     * @param converterHandle Address of converter object created by C code
     * @param input char array containing text to be converted.
     * @param inEnd stop conversion at this offset in input array (exclusive).
     * @param output byte array to receive conversion result.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */	                         
	public static final int convertCharToByte(/*long*/UConverter converterHandle,
                                   char[] input, int inEnd,
		                           byte[] output, int outEnd,
		                           int[] data,
		                           boolean flush) 
	{
		int[] errorCode = new int[] {ErrorCode.U_ZERO_ERROR};
		int[] inputBegin = new int[] {data[0]};
		int[] outputBegin = new int[] {data[1]};
		converterHandle.ucnv_fromUnicode(output, outputBegin, outEnd, input, inputBegin, inEnd, flush, errorCode);
		data[0] = inputBegin[0] - data[0];
		data[1] = outputBegin[0] - data[1];
		return errorCode[0];
	}
	
    /**
     * Converts an array of Unicode chars containing characters in an 
     * external encoding into an array of bytes.  This  method allows
     * a buffer by buffer conversion of a data stream.  The state of the
     * conversion is saved between calls to convert.  Among other things,
     * this means multibyte input sequences can be split between calls.
     * If a call to convert results in an Error, the conversion may be
     * continued by calling convert again with suitably modified parameters.
     * All conversions should be finished with a call to the flush method.
     *
     * @param converterHandle Address of converter object created by C code
     * @param input char array containing text to be converted.
     * @param inEnd stop conversion at this offset in input array (exclusive).
     * @param output byte array to receive conversion result.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */  		                           
	public static final int encode(/*long*/UConverter converterHandle,
                                   char[] input, int inEnd,
		                           byte[] output, int outEnd,
		                           int[] data,
		                           boolean flush)
	{
		int[] ec = new int[1];
	    ec[0] = convertCharToByte(converterHandle,input,inEnd, output,outEnd,data,flush);
	    int[] myData = data;
	    
	    if (converterHandle!=null && myData!=null){
	    	int[] err = {ErrorCode.U_ZERO_ERROR};
	    	myData[3] = UConverter.ucnv_fromUCountPending(converterHandle, err);
	    	
	    	if(ec[0] == ErrorCode.U_ILLEGAL_CHAR_FOUND || ec[0] == ErrorCode.U_INVALID_CHAR_FOUND){
	    		char invalidUChars[/*32*/] = new char[32];
	    		int[] count = {invalidUChars.length};
	    		converterHandle.ucnv_getInvalidUChars(invalidUChars,count,err);
	    		
	    		if (ErrorCode.isSuccess(err[0])){
	    			myData[2] = count[0];
	    		}
	    	}
	    }
	    return ec[0];
	}
	
	/**
     * Writes any remaining output to the output buffer and resets the
     * converter to its initial state. 
     *
     * @param converterHandle Address of converter object created by C code
     * @param output byte array to receive flushed output.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @return int error code returned by ICU
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @internal ICU 2.4
     */ 
	public static final int flushCharToByte(/*long*/UConverter converterHandle,
	                               byte[] output, 
	                               int outEnd, 
	                               int[] data)
	{
		int[] errorCode = {ErrorCode.U_ZERO_ERROR};
		if(converterHandle != null){
			char[] source ={0};
			if(data != null){
				if(output != null){
					int[] sourceBegin = {0};
					int sourceLimit=0;
					int[] outBegin= {data[1]};

					converterHandle.ucnv_fromUnicode(output, outBegin, outEnd, source, sourceBegin,
							sourceLimit,true, errorCode);
					data[1] = outBegin[0] - data[1];

				}else{
					errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
				}
			}else{
				errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
			}
			return errorCode[0];
		}
		errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}

	/**
     * Writes any remaining output to the output buffer and resets the
     * converter to its initial state. 
     *
     * @param converterHandle Address of converter object created by the native code
     * @param output char array to receive flushed output.
     * @param outEnd stop writing to output array at this offset (exclusive).
     * @return int error code returned by ICU
     * @param data integer array containing the following data    
     *        data[0] = inputOffset
     *        data[1] = outputOffset
     * @internal ICU 2.4
     */ 	
	public static final int flushByteToChar(/*long*/UConverter converterHandle,
	                               char[] output,  
	                               int outEnd, 
	                               int[] data)
	{
		int[] errorCode = {ErrorCode.U_ZERO_ERROR};
		if(converterHandle != null){
			byte[] source = {0};
			if(data != null){
				if(output != null){
					int[] sourceBegin = {0};
					int sourceLimit=0;
					int[] outBegin= {data[1]};

					converterHandle.ucnv_toUnicode(output, outBegin, outEnd, source, sourceBegin,
							sourceLimit,true, errorCode);
					data[1] = outBegin[0] - data[1];

				}else{
					errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
				}
			}else{
				errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
			}
			return errorCode[0];
		}
		errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}
	
	/**
	 * Open the converter with the specified encoding
	 *
	 * @param converterHandle long UConverter array for recieving the adress of converter object
	 *        created by the native code
	 * @param encoding string representing encoding
	 * @return int error code returned by ICU
     * @internal ICU 2.4
	 */
	public static final int openConverter(UConverter[] converterHandle, String encoding)
	{
		// ported from native method in ConverterInterface.c
		//agljport:delete UConverter conv=null;
		int[] errorCode = {ErrorCode.U_ZERO_ERROR};

		converterHandle[0] = UConverter.ucnv_open(encoding, errorCode);
		return errorCode[0];
	}
		
	/**
	 * Resets the ByteToChar (toUnicode) state of specified converter 
	 *
	 * @param converterHandle Address of converter object created by the native code
     * @internal ICU 2.4
     */
	public static final void resetByteToChar(/*long*/UConverter  converterHandle)
	{
		if(converterHandle != null)
			converterHandle.ucnv_resetToUnicode();
	}
    
    /**
	 * Resets the CharToByte (fromUnicode) state of specified converter 
	 *
	 * @param converterHandle Address of converter object created by the native code
     * @internal ICU 2.4
     */
	public static final void resetCharToByte(/*long*/UConverter  converterHandle)
	{
		if(converterHandle != null)
			converterHandle.ucnv_resetFromUnicode();
	}
	
	/**
	 * Closes the specified converter and releases the resources
	 *
	 * @param converterHandle Address of converter object created by the native code
     * @internal ICU 2.4
	 */
	public static final void closeConverter(/*long*/UConverter converterHandle)
	{
		if(converterHandle != null)
			converterHandle.ucnv_close();
	}
    
	private static final int setToUCallbackSubs(UConverter cnv,char[] subChars, int length,boolean stopOnIllegal )
	{	
		/*
	    SubCharStruct* substitutionCharS = (SubCharStruct*) malloc(sizeof(SubCharStruct));
	    UErrorCode errorCode = U_ZERO_ERROR;
	    if(substitutionCharS){
	       UConverterToUCallback toUOldAction;
	       void* toUOldContext=NULL;
	       void* toUNewContext=NULL ;
	       if(subChars){
	            u_strncpy(substitutionCharS->subChars,subChars,length);
	       }else{
	           substitutionCharS->subChars[0] =0xFFFD;
	       }
	       substitutionCharS->subChars[length]=0;
	       substitutionCharS->length = length;
	       substitutionCharS->stopOnIllegal = stopOnIllegal;
	       toUNewContext = substitutionCharS;
	
	       ucnv_setToUCallBack(cnv,
	           JNI_TO_U_CALLBACK_SUBSTITUTE,
	           toUNewContext,
	           &toUOldAction,
	           (const void**)&toUOldContext,
	           &errorCode);
	
	       if(toUOldContext){
	           SubCharStruct* temp = (SubCharStruct*) toUOldContext;
	           free(temp);
	       }
	
	       return errorCode;
	    }
	    */
	    return ErrorCode.U_ZERO_ERROR;
	}

    /**
     * Sets the substitution Unicode chars of the specified converter used
     * by encoder
	 * @param converterHandle Address of converter object created by the native code
     * @param subChars array of chars to used for substitution
     * @param length length of the array 
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */    
    public static final int setSubstitutionChars( /*long*/UConverter converterHandle,
                                   char[] subChars,int length)
	{
		int[] errorCode = { ErrorCode.U_ZERO_ERROR };
		if(converterHandle != null) {
			if(subChars != null) {
				errorCode[0] = setToUCallbackSubs(converterHandle, subChars, length, false);
			} else {
				// JNI code
				//errorCode = UErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
			
				// Set the STOP callback
				converterHandle.ucnv_setToUCallBack(new UConverterCallback.UCNV_TO_U_CALLBACK_STOP(), null, null, null, errorCode);
			}
			return errorCode[0];
		}
		errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}

    /**
     * Sets the substitution bytes of the specified converter used by decoder
     *
	 * @param converterHandle Address of converter object created by the native code
     * @param subChars array of bytes to used for substitution
     * @param length length of the array 
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */    
    public static final int setSubstitutionBytes( /*long*/UConverter converterHandle,
                                   byte[] subChars,int length)
	{
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
		UConverter cnv = converterHandle;
		byte[] u_subChars = subChars;
	
	    if(cnv != null){
	        if(u_subChars != null){
	             byte[] mySubChars= u_subChars;
	             cnv.ucnv_setSubstChars(mySubChars, (byte)length,errorCode);
	             if(ErrorCode.isFailure(errorCode[0])){
	                return errorCode[0];
	             }
	        }
	        else{   
	           errorCode[0] =  ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	        }
	        return errorCode[0];
	    }
	    errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	    return errorCode[0];
	}
    /**
     * Sets the substitution mode of CharToByte(fromUnicode) for the specified converter 
     *
	 * @param converterHandle Address of converter object created by the native code
     * @param mode to set the true/false
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */  
    public static final int setSubstitutionModeCharToByte(/*long*/UConverter converterHandle, 
                                   boolean mode)
	{
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
		UConverter conv = converterHandle;
	
		if(conv != null){
	
			UConverterCallback.UConverterFromUCallback[] fromUOldAction = new UConverterCallback.UConverterFromUCallback[1];
			byte[][] fromUOldContext = new byte[1][];
			byte[] fromUNewContext=null;
			if(mode){
	
				conv.ucnv_setFromUCallBack(new UConverterCallback.UCNV_FROM_U_CALLBACK_SUBSTITUTE(), fromUNewContext, fromUOldAction, fromUOldContext, errorCode);
	
			}
			else{
	
				conv.ucnv_setFromUCallBack(new UConverterCallback.UCNV_FROM_U_CALLBACK_STOP(), fromUNewContext, fromUOldAction, fromUOldContext, errorCode);
	
			}
			return errorCode[0];
		}
		errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}
    /**
     * Gets the numnber of invalid bytes in the specified converter object 
     * for the last error that has occured
     *
	 * @param converterHandle Address of converter object created by the native code
     * @param length array of int to recieve length of the array 
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */
    public static final int countInvalidBytes(/*long*/UConverter converterHandle, int[] length)
	{
	    UConverter cnv = converterHandle;
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
	    if(cnv != null){
	        byte invalidChars[/*32*/] = new byte[32];
	
					int[] len = length;
	        if(len != null){
	            cnv.ucnv_getInvalidChars(invalidChars,len,errorCode);
	        }
	        return errorCode[0];
	    }
	    errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}
    
    /**
     * Gets the numnber of invalid chars in the specified converter object 
     * for the last error that has occured
     *
	 * @param converterHandle Address of converter object created by the native code
     * @param length array of int to recieve length of the array 
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */   
    public static final int countInvalidChars(/*long*/UConverter converterHandle, int[] length)
	{
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
		UConverter cnv = converterHandle;
		char invalidUChars[/*32*/] = new char[32];
		if(cnv != null){
			int[] len = length;
			if(len != null){
				cnv.ucnv_getInvalidUChars(invalidUChars,len,errorCode);
			}
			return errorCode[0];
		}
		errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	
	}
    
    /**
     * Gets the number of bytes needed for converting a char
     *
	 * @param converterHandle Address of converter object created by the native code
     * @return number of bytes needed
     * @internal ICU 2.4
     */ 
    public static final int getMaxBytesPerChar(/*long*/UConverter converterHandle)
	{
		return converterHandle.ucnv_getMaxCharSize();
	}
   
    /**
     * Gets the number of bytes needed for converting a char
     *
     * @param converterHandle Address of converter object created by the native code
     * @return number of bytes needed
     * @internal ICU 3.2
     */ 
    public static final int getMinBytesPerChar(/*long*/UConverter converterHandle)
    {
    	return converterHandle.ucnv_getMinCharSize();
    }
    
    /**
     * Gets the average number of bytes needed for converting a char
     *
	 * @param converterHandle Address of converter object created by the native code
     * @return number of bytes needed
     * @internal ICU 2.4
     */ 
    public static final float getAveBytesPerChar(/*long*/UConverter converterHandle)
	{
		if(converterHandle != null) {
			float max = converterHandle.ucnv_getMaxCharSize();
			float min = converterHandle.ucnv_getMinCharSize();
			return (max + min)/2;
		}
		return -1;
	}
   
    /**
     * Gets the number of chars needed for converting a byte
     *
	 * @param converterHandle Address of converter object created by the native code
     * @return number of bytes needed
     * @internal ICU 2.4
     */ 
    public static final int getMaxCharsPerByte(/*long*/UConverter converterHandle)
	{
		if(converterHandle != null)
			return converterHandle.ucnv_getMaxCharSize();
		return -1;
	}
   
    /**
     * Gets the average numnber of chars needed for converting a byte
     *
	 * @param converterHandle Address of converter object created by the native code
     * @return number of bytes needed
     * @internal ICU 2.4
     */ 
    public static final float getAveCharsPerByte(/*long*/UConverter converterHandle)
	{
		float v = 0;
		if(converterHandle != null)
			v = 1/(float)getMaxCharsPerByte(converterHandle);
		return v;
	}
    
    //CSDL: added by Jack
    /**
     * Determines whether charset1 contains charset2.
     */
    public static final boolean contains(/*long*/UConverter cnv1, /*long*/UConverter cnv2)
    {	
    	/*
    	int errorCode[] = {UErrorCode.U_ZERO_ERROR};
        UnicodeSet set1;
        UnicodeSet set2;
        boolean bRet = false;
        
        if(cnv1 != null && cnv2 != null){
    	    // open charset 1 
        	set1 = new UnicodeSet(1, 2);
            UConverter.ucnv_getUnicodeSet(cnv1, set1, UConverter.UConverterUnicodeSet.UCNV_ROUNDTRIP_SET, errorCode);

            if(ErrorCode.isSuccess(errorCode[0])) {
                // open charset 2 
                errorCode[0] = UErrorCode.U_ZERO_ERROR;
                set2 = new UnicodeSet(1, 2);
                UConverter.ucnv_getUnicodeSet(cnv2, set2, UConverter.UConverterUnicodeSet.UCNV_ROUNDTRIP_SET, errorCode);

                // contains? 
                if(ErrorCode.isSuccess(errorCode[0])) {
                    bRet = set1.containsAll(set2);    	            
                }                
            }
        }
    	return bRet;    
    	*/
    	return false;
    }
    
    public static final byte[] getSubstitutionBytes(/*long*/UConverter converterHandle)
	{
	    UConverter cnv = converterHandle;
	    int status[] = {ErrorCode.U_ZERO_ERROR};
	    byte subBytes[/*10*/] = new byte[10];
	    byte[] len ={(byte)10};
	    byte[] arr;
	    if(cnv != null){
	        cnv.ucnv_getSubstChars(subBytes,len,status);
	        if(ErrorCode.isSuccess(status[0])){
	        	arr = new byte[len[0]];
	        	System.arraycopy(subBytes,0,arr,0,len[0]);
	        	return arr;				
	        }
	    }
	    return new byte[0];
	}
    /**
     * Ascertains if a given Unicode code unit can 
     * be converted to the target encoding
	 * @param converterHandle Address of converter object created by the native code
     * @param  codeUnit the character to be converted
     * @return true if a character can be converted
     * @internal ICU 2.4
     * 
     */
    public static final boolean canEncode(/*long*/UConverter converterHandle,int codeUnit)
	{
		int[] errorCode = {ErrorCode.U_ZERO_ERROR};
		if(converterHandle != null) {
			char source[] = new char[3];
			int[] mySource = {0};
			int sourceLimit = (codeUnit < 0x010000)? 1 : 2;
			byte target[] = new byte[5];
			int[] myTarget = {0};
			int targetLimit = 4;
			int[] i = {0};
	
			UConverterUTF16.U16_APPEND(source, i, 2, codeUnit, null);
			converterHandle.ucnv_fromUnicode(target, myTarget, targetLimit, source, mySource, sourceLimit, /*null,*/ true, errorCode);
	
			if(ErrorCode.isSuccess(errorCode[0])) {
				return true;
			}
		}
		return false;
	}
    
    /**
     * Ascertains if a given a byte sequence can be converted to Unicode
	 * @param converterHandle Address of converter object created by the native code
     * @param  bytes the bytes to be converted
     * @return true if a character can be converted
     * @internal ICU 2.4
     * 
     */
    public static final boolean canDecode(/*long*/UConverter converterHandle,byte[] bytes)
	{
	    int[] errorCode = {ErrorCode.U_ZERO_ERROR};
	    UConverter cnv = converterHandle;
	    if(cnv != null){
	        int len = bytes.length;
					byte[] cSource = bytes;
	        if(cSource != null){
	            int cSourceLimit = len;
	
	            /* Assume that we need at most twice the length of source */
							char[] target = new char[2*len];
							int[] targetBegin = {0};
	            int targetLimit = 2*len;
							int[] cSourceBegin = {0};
	
	                converterHandle.ucnv_toUnicode(target, targetBegin, targetLimit, 
	                               cSource, cSourceBegin,
	                               cSourceLimit,/*null,*/ true,errorCode);
	
	                if(ErrorCode.isSuccess(errorCode[0])){
										return true;
	                }
	        }
	    }
			return false;
	}
    
    /**
     * Gets the number of converters installed in the current installation of ICU
     * @return int number of converters installed
     * @internal ICU 2.4
     */
    public static final int countAvailable()
	{
		return UConverter.ucnv_countAvailable();
	}
    
    /**
     * Gets the canonical names of available converters 
     * @return Object[] names as an object array
     * @internal ICU 2.4
     */
    public static final String[] getAvailable()
	{
    	int num = UConverter.ucnv_countAvailable();
    	int[] error = {ErrorCode.U_ZERO_ERROR};
    	String name = null;
    	char[] canonicalName = new char[256];
    	canonicalName[0] = 0;
    	String[] ret = new String[num];
    
	    for(int i=0;i<num;i++) {
	        name = UConverter.ucnv_getAvailableName(i);
	        ret[i] = getJavaCanonicalName(name, 256, error);   
		}
	
		return ret;
	}
    
    /**
     * Gets the number of aliases for a converter name
     * @param enc encoding name
     * @return number of aliases for the converter
     * @internal ICU 2.4
     */
    public static final int countAliases(String enc)
	{
		int num = 0;
		int[] error = {ErrorCode.U_ZERO_ERROR};
	
		if(enc != null)
			num = UConverterAlias.ucnv_countAliases(enc, error);
		return num;
	}
    
    /** 
     * Gets the aliases associated with the converter name
     * @param encName converter name
     * @return converter names as elements in an object array
     * @internal ICU 2.4
     */
    public static final String[] getAliases(String encName)
	{
	    String[] ret = null;
	    int aliasNum = 0;
	    int[] error = {ErrorCode.U_ZERO_ERROR};
	    int i=0;
	    int j=0;
	    String aliasArray[/*50*/] = new String[50];
	
	    if(encName != null){
	        aliasNum = UConverterAlias.ucnv_countAliases(encName,error);
	        if(ErrorCode.isSuccess(error[0])){
	            for(i=0,j=0;i<aliasNum;i++){
	                String name = UConverterAlias.ucnv_getAlias(encName,i,error);
	                if(name.indexOf('+')==-1 && name.indexOf(',')==-1){
	                    aliasArray[j++]= name;
	                }
	            }
							ret = new String[j];
	            for(;--j>=0;) {
								ret[j] = aliasArray[j];
	            }
	        }            
	    }
	    return (ret);
	
	}
    
    /**
     * Gets the canonical name of the converter
     * @param enc converter name
     * @return canonical name of the converter
     * @internal ICU 2.4
     */
    public static final String getCanonicalName(String enc)
	{
		int[] error = {ErrorCode.U_ZERO_ERROR};
		String canonicalName = "";
		String ret = null;
	
		if(enc != null){
			canonicalName = UConverterAlias.ucnv_getAlias(enc,0,error);
			if(canonicalName!=null && canonicalName.indexOf(",") != -1){
				canonicalName = UConverterAlias.ucnv_getAlias(canonicalName,1,error);
			}
			ret = canonicalName;
		}
		return ret;	
	}
    
    /**
     * Gets the canonical name of the converter as defined by Java
     * @param enc converter name
     * @return canonical name of the converter
     * @internal ICU 3.4
     */
    public static final String getICUCanonicalName(String enc){
    	int errorCode[] = {ErrorCode.U_ZERO_ERROR};
        String canonicalName = null;
        String ret = null;
        
        if(enc!=null){
            if((canonicalName = UConverterAlias.ucnv_getCanonicalName(enc, "MIME", errorCode))!=null){
                ret = canonicalName;
            }else if((canonicalName = UConverterAlias.ucnv_getCanonicalName(enc, "IANA", errorCode))!=null){
                ret = canonicalName;
            }else if((canonicalName = UConverterAlias.ucnv_getCanonicalName(enc, "", errorCode))!=null){
                ret = canonicalName;
            }else if((canonicalName = UConverterAlias.ucnv_getAlias(enc, 0, errorCode))!=null){
                /* we have some aliases in the form x-blah .. match those first */
                ret = canonicalName;
            }else if(enc.indexOf("x-")==0){
                /* TODO: Match with getJavaCanonicalName method */
                /*
                char temp[ UCNV_MAX_CONVERTER_NAME_LENGTH] = {0};
                strcpy(temp, encName+2);
                */
                ret = enc.substring(2);
            }else{
                /* unsupported encoding */
               ret = "";
            }
        }
        return ret;    	
    }
      
    /**
     * Gets the canonical name of the converter as defined by Java
     * @param icuCanonicalName converter name
     * @return canonical name of the converter
     * @internal ICU 3.4
     */
    public static final String getJavaCanonicalName(String icuCanonicalName){
    	/*
    	 If a charset listed in the IANA Charset Registry is supported by an implementation 
    	 of the Java platform then its canonical name must be the name listed in the registry. 
    	 Many charsets are given more than one name in the registry, in which case the registry 
    	 identifies one of the names as MIME-preferred. If a charset has more than one registry 
    	 name then its canonical name must be the MIME-preferred name and the other names in 
    	 the registry must be valid aliases. If a supported charset is not listed in the IANA 
    	 registry then its canonical name must begin with one of the strings "X-" or "x-".
    	 */
    	int errorCode[] = {ErrorCode.U_ZERO_ERROR};
        String ret = null;
	    if(icuCanonicalName!=null && icuCanonicalName.charAt(0) != 0){
	        ret = getJavaCanonicalName(icuCanonicalName, UConverter.UCNV_MAX_CONVERTER_NAME_LENGTH, errorCode);
	    }	    
	    return ret;    	
    }    
    
	/*int32_t getJavaCanonicalName(const char* icuCanonicalName, char* canonicalName, int32_t capacity, 
                     UErrorCode* status){*/
	private static String getJavaCanonicalName(String icuCanonicalName, int capacity, int[] status){
		/*
		If a charset listed in the IANA Charset Registry is supported by an implementation 
		of the Java platform then its canonical name must be the name listed in the registry. 
		Many charsets are given more than one name in the registry, in which case the registry 
		identifies one of the names as MIME-preferred. If a charset has more than one registry 
		name then its canonical name must be the MIME-preferred name and the other names in 
		the registry must be valid aliases. If a supported charset is not listed in the IANA 
		registry then its canonical name must begin with one of the strings "X-" or "x-".
		*/
		String cName = null;
        /* find out the alias with MIME tag */
        if((cName=UConverter.ucnv_getStandardName(icuCanonicalName, "MIME", status))!=null){
        /* find out the alias with IANA tag */
        }else if((cName=UConverter.ucnv_getStandardName(icuCanonicalName, "IANA", status))!=null){
        }else {
            /*  
                check to see if an alias already exists with x- prefix, if yes then 
                make that the canonical name
            */
            int aliasNum = UConverterAlias.ucnv_countAliases(icuCanonicalName,status);
            String name;
            for(int i=0;i<aliasNum;i++){
                name = UConverterAlias.ucnv_getAlias(icuCanonicalName, i, status);
                if(name!=null && name.indexOf("x-")==0){
                    cName = name;
                    break;
                }
            }
            /* last resort just append x- to any of the alias and 
                make it the canonical name */
            if((cName==null || cName.length()==0) && ErrorCode.isSuccess(status[0])){
                name = UConverter.ucnv_getStandardName(icuCanonicalName, "UTR22", status);
                if(name==null && icuCanonicalName.indexOf(",")!=-1){
                    name = UConverterAlias.ucnv_getAlias(icuCanonicalName, 1, status);
                    if(status[0] == ErrorCode.U_INDEX_OUTOFBOUNDS_ERROR){
                        status[0] = ErrorCode.U_ZERO_ERROR;
                    }
                }
                /* if there is no UTR22 canonical name .. then just return itself*/
                if(name==null){
                    name = icuCanonicalName;
                }
                if(capacity >= 2){
                    cName = "x-";
                }
                cName += name;
            }
        }
        return cName;
    }
    
    /**
     * Sets the callback to Unicode for ICU conveter. The default behaviour of ICU callback
     * is to call the specified callback function for both illegal and unmapped sequences.
     * @param converterHandle Adress of the converter object created by native code
     * @param mode call back mode to set. This is either STOP_CALLBACK, SKIP_CALLBACK or SUBSTITUE_CALLBACK
     *        The converter performs the specified callback when an error occurs
     * @param stopOnIllegal If true sets the alerts the converter callback to stop on an illegal sequence
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */
    public static final int setCallbackDecode(/*long*/UConverter converterHandle, int mode, boolean stopOnIllegal)
	{
		UConverter conv = converterHandle;
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
	    if(conv != null){
	        
	    	UConverterCallback.UConverterToUCallback[] toUOldAction = new UConverterCallback.UConverterToUCallback[1];
	        byte[][] toUOldContext = new byte[1][];
	        byte[] toUNewContext=null;
	        UConverterCallback.UConverterToUCallback newAction;
	
	        switch(mode){
	        default: /* falls through */
	        case STOP_CALLBACK:
	           newAction  = new UConverterCallback.UCNV_TO_U_CALLBACK_STOP();
	           break;
	        case SKIP_CALLBACK:
	            newAction = new UConverterCallback.UCNV_TO_U_CALLBACK_SKIP() ;
	            
	            if(stopOnIllegal==true){
	                toUNewContext = UConverter.UCNV_SUB_STOP_ON_ILLEGAL;
	            }
	            
	            break;
	        case SUBSTITUTE_CALLBACK:
	            return setToUCallbackSubs(conv,null,0,stopOnIllegal);
	            
	        }
	
	        conv.ucnv_setToUCallBack(newAction, toUNewContext, toUOldAction, toUOldContext, errorCode);
	
	        return errorCode[0];
	    }
	    errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
	    return errorCode[0];
	}
   
    /**
     * Sets the callback from Unicode for ICU conveter. The default behaviour of ICU callback
     * is to call the specified callback function for both illegal and unmapped sequences.
     * @param converterHandle Adress of the converter object created by native code
     * @param mode call back mode to set. This is either STOP_CALLBACK, SKIP_CALLBACK or SUBSTITUE_CALLBACK
     *        The converter performs the specified callback when an error occurs
     * @param stopOnIllegal If true sets the alerts the converter callback to stop on an illegal sequence
     * @return int error code returned by ICU
     * @internal ICU 2.4
     */
    public static final int setCallbackEncode(/*long*/UConverter converterHandle, int mode, boolean stopOnIllegal)
	{
	    UConverter conv = converterHandle;
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
	
	    if(conv != null){
	        
	    	UConverterCallback.UConverterFromUCallback[] fromUOldAction = new UConverterCallback.UConverterFromUCallback[1];
	        byte[][] fromUOldContext = new byte[1][];
	        byte[] fromUNewContext=null;
	        UConverterCallback.UConverterFromUCallback newAction;
	        switch(mode){
	        default: /* falls through */
	        case STOP_CALLBACK:
	           newAction  = new UConverterCallback.UCNV_FROM_U_CALLBACK_STOP();
	           break;
	        case SKIP_CALLBACK:
	            newAction = new UConverterCallback.UCNV_FROM_U_CALLBACK_SKIP();
	            if(stopOnIllegal==true){
	                fromUNewContext = UConverter.UCNV_SUB_STOP_ON_ILLEGAL;
	            }
	            break;
	        case SUBSTITUTE_CALLBACK:
	            newAction = new UConverterCallback.UCNV_FROM_U_CALLBACK_SUBSTITUTE();
	            if(stopOnIllegal==true){
	                fromUNewContext = UConverter.UCNV_SUB_STOP_ON_ILLEGAL;
	            }
	            break;
	        }
	
	        conv.ucnv_setFromUCallBack(newAction, fromUNewContext, fromUOldAction, fromUOldContext, errorCode);
	
	        return errorCode[0];
	    }
	    errorCode[0] = ErrorCode.U_ILLEGAL_ARGUMENT_ERROR;
		return errorCode[0];
	}
    
	public static boolean isValidSubstitutionBytes(String enc, byte[] sub)
	{
		boolean isvalid = false;
		int err[] = {ErrorCode.U_ZERO_ERROR};
		UConverter cnv = UConverter.ucnv_open(enc, err);
		if(cnv != null) {
			err[0] = ErrorCode.U_ZERO_ERROR;
			cnv.ucnv_isValidSubstChars(sub, err);
			if(ErrorCode.isSuccess(err[0]))
					isvalid = true;
		}
		return isvalid;
	}

    /**
     * Returns a thread safe clone of the converter
     * @internal ICU 2.4
     */
    public static final int safeClone(/*long*/UConverter converterHandle,/*long*/UConverter[] handleArr)
	{
		int errorCode[] = {ErrorCode.U_ZERO_ERROR};
		//agljport:fix implement this
		return errorCode[0];
	}
    
    /** @internal ICU 2.4 */
    public static final int STOP_CALLBACK = 0;
    /** @internal ICU 2.4 */
    public static final int SKIP_CALLBACK = 1;
    /** @internal ICU 2.4 */
    public static final int SUBSTITUTE_CALLBACK = 3;

}
